for %%G in (*.sql) do sqlcmd /S vwmazdvebtsq02 /D EBT-E -i"%%G"
pause
