package com.ebtedge.fns.gateway.views.redesearch;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import com.ebtedge.fns.gateway.util.*;
import org.vaadin.lineawesome.LineAwesomeIconUrl;

import com.ebtedge.fns.gateway.config.GatAppConfig;
import com.ebtedge.fns.gateway.decorators.RedeSearchRequestDecorator;
import com.ebtedge.fns.gateway.decorators.RedeSearchRespDecorator;
import com.ebtedge.fns.gateway.decorators.RedeStatusUpdateDecorator;
import com.ebtedge.fns.gateway.dialogs.RedeStatusUpdateDialog;
import com.ebtedge.fns.gateway.forms.RedeSearchForm;
import com.ebtedge.fns.gateway.initializers.RedeSearchGridInitializer;
import com.ebtedge.fns.gateway.model.RedeGridVO;
import com.ebtedge.fns.gateway.model.RedeSearchCriteria;
import com.ebtedge.fns.gateway.model.RedeStatusUpdateRequest;
import com.ebtedge.fns.gateway.model.RedeSummaryGridSort;
import com.ebtedge.fns.gateway.security.CurrentUserAccess;
import com.ebtedge.fns.gateway.util.PredefinedTitleProvider.PredefinedTitlePdfFormat;
import com.ebtedge.yb.criteria.RedeSearchCriteriaQuery;
import com.ebtedge.yb.criteria.RedeStatusUpdateCriteriaQuery;
import com.ebtedge.yb.entity.RedeSearchResp;
import com.ebtedge.yb.service.GatService;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.notification.NotificationVariant;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import com.vaadin.flow.router.Menu;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.spring.annotation.UIScope;

import lombok.extern.slf4j.Slf4j;
import software.xdev.vaadin.grid_exporter.GridExportLocalizationConfig;
import software.xdev.vaadin.grid_exporter.GridExporter;

@PageTitle("REDE Comparison")
@Route(value = RouteUrls.REDE_SEARCH)
@Menu(order = 3, icon = LineAwesomeIconUrl.BALANCE_SCALE_SOLID)
@Slf4j
@UIScope
public class RedeSearchView extends VerticalLayout implements BeforeEnterObserver{

    private final Grid<RedeGridVO> grid = new Grid<>(RedeGridVO.class, false);
    private final GatService gatService;
    private final GatAppConfig gatAppConfig;
    private final Div totalRecordsDisplayDiv = new Div();
    private RedeSearchForm redeSearchForm;
    private int totalRecordCount = 0; // Store the total record count
    private RedeSearchCriteria searchResultsCriteria; // Store the search criteria used for the grid
    private final CurrentUserAccess currentUserAccess;

    public RedeSearchView(GatService gatService, GatAppConfig gatAppConfig, CurrentUserAccess currentUserAccess) {
        addClassNames("rede-summary-detail-view");

        this.gatService = gatService;
        this.gatAppConfig = gatAppConfig;
        this.currentUserAccess = currentUserAccess;
        initializeForm();
        setSizeFull();
        this.grid.setPageSize(Integer.parseInt(gatAppConfig.getGridInitialSize()));
        add(redeSearchForm, totalRecordsDisplayDiv, grid);
    }
    
    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        RedeSearchGridInitializer.initializeGrid(this.grid, this::openStatusUpdateDialog, this.currentUserAccess);
    }

    private void initializeForm() {
        totalRecordsDisplayDiv.addClassNames("rede-total-records-display-div");
        totalRecordsDisplayDiv.setVisible(false);
        redeSearchForm = new RedeSearchForm(getScoreTypes(),getRedeStatusList(), gatAppConfig.getDataRetentionDuration());
        redeSearchForm.addSearchEventListener(this::searchRede);
        redeSearchForm.addExportEventListener(event -> exportGridData());
        redeSearchForm.addClearEventListener(event -> {
            grid.setVisible(false);
            totalRecordsDisplayDiv.setVisible(false); // Hide the Total Record Count
            grid.setItems();
            totalRecordsDisplayDiv.removeAll(); // Clear the Total Record Count text
            grid.sort(null);
            searchResultsCriteria = null; // Reset the stored search criteria
            totalRecordCount = 0; // Reset the total record count
        });
        add(redeSearchForm);
    }


    private List<String> getScoreTypes() {
        return this.gatAppConfig
                .getScoreTypes()
                .stream()
                .sorted()
                .collect(Collectors.toList());
    }

    private List<String> getRedeStatusList() {
		return this.gatAppConfig.getRedeStatus().stream().map(String::trim)
				.sorted().collect(Collectors.toList());
	}

    /**
     * Perform REDE search
     *
     * @param event
     */

    /**
     * Perform REDE search
     *
     * @param event
     */
    private void searchRede(RedeSearchForm.SearchEvent event) {
        try {
            RedeSearchCriteria searchCriteria = event.getRedeSearchCriteria();
            this.searchResultsCriteria = searchCriteria.toExportCriteria();
            //creating array of List<RedeSearchResp> so we can update the list stored in the array
            final List<RedeSearchResp>[] cachedFirstPageData = new List[1];
            AtomicInteger counter = new AtomicInteger(1);
            this.grid.sort(null);
            
            this.grid.setItems(query -> {
                List<RedeSummaryGridSort> sortOrders = FormUtil.getRedeSummaryGridSortOrder(query);
                this.searchResultsCriteria.setGridSort(sortOrders);
                this.searchResultsCriteria.setSearchType("REDE SEARCH");
                RedeSearchCriteriaQuery redeSearchCriteriaQuery = RedeSearchRequestDecorator.toRedeSearchCriteria().apply(this.searchResultsCriteria);
                int offset = query.getOffset();
                int limit = query.getLimit();
                counter.set(offset + 1); // Updating the counter for row numbers

                // Checking if it's the first page and if the data is already cached
            	if(sortOrders.isEmpty()) {
	                if (offset == 0 && cachedFirstPageData[0] != null) {
	                    List<RedeSearchResp> redeSearchRespList = cachedFirstPageData[0];
	                    cachedFirstPageData[0] = null;
	
	                    return redeSearchRespList
	                            .stream()
	                            .map(resp -> {
	                                RedeGridVO vo = RedeSearchRespDecorator.toFinancialVO().apply(resp);
	                                vo.setRownumbers(counter.getAndIncrement());
	                                return vo;
	                            })
	                            .collect(Collectors.toList())
	                            .stream();
	                }
            	}
                redeSearchCriteriaQuery.setStartRow(Integer.toString(offset));
                redeSearchCriteriaQuery.setEndRow(Integer.toString(limit));
                if (offset != 0) {
                    redeSearchCriteriaQuery.setEndRow(Integer.toString(offset + Integer.parseInt(gatAppConfig.getGridInitialSize())));
                    redeSearchCriteriaQuery.setStartRow(Integer.toString(offset + 1));
                    redeSearchCriteriaQuery.setSearchType("REDE SEARCH NEXTSET");
                }
                
                if(sortOrders != null && !sortOrders.isEmpty()) {
                	redeSearchCriteriaQuery.setSearchType("REDE SEARCH SORT"); 
   				 }

                List<RedeSearchResp> redeSearchRespList = fetchRedeSearchData(redeSearchCriteriaQuery);
                if (redeSearchRespList != null && !redeSearchRespList.isEmpty()) {
                    totalRecordCount = Integer.parseInt(redeSearchRespList.get(0).getTotal_row_count());
                    totalRecordsDisplayDiv.removeAll();
                    totalRecordsDisplayDiv.add("Total Record Count: " + totalRecordCount);
                    totalRecordsDisplayDiv.setVisible(true);
                } else {
                    totalRecordCount = 0;
                    totalRecordsDisplayDiv.removeAll();
                    totalRecordsDisplayDiv.setVisible(false);
                }

                return redeSearchRespList.stream()
                        .map(resp -> {
                            RedeGridVO vo = RedeSearchRespDecorator.toFinancialVO().apply(resp);
                            vo.setRownumbers(counter.getAndIncrement());
                            return vo;
                        })
                        .collect(Collectors.toList())
                        .stream();
            }, query -> {
            	this.searchResultsCriteria.setSearchType("REDE SEARCH");
                RedeSearchCriteriaQuery redeSearchCriteriaQuery = RedeSearchRequestDecorator.toRedeSearchCriteria().apply(this.searchResultsCriteria);

                redeSearchCriteriaQuery.setStartRow("0");
                redeSearchCriteriaQuery.setEndRow(Integer.toString(Integer.parseInt(gatAppConfig.getGridInitialSize())));

                List<RedeSearchResp> redeSearchRespList = fetchRedeSearchData(redeSearchCriteriaQuery);
                if (redeSearchRespList != null && !redeSearchRespList.isEmpty()) {
                    cachedFirstPageData[0] = redeSearchRespList;
                    totalRecordsDisplayDiv.removeAll();
                    totalRecordCount = Integer.parseInt(redeSearchRespList.get(0).getTotal_row_count());
                    totalRecordsDisplayDiv.add("Total Record Count: " + totalRecordCount);
                    totalRecordsDisplayDiv.setVisible(true);
                    return totalRecordCount;
                } else {
                    totalRecordCount = 0; // Ensure total count is reset when no results
                    totalRecordsDisplayDiv.setVisible(false);
                    return 0;
                }
            });

            this.grid.setVisible(true);
        } catch (Exception e) {
            log.error("Error while fetching the data: {}", e);
            Notification notification = new Notification(e.getMessage(), 3000, Notification.Position.TOP_CENTER);
            notification.addThemeVariants(NotificationVariant.LUMO_ERROR);
            notification.open();
        }
    }


    private List<RedeSearchResp> fetchRedeSearchData(RedeSearchCriteriaQuery redeSearchCriteriaQuery) {
        if (!SessionUtil.isSessionValid()) {
            log.error("Session is invalid during fetchRedeSearchData. Redirecting to logout.");
            SessionUtil.invalidateSession();
            getUI().ifPresent(ui -> ui.getPage().setLocation(gatAppConfig.getLogoutUrl()));
            return List.of();
        }
        return gatService.redeSearch(redeSearchCriteriaQuery);
    }

    /**
     * Export grid data
     */
    private void exportGridData() {
        log.info("Export to Grid button clicked");

        int exportLimit = Integer.parseInt(gatAppConfig.getExportLimit());

        if (totalRecordCount > exportLimit) {
        	log.warn("Export limit exceeded. Record count: {}", totalRecordCount);
        	Notifications.showError("Export limit exceeded. You can only download up to " + exportLimit + " records.");
        } else if (totalRecordCount > 0) {
        	if (this.searchResultsCriteria == null) {
        		Notifications.showError("No search criteria found. Please perform a search before exporting.");
                return;
            }
        	 // Use the search results criteria for export, not the current form state
            RedeSearchCriteria searchCriteria = this.searchResultsCriteria.toExportCriteria();

            // Generate title
            String title = "REDE Comparison";

            // Generate date range
            String dateRange = "";
            if (searchCriteria.getStartDate() != null || searchCriteria.getEndDate() != null) {
                String startDate = searchCriteria.getStartDate() != null
                        ? searchCriteria.getStartDate().format(DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm"))
                        : "N/A";
                String endDate = searchCriteria.getEndDate() != null
                        ? searchCriteria.getEndDate().format(DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm"))
                        : "N/A";
                dateRange = getDateRangeText(startDate, endDate);
            }

            // Generate "Generated on" timestamp
            String generatedDate = getGeneratedOn();

            // Build search values dynamically
            StringBuilder searchValuesBuilder = new StringBuilder();
            if (searchCriteria.getTerminalId() != null && !searchCriteria.getTerminalId().isEmpty()) {
                searchValuesBuilder.append("Terminal ID: \"").append(searchCriteria.getTerminalId()).append("\"\n");
            }
            if (searchCriteria.getFnsNumber() != null && !searchCriteria.getFnsNumber().isEmpty()) {
                searchValuesBuilder.append("FNS Number: \"").append(searchCriteria.getFnsNumber()).append("\"\n");
            }
            if (searchCriteria.getStatus() != null && !searchCriteria.getStatus().isEmpty()) {
				searchValuesBuilder.append("Status: \"").append(searchCriteria.getStatus()).append("\"\n");
			}

            // Finalize search values
            String searchValues = searchValuesBuilder.toString().trim();

            // Generate dynamic file name
            String fileName = "RedeComparison_" +
                    DateTimeFormatter.ofPattern("yyyy_MM_dd_HH_mm").format(LocalDateTime.now(ZoneOffset.UTC));

            // Customize localization for the export wizard
            GridExportLocalizationConfig localizationConfig = new GridExportLocalizationConfig()
                    .with(GridExportLocalizationConfig.EXPORT_GRID, "Export Data");

            // Initialize the GridExporter with the custom localization and dynamic title
            GridExporter.newWithDefaults(grid)

                    .withLocalizationConfig(localizationConfig)
                    .withFileName(fileName) // Set the dynamic file name
                    .withColumnFilter(column -> !RedeSearchGridInitializer.isActionColumn(column))
                    .withAvailableFormats(
                            new PredefinedTitlePdfFormat(title, dateRange, generatedDate, searchValues)
                    )
                    .loadFromProvider(new PredefinedTitleProvider(title, dateRange, generatedDate, searchValues))
                    .open();
        } else {
        	log.warn("Grid is empty, nothing to export");
            Notifications.showError("Grid is empty, nothing to export");
        }
    }

    /**
     * Generate the "Generated on" timestamp.
     *
     * @return String
     */
    private String getGeneratedOn() {
        Calendar cal = Calendar.getInstance();
        String timestamp = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss ").format(cal.getTime());
        timestamp += cal.getTimeZone().getDisplayName(false, TimeZone.SHORT);
        return "Generated on: " + timestamp;
    }

    /**
     * Generate the date range string to display from the REDE search form.
     *
     * @param startDate Start date as a string
     * @param endDate   End date as a string
     * @return String
     */
    private String getDateRangeText(String startDate, String endDate) {
        return "Date Range: " + startDate + " - " + endDate;
    }
    

	/**
	 * Opens the status update dialog for a selected REDE entry
	 * 
	 * @param redeGridVO The REDE grid item to update
	 */
	private void openStatusUpdateDialog(RedeGridVO redeGridVO) {
		RedeStatusUpdateDialog dialog = new RedeStatusUpdateDialog(redeGridVO, getRedeStatusList());
		dialog.addSaveListener(event -> {
			RedeStatusUpdateRequest request = event.getRequest();

			RedeStatusUpdateCriteriaQuery query = RedeStatusUpdateDecorator.toStatusUpdateCriteria().apply(request);

			boolean success = gatService.updateRedeStatus(query);

			if (success) {
				Notifications.show("Status updated successfully.", NotificationVariant.LUMO_SUCCESS);
				if (redeSearchForm.getBinder().getBean() != null) {
					RedeSearchCriteria currentCriteria = redeSearchForm.getBinder().getBean();
					RedeSearchCriteria refreshCriteria = currentCriteria.toExportCriteria();
					refreshCriteria.setSearchType(currentCriteria.getSearchType());

					searchRede(new RedeSearchForm.SearchEvent(redeSearchForm, refreshCriteria));
				}
			} else {
				Notifications.showError("Failed to update status. Please try again.");
			}
		});

		dialog.open();
	}
}