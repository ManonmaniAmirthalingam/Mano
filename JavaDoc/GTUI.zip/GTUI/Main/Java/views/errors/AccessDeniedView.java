package com.ebtedge.fns.gateway.views.errors;

import com.ebtedge.fns.gateway.util.RouteUrls;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

/**
 * AccessDeniedView is a UI component displayed when the current user is denied access to a specific
 * page or resource.
 */
@Route(RouteUrls.ACCESS_DENIED)
@PageTitle("Access Denied")
public class AccessDeniedView extends VerticalLayout {

    public AccessDeniedView() {
        setSizeFull();
        setJustifyContentMode(JustifyContentMode.CENTER);
        setAlignItems(Alignment.CENTER);
        addClassName("access-denied-view");

        Icon warningIcon = VaadinIcon.LOCK.create();
        warningIcon.setSize("64px");
        warningIcon.setColor("#D32F2F");

        H1 title = new H1("Access Denied");
        title.getStyle().setColor("#D32F2F");

        Paragraph message = new Paragraph("You don't have permission to access this page.");

        add(warningIcon, title, message);
    }
}
