package com.ebtedge.fns.gateway.views.alerts;

import com.ebtedge.fns.gateway.model.AlertSummaryVO;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.contextmenu.GridContextMenu;
import com.vaadin.flow.component.grid.contextmenu.GridMenuItem;
import com.vaadin.flow.component.grid.contextmenu.GridSubMenu;
import com.vaadin.flow.component.html.Hr;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.theme.lumo.LumoUtility;

import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.experimental.UtilityClass;

@UtilityClass
public class AlertsSearchGridContextMenuBuilder {

	private static final String MENU_ITEM_CLASS = "grid-context-menu-item";
    private static final String CONTEXT_MENU_CLASS = "tran-search-grid-context-menu";
    
	 public void build(Grid<AlertSummaryVO> grid,ComponentEventListener<GridContextMenu.GridContextMenuItemClickEvent<AlertSummaryVO>> clickListener) {
	        MenuConfiguration config =
	                MenuConfiguration.builder()
	                        .grid(grid)
	                        .clickListener(clickListener)
	                        .build();

	        GridContextMenu<AlertSummaryVO> contextMenu = createBaseMenu(config.getGrid());
	        buildSearchMenu(contextMenu, config);
	        contextMenu.add(new Hr());
	       
	    }
	    
	    private static GridMenuItem<AlertSummaryVO> addMenuItem(
	            GridContextMenu<AlertSummaryVO> menu,
	            ContextMenuItemDef item,
	            boolean enabled,
	            ComponentEventListener<GridContextMenu.GridContextMenuItemClickEvent<AlertSummaryVO>>
	                    listener) {
	        GridMenuItem<AlertSummaryVO> menuItem = menu.addItem(item.getText());
	        configureMenuItem(menuItem, item, enabled, listener);
	        return menuItem;
	    }

	    private static GridMenuItem<AlertSummaryVO> addMenuItem(
	            GridSubMenu<AlertSummaryVO> menu,
	            ContextMenuItemDef item,
	            boolean enabled,
	            ComponentEventListener<GridContextMenu.GridContextMenuItemClickEvent<AlertSummaryVO>>
	                    listener) {
	        GridMenuItem<AlertSummaryVO> menuItem = menu.addItem(item.getText());
	        configureMenuItem(menuItem, item, enabled, listener);
	        return menuItem;
	    }
	    
	    private static void configureMenuItem(
	            GridMenuItem<AlertSummaryVO> menuItem,
	            ContextMenuItemDef item,
	            boolean enabled,
	            ComponentEventListener<GridContextMenu.GridContextMenuItemClickEvent<AlertSummaryVO>>
	                    listener) {
	        menuItem.addMenuItemClickListener(listener);
	        menuItem.addClassNames(MENU_ITEM_CLASS, LumoUtility.FontSize.XSMALL);
	        menuItem.setEnabled(enabled);
	        if (item.getIcon() != null) {
	            menuItem.addComponentAsFirst(item.getIcon().create());
	        }
	    }
	    
	    
	    private static void buildSearchMenu(
	            GridContextMenu<AlertSummaryVO> contextMenu, MenuConfiguration config) {
	        GridMenuItem<AlertSummaryVO> searchMenu =
	                addMenuItem(
	                        contextMenu, ContextMenuItemDef.SEARCH, true, config.getClickListener());
	        GridSubMenu<AlertSummaryVO> subMenu = searchMenu.getSubMenu();
	        addMenuItem(subMenu, ContextMenuItemDef.SEARCH_BY_CARD, true, config.getClickListener());
	        addMenuItem(
	                subMenu, ContextMenuItemDef.SEARCH_BY_TERMINAL, true, config.getClickListener());
	        addMenuItem(
	                subMenu, ContextMenuItemDef.SEARCH_BY_FNS_NUMBER, true, config.getClickListener());
	    }

	    

	    private static GridContextMenu<AlertSummaryVO> createBaseMenu(Grid<AlertSummaryVO> grid) {
	        GridContextMenu<AlertSummaryVO> menu = grid.addContextMenu();
	        menu.addClassName(CONTEXT_MENU_CLASS);
	        return menu;
	    }
	    
	    @Getter
	    @RequiredArgsConstructor
	    public enum ContextMenuItemDef {
	        SEARCH("Transaction Search", VaadinIcon.SEARCH),
	        SEARCH_BY_CARD("By Card Number", null),
	        SEARCH_BY_TERMINAL("By Terminal ID", null),
	        SEARCH_BY_FNS_NUMBER("By FNS Number", null);
	      
	        private final String text;
	        private final VaadinIcon icon;

	        public static ContextMenuItemDef fromLabel(String label) {
	            for (ContextMenuItemDef item : values()) {
	                if (item.getText().equals(label)) {
	                    return item;
	                }
	            }
	            throw new IllegalArgumentException("Unknown menu item: " + label);
	        }
	    }

	    
	    @Getter
	    @Builder
	    private static class MenuConfiguration {
	        private final Grid<AlertSummaryVO> grid;
	        private final ComponentEventListener<GridContextMenu.GridContextMenuItemClickEvent<AlertSummaryVO>> clickListener;
	    }
}
