package com.ebtedge.fns.gateway.views.alerts;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import com.ebtedge.fns.gateway.util.*;
import org.vaadin.lineawesome.LineAwesomeIconUrl;
import com.ebtedge.fns.gateway.config.GatAppConfig;
import com.ebtedge.fns.gateway.decorators.AlertSummaryReqDecorator;
import com.ebtedge.fns.gateway.decorators.AlertSummaryRespDecorator;
import com.ebtedge.fns.gateway.forms.AlertSummaryForm;
import com.ebtedge.fns.gateway.initializers.AlertSummaryInitializer;
import com.ebtedge.fns.gateway.model.AlertSearchCriteria;
import com.ebtedge.fns.gateway.model.AlertSummaryGridSort;
import com.ebtedge.fns.gateway.model.AlertSummaryVO;
import com.ebtedge.fns.gateway.util.PredefinedTitleProvider.PredefinedTitlePdfFormat;
import com.ebtedge.yb.criteria.AlertSummaryCriteria;
import com.ebtedge.yb.entity.AlertSummaryResp;
import com.ebtedge.yb.service.GatService;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.contextmenu.GridContextMenu;
import com.vaadin.flow.component.grid.contextmenu.GridMenuItem;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.*;
import com.vaadin.flow.spring.annotation.UIScope;
import com.vaadin.flow.theme.lumo.LumoUtility;
import jakarta.annotation.security.PermitAll;
import lombok.extern.slf4j.Slf4j;
import software.xdev.vaadin.grid_exporter.GridExportLocalizationConfig;
import software.xdev.vaadin.grid_exporter.GridExporter;

@PageTitle("Alerts")
@Route(RouteUrls.ALERTS)
@Menu(order = 4, icon = LineAwesomeIconUrl.BELL_SOLID)
@PermitAll
@Slf4j
@UIScope
public class AlertsView extends VerticalLayout implements BeforeEnterObserver {

    private final Grid<AlertSummaryVO> grid = new Grid<>(AlertSummaryVO.class, false);
    private final GatService gatService;
    private final GatAppConfig gatAppConfig;
    private final AlertSummaryForm alertSummaryForm;
    Div totalRecordsDisplayDiv = new Div();
    private int totalCount = 0; // Store the total record count
    private AlertSearchCriteria searchResultsCriteria; // search results criteria used for the grid

    /**
     * Callback executed before navigation to attaching Component chain is made.
     *
     * @param event before navigation event with event details
     */
    @Override
    public void beforeEnter(BeforeEnterEvent event) {
    	 setupGridContextMenu();
    }

    public AlertsView(GatService gatService, GatAppConfig gatAppConfig) {
        this.alertSummaryForm = alertSummaryForm(gatAppConfig);
        addClassNames("alert-summary-view");
        this.gatAppConfig = gatAppConfig;
        this.gatService = gatService;
        setSizeFull();
        this.grid.setPageSize(Integer.parseInt(gatAppConfig.getGridInitialSize()));
        totalRecordsDisplayDiv.addClassNames("alert-total-records-display-div");
        totalRecordsDisplayDiv.setVisible(true);
        AlertSummaryInitializer.initializeGrid(grid);
        add(alertSummaryForm, totalRecordsDisplayDiv, grid);
        setFlexGrow(1, grid);
    }

    private void setupGridContextMenu() {
    	AlertsSearchGridContextMenuBuilder.build(grid, this::handleContextMenuItemClick);
    }

    private void handleContextMenuItemClick(
            GridContextMenu.GridContextMenuItemClickEvent<AlertSummaryVO> event) {
    	AlertSummaryVO selectedItem = event.getItem().orElse(null);
        var menuItemDef =
        		AlertsSearchGridContextMenuBuilder.ContextMenuItemDef.fromLabel(
                        event.getSource().getText());
        if (selectedItem == null) {
            log.warn(
                    "Selected item is null. Cannot perform click action on context menu item {}.",
                    event.getSource().getText());
            return;
        }
        handleMenuItemAction(menuItemDef, selectedItem, event.getSource());
    }

    private void handleMenuItemAction(
    		AlertsSearchGridContextMenuBuilder.ContextMenuItemDef menuItemDef,
           AlertSummaryVO selectedItem,
            GridMenuItem<AlertSummaryVO> source) {
    	String cardNumber;
    	String terminalId;
    	String fnsNumber;
    	
        switch (menuItemDef) {
            case SEARCH_BY_CARD -> {
	            cardNumber = selectedItem.getCardNumber(); 
	            QueryParameters params = QueryParameters.simple(Map.of("cardNumber", cardNumber));
	            UI.getCurrent().navigate("/transaction/search/", params);
            }
            case SEARCH_BY_TERMINAL ->
            {
	            terminalId = selectedItem.getTerminalId(); 
	            QueryParameters params = QueryParameters.simple(Map.of("terminalId", terminalId));
	            UI.getCurrent().navigate("/transaction/search/", params);
            }
           
            case SEARCH_BY_FNS_NUMBER ->
            {
	            fnsNumber = selectedItem.getFnsNumber(); 
	            QueryParameters params = QueryParameters.simple(Map.of("fnsNumber", fnsNumber));
	            UI.getCurrent().navigate("/transaction/search/", params);
            }
          
            
            default -> log.info("Context menu item clicked: {}", source.getText());
        }
    }
    private AlertSummaryForm alertSummaryForm(GatAppConfig gatAppConfig) {
        List<String> ruleNames = gatAppConfig.getRuleNames().stream().sorted().toList();
        AlertSummaryForm alertSummaryForm = new AlertSummaryForm(ruleNames, gatAppConfig.getDataRetentionDuration());
        alertSummaryForm.addSearchEventListener(this::alertSearchSummaryForm);
        alertSummaryForm.addExportEventListener(event -> exportAlertSummaryData());
        alertSummaryForm.addClearGridEventListener(e -> clearGrid());
        return alertSummaryForm;
    }

    private void clearGrid() {
        totalRecordsDisplayDiv.removeAll(); // Clear the total count display div
        grid.setItems(); // Clear the grid's data provider
        grid.setVisible(false);
        grid.sort(null);
        searchResultsCriteria = null; // Reset the stored search criteria
        totalCount = 0; // Reset the total record count
    }

    /**
     * This method is called when the search button is clicked in the AlertSummaryForm.
     *
     * @param event
     */
    private void alertSearchSummaryForm(AlertSummaryForm.SearchEvent event) {
        try {
            AlertSearchCriteria searchCriteria = event.getAlertSearchCriteria();
            this.searchResultsCriteria = searchCriteria.toExportCriteria();
            //creating array of List<AlertSummaryResp> so we can update the list stored in the array
            final List<AlertSummaryResp>[] cachedFirstPageData = new List[1];
            AtomicInteger counter = new AtomicInteger(1);
            this.grid.sort(null);
            
            this.grid.setItems(query -> {
                List<AlertSummaryGridSort> sortOrders =  FormUtil.getAlertSummaryGridSortOrder(query);
                this.searchResultsCriteria.setGridSort(sortOrders);
                this.searchResultsCriteria.setSearchType("ALERT DETAILS SEARCH");
                AlertSummaryCriteria alertSummaryCriteria = AlertSummaryReqDecorator.toAlertSearchCriteria().apply(this.searchResultsCriteria);
                int offset = query.getOffset();
                int limit = query.getLimit();
                counter.set(offset + 1); // Updating the counter for row numbers

                // Checking if it's the first page and if the data is already cached
				if(sortOrders.isEmpty()) {
	                if (offset == 0 && cachedFirstPageData[0] != null) {
	                    List<AlertSummaryResp> alertSummaryRespList = cachedFirstPageData[0];
	                    cachedFirstPageData[0] = null;
	
	                    return alertSummaryRespList
	                            .stream()
	                            .filter(resp -> resp.getAlertid() != null) // Filter out null alert IDs
	                            .map(alertSummaryResp -> {
	                                AlertSummaryVO vo = AlertSummaryRespDecorator.toAlertSummaryVO().apply(alertSummaryResp);
	                                vo.setRownumbers(counter.getAndIncrement());
	                                return vo;
	                            })
	                            .collect(Collectors.toList())
	                            .stream();
	                }
				}
                alertSummaryCriteria.setStartrow(Integer.toString(offset));
                alertSummaryCriteria.setEndrow(Integer.toString(limit));
                if (offset != 0) {
                    alertSummaryCriteria.setEndrow(Integer.toString(offset + Integer.parseInt(gatAppConfig.getGridInitialSize())));
                    alertSummaryCriteria.setStartrow(Integer.toString(offset + 1));
                    alertSummaryCriteria.setSearchtype("ALERT DETAILS SEARCH NEXTSET");
                }
				
				 if(sortOrders != null && !sortOrders.isEmpty()) {
				 	alertSummaryCriteria.setSearchtype("ALERT DETAILS SEARCH SORT"); 
				 }
				
                List<AlertSummaryResp> alertSummaryRespList = fetchAlertSummaryData(alertSummaryCriteria);
                if (alertSummaryRespList != null && !alertSummaryRespList.isEmpty()) {
                    totalCount = Integer.parseInt(alertSummaryRespList.get(0).getTotal_row_count());
                    totalRecordsDisplayDiv.removeAll();
                    totalRecordsDisplayDiv.add("Total Record Count: " + totalCount);
                    totalRecordsDisplayDiv.setVisible(true);
                } else {
                    totalCount = 0;
                    totalRecordsDisplayDiv.removeAll();
                    totalRecordsDisplayDiv.setVisible(false);
                }

                return alertSummaryRespList
                        .stream()
                        .filter(resp -> resp.getAlertid() != null) // Filter out null alert IDs
                        .map(alertSummaryResp -> {
                            AlertSummaryVO vo = AlertSummaryRespDecorator.toAlertSummaryVO().apply(alertSummaryResp);
                            vo.setRownumbers(counter.getAndIncrement());
                            return vo;
                        })
                        .collect(Collectors.toList())
                        .stream();
            }, query -> {
            	this.searchResultsCriteria.setSearchType("ALERT DETAILS SEARCH");
                AlertSummaryCriteria alertSummaryCriteria = AlertSummaryReqDecorator.toAlertSearchCriteria().apply(this.searchResultsCriteria);

                alertSummaryCriteria.setStartrow("0");
                alertSummaryCriteria.setEndrow(Integer.toString(Integer.parseInt(gatAppConfig.getGridInitialSize())));

                List<AlertSummaryResp> alertSummaryRespList = fetchAlertSummaryData(alertSummaryCriteria);
                if (alertSummaryRespList != null && !alertSummaryRespList.isEmpty()) {
                    cachedFirstPageData[0] = alertSummaryRespList;
                    totalRecordsDisplayDiv.removeAll();
                    totalCount = Integer.parseInt(alertSummaryRespList.get(0).getTotal_row_count());
                    totalRecordsDisplayDiv.add("Total Record Count: " + totalCount);
                    totalRecordsDisplayDiv.setVisible(true);
                    return totalCount;
                } else {
                	totalCount = 0; // Ensure total count is reset when no results
                    totalRecordsDisplayDiv.setVisible(false);
                    return 0;
                }
            });

            this.grid.setVisible(true);
        } catch (Exception e) {
            log.error("Error while fetching the data: {}", e);
            Notifications.showError(e.getMessage());
        }
    }

    private List<AlertSummaryResp> fetchAlertSummaryData(AlertSummaryCriteria alertSummaryCriteria) {
        if (!SessionUtil.isSessionValid()) {
            log.error("Session is invalid during fetchAlertSummaryData. Redirecting to logout.");
            SessionUtil.invalidateSession();
            getUI().ifPresent(ui -> ui.getPage().setLocation(gatAppConfig.getLogoutUrl()));
            return List.of();
        }
        return gatService.alertSummarySearch(alertSummaryCriteria);
    }

    private Div createSearchAndSummaryLayout() {

        Div searchAndSumDiv = new Div();
        searchAndSumDiv.addClassNames(LumoUtility.Padding.Left.MEDIUM);

        Div summaryDiv = new Div();
        summaryDiv.setSizeFull();
        summaryDiv.add(this.grid);
        summaryDiv.addClassNames(LumoUtility.Padding.Left.SMALL);

        searchAndSumDiv.add(alertSummaryForm);
        searchAndSumDiv.add(summaryDiv);

        return searchAndSumDiv;

    }

    /**
     * Initializes grid empty state
     *
     * @param grid
     */
    private static void setGridEmptyState(Grid<AlertSummaryVO> grid) {
        Div emptyGrid = new Div();
        emptyGrid.add("***** No data present for the given search criteria *****");
        emptyGrid.addClassNames("empty-grid");
        grid.setEmptyStateComponent(emptyGrid);
    }


    private void exportAlertSummaryData() {
        log.info("Export button clicked for Alert Summary");

        int exportLimit = Integer.parseInt(gatAppConfig.getExportLimit());

        if (totalCount > exportLimit) {
        	log.warn("Export limit exceeded. Record count: {}", totalCount);
        	Notifications.showError("Export limit exceeded. You can only download up to " + exportLimit + " records.");
        } else if (totalCount > 0) {
        	// Ensure SearchResultsCriteria is available
            if (this.searchResultsCriteria == null) {
            	Notifications.showError("No search criteria found. Please perform a search before exporting.");
                return;
            }           
            // Use the search results criteria for export, not the current form state
            AlertSearchCriteria searchCriteria = this.searchResultsCriteria.toExportCriteria();

            // Generate title
            String title = "Alert Summary";

            // Generate date range
            String dateRange = "";
            if (searchCriteria.getStartDate() != null || searchCriteria.getEndDate() != null) {
                String startDate = searchCriteria.getStartDate() != null
                        ? searchCriteria.getStartDate().toString()
                        : "N/A";
                String endDate = searchCriteria.getEndDate() != null
                        ? searchCriteria.getEndDate().toString()
                        : "N/A";
                dateRange = "Date Range: " + startDate + " - " + endDate;
            }

            // Generate "Generated on" timestamp
            String generatedDate = "Generated on: " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss"));

            // Build search values dynamically
            StringBuilder searchValuesBuilder = new StringBuilder();
            if (searchCriteria.getAlertId() != null && !searchCriteria.getAlertId().isEmpty()) {
                searchValuesBuilder.append("Alert ID: \"").append(searchCriteria.getAlertId()).append("\"\n");
            }
            if (searchCriteria.getCard() != null && !searchCriteria.getCard().isEmpty()) {
                searchValuesBuilder.append("Card Number: \"").append(searchCriteria.getCard()).append("\"\n");
            }

            // Finalize search values
            String searchValues = searchValuesBuilder.toString().trim();

            // Generate dynamic file name
            String fileName = "AlertSummary_" +
                    DateTimeFormatter.ofPattern("yyyy_MM_dd_HH_mm").format(LocalDateTime.now(ZoneOffset.UTC));

            // Customize localization for the export wizard
            GridExportLocalizationConfig localizationConfig = new GridExportLocalizationConfig()
                    .with(GridExportLocalizationConfig.EXPORT_GRID, "Export Data");

            // Initialize the GridExporter with the custom localization and dynamic title
            GridExporter.newWithDefaults(grid)
                    .withLocalizationConfig(localizationConfig)
                    .withFileName(fileName) // Set the dynamic file name
                    .withAvailableFormats(
                            new PredefinedTitlePdfFormat(title, dateRange, generatedDate, searchValues)
                    )
                    .loadFromProvider(new PredefinedTitleProvider(title, dateRange, generatedDate, searchValues))
                    .open();
        } else {
        	log.warn("Grid is empty, nothing to export");
            Notifications.showError("Grid is empty, nothing to export");
        }
    }

}
