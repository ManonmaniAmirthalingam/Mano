package com.ebtedge.fns.gateway.views.monitor;

import com.ebtedge.fns.gateway.components.DetailsDrawer;
import com.ebtedge.fns.gateway.components.LazyTabSheet;
import com.ebtedge.fns.gateway.config.GatAppConfig;
import com.ebtedge.fns.gateway.model.BaseShmGridVO;
import com.ebtedge.fns.gateway.service.ShmRuleMetaService;
import com.ebtedge.fns.gateway.util.RouteUrls;
import com.ebtedge.fns.gateway.views.monitor.autorefresh.AutoRefreshBar;
import com.ebtedge.fns.gateway.views.monitor.autorefresh.AutoRefreshOption;
import com.ebtedge.fns.gateway.views.monitor.event.EffectDateTimeRangeChangeEvent;
import com.ebtedge.fns.gateway.views.monitor.filters.ShmGlobalFilter;
import com.ebtedge.fns.gateway.views.monitor.tabs.content.AbstractShmTabContent;
import com.ebtedge.fns.gateway.views.monitor.tabs.content.AbstractShmTabGridContent;
import com.ebtedge.fns.gateway.views.monitor.tabs.ShmTabFactory;
import com.ebtedge.fns.gateway.views.monitor.tabs.content.ShmDashboardTabContent;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.DetachEvent;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.Main;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.select.Select;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.component.tabs.Tabs;
import com.vaadin.flow.data.selection.SelectionEvent;
import com.vaadin.flow.router.Menu;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Scope;
import org.vaadin.lineawesome.LineAwesomeIconUrl;

import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.LockSupport;

/**
 * Represents the primary view for the System Health Monitor (SHM) application, which is used to
 * monitor and manage system health information through various tabs and components.
 *
 * <p>This class is annotated with Vaadin-related annotations such as {@link Route} and {@link
 * PageTitle} for configuring browser navigation and page properties. It is also decorated with CSS
 * import statements for custom styling and a custom icon through the {@link Menu} annotation.
 *
 * <p>The ShmView class initializes and manages components like tabs, a global filter, an
 * auto-refresh mechanism, and a details drawer to handle detailed data views. It serves as a parent
 * container for managing dynamic content and user interactions in the SHM interface.
 */
@Slf4j
@Scope("vaadin-route")
@PageTitle("System Health")
@Route(RouteUrls.SYSTEM_HEALTH)
@Menu(title = "System Health", order = 5, icon = LineAwesomeIconUrl.STORE_ALT_SOLID)
@CssImport("themes/fns-gateway/components/system-health-monitor.css")
@SuppressWarnings("rawtypes")
public class ShmView extends Main {

    private final ScheduledExecutorService scheduler;
    private final ShmGlobalFilter globalFilter;
    private final ShmTabFactory tabFactory;
    private final GatAppConfig appConfig;
    private final UI ui;

    private Select<AutoRefreshOption> autoRefreshSelect;
    private DetailsDrawer<BaseShmGridVO> drawer;
    private ShmEffectiveDateTimeRangeSelect dateTimeRangeSelect;
    private Tabs tabs;
    private LazyTabSheet tabSheet;

    public ShmView(
            ShmTabFactory tabFactory,
            ShmGlobalFilter globalFilter,
            ShmRuleMetaService ruleMetaService,
            GatAppConfig appConfig) {

        this.tabFactory = tabFactory;
        this.globalFilter = globalFilter;
        this.appConfig = appConfig;
        this.ui = UI.getCurrent();

        this.scheduler = Executors.newScheduledThreadPool(1);

        setupView();
        createDrawer(ruleMetaService);
        add(drawer);
    }

    private void setupView() {
        addClassName("system-health-monitor");
        setSizeFull();
    }

    private void createDrawer(ShmRuleMetaService ruleMetaService) {
        drawer = new DetailsDrawer<>(createMainPanel(), new ShmDetailsPanel(ruleMetaService));
        drawer.addDetailsCloseListener(
                event -> {
                    if (tabs != null && tabs.getSelectedTab() != null) {
                        getTabContent(tabs.getSelectedTab())
                                .ifPresent(this::deselectGridItemsIfPossible);
                    }
                });
    }

    @Override
    protected void onDetach(DetachEvent detachEvent) {
        super.onDetach(detachEvent);
        cleanup();
    }

    private void cleanup() {
        scheduler.shutdown();
    }

    private Component createMainPanel() {
        VerticalLayout mainPanel = new VerticalLayout();
        mainPanel.setPadding(false);
        mainPanel.setSpacing(false);
        mainPanel.setSizeFull();

        ShmHeader header = createHeader();
        tabSheet = createMainPanelContent();

        mainPanel.add(header, tabSheet);
        return mainPanel;
    }

    private ShmHeader createHeader() {
        ShmHeader header = new ShmHeader(appConfig);
        dateTimeRangeSelect = header.getDateTimeRangeSelect();

        autoRefreshSelect = header.getAutoRefreshSelect();
        setupAutoRefresh(header.getAutoRefreshBar());
        dateTimeRangeSelect.addChangeListener(this::handleEffectiveTimeChange);

        return header;
    }

    private LazyTabSheet createMainPanelContent() {
        tabs = tabFactory.createTabs();
        LazyTabSheet tabSheet = new LazyTabSheet(tabs, this::createTabContent);
        tabSheet.setSizeFull();
        tabSheet.setSpacing(false);
        tabSheet.addSelectedChangeListener(this::handleTabChange);
        return tabSheet;
    }

    private void handleTabChange(LazyTabSheet.TabChangeEvent event) {
        drawer.hideDetails();
        getTabContent(event.getSelectedTab())
                .ifPresent(
                        tabContent -> {
                            deselectGridItemsIfPossible(tabContent);
                            if (tabContent instanceof ShmDashboardTabContent dashboardTabContent) {
                                dashboardTabContent.refresh();
                            }
                        });
    }

    private void deselectGridItemsIfPossible(AbstractShmTabContent content) {
        if (content instanceof AbstractShmTabGridContent gridContent) {
            gridContent.getGrid().deselectAll();
        }
    }

    private void handleEffectiveTimeChange(EffectDateTimeRangeChangeEvent event) {
        updateAutoRefreshOption(event);
        refreshTabContent();
    }

    private void updateAutoRefreshOption(EffectDateTimeRangeChangeEvent event) {
        if (autoRefreshSelect == null) {
            return;
        }
        if (event.getSource().isCustomRangeSelected()) {
            autoRefreshSelect.setValue(AutoRefreshOption.OFF);
        } else {
            if (autoRefreshSelect.getValue() == AutoRefreshOption.OFF) {
                autoRefreshSelect.setValue(ShmHeader.DEFAULT_AUTO_REFRESH_OPTION);
            }
        }
    }

    private void refreshTabContent() {
        if (canRefreshContent()) {
            getTabContent(tabs.getSelectedTab())
                    .ifPresent(
                            tabContent -> {
                                globalFilter.setTimeRange(dateTimeRangeSelect.getRange());
                                tabContent.refresh();
                            });
        }
    }

    private boolean canRefreshContent() {
        return tabs != null
                && dateTimeRangeSelect != null
                && getTabContent(tabs.getSelectedTab()).isPresent();
    }

    private AbstractShmTabContent createTabContent(Tab tab) {
        AbstractShmTabContent content = tabFactory.createTabContent(tab);
        if (content instanceof AbstractShmTabGridContent gridContent) {
            registerGridClickListener(gridContent);
        }
        return content;
    }

    private Optional<AbstractShmTabContent> getTabContent(Tab tab) {
        if (tabSheet.getTabContent(tab) instanceof AbstractShmTabContent content) {
            return Optional.of(content);
        }
        return Optional.empty();
    }

    private void setupAutoRefresh(AutoRefreshBar autoRefreshBar) {
        autoRefreshBar.addCooldownCompleteListener(
                event -> {
                    AtomicReference<CompletableFuture<Void>> future =
                            new AtomicReference<>(new CompletableFuture<>());
                    scheduler.execute(
                            () -> {
                                while (!future.get().isDone()) {
                                    /* Give it a second to show an updating UI indicator before starting a new cooldown immediately,
                                    doing this makes the UI look smoother */
                                    LockSupport.parkUntil(System.currentTimeMillis() + 1000);
                                }
                                if (ui.isAttached()) {
                                    ui.access(autoRefreshBar::startCooldown);
                                }
                            });
                    ui.access(this::refreshTabContent);
                    future.get().complete(null);
                });
    }

    @SuppressWarnings("unchecked")
    private void registerGridClickListener(AbstractShmTabGridContent gridContent) {
        gridContent.addSelectionListener(
                event ->
                        ((SelectionEvent<Grid<BaseShmGridVO>, BaseShmGridVO>) event)
                                .getFirstSelectedItem()
                                .ifPresent(drawer::showDetails));
    }
}
