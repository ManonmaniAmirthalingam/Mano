package com.ebtedge.fns.gateway.views.monitor.tabs;

import com.ebtedge.fns.gateway.model.BaseShmGridVO;
import com.ebtedge.fns.gateway.model.DateTimeRange;
import com.ebtedge.fns.gateway.views.monitor.filters.ShmGlobalFilter;
import com.vaadin.flow.data.provider.hierarchy.AbstractHierarchicalDataProvider;
import com.vaadin.flow.data.provider.hierarchy.HierarchicalQuery;
import com.vaadin.flow.function.SerializablePredicate;
import lombok.extern.slf4j.Slf4j;

import java.util.*;
import java.util.stream.Stream;

/**
 * AbstractShmGridDataProvider is an abstract base class for implementing hierarchical data
 * providers for System Health Monitoring (SHM) grids. It defines common functionalities such as
 * data fetching, filtering, sorting, caching, and pagination.
 *
 * @param <T> the type of data this provider will handle, extending BaseShmGridVO
 */
@Slf4j
public abstract class AbstractShmGridDataProvider<T extends BaseShmGridVO>
        extends AbstractHierarchicalDataProvider<T, SerializablePredicate<T>> {

    private static final Comparator<BaseShmGridVO> DEFAULT_COMPARATOR =
            Comparator.comparing(BaseShmGridVO::getHealthStatus)
                    .thenComparing(BaseShmGridVO::getCount)
                    .reversed()
                    .thenComparing(BaseShmGridVO::getName);

    private final ShmGlobalFilter globalFilter;
    private final Map<String, List<T>> cache;

    protected AbstractShmGridDataProvider(ShmGlobalFilter globalFilter) {
        this.globalFilter = globalFilter;
        this.cache = new HashMap<>();
    }

    public Optional<T> getItem(String id) {
        return getCacheableItems().stream()
                .flatMap(item -> flatten(item).stream())
                .filter(item -> item.getEntity().equals(id))
                .findFirst();
    }

    @SuppressWarnings("unchecked")
    private List<T> flatten(T parent) {
        List<T> itemList = new ArrayList<>();
        itemList.add(parent);
        parent.getChildren().forEach(item -> itemList.addAll(flatten((T) item)));
        return itemList;
    }

    @Override
    public int getChildCount(HierarchicalQuery<T, SerializablePredicate<T>> query) {
        return query.getParent() == null
                ? (int) fetchAll(query).count()
                : query.getParent().getChildren().size();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Stream<T> fetchChildren(HierarchicalQuery<T, SerializablePredicate<T>> query) {
        return query.getParent() == null
                ? fetchAll(query)
                : (Stream<T>) query.getParent().getChildren().stream().sorted(DEFAULT_COMPARATOR);
    }

    @Override
    public boolean hasChildren(T item) {
        return item.getChildren() != null && !item.getChildren().isEmpty();
    }

    @Override
    public boolean isInMemory() {
        return false;
    }

    /**
     * Fetches data from the source for a given time range
     *
     * @param timeRange The time range for which to fetch data
     * @return Stream of data items
     */
    public abstract Stream<T> getSourceStream(DateTimeRange timeRange);

    private Stream<T> fetchAll(HierarchicalQuery<T, SerializablePredicate<T>> query) {
        Stream<T> dataStream = getCacheableItemsStream();
        dataStream = applyFilter(dataStream, query.getFilter().orElse(null));
        dataStream = applySorting(dataStream, query.getInMemorySorting());
        return applyPagination(dataStream, query);
    }

    private Stream<T> getCacheableItemsStream() {
        return getCacheableItems().stream();
    }

    public List<T> getCacheableItems() {
        String cacheKey = globalFilter.getCacheKey();

        if (!cache.containsKey(cacheKey)) {
            return fetchAndCacheData(cacheKey);
        }

        log.debug("Loading data from cache");
        return cache.get(cacheKey);
    }

    private List<T> fetchAndCacheData(String cacheKey) {
        log.debug("Fetching data from backend");
        cache.clear();

        List<T> items =
                getSourceStream(globalFilter.getTimeRange()).sorted(DEFAULT_COMPARATOR).toList();

        cache.put(cacheKey, items);
        return items;
    }

    private Stream<T> applyFilter(Stream<T> stream, SerializablePredicate<T> filter) {
        if (filter == null) {
            return stream;
        }
        return stream.filter(filter);
    }

    private Stream<T> applySorting(Stream<T> stream, Comparator<T> comparator) {
        return comparator != null ? stream.sorted(comparator) : stream;
    }

    private Stream<T> applyPagination(Stream<T> stream, HierarchicalQuery<T, ?> query) {
        return stream.skip(query.getOffset()).limit(query.getLimit());
    }
}
