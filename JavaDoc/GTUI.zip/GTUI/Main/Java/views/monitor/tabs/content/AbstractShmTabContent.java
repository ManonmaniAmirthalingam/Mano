package com.ebtedge.fns.gateway.views.monitor.tabs.content;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.Composite;
import com.vaadin.flow.data.provider.DataProvider;
import lombok.extern.slf4j.Slf4j;

/**
 * Represents an abstract base class for content management in a tab component. Provides the
 * framework for initializing components, managing data providers, and refreshing the tab content.
 * This class is intended to be extended by specific tab implementations.
 *
 * @param <T> the type of the main UI component managed by this tab content
 * @param <R> the type of the data objects handled by the data provider
 */
@Slf4j
public abstract class AbstractShmTabContent<T extends Component, R> extends Composite<T> {

    /**
     * Retrieves the data provider associated with this tab content
     *
     * @return The data provider for this tab content
     */
    public abstract DataProvider<R, ?> getDataProvider();

    public abstract void refresh();

    /**
     * Sets a new data provider for this tab content By default, this operation is not supported and
     * must be explicitly implemented by subclasses
     *
     * @param dataProvider The new data provider to set
     * @throws UnsupportedOperationException if the subclass does not implement the operation
     */
    public void setDataProvider(DataProvider<R, ?> dataProvider) {
        throw new UnsupportedOperationException(
                String.format(
                        "setDataProvider() is not implemented in %s. Override this method to provide implementation.",
                        getClass().getSimpleName()));
    }
}
