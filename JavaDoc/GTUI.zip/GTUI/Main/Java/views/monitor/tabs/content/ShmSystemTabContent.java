package com.ebtedge.fns.gateway.views.monitor.tabs.content;

import com.ebtedge.fns.gateway.config.MonitorProperties;
import com.ebtedge.fns.gateway.model.ShmSystemGridVO;
import com.ebtedge.fns.gateway.util.ShmEventFormatter;
import com.ebtedge.fns.gateway.views.monitor.filters.ShmBaseGridFilter;
import com.ebtedge.fns.gateway.views.monitor.filters.ShmGlobalFilter;
import com.ebtedge.fns.gateway.views.monitor.tabs.AbstractShmGridDataProvider;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.orderedlayout.FlexLayout;
import com.vaadin.flow.component.treegrid.TreeGrid;
import com.vaadin.flow.data.provider.ConfigurableFilterDataProvider;
import com.vaadin.flow.function.SerializablePredicate;
import com.vaadin.flow.theme.lumo.LumoUtility;

/**
 * Represents the content for a System Tab in the Shared Memory (SHM) application UI. This class
 * extends the functionality of the {@code AbstractShmTabGridContent} to provide a customized grid
 * and filter setup specifically for displaying and managing {@code ShmSystemGridVO} data.
 */
public class ShmSystemTabContent extends AbstractShmTabGridContent<ShmSystemGridVO> {
    private static final String NAME_FILTER_PLACEHOLDER = "Search By Name";

    public ShmSystemTabContent(
            AbstractShmGridDataProvider<ShmSystemGridVO> dataProvider,
            ShmGlobalFilter globalFilter,
            ShmEventFormatter alertFormatter,
            MonitorProperties.SystemHealthProperties systemHealthProperties) {
        super(dataProvider, globalFilter, alertFormatter, systemHealthProperties);
    }

    @Override
    protected Grid<ShmSystemGridVO> initGrid() {
        TreeGrid<ShmSystemGridVO> grid = new TreeGrid<>();
        configureGridColumns(grid, null);
        return grid;
    }

    @Override
    protected Component initFilters(
            Grid<ShmSystemGridVO> grid,
            ConfigurableFilterDataProvider<
                            ShmSystemGridVO, Void, SerializablePredicate<ShmSystemGridVO>>
                    dataProvider) {
        ShmBaseGridFilter<ShmSystemGridVO> baseGridFilter = new ShmBaseGridFilter<>();
        dataProvider.setFilter(baseGridFilter.getPredicate());

        Component nameFilter = createNameFilterComponent(NAME_FILTER_PLACEHOLDER, baseGridFilter);
        Component statusFilter = createStatusFilterComponent(baseGridFilter::setHealthStatus);

        grid.setDataProvider(dataProvider);

        return createFilterLayout(nameFilter, statusFilter);
    }

    private Component createFilterLayout(Component... filters) {
        FlexLayout layout = new FlexLayout(filters);
        configureFilterLayout(layout);
        return layout;
    }

    private void configureFilterLayout(FlexLayout layout) {
        layout.addClassName(LumoUtility.Gap.MEDIUM);
        layout.setFlexWrap(FlexLayout.FlexWrap.WRAP);
    }
}
