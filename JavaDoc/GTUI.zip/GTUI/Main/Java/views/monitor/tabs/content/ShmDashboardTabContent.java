package com.ebtedge.fns.gateway.views.monitor.tabs.content;

import com.ebtedge.fns.gateway.model.ShmDashboardVO;
import com.ebtedge.fns.gateway.util.ShmEventFormatter;
import com.ebtedge.fns.gateway.views.monitor.dashboard.EventTriggersOverview;
import com.ebtedge.fns.gateway.views.monitor.dashboard.HealthStatusesOverview;
import com.ebtedge.fns.gateway.views.monitor.filters.ShmGlobalFilter;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.board.Board;
import com.vaadin.flow.component.html.H5;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.data.provider.DataProvider;
import com.vaadin.flow.theme.lumo.LumoUtility;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Represents the dashboard content tab for the System Health Monitoring (SHM) application. The
 * class provides a visual overview of health statuses and event triggers by creating and managing
 * various UI components such as grids and dashboards.
 *
 * <p>This class relies on a data provider to fetch the monitoring data and uses a {@code
 * ShmEventFormatter} for formatting alert events in the triggers overview section.
 */
@Slf4j
@RequiredArgsConstructor
public class ShmDashboardTabContent extends AbstractShmTabContent<VerticalLayout, ShmDashboardVO> {
    private static final String STATUSES_HEADER = "Statuses Overview";
    private static final String TRIGGERS_HEADER = "Event Triggers Overview";

    private final ShmGlobalFilter globalFilter;
    private final DataProvider<ShmDashboardVO, ?> dataProvider;
    private final ShmEventFormatter alertFormatter;

    private final UI ui = UI.getCurrent();

    private HealthStatusesOverview linksOverview;
    private HealthStatusesOverview gatewaysOverview;
    private HealthStatusesOverview systemOverview;
    private HealthStatusesOverview statesOverview;
    private EventTriggersOverview triggersOverview;

    @Override
    protected VerticalLayout initContent() {
        VerticalLayout content = new VerticalLayout();
        Board dashboard = createDashboard();
        initializeComponents();
        addDashboardContent(dashboard);
        setupDataListener();
        refreshDashboard();
        content.add(dashboard);
        return content;
    }

    private Board createDashboard() {
        Board dashboard = new Board();
        dashboard.setSizeFull();
        return dashboard;
    }

    private void initializeComponents() {
        linksOverview = new HealthStatusesOverview("Links");
        gatewaysOverview = new HealthStatusesOverview("Gateways");
        systemOverview = new HealthStatusesOverview("System");
        statesOverview = new HealthStatusesOverview("States");
        triggersOverview = new EventTriggersOverview(globalFilter,"", alertFormatter);
    }

    private void addDashboardContent(Board dashboard) {
        dashboard.addRow(createHeader(STATUSES_HEADER));
        dashboard.addRow(linksOverview, gatewaysOverview, systemOverview, statesOverview);
        dashboard.addRow(createHeader(TRIGGERS_HEADER));
        dashboard.addRow(triggersOverview);
    }

    private Component createHeader(String title) {
        VerticalLayout layout = new VerticalLayout();
        layout.addClassName(LumoUtility.Padding.SMALL);
        layout.add(new H5(title));
        return layout;
    }

    private void setupDataListener() {
        dataProvider.addDataProviderListener(
                event -> updateDashboard(fetchDashboardData(event.getSource())));
    }

    private void refreshDashboard() {
        updateDashboard(fetchDashboardData(dataProvider));
    }

    private ShmDashboardVO fetchDashboardData(DataProvider<ShmDashboardVO, ?> provider) {
        return provider.fetch(null).findFirst().orElseGet(ShmDashboardVO::new);
    }

    private void updateDashboard(ShmDashboardVO data) {
        ui.access(() -> updateDashboardComponents(data));
    }

    private void updateDashboardComponents(ShmDashboardVO data) {
        linksOverview.setData(data.getLinks());
        gatewaysOverview.setData(data.getGateways());
        systemOverview.setData(data.getSystem());
        statesOverview.setData(data.getStates());
        triggersOverview.setData(data);
    }

    @Override
    public DataProvider<ShmDashboardVO, ?> getDataProvider() {
        return dataProvider;
    }

    @Override
    public void refresh() {
        getDataProvider().refreshAll();
    }
}
