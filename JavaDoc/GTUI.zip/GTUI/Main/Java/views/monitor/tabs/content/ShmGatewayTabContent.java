package com.ebtedge.fns.gateway.views.monitor.tabs.content;

import com.ebtedge.fns.gateway.config.MonitorProperties;
import com.ebtedge.fns.gateway.model.ShmGatewayGridVO;
import com.ebtedge.fns.gateway.util.ShmEventFormatter;
import com.ebtedge.fns.gateway.views.monitor.filters.ShmBaseGridFilter;
import com.ebtedge.fns.gateway.views.monitor.filters.ShmGlobalFilter;
import com.ebtedge.fns.gateway.views.monitor.tabs.AbstractShmGridDataProvider;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.orderedlayout.FlexLayout;
import com.vaadin.flow.component.treegrid.TreeGrid;
import com.vaadin.flow.data.provider.ConfigurableFilterDataProvider;
import com.vaadin.flow.function.SerializablePredicate;
import com.vaadin.flow.theme.lumo.LumoUtility;
import lombok.extern.slf4j.Slf4j;

/**
 * Represents a tabbed content component for displaying and managing ShmGateway grid data. This
 * class extends the functionality of the {@code AbstractShmTabGridContent} to provide specific
 * implementation for handling ShmGateway-related data.
 *
 * <p>The class is responsible for initializing the grid, configuring its columns, and setting up
 * filters for refining the displayed content. Filters are implemented for filtering by name and
 * status, and can be customized further as needed.
 *
 * <p>It utilizes a {@code TreeGrid} to display hierarchical data and integrates filter components
 * to provide dynamic filtering capabilities. Custom layout configurations are applied to organize
 * the filter components in a structured manner.
 */
@Slf4j
public class ShmGatewayTabContent extends AbstractShmTabGridContent<ShmGatewayGridVO> {
    private static final String NAME_FILTER_PLACEHOLDER = "Search By Name";

    public ShmGatewayTabContent(
            AbstractShmGridDataProvider<ShmGatewayGridVO> dataProvider,
            ShmGlobalFilter globalFilter,
            ShmEventFormatter alertFormatter,
            MonitorProperties.SystemHealthProperties systemHealthProperties) {
        super(dataProvider, globalFilter, alertFormatter, systemHealthProperties);
    }

    @Override
    protected Grid<ShmGatewayGridVO> initGrid() {
        TreeGrid<ShmGatewayGridVO> grid = new TreeGrid<>();
        configureGridColumns(grid, null);
        return grid;
    }

    @Override
    protected Component initFilters(
            Grid<ShmGatewayGridVO> grid,
            ConfigurableFilterDataProvider<
                            ShmGatewayGridVO, Void, SerializablePredicate<ShmGatewayGridVO>>
                    dataProvider) {
        ShmBaseGridFilter<ShmGatewayGridVO> baseGridFilter = new ShmBaseGridFilter<>();
        dataProvider.setFilter(baseGridFilter.getPredicate());

        Component nameFilter = createNameFilterComponent(NAME_FILTER_PLACEHOLDER, baseGridFilter);
        Component statusFilter = createStatusFilterComponent(baseGridFilter::setHealthStatus);

        grid.setDataProvider(dataProvider);

        return createFilterLayout(nameFilter, statusFilter);
    }

    private Component createFilterLayout(Component... filters) {
        FlexLayout layout = new FlexLayout(filters);
        configureFilterLayout(layout);
        return layout;
    }

    private void configureFilterLayout(FlexLayout layout) {
        layout.addClassName(LumoUtility.Gap.MEDIUM);
        layout.setFlexWrap(FlexLayout.FlexWrap.WRAP);
    }
}
