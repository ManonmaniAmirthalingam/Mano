package com.ebtedge.fns.gateway.views.monitor.tabs;

import com.ebtedge.fns.gateway.config.GatAppConfig;
import com.ebtedge.fns.gateway.model.*;
import com.ebtedge.fns.gateway.service.ShmTabDataService;
import com.ebtedge.fns.gateway.util.ShmEventFormatter;
import com.ebtedge.fns.gateway.views.monitor.ShmView;
import com.ebtedge.fns.gateway.views.monitor.filters.ShmGlobalFilter;
import com.ebtedge.fns.gateway.views.monitor.tabs.content.*;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.component.tabs.Tabs;
import com.vaadin.flow.component.tabs.TabsVariant;
import com.vaadin.flow.spring.annotation.RouteScope;
import com.vaadin.flow.spring.annotation.RouteScopeOwner;
import com.vaadin.flow.theme.lumo.LumoUtility;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.EnumMap;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Stream;

/**
 * The ShmTabFactory class is responsible for creating and managing the tabs and their corresponding
 * content for the System Health Monitor (SHM) view. It defines a set of tab types, their behaviors,
 * and content factories to support dynamic tab creation.
 *
 * <p>The factory uses a combination of dependency-injected services and internally defined
 * configurations to provide functionality for the SHM user interface.
 *
 * <p>An instance of this class is used to generate the tab components and bind them to the
 * appropriate content, ensuring a seamless integration with the SHM view architecture.
 *
 * <p>Dependencies: - ShmTabDataService: Provides data retrieval for tab content. - ShmGlobalFilter:
 * A shared filter for applying global filtering logic across tabs. - ShmEventFormatter: Utility for
 * formatting events within tab content.
 *
 * <p>Tab Factory Details: - Tab creation is managed by the `createTabs` method, generating
 * formatted tab elements based on predefined `TabType` enums. - For each tab, the associated
 * content is constructed through pre-configured factories mapping the `TabType` to the correct
 * content creation logic. - Supported tab types include DASHBOARD, LINKS, GATEWAYS, SYSTEM, and
 * STATES.
 *
 * <p>Features: - Supports the addition of new tab types through the `contentFactories` registry. -
 * Abstracts data provider creation for use by individual tab content.
 */
@Slf4j
@Component
@Scope(value = "vaadin-route", proxyMode = ScopedProxyMode.TARGET_CLASS)
@RouteScope
@RouteScopeOwner(ShmView.class)
@RequiredArgsConstructor
public class ShmTabFactory {

    private final ShmTabDataService dataService;
    private final ShmGlobalFilter globalFilter;
    private final ShmEventFormatter alertFormatter;
    private final GatAppConfig appConfig;

    private final Map<TabType, Function<TabType, AbstractShmTabContent<?, ?>>> contentFactories =
            createContentFactories();

    public Tabs createTabs() {
        Tabs tabs = new Tabs();
        configureTabs(tabs);
        addTabsContent(tabs);
        return tabs;
    }

    /**
     * Creates and returns the content associated with a given tab in the System Health Monitoring
     * (SHM) interface. This method determines the type of the tab and leverages a factory pattern
     * to instantiate the appropriate {@link AbstractShmTabContent} implementation for the tab.
     *
     * @param tab the tab whose content is to be created
     * @param <T> the type of the data object handled by the content's data provider
     * @return an instance of {@link AbstractShmTabContent} corresponding to the provided tab
     * @throws IllegalArgumentException if the tab type cannot be determined or if no factory exists
     *     for that type
     */
    @SuppressWarnings("unchecked")
    public <T> AbstractShmTabContent<?, T> createTabContent(Tab tab) {
        TabType type = getTabType(tab);
        return (AbstractShmTabContent<?, T>) contentFactories.get(type).apply(type);
    }

    private void configureTabs(Tabs tabs) {
        tabs.setWidthFull();
        tabs.addThemeVariants(TabsVariant.MATERIAL_FIXED);
    }

    private void addTabsContent(Tabs tabs) {
        Arrays.stream(TabType.values()).map(this::createTab).forEach(tabs::add);
    }

    private Tab createTab(TabType type) {
        Tab tab = new Tab(type.getLabel());
        tab.addClassName(LumoUtility.FontSize.LARGE);
        return tab;
    }

    private TabType getTabType(Tab tab) {
        return Optional.ofNullable(tab.getLabel())
                .map(TabType::fromLabel)
                .orElseThrow(() -> new IllegalArgumentException("Invalid tab: " + tab.getLabel()));
    }

    private Map<TabType, Function<TabType, AbstractShmTabContent<?, ?>>> createContentFactories() {
        Map<TabType, Function<TabType, AbstractShmTabContent<?, ?>>> factories =
                new EnumMap<>(TabType.class);

        factories.put(
                TabType.LINKS,
                type ->
                        new ShmLinksTabContent(
                                createDataProvider(ShmLinkGridVO.class),
                                globalFilter,
                                alertFormatter,
                                appConfig.getMonitor().getSystemHealth()));

        factories.put(
                TabType.GATEWAYS,
                type ->
                        new ShmGatewayTabContent(
                                createDataProvider(ShmGatewayGridVO.class),
                                globalFilter,
                                alertFormatter,
                                appConfig.getMonitor().getSystemHealth()));
        factories.put(
                TabType.SYSTEM,
                type ->
                        new ShmSystemTabContent(
                                createDataProvider(ShmSystemGridVO.class),
                                globalFilter,
                                alertFormatter,
                                appConfig.getMonitor().getSystemHealth()));

        factories.put(
                TabType.STATES,
                type ->
                        new ShmStatesTabContent(
                                createDataProvider(ShmStateBinGridVO.class),
                                globalFilter,
                                alertFormatter,
                                appConfig.getMonitor().getSystemHealth()));

        factories.put(
                TabType.DASHBOARD,
                type ->
                        new ShmDashboardTabContent(
                                globalFilter, createDashboardDataProvider(), alertFormatter));

        return factories;
    }

    private <T extends BaseShmGridVO> AbstractShmGridDataProvider<T> createDataProvider(
            Class<T> entityClass) {
        return new AbstractShmGridDataProvider<>(globalFilter) {
            @Override
            public Stream<T> getSourceStream(DateTimeRange timeRange) {
                return dataService
                        .getData(entityClass, timeRange.getStart(), timeRange.getEnd())
                        .stream();
            }
        };
    }

    private ShmTabDashboardDataProvider createDashboardDataProvider() {
        return new ShmTabDashboardDataProvider(dataService, globalFilter);
    }

    /**
     * Represents the different types of tabs available in the System Health Monitoring (SHM)
     * interface. Each enum constant corresponds to a specific tab in the SHM UI and provides a
     * textual label for display.
     *
     * <p>Methods: - fromLabel(String label): Returns the TabType corresponding to the provided
     * label. Throws an IllegalArgumentException if no matching TabType is found.
     *
     * <p>Field: - label: A string representing the display label associated with the tab type.
     */
    @Getter
    @RequiredArgsConstructor
    public enum TabType {
        DASHBOARD("Dashboard"),
        LINKS("Links"),
        GATEWAYS("Gateways"),
        SYSTEM("System"),
        STATES("States");

        private final String label;

        public static TabType fromLabel(String label) {
            return Arrays.stream(values())
                    .filter(type -> type.getLabel().equals(label))
                    .findFirst()
                    .orElseThrow(() -> new IllegalArgumentException("Unknown tab label: " + label));
        }
    }
}
