package com.ebtedge.fns.gateway.views.monitor.tabs.content;

import com.ebtedge.fns.gateway.config.MonitorProperties;
import com.ebtedge.fns.gateway.model.ShmAlert;
import com.ebtedge.fns.gateway.model.ShmStatus;
import com.ebtedge.fns.gateway.model.BaseShmGridVO;
import com.ebtedge.fns.gateway.rule.shm.ShmRuleViolation;
import com.ebtedge.fns.gateway.util.DateTimeConvertors;
import com.ebtedge.fns.gateway.util.ShmEventFormatter;
import com.ebtedge.fns.gateway.views.monitor.filters.ShmBaseGridFilter;
import com.ebtedge.fns.gateway.views.monitor.filters.ShmGlobalFilter;
import com.ebtedge.fns.gateway.views.monitor.tabs.AbstractShmGridDataProvider;
import com.vaadin.flow.component.*;
import com.vaadin.flow.component.charts.Chart;
import com.vaadin.flow.component.charts.model.*;
import com.vaadin.flow.component.charts.model.style.SolidColor;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.combobox.MultiSelectComboBox;
import com.vaadin.flow.component.grid.*;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.orderedlayout.*;
import com.vaadin.flow.component.treegrid.TreeGrid;
import com.vaadin.flow.data.provider.*;
import com.vaadin.flow.data.renderer.*;
import com.vaadin.flow.data.selection.SelectionListener;
import com.vaadin.flow.function.SerializablePredicate;
import com.vaadin.flow.shared.Registration;

import com.vaadin.flow.theme.lumo.LumoUtility;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import java.time.*;
import java.time.format.TextStyle;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * AbstractShmTabGridContent is a base abstract class that provides functionality for a grid-based
 * user interface within a shared memory (Shm) tab. It is designed to handle data of type T, which
 * extends BaseShmGridVO. The class manages grid configuration, initialization, and interaction with
 * data providers, filters, and renderers.
 *
 * @param <T> The type parameter representing the data model that the grid will handle, and must
 *     extend BaseShmGridVO.
 */
@Slf4j
public abstract class AbstractShmTabGridContent<T extends BaseShmGridVO>
        extends AbstractShmTabContent<VerticalLayout, T> {

    private static final ZoneId CENTRAL_TIMEZONE = DateTimeConvertors.CENTRAL_TIMEZONE;
    private static final int GRID_PAGE_SIZE = 500;
    protected static final String NAME_COLUMN_HEADER = "Name";
    private static final String STATUS_COLUMN_HEADER = "Status";
    private static final String ALERTS_COLUMN_HEADER = "Triggers";
    private static final String STATUS_COLUMN_WIDTH = "150px";
    private static final String NAME_COLUMN_WIDTH = "180px";

    @Getter private final Grid<T> grid;
    private final ShmGlobalFilter globalFilter;
    private final AbstractShmGridDataProvider<T> dataProvider;
    private final ShmEventFormatter alertFormatter;
    private final MonitorProperties.SystemHealthProperties systemHealthProperties;

    protected AbstractShmTabGridContent(
            AbstractShmGridDataProvider<T> baseDataProvider,
            ShmGlobalFilter globalFilter,
            ShmEventFormatter alertFormatter,
            MonitorProperties.SystemHealthProperties systemHealthProperties) {

        this.globalFilter = globalFilter;
        this.dataProvider = baseDataProvider;
        this.alertFormatter = alertFormatter;
        this.systemHealthProperties = systemHealthProperties;

        this.grid = initGrid();
        configureGrid();
    }

    @Override
    public void refresh() {
        Set<String> selectedItemIds =
                grid.getSelectedItems().stream()
                        .map(BaseShmGridVO::getEntity)
                        .collect(Collectors.toSet());
        grid.getDataProvider().refreshAll();
        if (!selectedItemIds.isEmpty()) {
            // Grid doesn't refresh selection when refreshing data, so we have to do it manually
            grid.getSelectionModel().deselectAll();
            selectedItemIds.stream()
                    .map(dataProvider::getItem)
                    .filter(Optional::isPresent)
                    .map(Optional::get)
                    .forEach(grid::select);
        }
    }

    @Override
    protected VerticalLayout initContent() {
        VerticalLayout content = new VerticalLayout();
        content.setSizeFull();

        Component filters = initFilters(grid, dataProvider.withConfigurableFilter());
        content.add(filters, grid);

        return content;
    }

    @Override
    public DataProvider<T, ?> getDataProvider() {
        return dataProvider;
    }

    public Registration addSelectionListener(SelectionListener<Grid<T>, T> listener) {
        return grid.addSelectionListener(listener);
    }

    protected abstract Grid<T> initGrid();

    protected abstract Component initFilters(
            Grid<T> grid,
            ConfigurableFilterDataProvider<T, Void, SerializablePredicate<T>> dataProvider);

    protected void configureGridColumns(
            Grid<T> grid, Function<List<Grid.Column<T>>, List<Grid.Column<T>>> columnUpdater) {

        List<Grid.Column<T>> columns = new ArrayList<>();
        addNameColumn(grid, columns);
        addStatusColumn(grid, columns);
        addAlertsColumn(grid, columns);

        if (columnUpdater != null) {
            grid.setColumnOrder(columnUpdater.apply(columns));
        }
    }

    private void configureGrid() {
        grid.setPageSize(GRID_PAGE_SIZE);
        grid.setDetailsVisibleOnClick(false);
    }

    private void addNameColumn(Grid<T> grid, List<Grid.Column<T>> columns) {
        if (grid instanceof TreeGrid<T> treeGrid) {
            columns.add(createNameColumn(treeGrid));
        }
    }

    protected Grid.Column<T> createNameColumn(TreeGrid<T> grid) {
        return grid.addHierarchyColumn(BaseShmGridVO::getName)
                .setHeader(NAME_COLUMN_HEADER)
                .setWidth(NAME_COLUMN_WIDTH)
                .setResizable(true)
                .setFlexGrow(0)
                .setSortable(true);
    }

    private void addStatusColumn(Grid<T> grid, List<Grid.Column<T>> columns) {
        columns.add(
                grid.addColumn(createHealthStatusRenderer())
                        .setHeader(STATUS_COLUMN_HEADER)
                        .setTextAlign(ColumnTextAlign.CENTER)
                        .setWidth(STATUS_COLUMN_WIDTH)
                        .setSortable(true)
                        .setFlexGrow(0)
                        .setComparator(BaseShmGridVO::getHealthStatus));
    }

    private void addAlertsColumn(Grid<T> grid, List<Grid.Column<T>> columns) {
        columns.add(
                grid.addColumn(createChartRenderer())
                        .setHeader(ALERTS_COLUMN_HEADER)
                        .setTextAlign(ColumnTextAlign.CENTER)
                        .setAutoWidth(true)
                        .setFlexGrow(1));
    }

    protected MultiSelectComboBox<T> createNameFilterComponent(
            String label, ShmBaseGridFilter<T> filter) {
        MultiSelectComboBox<T> filterComponent = new MultiSelectComboBox<>(label);
        filterComponent.setMinWidth("250px");

        filterComponent.setClearButtonVisible(true);
        filterComponent.addValueChangeListener(
                event -> {
                    filter.setNames(
                            event.getValue().stream()
                                    .map(BaseShmGridVO::getName)
                                    .collect(Collectors.toSet()));
                    refresh();
                });
        filterComponent.setAutoOpen(true);
        filterComponent.setAllowCustomValue(true);
        filterComponent.setItemLabelGenerator(filter.getItemLabelGenerator());
        List<T> items = new ArrayList<>(dataProvider.getCacheableItems());
        items.sort(Comparator.comparing(BaseShmGridVO::getName));
        filterComponent.setItems(
                (item, text) -> filter.getComboboxItemFilter().test(item, text), items);
        return filterComponent;
    }

    protected ComboBox<ShmStatus> createStatusFilterComponent(Consumer<ShmStatus> filterConsumer) {
        ComboBox<ShmStatus> filter = new ComboBox<>("Filter By Status");
        filter.setItems(ShmStatus.values());
        filter.setItemLabelGenerator(ShmStatus::getValue);
        filter.setPlaceholder("All");
        filter.setClearButtonVisible(true);
        filter.addValueChangeListener(
                event -> {
                    filterConsumer.accept(event.getValue());
                    refresh();
                });
        return filter;
    }

    protected Renderer<T> createHealthStatusRenderer() {
        return new ComponentRenderer<>(
                (item -> {
                    ShmStatus status = item.getHealthStatus();
                    return status.getDisplayComponent();
                }));
    }

    protected Renderer<T> createChartRenderer() {
        return new ComponentRenderer<>(
                (item) -> {
                    var layout = new HorizontalLayout();
                    layout.setPadding(false);
                    layout.setSpacing(false);

                    Chart chart = new Chart(ChartType.SPLINE);
                    chart.setHeight("100px");
                    chart.addClassName(LumoUtility.Flex.GROW);
                    Configuration conf = chart.getConfiguration();
                    Time time = new Time();
                    time.setUseUTC(false);
                    conf.setTime(time);
                    Tooltip tooltip = new Tooltip(true);
                    tooltip.setUseHTML(true);
                    conf.setTooltip(tooltip);

                    conf.addxAxis(createXAxis());
                    conf.addyAxis(createYAxis());

                    addSeries(chart, item);
                    layout.add(chart, createChartTextSection("Triggers: " + item.getCount()));
                    return layout;
                });
    }

    private static YAxis createYAxis() {
        YAxis yAxis = new YAxis();
        yAxis.setVisible(false);
        yAxis.setGridLineWidth(0);
        return yAxis;
    }

    private XAxis createXAxis() {
        XAxis xAxis = new XAxis();
        xAxis.setType(AxisType.DATETIME);
        xAxis.setGridLineWidth(0);
        xAxis.setLineWidth(0);
        xAxis.setMin(getFilterStartTime().toEpochMilli());
        xAxis.setMax(getFilterEndTime().toEpochMilli());
        xAxis.setStartOnTick(false);
        xAxis.setEndOnTick(false);
        xAxis.setMinPadding(0);
        xAxis.setMaxPadding(0);
        return xAxis;
    }

    private Component createChartTextSection(String text) {
        VerticalLayout layout = new VerticalLayout();
        layout.setPadding(false);
        layout.setSpacing(false);
        layout.setSizeUndefined();
        layout.addClassNames(LumoUtility.Padding.Left.SMALL, LumoUtility.Padding.Bottom.SMALL);
        Span top = new Span(text);
        top.addClassName(LumoUtility.Padding.Top.MEDIUM);
        layout.addClassNames(LumoUtility.JustifyContent.BETWEEN, LumoUtility.Flex.GROW_NONE);
        Span bottom =
                new Span(
                        DateTimeConvertors.CENTRAL_TIMEZONE.getDisplayName(
                                TextStyle.FULL_STANDALONE, Locale.US));
        bottom.addClassName(LumoUtility.Padding.Bottom.XSMALL);
        layout.add(top, bottom);

        return layout;
    }

    private void addSeries(Chart chart, T item) {
        Map<ShmAlert, Integer> eventMap =
                item.getRuleViolations().stream()
                        .map(ShmRuleViolation::getAlertAccumulation)
                        .map(Map::entrySet)
                        .flatMap(Collection::stream)
                        .collect(
                                Collectors.groupingBy(
                                        Map.Entry::getKey,
                                        Collectors.summingInt(Map.Entry::getValue)));

        Duration healthRecoveryDuration = systemHealthProperties.getHealthRecoveryDuration();
        Map<Instant, Integer> seriesValueMap =
                eventMap.entrySet().stream()
                        .map(
                                entry ->
                                        new AbstractMap.SimpleEntry<>(
                                                entry.getKey().getTimestamp(), entry.getValue()))
                        .collect(
                                Collectors.toMap(
                                        Map.Entry::getKey, Map.Entry::getValue, Math::max));

        List<List<Instant>> unhealthyLines =
                addPaddings(
                        groupConnectedPoints(
                                eventMap.keySet().stream().map(ShmAlert::getTimestamp).toList(),
                                healthRecoveryDuration),
                        Duration.ofMillis(1),
                        healthRecoveryDuration);
        createDataSeries(unhealthyLines, seriesValueMap, ShmStatus.UNHEALTHY)
                .forEach(chart.getConfiguration()::addSeries);

        List<List<Instant>> healthyLines = findGaps(unhealthyLines);
        createDataSeries(healthyLines, new HashMap<>(), ShmStatus.HEALTHY)
                .forEach(chart.getConfiguration()::addSeries);

        if (item.getHealthStatus() == ShmStatus.UNHEALTHY) {
            PlotOptionsScatter errorSeriesOptions = getErrorScatterPlotOptions();
            DataSeries errorSeries = new DataSeries();
            errorSeries.setPlotOptions(errorSeriesOptions);
            addScatterSeriesItems(eventMap.entrySet(), errorSeries::add);
            chart.getConfiguration().addSeries(errorSeries);
        }
    }

    private List<DataSeries> createDataSeries(
            List<List<Instant>> lines, Map<Instant, Integer> valueMap, ShmStatus status) {
        List<DataSeries> dataSeriesList = new ArrayList<>();
        lines.stream()
                .map(
                        line ->
                                line.stream()
                                        .collect(
                                                Collectors.toMap(
                                                        point -> point,
                                                        point -> valueMap.getOrDefault(point, 0),
                                                        Integer::max,
                                                        TreeMap::new)))
                .map(line -> createDataSeries(line.entrySet(), status))
                .forEach(dataSeriesList::add);
        return dataSeriesList;
    }

    private DataSeries createDataSeries(
            Set<Map.Entry<Instant, Integer>> entries, ShmStatus status) {
        DataSeries dataSeries = new DataSeries();
        dataSeries.setPlotOptions(getSplinePlotOptions(status));
        entries.stream()
                .map(entry -> new DataSeriesItem(entry.getKey(), entry.getValue()))
                .forEach(dataSeries::add);
        return dataSeries;
    }

    private List<List<Instant>> groupConnectedPoints(List<Instant> points, Duration duration) {
        if (points.isEmpty()) return Collections.emptyList();
        List<Instant> sorted = new ArrayList<>(points);
        sorted.sort(Comparator.naturalOrder());

        List<List<Instant>> groups = new ArrayList<>();
        List<Instant> currentGroup = new ArrayList<>();
        currentGroup.add(sorted.get(0));

        for (int i = 1; i < sorted.size(); i++) {
            Instant previous = sorted.get(i - 1);
            Instant current = sorted.get(i);
            if (Duration.between(previous, current).compareTo(duration.multipliedBy(2)) <= 0) {
                currentGroup.add(current);
            } else {
                groups.add(currentGroup);
                currentGroup = new ArrayList<>();
                currentGroup.add(current);
            }
        }
        groups.add(currentGroup);
        return groups;
    }

    private List<List<Instant>> addPaddings(
            List<List<Instant>> groups, Duration left, Duration right) {
        List<List<Instant>> paddedGroups = new ArrayList<>();
        for (List<Instant> group : groups) {
            if (group.isEmpty()) continue;
            Instant first = group.get(0);
            Instant last;
            if (group.size() == 1) {
                last = first;
            } else {
                last = group.get(group.size() - 1);
            }
            group.add(first.minus(left));
            group.add(last.plus(right));
            List<Instant> paddedGroup = new ArrayList<>(group);
            paddedGroup.sort(Comparator.naturalOrder());
            paddedGroups.add(paddedGroup);
        }
        return paddedGroups;
    }

    private List<List<Instant>> findGaps(List<List<Instant>> groups) {
        if (groups.isEmpty()) {
            Instant start = getFilterStartTime();
            Instant end = getFilterEndTime();
            // Adding a middle point is a trick to make the chart display more time ticks as per a
            // requirement
            return List.of(addNoises(start, end, 2));
        }
        record TimeRange(Instant start, Instant end) {}
        ;
        List<TimeRange> gaps = new ArrayList<>();
        List<TimeRange> ranges =
                groups.stream()
                        .map(group -> new TimeRange(group.get(0), group.get(group.size() - 1)))
                        .toList();
        Instant previousEnd = getFilterStartTime();
        for (TimeRange range : ranges) {
            if (range.start().isAfter(previousEnd)) {
                gaps.add(new TimeRange(previousEnd, range.start()));
            }
            if (range.end().isAfter(previousEnd)) {
                previousEnd = range.end();
            }
        }
        if (previousEnd.isBefore(getFilterEndTime())) {
            gaps.add(new TimeRange(previousEnd, getFilterEndTime()));
        }
        return gaps.stream()
                .map(
                        gap -> {
                            List<Instant> group = new ArrayList<>();
                            group.add(gap.start());
                            group.add(gap.end());
                            return group;
                        })
                .toList();
    }

    private List<Instant> addNoises(Instant start, Instant end, int noiseCount) {
        List<Instant> noisePoints = new ArrayList<>();
        noisePoints.add(start);
        Duration duration = Duration.between(start, end);
        long interval = duration.toMillis() / (noiseCount + 1);
        for (int i = 1; i <= noiseCount; i++) {
            noisePoints.add(start.plusMillis(i * interval));
        }
        noisePoints.add(end);
        return noisePoints;
    }

    private void addScatterSeriesItems(
            Set<Map.Entry<ShmAlert, Integer>> eventEntries,
            Consumer<DataSeriesItem> seriesItemConsumer) {
        eventEntries.forEach(
                entry -> {
                    DataSeriesItem errorItem =
                            new DataSeriesItem(entry.getKey().getTimestamp(), entry.getValue());
                    errorItem.setDescription(alertFormatter.formatHtml(entry));
                    seriesItemConsumer.accept(errorItem);
                });
    }

    private AbstractPlotOptions getSplinePlotOptions(ShmStatus status) {
        PlotOptionsAreaspline plotOptions = new PlotOptionsAreaspline();
        plotOptions.setMarker(new Marker(false));
        plotOptions.setLineWidth(1);
        plotOptions.setFillOpacity(0.1);
        plotOptions.setShowInLegend(false);
        plotOptions.setEnableMouseTracking(false);
        if (status == ShmStatus.HEALTHY) {
            plotOptions.setColor(SolidColor.GREEN);
        } else {
            plotOptions.setColor(SolidColor.ORANGE);
        }
        return plotOptions;
    }

    private PlotOptionsScatter getErrorScatterPlotOptions() {
        PlotOptionsScatter errorSeriesOptions = new PlotOptionsScatter();
        SeriesTooltip seriesTooltip = new SeriesTooltip();
        seriesTooltip.setHeaderFormat("");
        seriesTooltip.setPointFormatter("function(){ return `${this.description}`; }");
        errorSeriesOptions.setTooltip(seriesTooltip);
        errorSeriesOptions.setMarker(new Marker(true));
        errorSeriesOptions.setShowInLegend(false);
        errorSeriesOptions.getMarker().setFillColor(SolidColor.RED);
        errorSeriesOptions.getMarker().setRadius(3);
        errorSeriesOptions.getMarker().setSymbol(MarkerSymbolEnum.CIRCLE);
        return errorSeriesOptions;
    }

    private Instant getFilterStartTime() {
        return globalFilter.getTimeRange().getStart().atZone(CENTRAL_TIMEZONE).toInstant();
    }

    private Instant getFilterEndTime() {
        return globalFilter.getTimeRange().getEnd().atZone(CENTRAL_TIMEZONE).toInstant();
    }
}
