package com.ebtedge.fns.gateway.views.monitor.tabs.content;

import com.ebtedge.fns.gateway.config.MonitorProperties;
import com.ebtedge.fns.gateway.model.BaseShmGridVO;
import com.ebtedge.fns.gateway.model.ShmStateBinGridVO;
import com.ebtedge.fns.gateway.util.ShmEventFormatter;
import com.ebtedge.fns.gateway.views.monitor.filters.ShmGlobalFilter;
import com.ebtedge.fns.gateway.views.monitor.filters.ShmStateGridFilter;
import com.ebtedge.fns.gateway.views.monitor.tabs.AbstractShmGridDataProvider;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.orderedlayout.FlexLayout;
import com.vaadin.flow.component.treegrid.TreeGrid;
import com.vaadin.flow.data.provider.ConfigurableFilterDataProvider;
import com.vaadin.flow.function.SerializablePredicate;
import com.vaadin.flow.theme.lumo.LumoUtility;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

/**
 * ShmStatesTabContent is a UI component class responsible for rendering the content of a tab
 * displaying data about SHM state BINs. It extends the AbstractShmTabGridContent class with the
 * type parameter ShmStateBinGridVO, inheriting common functionalities and adding specific behavior
 * for managing state data.
 *
 * <p>This class is designed to construct a grid interface where each row represents a
 * ShmStateBinGridVO object. The grid includes filtering and column customization specific to the
 * needs of managing SHM state data.
 *
 * <p>Key responsibilities of this class include: - Configuring the grid and its columns to display
 * relevant information. - Adding a "Card BIN" column with specific settings such as width and
 * sorting capability. - Initializing and managing filters for the grid, enabling users to filter
 * data by name, card BIN, or status, utilizing customizable filtering predicates. - Setting up the
 * visual layout for filters in a flexible, responsive design.
 *
 * <p>Constructor Summary: - ShmStatesTabContent(AbstractShmGridDataProvider<ShmStateBinGridVO>
 * dataProvider, ShmGlobalFilter globalFilter, ShmEventFormatter alertFormatter): Initializes the
 */
@Slf4j
public class ShmStatesTabContent extends AbstractShmTabGridContent<ShmStateBinGridVO> {
    private static final String CARD_BIN_COLUMN_WIDTH = "130px";
    private static final String NAME_FILTER_PLACEHOLDER = "Search By Name or BIN";
    private static final int CARD_BIN_COLUMN_INDEX = 1;
    private static final String NAME_COLUMN_WIDTH = "280px";

    public ShmStatesTabContent(
            AbstractShmGridDataProvider<ShmStateBinGridVO> dataProvider,
            ShmGlobalFilter globalFilter,
            ShmEventFormatter alertFormatter,
            MonitorProperties.SystemHealthProperties systemHealthProperties) {
        super(dataProvider, globalFilter, alertFormatter, systemHealthProperties);
    }

    @Override
    protected Grid<ShmStateBinGridVO> initGrid() {
        TreeGrid<ShmStateBinGridVO> grid = new TreeGrid<>();
        configureGridColumns(grid, columns -> addBinColumn(grid, columns));
        return grid;
    }

    @Override
    protected Grid.Column<ShmStateBinGridVO> createNameColumn(TreeGrid<ShmStateBinGridVO> grid) {
        return grid.addHierarchyColumn(BaseShmGridVO::getName)
                .setHeader(NAME_COLUMN_HEADER)
                .setWidth(NAME_COLUMN_WIDTH)
                .setResizable(true)
                .setFlexGrow(0)
                .setSortable(true);
    }

    private List<Grid.Column<ShmStateBinGridVO>> addBinColumn(
            Grid<ShmStateBinGridVO> grid, List<Grid.Column<ShmStateBinGridVO>> columns) {
        Grid.Column<ShmStateBinGridVO> binColumn = createBinColumn(grid);
        columns.add(CARD_BIN_COLUMN_INDEX, binColumn);
        return columns;
    }

    private Grid.Column<ShmStateBinGridVO> createBinColumn(Grid<ShmStateBinGridVO> grid) {
        return grid.addColumn(ShmStateBinGridVO::getBin)
                .setHeader("BIN")
                .setWidth(CARD_BIN_COLUMN_WIDTH)
                .setFlexGrow(0)
                .setSortable(true);
    }

    @Override
    protected Component initFilters(
            Grid<ShmStateBinGridVO> grid,
            ConfigurableFilterDataProvider<
                            ShmStateBinGridVO, Void, SerializablePredicate<ShmStateBinGridVO>>
                    dataProvider) {
        ShmStateGridFilter stateGridFilter = new ShmStateGridFilter();
        dataProvider.setFilter(stateGridFilter.getPredicate());

        Component nameFilter = createNameFilterComponent(NAME_FILTER_PLACEHOLDER, stateGridFilter);
        Component statusFilter = createStatusFilterComponent(stateGridFilter::setHealthStatus);

        grid.setDataProvider(dataProvider);

        return createFilterLayout(nameFilter, statusFilter);
    }

    private Component createFilterLayout(Component... filters) {
        FlexLayout layout = new FlexLayout(filters);
        configureFilterLayout(layout);
        return layout;
    }

    private void configureFilterLayout(FlexLayout layout) {
        layout.addClassName(LumoUtility.Gap.MEDIUM);
        layout.setFlexWrap(FlexLayout.FlexWrap.WRAP);
    }
}
