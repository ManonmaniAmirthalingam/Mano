package com.ebtedge.fns.gateway.views.monitor.tabs.content;

import com.ebtedge.fns.gateway.config.MonitorProperties;
import com.ebtedge.fns.gateway.model.ShmLinkGridVO;
import com.ebtedge.fns.gateway.util.ShmEventFormatter;
import com.ebtedge.fns.gateway.views.monitor.filters.ShmBaseGridFilter;
import com.ebtedge.fns.gateway.views.monitor.filters.ShmGlobalFilter;
import com.ebtedge.fns.gateway.views.monitor.tabs.AbstractShmGridDataProvider;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.orderedlayout.FlexLayout;
import com.vaadin.flow.component.treegrid.TreeGrid;
import com.vaadin.flow.data.provider.ConfigurableFilterDataProvider;
import com.vaadin.flow.function.SerializablePredicate;
import com.vaadin.flow.theme.lumo.LumoUtility;
import lombok.extern.slf4j.Slf4j;

/**
 * The ShmLinksTabContent class is a representation of a single tab content for displaying and
 * managing SHM link grid data in a tabular form. It extends AbstractShmTabGridContent and provides
 * additional functionality specific to SHM Links, including grid initialization and filter
 * management.
 *
 * <p>This class provides mechanisms to: - Initialize a grid for SHM links data using a TreeGrid. -
 * Configure filters for dynamic data filtering including name and status filters. - Handle layout
 * setup for filters in the user interface.
 */
@Slf4j
public class ShmLinksTabContent extends AbstractShmTabGridContent<ShmLinkGridVO> {
    private static final String NAME_FILTER_PLACEHOLDER = "Search By Name";

    public ShmLinksTabContent(
            AbstractShmGridDataProvider<ShmLinkGridVO> dataProvider,
            ShmGlobalFilter globalFilter,
            ShmEventFormatter alertFormatter,
            MonitorProperties.SystemHealthProperties systemHealthProperties) {
        super(dataProvider, globalFilter, alertFormatter, systemHealthProperties);
    }

    @Override
    protected Grid<ShmLinkGridVO> initGrid() {
        TreeGrid<ShmLinkGridVO> grid = new TreeGrid<>();
        configureGridColumns(grid, null);
        return grid;
    }

    @Override
    protected Component initFilters(
            Grid<ShmLinkGridVO> grid,
            ConfigurableFilterDataProvider<
                            ShmLinkGridVO, Void, SerializablePredicate<ShmLinkGridVO>>
                    dataProvider) {
        ShmBaseGridFilter<ShmLinkGridVO> baseGridFilter = new ShmBaseGridFilter<>();
        dataProvider.setFilter(baseGridFilter.getPredicate());

        Component nameFilter = createNameFilterComponent(NAME_FILTER_PLACEHOLDER, baseGridFilter);
        Component statusFilter = createStatusFilterComponent(baseGridFilter::setHealthStatus);

        grid.setDataProvider(dataProvider);

        return createFilterLayout(nameFilter, statusFilter);
    }

    private Component createFilterLayout(Component... filters) {
        FlexLayout layout = new FlexLayout(filters);
        configureFilterLayout(layout);
        return layout;
    }

    private void configureFilterLayout(FlexLayout layout) {
        layout.addClassName(LumoUtility.Gap.MEDIUM);
        layout.setFlexWrap(FlexLayout.FlexWrap.WRAP);
    }
}
