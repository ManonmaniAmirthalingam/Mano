package com.ebtedge.fns.gateway.views.monitor.tabs;

import com.ebtedge.fns.gateway.model.ShmDashboardVO;
import com.ebtedge.fns.gateway.service.ShmTabDataService;
import com.ebtedge.fns.gateway.views.monitor.filters.ShmGlobalFilter;
import com.vaadin.flow.data.provider.AbstractDataProvider;
import com.vaadin.flow.data.provider.Query;

import java.util.stream.Stream;

/**
 * Data provider class for SHM (System Health Monitoring) Tab Dashboard data. This class extends
 * AbstractDataProvider and provides data fetching functionality for the ShmDashboardVO. It
 * integrates with the ShmTabDataService to retrieve dashboard data filtered by the global time
 * range configured in ShmGlobalFilter.
 *
 * <p>This class encapsulates the logic for retrieving the required data, providing it in a stream
 * format, and informing the system whether the data is handled in-memory.
 *
 * <p>Responsibilities: - Fetches dashboard data for the SHM Grid components such as links,
 * gateways, systems, and states. - Relies on ShmTabDataService for actual data retrieval. - Adapts
 * queries to the global filter time range defined in ShmGlobalFilter.
 *
 * <p>Extends: AbstractDataProvider<ShmDashboardVO, Void>
 *
 * <p>Dependencies: - ShmTabDataService: Service class to retrieve data for different types of SHM
 * entities. - ShmGlobalFilter: Global filter configuration containing the time range for data
 * queries.
 */
public class ShmTabDashboardDataProvider extends AbstractDataProvider<ShmDashboardVO, Void> {
    private final ShmTabDataService dataProviderService;
    private final ShmGlobalFilter globalFilter;

    public ShmTabDashboardDataProvider(
            ShmTabDataService dataProviderService, ShmGlobalFilter globalFilter) {
        this.dataProviderService = dataProviderService;
        this.globalFilter = globalFilter;
    }

    @Override
    public boolean isInMemory() {
        return false;
    }

    @Override
    public int size(Query<ShmDashboardVO, Void> query) {
        return 1;
    }

    @Override
    public Stream<ShmDashboardVO> fetch(Query<ShmDashboardVO, Void> query) {
        return dataProviderService
                .getData(
                        ShmDashboardVO.class,
                        globalFilter.getTimeRange().getStart(),
                        globalFilter.getTimeRange().getEnd())
                .stream();
    }
}
