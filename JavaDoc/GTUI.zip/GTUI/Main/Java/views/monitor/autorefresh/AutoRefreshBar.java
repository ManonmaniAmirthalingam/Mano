package com.ebtedge.fns.gateway.views.monitor.autorefresh;

import com.google.common.util.concurrent.AtomicDouble;
import com.vaadin.flow.component.*;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.progressbar.ProgressBar;
import com.vaadin.flow.shared.Registration;

import java.util.Optional;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * Represents an auto-refresh progress bar with a cooldown mechanism. The progress bar indicates the
 * time remaining until the next refresh. Provides functionality to start or stop the cooldown
 * timer, and triggers a cooldown completion event at the end of the process.
 */
@Slf4j
public class AutoRefreshBar extends Composite<Div> {
    private static final int PROGRESS_MAX = 100;
    private static final long PROGRESS_UPDATE_INTERVAL_MS = 100;
    private static final String THREAD_NAME = "AutoRefreshBar-Thread";
    private static final String COMPONENT_CLASS_NAME = "auto-refresh-bar";

    private final UI ui;
    private final ProgressBar progressBar;
    private final ScheduledExecutorService scheduler;
    private final AtomicReference<ScheduledFuture<?>> currentTask;
    private final AtomicDouble progressValue;
    private final AtomicBoolean isRunning;

    @Getter @Setter private int cooldownTimeInSeconds;

    public AutoRefreshBar() {
        this.ui = UI.getCurrent();
        this.progressBar = createProgressBar();
        this.scheduler = createScheduler();
        this.currentTask = new AtomicReference<>();
        this.progressValue = new AtomicDouble(0);
        this.isRunning = new AtomicBoolean(false);
    }

    @Override
    protected Div initContent() {
        Div content = new Div(progressBar);
        content.addClassName(COMPONENT_CLASS_NAME);
        content.setWidthFull();
        return content;
    }

    /** Starts the cooldown timer */
    public void startCooldown() {
        stop(false);
        if (cooldownTimeInSeconds <= 0) {
            return;
        }

        log.debug(
                "Thread: {} - Starting cooldown for {} seconds",
                Thread.currentThread(),
                cooldownTimeInSeconds);
        scheduleProgressUpdates();
    }

    private void stop(boolean indeterminate) {
        if (isRunning.compareAndSet(true, false)) {
            updateProgressBarState(0, indeterminate);
            cancelCurrentTask();
            if (!indeterminate) {
                log.debug("Thread: {} - Cooldown stopped", Thread.currentThread());
            }
        }
    }

    private ProgressBar createProgressBar() {
        ProgressBar bar = new ProgressBar(0, PROGRESS_MAX, 0);
        bar.setWidthFull();
        bar.setHeight("1px");
        configureProgressBarStyle(bar);
        return bar;
    }

    private void configureProgressBarStyle(ProgressBar bar) {
        bar.getStyle().setPadding("0px").setMarginTop("0px");
    }

    private ScheduledExecutorService createScheduler() {
        return Executors.newScheduledThreadPool(
                1,
                r -> {
                    Thread thread = new Thread(r, THREAD_NAME);
                    thread.setDaemon(true);
                    return thread;
                });
    }

    private void cancelCurrentTask() {
        Optional.ofNullable(currentTask.get()).ifPresent(task -> task.cancel(true));
    }

    private void scheduleProgressUpdates() {
        updateProgressBarState(PROGRESS_MAX, false);
        isRunning.set(true);
        double progressIncrement = calculateProgressIncrement();

        ScheduledFuture<?> task =
                scheduler.scheduleWithFixedDelay(
                        () -> updateProgress(progressIncrement),
                        0,
                        PROGRESS_UPDATE_INTERVAL_MS,
                        TimeUnit.MILLISECONDS);

        currentTask.set(task);
    }

    private double calculateProgressIncrement() {
        return ((double) PROGRESS_MAX * PROGRESS_UPDATE_INTERVAL_MS)
                / (cooldownTimeInSeconds * 1000);
    }

    private void updateProgress(double progressIncrement) {
        if (!isRunning.get()) {
            return;
        }

        double currentValue = progressValue.get();
        double newValue = Math.max(0, currentValue - progressIncrement);

        if (newValue <= 0) {
            completeCooldown();
        } else {
            updateProgressBarState(newValue, false);
        }
    }

    private void completeCooldown() {
        stop(true);
        log.debug("Thread: {} - Cooldown complete", Thread.currentThread());
        fireEvent(new CooldownCompleteEvent(this));
    }

    private void updateProgressBarState(double value, boolean indeterminate) {
        progressValue.set(value);
        ui.access(
                () -> {
                    progressBar.setValue(value);
                    progressBar.setIndeterminate(indeterminate);
                });
    }

    /**
     * Adds a listener for cooldown completion events
     *
     * @param listener the event listener to add
     * @return registration for removing the listener
     */
    public Registration addCooldownCompleteListener(
            ComponentEventListener<CooldownCompleteEvent> listener) {
        return addListener(CooldownCompleteEvent.class, listener);
    }

    @Override
    protected void onDetach(DetachEvent detachEvent) {
        super.onDetach(detachEvent);
        cleanup();
    }

    private void cleanup() {
        stop(false);
        scheduler.shutdownNow();
    }

    /** Event fired when cooldown completes */
    public static class CooldownCompleteEvent extends ComponentEvent<AutoRefreshBar> {
        public CooldownCompleteEvent(AutoRefreshBar source) {
            super(source, false);
        }
    }
}
