package com.ebtedge.fns.gateway.views.monitor.autorefresh;

import lombok.Getter;

/**
 * Represents the auto-refresh options for a system or component. Provides predefined configurations
 * for refreshing intervals, including an "Off" option to disable auto-refresh.
 */
@Getter
public enum AutoRefreshOption {
    OFF("Off", -1),
    TEN_SECONDS("10s", 10),
    FIFTEEN_SECONDS("15s", 15),
    THIRTY_SECONDS("30s", 30),
    ONE_MINUTE("60s", 60),
    TWO_MINUTES("2m", 120),
    ONE_HOUR("1h", 3600);

    private final String label;
    private final int cooldownTimeInSeconds;

    /**
     * Creates a new auto-refresh option
     *
     * @param label display label for the option
     * @param cooldownTimeInSeconds refresh interval in seconds
     */
    AutoRefreshOption(String label, int cooldownTimeInSeconds) {
        this.label = label;
        this.cooldownTimeInSeconds = cooldownTimeInSeconds;
    }
}
