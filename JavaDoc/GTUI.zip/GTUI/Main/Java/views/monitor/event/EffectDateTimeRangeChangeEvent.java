package com.ebtedge.fns.gateway.views.monitor.event;

import com.ebtedge.fns.gateway.model.DateTimeRange;
import com.ebtedge.fns.gateway.views.monitor.ShmEffectiveDateTimeRangeSelect;
import com.vaadin.flow.component.ComponentEvent;

/**
 * Event fired when the effective date-time range is changed in the monitor This event is used to
 * notify listeners about changes in the selected time range
 */
public class EffectDateTimeRangeChangeEvent
        extends ComponentEvent<ShmEffectiveDateTimeRangeSelect> {

    /**
     * Creates a new date-time range change event
     *
     * @param source The MonitorDateTimeRangeSelect component that triggered the event
     */
    public EffectDateTimeRangeChangeEvent(ShmEffectiveDateTimeRangeSelect source) {
        super(source, /* fromClient */ false);
    }

    /**
     * Gets the currently selected date-time range
     *
     * @return The selected DateTimeRange
     */
    public DateTimeRange getSelectedRange() {
        return getSource().getRange();
    }
}
