package com.ebtedge.fns.gateway.views.monitor.event;

import com.ebtedge.fns.gateway.views.monitor.autorefresh.AutoRefreshOption;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.select.Select;

/**
 * Event fired when the auto-refresh option is changed in a Select component. This event is used to
 * notify listeners about changes in the selected auto-refresh setting.
 */
public class AutoRefreshChangeEvent extends ComponentEvent<Select<AutoRefreshOption>> {

    /**
     * Creates a new auto-refresh change event
     *
     * @param source The Select component that triggered the event
     */
    public AutoRefreshChangeEvent(Select<AutoRefreshOption> source) {
        super(source, /* fromClient */ false);
    }

    /**
     * Gets the currently selected auto-refresh option
     *
     * @return The selected AutoRefreshOption
     */
    public AutoRefreshOption getSelectedOption() {
        return getSource().getValue();
    }
}
