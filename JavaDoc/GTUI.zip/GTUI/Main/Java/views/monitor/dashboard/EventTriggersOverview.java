package com.ebtedge.fns.gateway.views.monitor.dashboard;

import com.ebtedge.fns.gateway.model.ShmDashboardVO;
import com.ebtedge.fns.gateway.model.BaseShmGridVO;
import com.ebtedge.fns.gateway.model.ShmAlert;
import com.ebtedge.fns.gateway.rule.shm.ShmRuleViolation;
import com.ebtedge.fns.gateway.util.DateTimeConvertors;
import com.ebtedge.fns.gateway.util.ShmEventFormatter;
import com.ebtedge.fns.gateway.views.monitor.filters.ShmGlobalFilter;
import com.vaadin.flow.component.Composite;
import com.vaadin.flow.component.charts.Chart;
import com.vaadin.flow.component.charts.model.*;
import com.vaadin.flow.component.charts.model.style.Color;
import com.vaadin.flow.component.charts.model.style.SolidColor;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.TextStyle;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

/**
 * The EventTriggersOverview class is responsible for rendering a graphical overview of event
 * triggers over time. It extends the Composite class with a Chart as the base content. The chart
 * visualizes accumulated event data across different categories such as Links, Gateways, System,
 * and States. The data is presented using a spline chart with time on the x-axis and trigger
 * accumulation on the y-axis. Tooltips, markers, and custom formatting for alerts are included for
 * enhanced interaction and data presentation.
 *
 * <p>The class leverages the ShmEventFormatter for formatting alert descriptions in the tooltip
 * contents.
 */
public class EventTriggersOverview extends Composite<Chart> {

    private static final ZoneId CENTRAL_TIMEZONE = DateTimeConvertors.CENTRAL_TIMEZONE;
    private static final String Y_AXIS_TITLE = "Trigger Accumulation (Total)";
    private static final int MARKER_RADIUS = 3;

    private final ShmGlobalFilter globalFilter;
    private final String title;
    private final ShmEventFormatter alertFormatter;

    public EventTriggersOverview(
            ShmGlobalFilter globalFilter, String title, ShmEventFormatter alertFormatter) {
        this.globalFilter = globalFilter;
        this.title = title;
        this.alertFormatter = alertFormatter;
    }

    @Override
    protected Chart initContent() {
        Chart chart = new Chart(ChartType.SPLINE);
        Configuration conf = chart.getConfiguration();
        Time time = new Time();
        time.setUseUTC(false);
        conf.setTime(time);
        conf.setTitle(title);
        conf.addxAxis(createXAxis());
        conf.addyAxis(createYAxis());
        conf.setTooltip(createTooltip());

        return chart;
    }

    /**
     * Updates the chart with new data
     *
     * @param data Dashboard data containing links, gateways, and states
     * @throws IllegalArgumentException if data is null
     */
    public void setData(ShmDashboardVO data) {
        Objects.requireNonNull(data, "Data cannot be null");

        Configuration config = getContent().getConfiguration();
        config.setSeries(createAllSeries(data));
        XAxis xAxis = config.getxAxis();
        xAxis.setMin(getFilterStartTime().toEpochMilli());
        xAxis.setMax(getFilterEndTime().toEpochMilli());
        getContent().drawChart(true);
    }

    private XAxis createXAxis() {
        XAxis xAxis = new XAxis();
        xAxis.setTitle(CENTRAL_TIMEZONE.getDisplayName(TextStyle.FULL, Locale.US));
        xAxis.setType(AxisType.DATETIME);
        xAxis.setStartOnTick(true);
        xAxis.setEndOnTick(true);
        return xAxis;
    }

    private YAxis createYAxis() {
        YAxis yAxis = new YAxis();
        yAxis.setTitle(Y_AXIS_TITLE);
        yAxis.setType(AxisType.CATEGORY);
        return yAxis;
    }

    private Tooltip createTooltip() {
        Tooltip tooltip = new Tooltip();
        tooltip.setEnabled(true);
        tooltip.setShared(false);
        return tooltip;
    }

    private List<Series> createAllSeries(ShmDashboardVO data) {
        return Arrays.asList(
                createDataSeries("Links", data.getLinks(), SolidColor.BLUE),
                createDataSeries("Gateways", data.getGateways(), SolidColor.ORANGE),
                createDataSeries("System", data.getSystem(), SolidColor.GRAY),
                createDataSeries("States", data.getStates(), SolidColor.CYAN));
    }

    private DataSeries createDataSeries(
            String title, List<? extends BaseShmGridVO> data, Color color) {
        DataSeries series = new DataSeries(title);
        series.setPlotOptions(createPlotOptions(color));

        AtomicInteger counter = new AtomicInteger();
        getEventStream(data)
                .sorted(Map.Entry.comparingByKey())
                .forEach(event -> addDataPoint(series, event, counter));

        return series;
    }

    private Stream<Map.Entry<ShmAlert, Integer>> getEventStream(
            List<? extends BaseShmGridVO> data) {
        return data.stream()
                .map(BaseShmGridVO::getRuleViolations)
                .flatMap(Collection::stream)
                .map(ShmRuleViolation::getAlertAccumulation)
                .map(Map::entrySet)
                .flatMap(Collection::stream);
    }

    private void addDataPoint(
            DataSeries series, Map.Entry<ShmAlert, Integer> event, AtomicInteger counter) {
        DataSeriesItem item =
                new DataSeriesItem(
                        event.getKey().getTimestamp(),
                        counter.updateAndGet(count -> count + event.getValue()));
        item.setDescription(alertFormatter.formatHtml(event));
        series.add(item);
    }

    private PlotOptionsSpline createPlotOptions(Color color) {
        PlotOptionsSpline options = new PlotOptionsSpline();
        options.setTooltip(createSeriesTooltip());
        options.setMarker(createMarker(color));
        options.setColor(color);
        options.setShowInLegend(true);
        options.setTurboThreshold(0);
        return options;
    }

    private SeriesTooltip createSeriesTooltip() {
        SeriesTooltip tooltip = new SeriesTooltip();
        tooltip.setHeaderFormat("");
        tooltip.setPointFormatter("function(){ return `${this.description}`; }");
        return tooltip;
    }

    private Marker createMarker(Color color) {
        Marker marker = new Marker(true);
        marker.setFillColor(color);
        marker.setRadius(MARKER_RADIUS);
        marker.setSymbol(MarkerSymbolEnum.CIRCLE);
        return marker;
    }

    private Instant getFilterStartTime() {
        return globalFilter.getTimeRange().getStart().atZone(CENTRAL_TIMEZONE).toInstant();
    }

    private Instant getFilterEndTime() {
        return globalFilter.getTimeRange().getEnd().atZone(CENTRAL_TIMEZONE).toInstant();
    }
}
