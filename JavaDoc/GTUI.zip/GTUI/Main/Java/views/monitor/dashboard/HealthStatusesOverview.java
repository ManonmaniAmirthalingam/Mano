package com.ebtedge.fns.gateway.views.monitor.dashboard;

import com.ebtedge.fns.gateway.model.ShmStatus;
import com.ebtedge.fns.gateway.model.BaseShmGridVO;
import com.vaadin.flow.component.Composite;
import com.vaadin.flow.component.charts.Chart;
import com.vaadin.flow.component.charts.model.*;
import com.vaadin.flow.component.charts.model.style.SolidColor;
import com.vaadin.flow.component.html.*;
import com.vaadin.flow.component.orderedlayout.*;
import com.vaadin.flow.dom.Style;
import com.vaadin.flow.theme.lumo.LumoUtility;

import java.util.*;
import java.util.stream.Collectors;

/**
 * The HealthStatusesOverview class is a UI component used to display an overview of health statuses
 * in a visually appealing way using a donut chart, a status indicator, and a total count of items.
 * It extends Composite<VerticalLayout>, encapsulating various child components and creating a
 * cohesive layout.
 *
 * <p>The main purpose of this class is to provide a summary of health data grouped by status,
 * visually represented with interactive elements that include: - A status indicator indicating the
 * most critical status. - A donut chart displaying proportions of each health status. - A total
 * count display showing the count of unhealthy items out of the total.
 *
 * <p>The class relies on input data in the form of a list of BaseShmGridVO instances, which contain
 * information about the health statuses and counts. It processes this input data to update the
 * display dynamically.
 */
public class HealthStatusesOverview extends Composite<VerticalLayout> {
    private static final String CHART_SIZE = "200px";
    private static final String STATUS_INDICATOR_SIZE = "12px";

    private final String title;
    private final Div statusIndicator;
    private final Span totalCounter;
    private final Chart donutChart;

    public HealthStatusesOverview(String title) {
        this.title = title;
        this.statusIndicator = createStatusIndicator();
        this.totalCounter = createTotalCounter();
        this.donutChart = createDonutChart();
    }

    @Override
    protected VerticalLayout initContent() {
        VerticalLayout layout = new VerticalLayout(createHeader(), createChartWrapper());
        layout.setAlignItems(FlexComponent.Alignment.CENTER);
        return layout;
    }

    /**
     * Updates the chart and status indicator with new data
     *
     * @param data List of monitor grid items to display
     */
    public void setData(List<? extends BaseShmGridVO> data) {
        Map<ShmStatus, List<BaseShmGridVO>> statusMap = groupDataByStatus(data);
        updateStatusIndicator(statusMap);
        updateChart(statusMap);
        updateTotalCounter(statusMap);
    }

    private Div createStatusIndicator() {
        Div indicator = new Div();
        Style style = indicator.getStyle();
        style.set("width", STATUS_INDICATOR_SIZE)
                .set("height", STATUS_INDICATOR_SIZE)
                .setBackgroundColor(SolidColor.GREY.toString())
                .setBorderRadius("50%")
                .setDisplay(Style.Display.INLINE_BLOCK);
        return indicator;
    }

    private Span createTotalCounter() {
        Span counter = new Span();
        Style style = counter.getStyle();
        style.setPosition(Style.Position.ABSOLUTE)
                .setTop("50%")
                .setLeft("50%")
                .setTransform("translate(-50%, -50%)");
        return counter;
    }

    private Chart createDonutChart() {
        Chart chart = new Chart(ChartType.PIE);
        Configuration conf = chart.getConfiguration();

        conf.setTooltip(createTooltip());
        conf.setPlotOptions(createPlotOptions());

        chart.setWidth(CHART_SIZE);
        chart.setHeight(CHART_SIZE);

        return chart;
    }

    private Tooltip createTooltip() {
        Tooltip tooltip = new Tooltip();
        tooltip.setEnabled(true);
        tooltip.setShared(false);
        tooltip.setPointFormat("{point.y}");
        return tooltip;
    }

    private PlotOptionsPie createPlotOptions() {
        PlotOptionsPie options = new PlotOptionsPie();
        options.setInnerSize("60%");
        options.getDataLabels().setEnabled(false);
        return options;
    }

    private HorizontalLayout createHeader() {
        H2 titleText = new H2(title);
        titleText.addClassNames(LumoUtility.FontWeight.NORMAL, LumoUtility.FontSize.MEDIUM);

        HorizontalLayout header = new HorizontalLayout(statusIndicator, titleText);
        header.setAlignItems(FlexComponent.Alignment.CENTER);
        header.addClassName(LumoUtility.Gap.SMALL);

        return header;
    }

    private Div createChartWrapper() {
        Div wrapper = new Div(donutChart, totalCounter);
        wrapper.setWidth(CHART_SIZE);
        wrapper.setHeight(CHART_SIZE);
        wrapper.getStyle().setPosition(Style.Position.RELATIVE);
        return wrapper;
    }

    private Map<ShmStatus, List<BaseShmGridVO>> groupDataByStatus(
            List<? extends BaseShmGridVO> data) {
        return Optional.ofNullable(data).stream()
                .flatMap(Collection::stream)
                .collect(Collectors.groupingBy(BaseShmGridVO::getHealthStatus));
    }

    private void updateStatusIndicator(Map<ShmStatus, List<BaseShmGridVO>> statusMap) {
        SolidColor color = determineStatusColor(statusMap);
        statusIndicator.getStyle().setBackgroundColor(color.toString());
    }

    private SolidColor determineStatusColor(Map<ShmStatus, List<BaseShmGridVO>> statusMap) {
        if (statusMap.containsKey(ShmStatus.UNHEALTHY)) {
            return SolidColor.RED;
        } else if (statusMap.containsKey(ShmStatus.HEALTHY)) {
            return SolidColor.GREEN;
        }
        return SolidColor.GREY;
    }

    private void updateChart(Map<ShmStatus, List<BaseShmGridVO>> statusMap) {
        DataSeries series = new DataSeries(title);
        statusMap.forEach((status, list) -> series.add(createDataSeriesItem(status, list.size())));

        donutChart.getConfiguration().setSeries(series);
        series.updateSeries();
    }

    private DataSeriesItem createDataSeriesItem(ShmStatus status, int count) {
        return new DataSeriesItem(
                status.getValue(),
                count,
                status == ShmStatus.HEALTHY ? SolidColor.GREEN : SolidColor.RED);
    }

    private void updateTotalCounter(Map<ShmStatus, List<BaseShmGridVO>> statusMap) {
        int unhealthyCount = statusMap.getOrDefault(ShmStatus.UNHEALTHY, List.of()).size();
        int totalCount = statusMap.values().stream().mapToInt(List::size).sum();

        totalCounter.setText(String.format("%d/%d", unhealthyCount, totalCount));
    }
}
