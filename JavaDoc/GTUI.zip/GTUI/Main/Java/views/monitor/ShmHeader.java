package com.ebtedge.fns.gateway.views.monitor;

import com.ebtedge.fns.gateway.config.GatAppConfig;
import com.ebtedge.fns.gateway.views.monitor.autorefresh.AutoRefreshBar;
import com.ebtedge.fns.gateway.views.monitor.autorefresh.AutoRefreshOption;
import com.ebtedge.fns.gateway.views.monitor.event.AutoRefreshChangeEvent;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.Composite;
import com.vaadin.flow.component.DetachEvent;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.FlexLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.select.Select;
import com.vaadin.flow.dom.Style;
import com.vaadin.flow.shared.Registration;
import com.vaadin.flow.theme.lumo.LumoUtility;
import lombok.Getter;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

/**
 * The {@code ShmHeader} class represents the header component for the System Health Monitor (SHM)
 * UI. It extends {@code Composite<VerticalLayout>} to provide a structured and reusable design for
 * the header containing essential UI elements such as an auto-refresh bar, date-time range
 * selector, and header controls.
 *
 * <p>This class encapsulates the creation and initialization of the UI layout and its components,
 * managing their configuration and interactions. It provides responsive support for maintaining
 * proper alignment, spacing, and aesthetics in the header area.
 */
public class ShmHeader extends Composite<VerticalLayout> {
    private static final String HEADING_TEXT = "System Health";
    private static final int AUTO_REFRESH_WIDTH = 110;
    public static final String AUTO_REFRESH_LABEL = "Auto Refresh";
    public static final AutoRefreshOption DEFAULT_AUTO_REFRESH_OPTION =
            AutoRefreshOption.TEN_SECONDS;

    private final List<Registration> registrations;

    @Getter private final AutoRefreshBar autoRefreshBar;
    @Getter private final ShmEffectiveDateTimeRangeSelect dateTimeRangeSelect;
    @Getter private final Select<AutoRefreshOption> autoRefreshSelect;

    public ShmHeader(GatAppConfig appConfig) {
        this.registrations = new ArrayList<>();
        this.autoRefreshBar = createAutoRefreshBar();
        this.autoRefreshSelect = createRefreshControl();
        this.dateTimeRangeSelect = createDateTimeRangeSelect(appConfig);
    }

    @Override
    protected VerticalLayout initContent() {
        VerticalLayout layout = new VerticalLayout();
        layout.setPadding(false);
        layout.setSpacing(false);

        layout.add(autoRefreshBar, createMainContent());

        return layout;
    }

    @Override
    protected void onDetach(DetachEvent detachEvent) {
        super.onDetach(detachEvent);
        cleanup();
    }

    private Component createMainContent() {
        VerticalLayout wrapper = new VerticalLayout();
        wrapper.setWidthFull();
        wrapper.addClassNames(LumoUtility.Padding.NONE);
        FlexLayout mainContentLayout = createContentLayout();
        Div headingSpacer = new Div(createHeading());
        headingSpacer.addClassName(LumoUtility.Padding.Horizontal.MEDIUM);
        Div menuBarSpacer = new Div(createMenuBar());
        menuBarSpacer.addClassName(LumoUtility.Padding.Horizontal.MEDIUM);
        mainContentLayout.add(headingSpacer, menuBarSpacer);
        wrapper.add(mainContentLayout);
        return wrapper;
    }

    private FlexLayout createContentLayout() {
        FlexLayout layout = new FlexLayout();
        layout.setWidthFull();
        layout.setFlexWrap(FlexLayout.FlexWrap.WRAP);
        layout.setJustifyContentMode(FlexComponent.JustifyContentMode.BETWEEN);
        layout.setAlignItems(FlexComponent.Alignment.CENTER);
        return layout;
    }

    private AutoRefreshBar createAutoRefreshBar() {
        AutoRefreshBar bar = new AutoRefreshBar();
        setupAutoRefreshListener(bar);
        return bar;
    }

    private void setupAutoRefreshListener(AutoRefreshBar bar) {
        registrations.add(
                addListener(AutoRefreshChangeEvent.class, event -> updateAutoRefresh(bar, event)));
    }

    private void updateAutoRefresh(AutoRefreshBar bar, AutoRefreshChangeEvent event) {
        int cooldownTime = event.getSource().getValue().getCooldownTimeInSeconds();
        bar.setCooldownTimeInSeconds(cooldownTime);
        bar.startCooldown();
    }

    private Component createHeading() {
        H2 heading = new H2(HEADING_TEXT);
        heading.addClassNames(LumoUtility.FontSize.XXLARGE, LumoUtility.Padding.Horizontal.MEDIUM);
        heading.getStyle()
                .setDisplay(Style.Display.INLINE_BLOCK)
                .setWhiteSpace(Style.WhiteSpace.NOWRAP);
        return heading;
    }

    private Component createMenuBar() {
        FlexLayout menuBar = new FlexLayout();
        menuBar.setFlexWrap(FlexLayout.FlexWrap.WRAP);
        menuBar.addClassNames(LumoUtility.Gap.SMALL, LumoUtility.Padding.Horizontal.MEDIUM);
        menuBar.setJustifyContentMode(FlexComponent.JustifyContentMode.END);
        menuBar.add(dateTimeRangeSelect, autoRefreshSelect);

        return menuBar;
    }

    private Select<AutoRefreshOption> createRefreshControl() {
        Select<AutoRefreshOption> control = new Select<>();
        control.setPrefixComponent(VaadinIcon.REFRESH.create());
        control.setMaxWidth(AUTO_REFRESH_WIDTH + "px");
        control.setItemLabelGenerator(AutoRefreshOption::getLabel);
        control.setItems(AutoRefreshOption.values());
        control.setValue(DEFAULT_AUTO_REFRESH_OPTION);
        control.setLabel(AUTO_REFRESH_LABEL);
        setupRefreshControlListeners(control);
        return control;
    }

    private void setupRefreshControlListeners(Select<AutoRefreshOption> control) {
        fireEvent(new AutoRefreshChangeEvent(control));
        control.addValueChangeListener(event -> fireEvent(new AutoRefreshChangeEvent(control)));
    }

    private ShmEffectiveDateTimeRangeSelect createDateTimeRangeSelect(GatAppConfig appConfig) {
        ShmEffectiveDateTimeRangeSelect select = new ShmEffectiveDateTimeRangeSelect();
        configureDateTimeRange(select, appConfig);
        return select;
    }

    private void configureDateTimeRange(
            ShmEffectiveDateTimeRangeSelect select, GatAppConfig appConfig) {
        Duration retention = appConfig.getDataRetentionDuration();
        LocalDateTime todayAtBeginning = LocalDateTime.of(LocalDate.now(), LocalTime.MIN);
        select.setMin(todayAtBeginning.minus(retention));
    }

    private void cleanup() {
        registrations.forEach(Registration::remove);
        registrations.clear();
    }
}
