package com.ebtedge.fns.gateway.views.monitor;

import com.ebtedge.fns.gateway.components.DateTimeRangePicker;
import com.ebtedge.fns.gateway.model.DateTimeRange;
import com.ebtedge.fns.gateway.views.monitor.event.EffectDateTimeRangeChangeEvent;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.Composite;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexLayout;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.data.provider.ListDataProvider;
import com.vaadin.flow.dom.Style;
import com.vaadin.flow.shared.Registration;
import com.vaadin.flow.theme.lumo.LumoUtility;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.vaadin.firitin.components.button.VButton;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.List;

/**
 * Represents a UI component for selecting effective date and time ranges, either from predefined
 * options or by specifying a custom range. This component combines a date-time range picker, a
 * combobox for predefined ranges, and optional actions for applying or canceling custom input.
 *
 * <p>The component provides functionality to define minimum and maximum date-time boundaries,
 * trigger change events when the selected range changes, and toggle between select mode and input
 * mode for custom date-time ranges.
 */
public class ShmEffectiveDateTimeRangeSelect extends Composite<FlexLayout> {
    private static final String START_DATE_TIME_LABEL = "Start Date/Time (CST)";
    private static final String END_DATE_TIME_LABEL = "End Date/Time (CST)";
    private static final DateTimeFormatter DATE_TIME_FORMATTER =
            DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm");
    private static final DateTimeRangeOption DEFAULT_OPTION = DateTimeRangeOption.LAST_FIVE_MINUTES;
    public static final String EFFECTIVE_TIME_RANGE_LABEL = "Effective Time Range";

    private final DateTimeRangePicker dateTimeRangePicker;
    private final ComboBox<DateTimeRangeOption> rangeComboBox;
    private final ListDataProvider<DateTimeRangeOption> rangeDataProvider;

    private Component actionsContainer;
    private DateTimeRangeOption previousOption;
    private DateTimeRange customRange;

    public ShmEffectiveDateTimeRangeSelect() {
        this.dateTimeRangePicker = createDateTimeRangePicker();
        this.rangeDataProvider = createRangeDataProvider();
        this.rangeComboBox = createRangeComboBox();
    }

    /**
     * Sets the maximum selectable date and time for the date-time range picker.
     *
     * @param max the maximum date and time that can be selected. It should not be null.
     */
    public void setMax(LocalDateTime max) {
        dateTimeRangePicker.setMax(max);
    }

    /**
     * Sets the minimum selectable date and time for the date-time range picker.
     *
     * @param min the minimum date and time that can be selected. It should not be null.
     */
    public void setMin(LocalDateTime min) {
        dateTimeRangePicker.setMin(min);
    }

    /**
     * Retrieves the currently selected date-time range based on the selected option. If the option
     * is a custom range, the custom range is returned. If the option does not support a range or an
     * error occurs, the previous option's range is returned.
     *
     * @return the selected {@code DateTimeRange}, which may correspond to a predefined or custom
     *     range. If an unsupported operation occurs, the range of the previous option is returned.
     */
    public DateTimeRange getRange() {
        DateTimeRangeOption currentOption = rangeComboBox.getValue();
        try {
            return rangeComboBox.getValue() == DateTimeRangeOption.CUSTOM_RANGE_VALUE
                    ? customRange
                    : currentOption.getRange();
        } catch (UnsupportedOperationException e) {
            return previousOption.getRange();
        }
    }

    public boolean isCustomRangeSelected() {
        return rangeComboBox.getValue() == DateTimeRangeOption.CUSTOM_RANGE_VALUE;
    }

    /**
     * Adds a listener that will be notified when the effective date-time range is changed. The
     * listener will receive an {@code EffectDateTimeRangeChangeEvent} with details about the
     * change.
     *
     * @param listener the listener to be added, which will handle {@code
     *     EffectDateTimeRangeChangeEvent} events
     * @return a {@code Registration} object that can be used to remove the listener
     */
    public Registration addChangeListener(
            ComponentEventListener<EffectDateTimeRangeChangeEvent> listener) {
        return addListener(EffectDateTimeRangeChangeEvent.class, listener);
    }

    @Override
    protected FlexLayout initContent() {
        FlexLayout layout = new FlexLayout();
        configureLayout(layout);

        actionsContainer = createActionsContainer();
        setMode(Mode.SELECT);

        layout.add(dateTimeRangePicker, rangeComboBox, actionsContainer);
        return layout;
    }

    private void configureLayout(FlexLayout layout) {
        layout.addClassNames(LumoUtility.Gap.MEDIUM, LumoUtility.JustifyContent.END);
    }

    private DateTimeRangePicker createDateTimeRangePicker() {
        DateTimeRangePicker picker =
                new DateTimeRangePicker(START_DATE_TIME_LABEL, END_DATE_TIME_LABEL);
        picker.setRequiredIndicatorVisible(true);
        return picker;
    }

    private ListDataProvider<DateTimeRangeOption> createRangeDataProvider() {
        List<DateTimeRangeOption> options = Arrays.asList(DateTimeRangeOption.values());
        ListDataProvider<DateTimeRangeOption> provider = new ListDataProvider<>(options);
        provider.setFilter(this::filterRangeOption);
        return provider;
    }

    private boolean filterRangeOption(DateTimeRangeOption option) {
        return option != DateTimeRangeOption.CUSTOM_RANGE_VALUE || customRange != null;
    }

    private ComboBox<DateTimeRangeOption> createRangeComboBox() {
        ComboBox<DateTimeRangeOption> comboBox = new ComboBox<>(EFFECTIVE_TIME_RANGE_LABEL);
        configureRangeComboBox(comboBox);
        setupRangeComboBoxListeners(comboBox);
        return comboBox;
    }

    private void configureRangeComboBox(ComboBox<DateTimeRangeOption> comboBox) {
        comboBox.setPrefixComponent(VaadinIcon.TIME_BACKWARD.create());
        comboBox.setItemLabelGenerator(this::generateRangeLabel);
        comboBox.setItems(rangeDataProvider);
        comboBox.setValue(DEFAULT_OPTION);
        comboBox.setMinWidth("160px");
    }

    private String generateRangeLabel(DateTimeRangeOption option) {
        if (option == DateTimeRangeOption.CUSTOM_RANGE_VALUE) {
            return formatCustomRange();
        }
        return option.getLabel();
    }

    private String formatCustomRange() {
        return DATE_TIME_FORMATTER.format(customRange.getStart())
                + " - "
                + DATE_TIME_FORMATTER.format(customRange.getEnd());
    }

    private void setupRangeComboBoxListeners(ComboBox<DateTimeRangeOption> comboBox) {
        comboBox.addValueChangeListener(
                event -> {
                    previousOption = event.getOldValue();
                    DateTimeRangeOption currentOption = comboBox.getValue();

                    if (currentOption == DateTimeRangeOption.CUSTOM_RANGE) {
                        setMode(Mode.INPUTS);
                    } else {
                        if (currentOption != DateTimeRangeOption.CUSTOM_RANGE_VALUE) {
                            customRange = null;
                        }
                        comboBox.getDataProvider().refreshAll();
                        fireEvent(new EffectDateTimeRangeChangeEvent(this));
                    }
                });
    }

    private Component createActionsContainer() {
        HorizontalLayout container = new HorizontalLayout();
        container.addClassName(LumoUtility.Padding.End.MEDIUM);
        Button applyButton = createActionButton(VaadinIcon.CHECK, this::handleApply);
        Button cancelButton = createActionButton(VaadinIcon.CLOSE, this::handleCancel);
        container.add(applyButton, cancelButton);
        return container;
    }

    private Button createActionButton(VaadinIcon icon, Runnable clickHandler) {
        Button button = new Button(icon.create());
        button.addThemeVariants(ButtonVariant.LUMO_ICON);
        configureActionButton(button);
        button.addClickListener(e -> clickHandler.run());
        return button;
    }

    private void configureActionButton(Button button) {
        button.addClassName(LumoUtility.Margin.Top.XLARGE);
        button.addThemeName(VButton.ButtonSize.SMALL.getThemeName());
        button.getStyle().setAlignSelf(Style.AlignSelf.FLEX_START);
    }

    private void handleApply() {
        if (dateTimeRangePicker.isInvalid()) {
            return;
        }
        customRange = dateTimeRangePicker.getValue();
        rangeComboBox.setValue(DateTimeRangeOption.CUSTOM_RANGE_VALUE);
        setMode(Mode.SELECT);
    }

    private void handleCancel() {
        rangeComboBox.setValue(previousOption);
        setMode(Mode.SELECT);
    }

    private void setMode(Mode mode) {
        switch (mode) {
            case SELECT -> setSelectMode();
            case INPUTS -> setInputsMode();
        }
    }

    private void setSelectMode() {
        dateTimeRangePicker.setVisible(false);
        actionsContainer.setVisible(false);
        rangeComboBox.setVisible(true);
    }

    private void setInputsMode() {
        updateDateTimeRangePickerValues();
        dateTimeRangePicker.setVisible(true);
        dateTimeRangePicker.setMax(LocalDateTime.of(LocalDate.now(), LocalTime.MAX));
        actionsContainer.setVisible(true);
        rangeComboBox.setVisible(false);
    }

    private void updateDateTimeRangePickerValues() {
        DateTimeRange range =
                previousOption == DateTimeRangeOption.CUSTOM_RANGE_VALUE
                        ? customRange
                        : previousOption.getRange();
        dateTimeRangePicker.setValue(range);
    }

    private enum Mode {
        SELECT,
        INPUTS
    }

    /**
     * Enumerates predefined date-time range options, commonly used for selecting or filtering
     * periods of time in UI components or other functionality related to time ranges.
     *
     * <p>Each enumerated value defines a specific range by specifying an amount of time, a unit of
     * time measurement, and a descriptive label. The range is typically computed relative to the
     * current date and time.
     *
     * <p>Special values such as `YESTERDAY`, `CUSTOM_RANGE`, and `CUSTOM_RANGE_VALUE` override
     * default behavior to provide specific implementations or to denote ranges not supported by
     * default operations.
     */
    @RequiredArgsConstructor
    @Getter
    public enum DateTimeRangeOption {
        LAST_FIVE_MINUTES(5, ChronoUnit.MINUTES, "Last 5 minutes"),
        LAST_FIFTEEN_MINUTES(15, ChronoUnit.MINUTES, "Last 15 minutes"),
        LAST_THIRTY_MINUTES(30, ChronoUnit.MINUTES, "Last 30 minutes"),
        LAST_ONE_HOUR(1, ChronoUnit.HOURS, "Last 1 hour"),
        LAST_THREE_HOURS(3, ChronoUnit.HOURS, "Last 3 hours"),
        LAST_SIX_HOURS(6, ChronoUnit.HOURS, "Last 6 hours"),
        LAST_TWELVE_HOURS(12, ChronoUnit.HOURS, "Last 12 hours"),
        LAST_TWENTY_FOUR_HOURS(24, ChronoUnit.HOURS, "Last 24 hours"),
        YESTERDAY(1, ChronoUnit.DAYS, "Yesterday") {
            @Override
            public DateTimeRange getRange() {
                LocalDateTime end = LocalDate.now().minusDays(1).atTime(LocalTime.MAX);
                return new DateTimeRange(end.minusDays(1), end);
            }
        },
        CUSTOM_RANGE(0, null, "Custom range") {
            @Override
            public DateTimeRange getRange() {
                throw new UnsupportedOperationException("Not supported");
            }
        },
        CUSTOM_RANGE_VALUE(0, null, null) {
            @Override
            public DateTimeRange getRange() {
                throw new UnsupportedOperationException("Not supported");
            }

            @Override
            public String getLabel() {
                throw new UnsupportedOperationException("Not supported");
            }
        };

        private final long amount;
        private final ChronoUnit unit;
        private final String label;

        public DateTimeRange getRange() {
            LocalDateTime end = LocalDateTime.now();
            LocalDateTime start = end.minus(amount, unit);
            return new DateTimeRange(start, end);
        }
    }
}
