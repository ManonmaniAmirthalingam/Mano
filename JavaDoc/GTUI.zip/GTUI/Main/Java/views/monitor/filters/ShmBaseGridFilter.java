package com.ebtedge.fns.gateway.views.monitor.filters;

import com.ebtedge.fns.gateway.model.ShmStatus;
import com.ebtedge.fns.gateway.model.BaseShmGridVO;
import com.vaadin.flow.component.ItemLabelGenerator;
import com.vaadin.flow.function.SerializablePredicate;
import lombok.Data;
import java.util.Optional;
import java.util.Set;
import java.util.function.BiPredicate;

/**
 * A generic base class for filtering grid items in the System Health Monitoring (SHM) framework.
 * This class provides mechanisms for filtering items based on their name and health status.
 *
 * @param <T> The type of grid view object, which must extend BaseShmGridVO
 */
@Data
public class ShmBaseGridFilter<T extends BaseShmGridVO> {
    private static final String EMPTY_STRING = "";
    private final BiPredicate<T, String> comboboxItemFilter =
            (item, filterText) -> containsIgnoreCase(item.getName(), filterText);
    private final ItemLabelGenerator<T> itemLabelGenerator = BaseShmGridVO::getName;
    protected Set<String> names;
    protected ShmStatus healthStatus;

    /**
     * Creates a predicate for filtering grid items based on name and health status
     *
     * @return A predicate that combines name and status filtering
     */
    public SerializablePredicate<T> getPredicate() {
        return item -> isNameMatching(item) && isStatusMatching(item);
    }

    /**
     * Checks if an item matches the name filter criteria
     *
     * @param item The item to check
     * @return true if the item matches the name filter or if no name filter is set
     */
    protected boolean isNameMatching(T item) {
        return Optional.ofNullable(names)
                .map(
                        names ->
                                names.isEmpty()
                                        || names.stream()
                                                .anyMatch(
                                                        name ->
                                                                containsIgnoreCase(
                                                                        item.getName(), name)))
                .orElse(true);
    }

    /**
     * Checks if an item matches the health status filter criteria
     *
     * @param item The item to check
     * @return true if the item matches the status filter or if no status filter is set
     */
    protected boolean isStatusMatching(T item) {
        return Optional.ofNullable(healthStatus)
                .map(status -> item.getHealthStatus() == status)
                .orElse(true);
    }

    protected boolean containsIgnoreCase(String source, String target) {
        return Optional.ofNullable(source)
                .map(String::toLowerCase)
                .orElse(EMPTY_STRING)
                .contains(
                        Optional.ofNullable(target).map(String::toLowerCase).orElse(EMPTY_STRING));
    }
}
