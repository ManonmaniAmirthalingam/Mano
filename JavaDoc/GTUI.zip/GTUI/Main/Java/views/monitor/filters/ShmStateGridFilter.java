package com.ebtedge.fns.gateway.views.monitor.filters;

import com.ebtedge.fns.gateway.model.ShmStateBinGridVO;
import com.vaadin.flow.component.ItemLabelGenerator;
import lombok.Getter;
import lombok.Setter;

import java.util.function.BiPredicate;

/**
 * The ShmStateGridFilter class extends the functionality of ShmBaseGridFilter to provide
 * specialized filtering for ShmStateBinGridVO objects. It introduces additional filtering
 * capabilities based on a bin-related search text.
 *
 * <p>This class is designed to enhance filtering of state bin grid items within the System Health
 * Monitoring (SHM) application, allowing more specific filtering criteria to be applied.
 *
 * <p>Inherited functionality from the ShmBaseGridFilter base class includes: - Ability to filter
 * items based on name and health status. - Predicate creation for combining different filtering
 * criteria.
 */
@Getter
@Setter
public class ShmStateGridFilter extends ShmBaseGridFilter<ShmStateBinGridVO> {
    private final BiPredicate<ShmStateBinGridVO, String> comboboxItemFilter = (item, filterText) -> containsIgnoreCase(item.getState(), filterText) || containsIgnoreCase(item.getBin(), filterText);
    private final ItemLabelGenerator<ShmStateBinGridVO> itemLabelGenerator = item -> item.getState() + " - " + item.getBin();
}
