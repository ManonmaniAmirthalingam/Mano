package com.ebtedge.fns.gateway.views.monitor.filters;

import static com.ebtedge.fns.gateway.views.monitor.ShmEffectiveDateTimeRangeSelect.*;

import com.ebtedge.fns.gateway.model.DateTimeRange;
import com.ebtedge.fns.gateway.views.monitor.ShmView;
import com.vaadin.flow.spring.annotation.*;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;

/**
 * The ShmGlobalFilter class is a global filter component responsible for managing time range
 * settings and cache key invalidation in the context of the system health monitor (SHM)
 * application.
 *
 * <p>It allows updating of the active time range, tracks changes to the range, and generates a new
 * cache key whenever the range changes or is manually invalidated. This ensures that data related
 * to the new time range is properly re-evaluated when required.
 *
 * <p>An embedded logging mechanism is used to provide debug information about cache key resets and
 * time range updates.
 */
@Slf4j
@Scope(value = "vaadin-route", proxyMode = ScopedProxyMode.TARGET_CLASS)
@RouteScope
@RouteScopeOwner(ShmView.class)
@Component
public class ShmGlobalFilter {

    private static final AtomicReference<String> cacheKey =
            new AtomicReference<>(generateNewCacheKey());

    @Getter private DateTimeRange timeRange;

    public ShmGlobalFilter() {
        initializeTimeRange();
    }

    /**
     * Updates the time range and invalidates the cache
     *
     * @param newTimeRange The new time range to set
     */
    public void setTimeRange(DateTimeRange newTimeRange) {
        if (hasTimeRangeChanged(newTimeRange)) {
            updateTimeRangeAndCacheKey(newTimeRange);
        }
    }

    /**
     * Retrieves the current cache key
     *
     * @return Current cache key
     */
    public String getCacheKey() {
        return cacheKey.get();
    }

    /** Forces cache invalidation by generating a new cache key */
    public void resetCacheKey() {
        cacheKey.set(generateNewCacheKey());
        log.debug("Cache key reset to: {}", getCacheKey());
    }

    private void initializeTimeRange() {
        timeRange = DateTimeRangeOption.LAST_FIVE_MINUTES.getRange();
    }

    private boolean hasTimeRangeChanged(DateTimeRange newTimeRange) {
        return !timeRange.equals(newTimeRange);
    }

    private void updateTimeRangeAndCacheKey(DateTimeRange newTimeRange) {
        timeRange = newTimeRange;
        resetCacheKey();
        log.debug("Time range updated to: {}", newTimeRange);
    }

    private static String generateNewCacheKey() {
        return UUID.randomUUID().toString();
    }
}
