package com.ebtedge.fns.gateway.views.monitor;

import com.ebtedge.fns.gateway.components.DetailsDrawer;
import com.ebtedge.fns.gateway.model.BaseShmGridVO;
import com.ebtedge.fns.gateway.model.ShmAlert;
import com.ebtedge.fns.gateway.rule.RuleType;
import com.ebtedge.fns.gateway.rule.shm.ShmRuleType;
import com.ebtedge.fns.gateway.rule.shm.ShmRuleViolation;
import com.ebtedge.fns.gateway.service.ShmRuleMetaService;
import com.ebtedge.fns.gateway.util.DateTimeConvertors;
import com.ebtedge.yb.entity.ShmRuleMeta;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.Text;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.H5;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.data.provider.ListDataProvider;
import com.vaadin.flow.theme.lumo.LumoUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.vaadin.klaudeta.PaginatedGrid;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * ShmDetailsPanel is a UI component that extends the Div class and implements the DrawableDetails
 * interface for displaying detailed information about a selected BaseShmGridVO instance. It
 * provides a structured layout to present information such as health details, trigger details, and
 * violated rules using forms, grids, and other UI components.
 *
 * <p>This class is specifically designed to cater to system health monitoring needs, using detailed
 * formatting and dynamic configuration of UI components based on the data provided in the
 * BaseShmGridVO model. It ensures responsiveness and visual clarity through well-defined layouts
 * and styles.
 */
public class ShmDetailsPanel extends VerticalLayout
        implements DetailsDrawer.DrawableDetails<BaseShmGridVO> {
    private static final int TRIGGERS_PAGE_SIZE = 16;
    private static final int PAGINATOR_SIZE = 5;

    private final AlertGridFactory alertGridFactory;

    public ShmDetailsPanel(ShmRuleMetaService ruleMetaService) {
        this.alertGridFactory = new AlertGridFactory(ruleMetaService);
        addClassName("system-health-monitor-details");
    }

    @Override
    public void showDetails(BaseShmGridVO selectedItem) {
        removeAll();
        add(createContent(selectedItem));
    }

    private Component createContent(BaseShmGridVO item) {
        VerticalLayout content = new VerticalLayout();
        content.addClassNames(LumoUtility.Padding.Vertical.NONE);
        content.setWidthFull();
        content.add(createHealthOverviewContent(item), createTriggersContent(item));
        return content;
    }

    private Component createHealthOverviewContent(BaseShmGridVO item) {
        Div content = new Div();
        content.setWidthFull();
        content.addClassNames(LumoUtility.Border.ALL, LumoUtility.BorderRadius.MEDIUM);
        content.add(createTitle("Health Overview"), createHealthOverviewForm(item));
        return content;
    }

    private Component createTitle(String title) {
        Div headingWrapper = new Div();
        headingWrapper.addClassNames("heading");
        headingWrapper.setWidthFull();
        H5 titleEl = new H5(title);
        titleEl.addClassNames(LumoUtility.Padding.MEDIUM);
        headingWrapper.add(titleEl);
        return headingWrapper;
    }

    private FormLayout createHealthOverviewForm(BaseShmGridVO item) {
        FormLayout form = new FormLayout();
        configureFormLayout(form);
        addFormItems(form, item);
        return form;
    }

    private void configureFormLayout(FormLayout form) {
        form.setResponsiveSteps(
                new FormLayout.ResponsiveStep("0px", 1), new FormLayout.ResponsiveStep("500px", 2));
        form.addClassNames(LumoUtility.Padding.LARGE, LumoUtility.Padding.Top.SMALL);
    }

    private void addFormItems(FormLayout form, BaseShmGridVO item) {
        form.addFormItem(new Text(item.getName()), "Name:");
        form.addFormItem(item.getHealthStatus().getDisplayComponent(), "Status:");
        form.addFormItem(createTriggerCountSpan(item), "Trigger Count:");
        form.addFormItem(
                createViolatedRuleTypesComponent(
                        item.getRuleViolations().stream()
                                .map(ShmRuleViolation::getRuleType)
                                .collect(Collectors.toUnmodifiableSet())),
                "Trigger Types:");
    }

    private Span createTriggerCountSpan(BaseShmGridVO item) {
        int count =
                item.getRuleViolations().stream()
                        .map(ShmRuleViolation::getAlertAccumulation)
                        .map(Map::values)
                        .flatMap(Collection::stream)
                        .mapToInt(Integer::intValue)
                        .sum();
        return new Span(String.valueOf(count));
    }

    private Component createTriggersContent(BaseShmGridVO item) {
        Div content = new Div();
        content.setWidthFull();
        H5 heading = new H5("Trigger Details:");
        heading.addClassNames(LumoUtility.Padding.Vertical.MEDIUM);

        PaginatedGrid<ShmAlert, ?> grid = alertGridFactory.createGrid(getAlertList(item));

        content.add(heading, grid);
        return content;
    }

    private List<ShmAlert> getAlertList(BaseShmGridVO item) {
        return item.getRuleViolations().stream()
                .map(ShmRuleViolation::getAlertAccumulation)
                .map(Map::entrySet)
                .flatMap(Collection::stream)
                .flatMap(
                        entry -> {
                            int count = entry.getValue();
                            ShmAlert alert = entry.getKey();
                            return IntStream.range(0, count).mapToObj(i -> alert);
                        })
                .sorted(Comparator.comparing(ShmAlert::getTimestamp).reversed())
                .toList();
    }

    private Component createViolatedRuleTypesComponent(Set<RuleType> triggerTypes) {
        if (triggerTypes.isEmpty()) {
            return new Span("-");
        }

        VerticalLayout layout = new VerticalLayout();
        layout.setSpacing(false);
        layout.setPadding(false);

        triggerTypes.forEach(type -> addRuleTypeSpan(layout, type));

        return layout;
    }

    private void addRuleTypeSpan(VerticalLayout layout, RuleType triggerType) {
        Span span = createRuleTypeSpan(triggerType);
        if (layout.getComponentCount() > 0) {
            span.addClassName(LumoUtility.Margin.Top.SMALL);
        }
        layout.add(span);
    }

    private Span createRuleTypeSpan(RuleType triggerType) {
        Span span = new Span(triggerType.getDescription());
        span.getElement().getThemeList().add("badge error");
        return span;
    }

    @RequiredArgsConstructor
    private static class AlertGridFactory {
        private final ShmRuleMetaService ruleMetaService;

        public PaginatedGrid<ShmAlert, ?> createGrid(List<ShmAlert> items) {
            PaginatedGrid<ShmAlert, ?> grid = new PaginatedGrid<>();
            configureColumns(grid);
            configureGrid(grid, items);
            return grid;
        }

        private void configureColumns(PaginatedGrid<ShmAlert, ?> grid) {
            grid.addColumn(
                            alert ->
                                    DateTimeConvertors.formatTimestamp(
                                            alert.getTimestamp(),
                                            DateTimeConvertors.CENTRAL_TIMEZONE))
                    .setHeader("Timestamp (CST)")
                    .setAutoWidth(true)
                    .setSortable(true);

            grid.addColumn(
                            alert ->
                                    ruleMetaService
                                            .findByTriggerId(alert.getAlertTriggerId())
                                            .map(ShmRuleMeta::getTriggerType)
                                            .map(ShmRuleType::fromName)
                                            .map(ShmRuleType::getDescription)
                                            .orElse(StringUtils.EMPTY))
                    .setHeader("Trigger Type")
                    .setAutoWidth(true)
                    .setSortable(true);

            grid.addColumn(ShmAlert::getAlertEntity)
                    .setHeader("Entity")
                    .setAutoWidth(true)
                    .setSortable(true);

            grid.addColumn(ShmAlert::getAlertMsg)
                    .setHeader("Message")
                    .setAutoWidth(true)
                    .setSortable(true);

            grid.addColumn(ShmAlert::getAlertTriggerId)
                    .setHeader("Trigger ID")
                    .setAutoWidth(true)
                    .setSortable(true);
        }

        private void configureGrid(PaginatedGrid<ShmAlert, ?> grid, List<ShmAlert> items) {
            grid.setDetailsVisibleOnClick(false);
            grid.setItems(new ListDataProvider<>(items));
            grid.setPageSize(TRIGGERS_PAGE_SIZE);
            grid.setPaginatorSize(PAGINATOR_SIZE);
        }
    }
}
