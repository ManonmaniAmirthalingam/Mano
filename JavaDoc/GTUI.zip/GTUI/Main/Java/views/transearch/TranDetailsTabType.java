package com.ebtedge.fns.gateway.views.transearch;

import com.vaadin.flow.component.tabs.Tab;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.Arrays;
import java.util.List;

/**
 * Enumeration representing the different types of transaction details tabs. It provides a set of
 * predefined tab types selected from the values defined within this enumeration. Each tab type
 * corresponds to a label used in transaction details views.
 */
@Getter
@RequiredArgsConstructor
public enum TranDetailsTabType {
    TRANS_INFO("Tran Info"),
    REDE("REDE"),
    INTERNET_DELIVERY_INFO("Internet Delivery Info"),
    MONITOR_BLOCK("Monitor/Block");

    private final String label;

    public static TranDetailsTabType fromLabel(String label) {
        for (TranDetailsTabType tabType : values()) {
            if (tabType.getLabel().equals(label)) {
                return tabType;
            }
        }
        throw new IllegalArgumentException("Unknown tab type: " + label);
    }

    public static List<Tab> createTabs() {
        return Arrays.stream(values()).map(TranDetailsTabType::getLabel).map(Tab::new).toList();
    }
}
