package com.ebtedge.fns.gateway.views.transearch;

import com.ebtedge.fns.gateway.components.DetailsDrawer;
import com.ebtedge.fns.gateway.components.LazyTabSheet;
import com.ebtedge.fns.gateway.config.TppDescMappingConfig;
import com.ebtedge.fns.gateway.initializers.TranDetailTabInitializer;
import com.ebtedge.fns.gateway.model.FinancialTranVO;
import com.ebtedge.fns.gateway.security.CurrentUserAccess;
import com.ebtedge.fns.gateway.service.FnApiService;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.component.tabs.Tabs;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * TranDetailsView is a component class used for displaying and managing transaction details. It
 * implements the {@code Drawer.DrawableDetails} interface to show or hide the details panel. The
 * view supports tab-based navigation for different transaction-related data.
 */
public class TranDetailsView extends Div
        implements DetailsDrawer.DrawableDetails<TranDetailsView.ActiveTabData> {

    private final TppDescMappingConfig tppDescMappingConfig;
    private final CurrentUserAccess currentUserAccess;
    private final FnApiService fnApiService;

    public TranDetailsView(
            TppDescMappingConfig tppDescMappingConfig,
            CurrentUserAccess currentUserAccess,
            FnApiService fnApiService) {
        this.tppDescMappingConfig = tppDescMappingConfig;
        this.currentUserAccess = currentUserAccess;
        this.fnApiService = fnApiService;
        addClassNames("tran-details");
    }

    private LazyTabSheet createTabSheet(ActiveTabData activeTabData) {
        TranDetailsTabType activeTab = activeTabData.getTabType();
        FinancialTranVO data = activeTabData.getData();
        Tabs tabs = createTranDetailsTabs();
        int tabIndex = activeTab.ordinal();
        tabs.setSelectedIndex(tabIndex);
        LazyTabSheet tabSheet =
                new LazyTabSheet(
                        tabs,
                        tab ->
                                switch (TranDetailsTabType.fromLabel(tab.getLabel())) {
                                    case TRANS_INFO ->
                                            TranDetailTabInitializer.createTranInfoTabContent(
                                                    data, tppDescMappingConfig);
                                    case REDE ->
                                            TranDetailTabInitializer.createREDETabContent(data);
                                    case INTERNET_DELIVERY_INFO ->
                                            TranDetailTabInitializer
                                                    .createInternetDeliveryInfoTabContent(data);
                                    case MONITOR_BLOCK ->
                                            TranDetailTabInitializer.createMonitorBlockTabContent(
                                                    data, currentUserAccess, fnApiService);
                                });
        tabSheet.setSizeFull();
        tabSheet.setSpacing(false);
        tabSheet.getStyle().setPaddingTop("0");
        return tabSheet;
    }

    private Tabs createTranDetailsTabs() {
        Tabs tabs = new Tabs();
        tabs.addClassNames("tran-detail-tabs");
        tabs.setWidthFull();
        tabs.add(TranDetailsTabType.createTabs().toArray(Tab[]::new));
        return tabs;
    }

    @Override
    public void showDetails(TranDetailsView.ActiveTabData activeTabData) {
        removeAll();
        add(createTabSheet(activeTabData));
    }

    @Override
    public void hideDetails() {
        removeAll();
    }

    @Getter
    @AllArgsConstructor
    public static class ActiveTabData {
        private TranDetailsTabType tabType;
        private FinancialTranVO data;
    }
}
