package com.ebtedge.fns.gateway.views.transearch;

import com.ebtedge.fns.gateway.model.FinancialTranVO;
import com.ebtedge.fns.gateway.security.CurrentUserAccess;
import com.ebtedge.fns.gateway.security.UserPermission;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.contextmenu.GridContextMenu;
import com.vaadin.flow.component.grid.contextmenu.GridMenuItem;
import com.vaadin.flow.component.grid.contextmenu.GridSubMenu;
import com.vaadin.flow.component.html.Hr;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.theme.lumo.LumoUtility;

import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.experimental.UtilityClass;

/**
 * Utility class responsible for building and configuring a context menu specific to a transactional
 * search grid. The context menu includes multiple hierarchical menu items and integrates user
 * access controls to enable/disable functionality. It is designed to operate within a Vaadin-based
 * Grid and customize its behavior dynamically based on user permissions.
 *
 * <p>This class provides methods to: - Configure and add a base context menu to a grid. - Construct
 * sub-menus for search, monitoring, and terminal blocking functionalities. - Apply user-specific
 * permission checks to enable or disable menu actions.
 */
@UtilityClass
public class TranSearchGridContextMenuBuilder {
    private static final String MENU_ITEM_CLASS = "grid-context-menu-item";
    private static final String CONTEXT_MENU_CLASS = "tran-search-grid-context-menu";

    public void build(
            Grid<FinancialTranVO> grid,
            CurrentUserAccess currentUserAccess,
            ComponentEventListener<GridContextMenu.GridContextMenuItemClickEvent<FinancialTranVO>>
                    clickListener) {
        MenuConfiguration config =
                MenuConfiguration.builder()
                        .grid(grid)
                        .currentUserAccess(currentUserAccess)
                        .clickListener(clickListener)
                        .build();

        GridContextMenu<FinancialTranVO> contextMenu = createBaseMenu(config.getGrid());
        buildSearchMenu(contextMenu, config);
        contextMenu.add(new Hr());
        buildMonitoringMenu(contextMenu, config);
        buildBlockTerminalMenu(contextMenu, config);
    }

    private static GridContextMenu<FinancialTranVO> createBaseMenu(Grid<FinancialTranVO> grid) {
        GridContextMenu<FinancialTranVO> menu = grid.addContextMenu();
        menu.addClassName(CONTEXT_MENU_CLASS);
        return menu;
    }

    private static void buildSearchMenu(
            GridContextMenu<FinancialTranVO> contextMenu, MenuConfiguration config) {
        GridMenuItem<FinancialTranVO> searchMenu =
                addMenuItem(
                        contextMenu, ContextMenuItemDef.SEARCH, true, config.getClickListener());
        GridSubMenu<FinancialTranVO> subMenu = searchMenu.getSubMenu();
        addMenuItem(subMenu, ContextMenuItemDef.SEARCH_BY_CARD, true, config.getClickListener());
        addMenuItem(
                subMenu, ContextMenuItemDef.SEARCH_BY_TERMINAL, true, config.getClickListener());
        addMenuItem(
                subMenu, ContextMenuItemDef.SEARCH_BY_FNS_NUMBER, true, config.getClickListener());
    }

    private static void buildMonitoringMenu(
            GridContextMenu<FinancialTranVO> contextMenu, MenuConfiguration config) {
        boolean monitoringEnabled = isMonitoringEnabled(config.getCurrentUserAccess());
        addMenuItem(
                contextMenu,
                ContextMenuItemDef.MONITOR,
                monitoringEnabled,
                config.getClickListener());
    }

    private static void buildBlockTerminalMenu(
            GridContextMenu<FinancialTranVO> contextMenu, MenuConfiguration config) {
        addMenuItem(
                contextMenu,
                ContextMenuItemDef.BLOCK_TERMINAL,
                config.getCurrentUserAccess().hasPermission(UserPermission.GWAllowTerminalIdBlock),
                config.getClickListener());
    }

    private static GridMenuItem<FinancialTranVO> addMenuItem(
            GridContextMenu<FinancialTranVO> menu,
            ContextMenuItemDef item,
            boolean enabled,
            ComponentEventListener<GridContextMenu.GridContextMenuItemClickEvent<FinancialTranVO>>
                    listener) {
        GridMenuItem<FinancialTranVO> menuItem = menu.addItem(item.getText());
        configureMenuItem(menuItem, item, enabled, listener);
        return menuItem;
    }

    private static GridMenuItem<FinancialTranVO> addMenuItem(
            GridSubMenu<FinancialTranVO> menu,
            ContextMenuItemDef item,
            boolean enabled,
            ComponentEventListener<GridContextMenu.GridContextMenuItemClickEvent<FinancialTranVO>>
                    listener) {
        GridMenuItem<FinancialTranVO> menuItem = menu.addItem(item.getText());
        configureMenuItem(menuItem, item, enabled, listener);
        return menuItem;
    }

    private static void configureMenuItem(
            GridMenuItem<FinancialTranVO> menuItem,
            ContextMenuItemDef item,
            boolean enabled,
            ComponentEventListener<GridContextMenu.GridContextMenuItemClickEvent<FinancialTranVO>>
                    listener) {
        menuItem.addMenuItemClickListener(listener);
        menuItem.addClassNames(MENU_ITEM_CLASS, LumoUtility.FontSize.XSMALL);
        menuItem.setEnabled(enabled);
        if (item.getIcon() != null) {
            menuItem.addComponentAsFirst(item.getIcon().create());
        }
    }

    private static boolean isMonitoringEnabled(CurrentUserAccess currentUserAccess) {
        return currentUserAccess.hasPermission(UserPermission.GWAllowCardMonitor)
                || currentUserAccess.hasPermission(UserPermission.GWAllowTerminalIdMonitor);
    }

    @Getter
    @RequiredArgsConstructor
    public enum ContextMenuItemDef {
        SEARCH("Search", VaadinIcon.SEARCH),
        SEARCH_BY_CARD("By Card Number", null),
        SEARCH_BY_TERMINAL("By Terminal ID", null),
        SEARCH_BY_FNS_NUMBER("By FNS Number", null),
        MONITOR("Monitor", VaadinIcon.EYE),
        BLOCK_TERMINAL("Block Terminal", VaadinIcon.LOCK);

        private final String text;
        private final VaadinIcon icon;

        public static ContextMenuItemDef fromLabel(String label) {
            for (ContextMenuItemDef item : values()) {
                if (item.getText().equals(label)) {
                    return item;
                }
            }
            throw new IllegalArgumentException("Unknown menu item: " + label);
        }
    }

    @Getter
    @Builder
    private static class MenuConfiguration {
        private final Grid<FinancialTranVO> grid;
        private final CurrentUserAccess currentUserAccess;
        private final ComponentEventListener<
                        GridContextMenu.GridContextMenuItemClickEvent<FinancialTranVO>>
                clickListener;
    }
}
