package com.ebtedge.fns.gateway.views.transearch;

import com.ebtedge.config.helper.ConfigUtil;
import com.ebtedge.fns.gateway.components.DetailsDrawer;
import com.ebtedge.fns.gateway.config.GatAppConfig;
import com.ebtedge.fns.gateway.config.TppDescMappingConfig;
import com.ebtedge.fns.gateway.decorators.TranSearchRequestDecorator;
import com.ebtedge.fns.gateway.decorators.TranSearchRespDecorator;
import com.ebtedge.fns.gateway.forms.TransactionSearchForm;
import com.ebtedge.fns.gateway.initializers.TranDetailTabInitializer;
import com.ebtedge.fns.gateway.initializers.TranSearchGridInitializer;
import com.ebtedge.fns.gateway.model.FinancialTranVO;
import com.ebtedge.fns.gateway.model.TranSearchCriteria;
import com.ebtedge.fns.gateway.model.TranSummaryGridSort;
import com.ebtedge.fns.gateway.security.CurrentUserAccess;
import com.ebtedge.fns.gateway.service.FnApiService;
import com.ebtedge.fns.gateway.util.*;
import com.ebtedge.fns.gateway.util.PredefinedTitleProvider.PredefinedTitlePdfFormat;
import com.ebtedge.fns.gateway.views.errors.AccessDeniedView;
import com.ebtedge.yb.criteria.TranSearchCriteriaQuery;
import com.ebtedge.yb.entity.TranSearchResp;
import com.ebtedge.yb.service.GatService;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.contextmenu.GridContextMenu;
import com.vaadin.flow.component.grid.contextmenu.GridMenuItem;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.router.*;
import com.vaadin.flow.spring.annotation.UIScope;
import com.vaadin.flow.theme.lumo.LumoUtility;
import lombok.extern.slf4j.Slf4j;
import org.vaadin.lineawesome.LineAwesomeIconUrl;
import software.xdev.vaadin.grid_exporter.GridExportLocalizationConfig;
import software.xdev.vaadin.grid_exporter.GridExporter;
import java.util.Map;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * View for Transaction Search. This page will take care of initializing Transaction search from, grid and all other details related to transaction search.
 *
 * @author e3023044
 * @version 1.0.0
 * @see {@link TransactionSearchForm}
 * @see {@link TranSearchGridInitializer}
 * @see {@link TranDetailTabInitializer}
 * @since 1.0.0
 */
@PageTitle("Transaction Search")
@Route(value = RouteUrls.TRANSACTION_SEARCH)
@Menu(order = 1, icon = LineAwesomeIconUrl.HOME_SOLID)
@Slf4j
@UIScope
public class TransactionSearchView extends Div implements BeforeEnterObserver {

    private final Grid<FinancialTranVO> grid = new Grid<>(FinancialTranVO.class, false);
    private final GatService gatService;
    private final GatAppConfig gatAppConfig;
    final ConfigUtil configUtil;
    final SSOUtil ssoUtil;
    private final CurrentUserAccess currentUserAccess;
    private final FnApiService fnApiService;
    TransactionSearchForm transactionSearchForm = null;
    private DetailsDrawer<TranDetailsView.ActiveTabData> detailsDrawer;
    Div totalRecordsDisplayDiv = new Div();
    private int totalCount = 0; // Store the total record count
    TppDescMappingConfig tppDescMappingConfig;
    private TranSearchCriteria searchResultsCriteria; // Store the search criteria used for the grid

    @Override
    public void beforeEnter(BeforeEnterEvent event) {

        boolean isValid = ssoUtil.handleSSO(event);

        if (!isValid) {
            SessionUtil.invalidateSession();
            event.forwardToUrl(gatAppConfig.getLogoutUrl());
        } else if (!currentUserAccess.hasAccessToUrl(RouteUrls.TRANSACTION_SEARCH)) {
            log.warn(
                    "User {} attempted to access unauthorized route {}",
                    SessionUtil.getUserId(),
                    event.getLocation().getPath());
            event.forwardTo(AccessDeniedView.class);
        }
		Map<String, List<String>> params = event.getLocation().getQueryParameters().getParameters();
		String cardNo = params.getOrDefault("cardNumber", List.of("")).get(0);
		String fnsNo = params.getOrDefault("fnsNumber",  List.of("")).get(0);
		String terminalId = params.getOrDefault("terminalId",  List.of("")).get(0);
		transactionSearchForm.getCard().setValue(cardNo);
		transactionSearchForm.getFnsNumber().setValue(fnsNo);
		transactionSearchForm.getTerminalId().setValue(terminalId);
        setupGridContextMenu();
    }

    /**
     * Initializes Transaction Search view.
     *
     * @param gatService   {@link GatService}
     * @param gatAppConfig {@link GatAppConfig}
     */
    public TransactionSearchView(GatService gatService, GatAppConfig gatAppConfig,
                                 ConfigUtil configUtil, SSOUtil ssoUtil, TppDescMappingConfig tppDescMappingConfig, CurrentUserAccess currentUserAccess, FnApiService fnApiService) {
        addClassNames("tran-summary-detail-view");
        setSizeFull();
        this.gatAppConfig = gatAppConfig;
        this.gatService = gatService;
        this.configUtil = configUtil;
        this.ssoUtil = ssoUtil;
        this.tppDescMappingConfig = tppDescMappingConfig;
        this.currentUserAccess = currentUserAccess;
        this.fnApiService = fnApiService;
        initForm();
        this.grid.setPageSize(Integer.parseInt(gatAppConfig.getGridInitialSize()));
        TranSearchGridInitializer.initializeGrid(this.grid, tppDescMappingConfig);
        registerSelectionChangeListener(grid);
        transactionSearchForm.addExportEventListener(event -> exportGridData());
        transactionSearchForm.addClearEventListener(event -> {
            grid.setVisible(false);
            totalRecordsDisplayDiv.setVisible(false); // Hide the Total Record Count
            detailsDrawer.hideDetails();
            totalRecordsDisplayDiv.removeAll(); // Clear the Total Record Count text
            grid.setItems();
            grid.sort(null);
            searchResultsCriteria = null; // Reset search results criteria
            totalCount = 0; // Reset the total record count
        });
        initDrawer();
    }

    /**
     * Initialize Transaction Search form {@link TransactionSearchForm}
     */
    private void initForm() {
        transactionSearchForm = new TransactionSearchForm(getStateCodeAndDesc(), getBusinessTypeCodeAndDesc(), gatAppConfig.getDataRetentionDuration());
        transactionSearchForm.addSearchEventListener(this::searchTransactions);
    }

    private void initDrawer() {
        detailsDrawer =
                new DetailsDrawer<>(
                        createPrimaryLayout(),
                        new TranDetailsView(tppDescMappingConfig, currentUserAccess, fnApiService));
        detailsDrawer.setDetailsTitle("Transaction Details");
        add(detailsDrawer);
    }

    /**
     * Creates primary layout for Transaction search view. Primary layout contains Search Criteria,
     * Search summary results. This also contains Div that holds Total record count info.
     *
     * @return
     */
    private Div createPrimaryLayout() {

        Div primaryLayoutMainDiv = new Div();
        primaryLayoutMainDiv.addClassNames(LumoUtility.Padding.Left.MEDIUM, LumoUtility.Overflow.AUTO);

        totalRecordsDisplayDiv.addClassNames("total-records-display-div");
        totalRecordsDisplayDiv.setVisible(false);

        Div searchSummaryDiv = new Div();
        searchSummaryDiv.setSizeFull();
        searchSummaryDiv.add(this.grid);
        searchSummaryDiv.addClassNames(LumoUtility.Padding.Left.SMALL);

        primaryLayoutMainDiv.add(transactionSearchForm);
        primaryLayoutMainDiv.add(totalRecordsDisplayDiv);
        primaryLayoutMainDiv.add(searchSummaryDiv);

        return primaryLayoutMainDiv;

    }

    private void setupGridContextMenu() {
        TranSearchGridContextMenuBuilder.build(
                grid, currentUserAccess, this::handleContextMenuItemClick);
    }

    private void handleContextMenuItemClick(
            GridContextMenu.GridContextMenuItemClickEvent<FinancialTranVO> event) {
        FinancialTranVO selectedItem = event.getItem().orElse(null);
        var menuItemDef =
                TranSearchGridContextMenuBuilder.ContextMenuItemDef.fromLabel(
                        event.getSource().getText());
        if (selectedItem == null) {
            log.warn(
                    "Selected item is null. Cannot perform click action on context menu item {}.",
                    event.getSource().getText());
            return;
        }
        handleMenuItemAction(menuItemDef, selectedItem, event.getSource());
    }

    private void handleMenuItemAction(
            TranSearchGridContextMenuBuilder.ContextMenuItemDef menuItemDef,
            FinancialTranVO selectedItem,
            GridMenuItem<FinancialTranVO> source) {
        switch (menuItemDef) {
            case SEARCH_BY_CARD ->
                    transactionSearchForm.getCard().setValue(selectedItem.getCardNumber());
            case SEARCH_BY_TERMINAL ->
                    transactionSearchForm.getTerminalId().setValue(selectedItem.getTerminalId());
            case SEARCH_BY_FNS_NUMBER ->
                    transactionSearchForm.getFnsNumber().setValue(selectedItem.getFnsNumber());
            case MONITOR, BLOCK_TERMINAL ->
                    showTransactionDetails(selectedItem, TranDetailsTabType.MONITOR_BLOCK);
            default -> log.info("Context menu item clicked: {}", source.getText());
        }
    }

    private void registerSelectionChangeListener(Grid<FinancialTranVO> grid) {
        grid.asSingleSelect()
                .addValueChangeListener(
                        event -> {
                            FinancialTranVO selectedTransaction = event.getValue();
                            if (selectedTransaction != null) {
                                showTransactionDetails(
                                        selectedTransaction, TranDetailsTabType.TRANS_INFO);
                            }
                        });
    }

    private void showTransactionDetails(FinancialTranVO transaction, TranDetailsTabType tabType) {
        var activeTabData = new TranDetailsView.ActiveTabData(tabType, transaction);
        detailsDrawer.showDetails(activeTabData);
    }

    /**
     * perform transaction search
     *
     * @param event
     */
    private void searchTransactions(TransactionSearchForm.SearchEvent event) {

        try {
            TranSearchCriteria searchCriteria = event.getTranSearchCriteria();
            this.searchResultsCriteria = searchCriteria.toExportCriteria();
            //creating array of List<UserActivitySearchResp> so we can update the list stored in the array
            final List<TranSearchResp>[] cachedFirstPageData = new List[1];
            AtomicInteger counter = new AtomicInteger(1);
            this.grid.sort(null);
            detailsDrawer.hideDetails();
            this.grid.setItems(query -> {
                List<TranSummaryGridSort> sortOrders = FormUtil.getTranSummaryGridSortOrder(query);
                this.searchResultsCriteria.setGridSort(sortOrders);
                this.searchResultsCriteria.setSearchType("TRANSACTION SEARCH");
                TranSearchCriteriaQuery tranSearchCriteriaQuery = TranSearchRequestDecorator.toTranSearchCriteria().apply(this.searchResultsCriteria);
                int offset = query.getOffset();
                int limit = query.getLimit();
                counter.set(offset + 1); // Updating the counter for row numbers

                // Checking if it's the first page and if the data is already cached
            	if(sortOrders.isEmpty()) {
	                if (offset == 0 && cachedFirstPageData[0] != null) {
	                    List<TranSearchResp> tranSearchRespList = cachedFirstPageData[0];
	                    cachedFirstPageData[0] = null;

	                    return tranSearchRespList
	                            .stream()
	                            .map(tranSearchResp -> {
	                                FinancialTranVO vo = TranSearchRespDecorator.toFinancialVO().apply(tranSearchResp);
	                                vo.setRownumbers(counter.getAndIncrement());
	                                return vo;
	                            })
	                            .collect(Collectors.toList())
	                            .stream();
	                }
            	}


                tranSearchCriteriaQuery.setStartRow(Integer.toString(offset));
                tranSearchCriteriaQuery.setEndRow(Integer.toString(limit));
                if (offset != 0) {
                    tranSearchCriteriaQuery.setEndRow(Integer.toString(offset + Integer.parseInt(gatAppConfig.getGridInitialSize())));
                    tranSearchCriteriaQuery.setStartRow(Integer.toString(offset + 1));
                    tranSearchCriteriaQuery.setSearchType("TRANSACTION SEARCH NEXTSET");
                }

                if(sortOrders != null && !sortOrders.isEmpty()) {
					 tranSearchCriteriaQuery.setSearchType("TRANSACTION SEARCH SORT");
				 }

                List<TranSearchResp> tranSearchRespList = fetchTransactionSearchData(tranSearchCriteriaQuery);
                if (tranSearchRespList != null && tranSearchRespList.size() > 0) {
                    totalCount = Integer.parseInt(tranSearchRespList.get(0)
                            .getTotalRowCount());
                    totalRecordsDisplayDiv.removeAll();
                    totalRecordsDisplayDiv.add("Total Record Count: " + totalCount);
                    totalRecordsDisplayDiv.setVisible(true);
                } else {
                    totalCount = 0;
                    totalRecordsDisplayDiv.removeAll();
                    totalRecordsDisplayDiv.setVisible(false);
                }
                return tranSearchRespList.stream()
                        .map(tranSearchResp -> {
                            FinancialTranVO vo = TranSearchRespDecorator.toFinancialVO().apply(tranSearchResp);
                            vo.setRownumbers(counter.getAndIncrement());
                            return vo;
                        })
                        .collect(Collectors.toList())
                        .stream();
            }, query -> {
                int gridSize = Integer.parseInt(gatAppConfig.getGridInitialSize());
                this.searchResultsCriteria.setSearchType("TRANSACTION SEARCH");
                TranSearchCriteriaQuery tranSearchCriteriaQuery = TranSearchRequestDecorator.toTranSearchCriteria().apply(this.searchResultsCriteria);

                tranSearchCriteriaQuery.setStartRow("0");
                tranSearchCriteriaQuery.setEndRow(Integer.toString(Integer.parseInt(gatAppConfig.getGridInitialSize())));

                List<TranSearchResp> tranSearchRespList = fetchTransactionSearchData(tranSearchCriteriaQuery);
                if (tranSearchRespList != null && !tranSearchRespList.isEmpty()) {
                    cachedFirstPageData[0] = tranSearchRespList;
                    totalRecordsDisplayDiv.removeAll();
                    totalCount = Integer.parseInt(tranSearchRespList.get(0).getTotalRowCount());
                    totalRecordsDisplayDiv.add("Total Record Count: " + totalCount);
                    totalRecordsDisplayDiv.setVisible(true);
                    if(totalCount > gridSize){
                        return gridSize;
                    }
                    return totalCount;
                } else {
                	totalCount = 0; // Ensure total count is reset when no results
                    totalRecordsDisplayDiv.setVisible(false);
                    return 0;
                }
            });
        } catch (Exception e) {
            log.error("Error while fetching the transaction search data: {}", e);
            Notifications.showError(e.getMessage());
        }
        this.grid.setVisible(true);
    }

    private List<TranSearchResp> fetchTransactionSearchData(TranSearchCriteriaQuery tranSearchCriteriaQuery) {
        if (!SessionUtil.isSessionValid()) {
            log.error("Session is invalid during fetchTransactionSearchData. Redirecting to logout.");
            SessionUtil.invalidateSession();
            getUI().ifPresent(ui -> ui.getPage().setLocation(gatAppConfig.getLogoutUrl()));
            return List.of();
        }
        return gatService.transactionSearch(tranSearchCriteriaQuery);
    }

    private List<String> getStateCodeAndDesc() {
        return this.gatAppConfig
                .getStateCodes()
                .stream()
                .map(GatAppConfig::getNameAndAbbr)
                .sorted()
                .collect(Collectors.toList());
    }

    private List<String> getBusinessTypeCodeAndDesc() {
        return this.gatAppConfig
                .getBusinessTypes()
                .stream()
                .map(GatAppConfig::getBusinessCodeDesc)
                .sorted()
                .collect(Collectors.toList());
    }

    private void exportGridData() {
        log.info("Export to Grid button clicked");

        // Read the export limit from the configuration
        int exportLimit = Integer.parseInt(gatAppConfig.getExportLimit());

        if (totalCount > exportLimit) {
            log.warn("Export limit exceeded. Record count: {}", totalCount);
            Notifications.showError("Export limit exceeded. You can only download up to " + exportLimit + " records.");
        } else if (totalCount > 0) {
        	// Ensure SearchResultsCriteria is available
            if (this.searchResultsCriteria == null) {
                Notifications.showError("No search criteria found. Please perform a search before exporting.");
                return;
            }
            
            // Use the search results criteria for export, not the current form state
            TranSearchCriteria searchCriteria = this.searchResultsCriteria.toExportCriteria();

            // Generate title
            String title = "Transaction History";

            // Generate date range
            String dateRange = "";
            if (searchCriteria.getStartDate() != null && searchCriteria.getEndDate() != null) {
                dateRange = getDateRangeText(
                        searchCriteria.getStartDate().format(DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm")),
                        searchCriteria.getEndDate().format(DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm"))
                );
            }
            // Generate "Generated on" timestamp
            String generatedDate = getGeneratedOn();

            // Build search values dynamically
            StringBuilder searchValuesBuilder = new StringBuilder();
            if (searchCriteria.getCard() != null && !searchCriteria.getCard().isEmpty()) {
                searchValuesBuilder.append("Card #: \"").append(searchCriteria.getCard()).append("\"\n");
            }
            if (searchCriteria.getTerminalId() != null && !searchCriteria.getTerminalId().isEmpty()) {
                searchValuesBuilder.append("Terminal ID: \"").append(searchCriteria.getTerminalId()).append("\"\n");
            }
            if (searchCriteria.getFnsNumber() != null && !searchCriteria.getFnsNumber().isEmpty()) {
                searchValuesBuilder.append("FNS Number: \"").append(searchCriteria.getFnsNumber()).append("\"\n");
            }
            if (searchCriteria.getStates() != null && !searchCriteria.getStates().isEmpty()) {
                searchValuesBuilder.append("Merchant State: \"")
                        .append(String.join(", ", searchCriteria.getStates())).append("\"\n");
            }

            // Finalize search values
            String searchValues = searchValuesBuilder.toString().trim();

            // Generate dynamic file name
            String fileName = "TransactionHistory_" +
                    DateTimeFormatter.ofPattern("yyyy_MM_dd_HH_mm").format(LocalDateTime.now(ZoneOffset.UTC));

            // Customize localization for the export wizard
            GridExportLocalizationConfig localizationConfig = new GridExportLocalizationConfig()
                    .with(GridExportLocalizationConfig.EXPORT_GRID, "Export Data");

            // Initialize the GridExporter with the custom localization and dynamic title
            GridExporter.newWithDefaults(grid)
                    .withLocalizationConfig(localizationConfig)
                    .withFileName(fileName) // Set the dynamic file name
                    .withAvailableFormats(
                            new PredefinedTitlePdfFormat(title, dateRange, generatedDate, searchValues)
                    )
                    .loadFromProvider(new PredefinedTitleProvider(title, dateRange, generatedDate, searchValues))
                    .open();
        } else {
            log.warn("Grid is empty, nothing to export");
            Notifications.showError("Grid is empty, nothing to export");
        }
    }

    /**
     * Generate the "Generated on" timestamp.
     *
     * @return String
     */
    private String getGeneratedOn() {
        Calendar cal = Calendar.getInstance();
        String timestamp = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss ").format(cal.getTime());
        timestamp += cal.getTimeZone().getDisplayName(false, TimeZone.SHORT);
        return "Generated on: " + timestamp;
    }

    /**
     * Generate the date range string to display from the transaction search form.
     *
     * @param startDate Start date as a string
     * @param endDate   End date as a string
     * @return String
     */
    private String getDateRangeText(String startDate, String endDate) {
        return "Date Range: " + startDate + " - " + endDate;
    }

}
