package com.ebtedge.fns.gateway.views.useractivity;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import com.ebtedge.fns.gateway.domain.UserInfo;
import com.ebtedge.fns.gateway.model.UserActivityGridSort;
import com.ebtedge.fns.gateway.util.*;
import com.vaadin.flow.router.*;
import com.vaadin.flow.spring.annotation.UIScope;
import org.vaadin.lineawesome.LineAwesomeIconUrl;

import com.ebtedge.fns.gateway.config.GatAppConfig;
import com.ebtedge.fns.gateway.decorators.UserActivityReqDecorator;
import com.ebtedge.fns.gateway.decorators.UserActivityRespDecorator;
import com.ebtedge.fns.gateway.forms.UserActivitySearchForm;
import com.ebtedge.fns.gateway.initializers.UserActivityGridInitializer;
import com.ebtedge.fns.gateway.layout.MainLayout;
import com.ebtedge.fns.gateway.model.UserActivityGridVO;
import com.ebtedge.fns.gateway.model.UserActivitySearchCriteria;
import com.ebtedge.fns.gateway.util.PredefinedTitleProvider.PredefinedTitlePdfFormat;
import com.ebtedge.yb.criteria.UserActivitySearchQuery;
import com.ebtedge.yb.entity.UserActivitySearchResp;
import com.ebtedge.yb.service.GatService;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.server.VaadinSession;

import jakarta.annotation.security.PermitAll;
import lombok.extern.slf4j.Slf4j;
import software.xdev.vaadin.grid_exporter.GridExportLocalizationConfig;
import software.xdev.vaadin.grid_exporter.GridExporter;


@PageTitle("User Activity")
@Route(value = RouteUrls.USER_ACTIVITY, layout = MainLayout.class)
@Menu(order = 5, icon = LineAwesomeIconUrl.USER_TIMES_SOLID)
@PermitAll
@Slf4j
@UIScope
public class UserActivityView extends VerticalLayout {

    private final Grid<UserActivityGridVO> userActivityGrid = new Grid<>(UserActivityGridVO.class, false);
    private final GatService gatService;
    private final GatAppConfig gatAppConfig;
    Div totalRecordsDisplayDiv = new Div();
    UserActivitySearchForm userActivitySearchForm = null;
    private int totalCount = 0; // Store the total record count
    private UserActivitySearchCriteria searchResultsCriteria; // the search results criteria used for the grid

    public UserActivityView(GatService gatService, GatAppConfig gatAppConfig) {
        addClassNames("user-activity");
        this.gatService = gatService;
        this.gatAppConfig = gatAppConfig;
        setSizeFull();
        totalRecordsDisplayDiv.addClassNames("total-records-display-div");
        totalRecordsDisplayDiv.setVisible(false);
        this.userActivityGrid.setPageSize(Integer.parseInt(gatAppConfig.getGridInitialSize()));
        UserActivityGridInitializer.initializeGrid(userActivityGrid);
        getUserActivitySearchForm();
        configureSearchFormBasedOnUserRole(); // Check user role and configure search form
        add(getUserActivitySearchForm(), totalRecordsDisplayDiv, userActivityGrid);
        setFlexGrow(1, userActivityGrid);
    }

    private void configureSearchFormBasedOnUserRole() {
        // Retrieving current user's information
        UserInfo userInfo = (UserInfo) VaadinSession.getCurrent().getAttribute("userInfo");

        if (userInfo != null && !userInfo.isAdminUser()) {
            // For Non-admin user: Set search fields to user's info and make them uneditable
            String userId = userInfo.getUserId() != null ? userInfo.getUserId() : "testuser";
            String firstName = userInfo.getFirstName() != null ? userInfo.getFirstName() : "testuser";
            String lastName = userInfo.getLastName() != null ? userInfo.getLastName() : "testuser";

            UserActivitySearchCriteria criteria = new UserActivitySearchCriteria();
            criteria.setUserId(userId);
            criteria.setFirstName(firstName);
            criteria.setLastName(lastName);
            getUserActivitySearchForm().getBinder().setBean(criteria);

            getUserActivitySearchForm().setFieldEditable("userId", false);
            getUserActivitySearchForm().setFieldEditable("firstName", false);
            getUserActivitySearchForm().setFieldEditable("lastName", false);
        } else {
            //TODO: implement logout when ONLY userInfo is null
            log.error("User is not logged in or is an admin user.");
        }

    }

    private UserActivitySearchForm getUserActivitySearchForm() {
        if (userActivitySearchForm == null) {
            userActivitySearchForm = new UserActivitySearchForm(gatAppConfig.getDataRetentionDuration());
            userActivitySearchForm.addSearchEventListener(this::searchUserActivity);
            userActivitySearchForm.addExportEventListener(e -> exportGridData());
            userActivitySearchForm.addClearGridEventListener(e -> clearGrid());
        }
        return userActivitySearchForm;
    }

    private void clearGrid() {
        totalRecordsDisplayDiv.removeAll();
        totalRecordsDisplayDiv.setVisible(false);
        userActivityGrid.setItems();
        userActivityGrid.setVisible(false);
        userActivityGrid.sort(null);
        searchResultsCriteria = null; // Reset stored search criteria
        totalCount = 0; // Reset the total record count
    }

    /**
     * Method to perform user activity search based on the criteria provided in the search form.
     *
     * @param searchEvent the event containing the search criteria
     */
    private void searchUserActivity(UserActivitySearchForm.SearchEvent searchEvent) {
        try {
            userActivityGrid.scrollToStart();
            UserActivitySearchCriteria searchCriteria = searchEvent.getSearchCriteria();
            this.searchResultsCriteria = searchCriteria.toExportCriteria();
            //creating array of List<UserActivitySearchResp> so we can update the list stored in the array
            final List<UserActivitySearchResp>[] cachedFirstPageData = new List[1];
            AtomicInteger counter = new AtomicInteger(1);
            this.userActivityGrid.sort(null);

            this.userActivityGrid.setItems(query -> {
                List<UserActivityGridSort> sortOrders = FormUtil.getUserActivityGridSortOrder(query);
                this.searchResultsCriteria.setGridSort(sortOrders);
                this.searchResultsCriteria.setSearchType("USER ACTIVITY");
                UserActivitySearchQuery searchQuery = UserActivityReqDecorator.toUserActivitySearchQuery().apply(this.searchResultsCriteria);
                int offset = query.getOffset();
                int limit = query.getLimit();
                counter.set(offset + 1); //updating the counter for row numbers

                // Checking if it's the first page and if the data is already cached
                if (sortOrders.isEmpty()) {
                    if (offset == 0 && cachedFirstPageData[0] != null) {
                        List<UserActivitySearchResp> userActivityRespList = cachedFirstPageData[0];
                        cachedFirstPageData[0] = null;

                        return userActivityRespList
                                .stream()
                                .map(userActivitySearchResp -> {
                                    UserActivityGridVO vo = UserActivityRespDecorator.toUserActivityGridVO().apply(userActivitySearchResp);
                                    vo.setRownumbers(counter.getAndIncrement());
                                    return vo;
                                })
                                .collect(Collectors.toList())
                                .stream();
                    }
                }
                searchQuery.setStartRow(Integer.toString(offset));
                searchQuery.setEndRow(Integer.toString(limit));
                if (offset != 0) {
                    searchQuery.setEndRow(Integer.toString(offset + Integer.parseInt(gatAppConfig.getGridInitialSize())));
                    searchQuery.setStartRow(Integer.toString(offset + 1));
                    searchQuery.setSearchType("USER ACTIVITY NEXTSET");
                }

                if (sortOrders != null && !sortOrders.isEmpty()) {
                    searchQuery.setSearchType("USER ACTIVITY SORT");
                }


                List<UserActivitySearchResp> userActivityRespList = fetchUserActivityData(searchQuery);
                if (userActivityRespList != null && !userActivityRespList.isEmpty()) {
                    totalCount = Integer.parseInt(userActivityRespList.get(0).getTotalRowCount());
                    totalRecordsDisplayDiv.removeAll();
                    totalRecordsDisplayDiv.add("Total Record Count: " + totalCount);
                    totalRecordsDisplayDiv.setVisible(true);
                } else {
                    totalCount = 0;
                    totalRecordsDisplayDiv.removeAll();
                    totalRecordsDisplayDiv.setVisible(false);
                }

                return userActivityRespList.stream()
                        .map(userActivitySearchResp -> {
                            UserActivityGridVO vo = UserActivityRespDecorator.toUserActivityGridVO().apply(userActivitySearchResp);
                            vo.setRownumbers(counter.getAndIncrement());
                            return vo;
                        })
                        .collect(Collectors.toList())
                        .stream();
            }, query -> {
            	this.searchResultsCriteria.setSearchType("USER ACTIVITY");
                UserActivitySearchQuery searchQuery = UserActivityReqDecorator.toUserActivitySearchQuery().apply(this.searchResultsCriteria);
                searchQuery.setStartRow("0");
                searchQuery.setEndRow(Integer.toString(Integer.parseInt(gatAppConfig.getGridInitialSize())));
                List<UserActivitySearchResp> userActivityRespList = fetchUserActivityData(searchQuery);
                if (userActivityRespList != null && !userActivityRespList.isEmpty()) {
                    cachedFirstPageData[0] = userActivityRespList;
                    totalRecordsDisplayDiv.removeAll();
                    totalCount = Integer.parseInt(userActivityRespList.get(0).getTotalRowCount());
                    totalRecordsDisplayDiv.add("Total Record Count: " + totalCount);
                    totalRecordsDisplayDiv.setVisible(true);
                    return totalCount;
                } else {
                	totalCount = 0; // Ensure total count is reset when no results
                    totalRecordsDisplayDiv.setVisible(false);
                    return 0;
                }
            });

            this.userActivityGrid.setVisible(true);
        } catch (Exception e) {
            log.error("Error while fetching user activity data: {}", e);
            Notifications.showError(e.getMessage());
        }
    }

    private List<UserActivitySearchResp> fetchUserActivityData(UserActivitySearchQuery searchQuery) {
        // Validate session before making the service call
        if (!SessionUtil.isSessionValid()) {
            log.error("Session is invalid during fetchUserActivityData. Redirecting to logout.");
            SessionUtil.invalidateSession();
            getUI().ifPresent(ui -> ui.getPage().setLocation(gatAppConfig.getLogoutUrl()));
            return List.of();
        }
        // Fetch data from the service if Session is valid
        return gatService.userActivitySearch(searchQuery);
    }

    /**
     * Method to export grid data to a file.
     */
    private void exportGridData() {
        log.info("Export to Grid button clicked");

        // Read the export limit from the configuration
        int exportLimit = Integer.parseInt(gatAppConfig.getExportLimit());

        if (this.totalCount > exportLimit) {
            log.warn("Export limit exceeded. Record count: {}", this.totalCount);
            Notifications.showError("Export limit exceeded. You can only download up to " + exportLimit + " records.");
        } else if (this.totalCount > 0) {
        	// Ensure SearchResultsCriteria is available
            if (this.searchResultsCriteria == null) {
            	Notifications.showError("No search criteria found. Please perform a search before exporting.");
                return;
            }

            // Use the search results criteria for export, not the current form state
            UserActivitySearchCriteria searchCriteria = this.searchResultsCriteria.toExportCriteria();

            // Generate title
            String title = "UserActivity History";

            // Generate date range
            String dateRange = "";
            if (searchCriteria.getStartDate() != null || searchCriteria.getEndDate() != null) {
                String startDate = searchCriteria.getStartDate() != null
                        ? searchCriteria.getStartDate().format(DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm"))
                        : "N/A";
                String endDate = searchCriteria.getEndDate() != null
                        ? searchCriteria.getEndDate().format(DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm"))
                        : "N/A";
                dateRange = getDateRangeText(startDate, endDate);
            }

            // Generate "Generated on" timestamp
            String generatedDate = getGeneratedOn();

            // Build search values dynamically
            StringBuilder searchValuesBuilder = new StringBuilder();
            if (searchCriteria.getUserId() != null && !searchCriteria.getUserId().isEmpty()) {
                searchValuesBuilder.append("User ID: \"").append(searchCriteria.getUserId()).append("\"\n");
            }
            if (searchCriteria.getFirstName() != null && !searchCriteria.getFirstName().isEmpty()) {
                searchValuesBuilder.append("First Name: \"").append(searchCriteria.getFirstName()).append("\"\n");
            }
            if (searchCriteria.getLastName() != null && !searchCriteria.getLastName().isEmpty()) {
                searchValuesBuilder.append("Last Name: \"").append(searchCriteria.getLastName()).append("\"\n");
            }

            // Finalize search values
            String searchValues = searchValuesBuilder.toString().trim();

            // Generate dynamic file name
            String fileName = "UserActivityHistory_" +
                    DateTimeFormatter.ofPattern("yyyy_MM_dd_HH_mm").format(LocalDateTime.now(ZoneOffset.UTC));

            // Customize localization for the export wizard
            GridExportLocalizationConfig localizationConfig = new GridExportLocalizationConfig()
                    .with(GridExportLocalizationConfig.EXPORT_GRID, "Export Data");

            // Initialize the GridExporter with the custom localization and dynamic title
            GridExporter.newWithDefaults(userActivityGrid)
                    .withLocalizationConfig(localizationConfig)
                    .withFileName(fileName) // Set the dynamic file name
                    .withAvailableFormats(
                            new PredefinedTitlePdfFormat(title, dateRange, generatedDate, searchValues)
                    )
                    .loadFromProvider(new PredefinedTitleProvider(title, dateRange, generatedDate, searchValues))
                    .open();
        } else {
            log.warn("Grid is empty, nothing to export");
            Notifications.showError("Grid is empty, nothing to export");
        }
    }

    /**
     * Generate the "Generated on" timestamp.
     *
     * @return String
     */
    private String getGeneratedOn() {
        Calendar cal = Calendar.getInstance();
        String timestamp = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss ").format(cal.getTime());
        timestamp += cal.getTimeZone().getDisplayName(false, TimeZone.SHORT);
        return "Generated on: " + timestamp;
    }

    /**
     * Generate the date range string to display from the transaction search form.
     *
     * @param startDate Start date as a string
     * @param endDate   End date as a string
     * @return String
     */
    private String getDateRangeText(String startDate, String endDate) {
        return "Date Range: " + startDate + " - " + endDate;
    }
}
