package com.ebtedge.fns.gateway.views.userpreference;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Collectors;

import com.ebtedge.fns.gateway.util.RouteUrls;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.vaadin.lineawesome.LineAwesomeIconUrl;

import com.ebtedge.config.helper.ConfigUtil;
import com.ebtedge.fns.gateway.config.GatAppConfig;
import com.ebtedge.fns.gateway.config.GatAppConfig.AlertListItem;
import com.ebtedge.fns.gateway.decorators.UserPreferenceReqDecorator;
import com.ebtedge.fns.gateway.decorators.UserPreferenceRespDecorator;
import com.ebtedge.fns.gateway.forms.UserPreferencesForm;
import com.ebtedge.fns.gateway.initializers.UserPreferenceGridInitializer;
import com.ebtedge.fns.gateway.layout.MainLayout;
import com.ebtedge.fns.gateway.model.UserPreferenceSearchCriteria;
import com.ebtedge.fns.gateway.model.UserPreferenceVO;
import com.ebtedge.fns.gateway.util.IpAddressUtil;
import com.ebtedge.fns.gateway.util.Notifications;
import com.ebtedge.fns.gateway.util.SessionUtil;
import com.ebtedge.kafka.core.EventPublisher;
import com.ebtedge.kafka.service.EventPublisherService;
import com.ebtedge.yb.criteria.UserPreferenceSearchQuery;
import com.ebtedge.yb.entity.UserPeferenceSearchResp;
import com.ebtedge.yb.exception.YBCoreException;
import com.ebtedge.yb.service.GatService;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.H3;
import com.vaadin.flow.component.html.H5;
import com.vaadin.flow.component.notification.NotificationVariant;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import com.vaadin.flow.router.BeforeLeaveEvent;
import com.vaadin.flow.router.BeforeLeaveObserver;
import com.vaadin.flow.router.Menu;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinSession;

import jakarta.annotation.security.PermitAll;
import lombok.extern.slf4j.Slf4j;

/**
 * User Preferences View for managing alert preferences
 */
@PageTitle("User Preferences")
@Route(value = RouteUrls.USER_PREFERENCES, layout = MainLayout.class)
@Menu(order = 7, icon = LineAwesomeIconUrl.USER_COG_SOLID)
@PermitAll
@Slf4j
public class UserPreferencesView extends VerticalLayout implements BeforeLeaveObserver, BeforeEnterObserver  {

	private static final String SUCCESS_MESSAGE = "User preferences saved successfully";
	private static final String ERROR_MESSAGE = "Please correct form errors";
	private static final String CANCEL_MESSAGE = "Operation cancelled";
	private final Grid<UserPreferenceVO> grid = new Grid<>(UserPreferenceVO.class, false);
	private final GatService gatService;
	private final GatAppConfig gatAppConfig;
	private final UserPreferencesForm userPreferencesForm;
	private final Map<String, String> alertCodeMap = new HashMap<>();
	private Map<String, String> reverseAlertCodeMap;

	/**
	 * Constructor - initializes the view
	 * 
	 * @param gatService   Gateway service
	 * @param configUtil   Configuration utility
	 * @param gatAppConfig Gateway application configuration
	 */
	  
		@Override
	    public void beforeEnter(BeforeEnterEvent event) {
	        boolean isSessionValid = SessionUtil.isSessionValid();
	        if (!isSessionValid) {
	            SessionUtil.invalidateSession();
	            event.forwardToUrl(gatAppConfig.getLogoutUrl());
	        }
	    }

	    /**
	     * Before leaving this page, pageName will be stored in the vaadin session.
	     * This previousUrl is referred in AnalyticsView.
	     * once after opening the GatsInsight in a new tab,GATS UI will load the previous screen.
	     */
	    @Override
	    public void beforeLeave(BeforeLeaveEvent event) {
	        String currentPage = "alerts";
	        VaadinSession.getCurrent().setAttribute("previousUrl", currentPage);
	    }
	    
	    
	public UserPreferencesView(GatService gatService, ConfigUtil configUtil, GatAppConfig gatAppConfig) {
		addClassName("user-preference-view");
		setPadding(true);
		setSpacing(true);

		this.gatAppConfig = gatAppConfig;
		this.gatService = gatService;
		this.userPreferencesForm = new UserPreferencesForm();
		initAlertCodeMap();
		initGrid();

		userPreferencesForm.setGridAndService(grid, gatService);
		userPreferencesForm.addSaveEventListener(event -> handleFormSave(event));
		userPreferencesForm.addCancelEventListener(event -> handleFormCancel());
		setJustifyContentMode(JustifyContentMode.CENTER);
		setAlignItems(Alignment.CENTER);
		buildView();

		fetchUserPreferences();
	}

	/**
	 * Initializes the mapping between alert codes and their display names
	 */
	private void initAlertCodeMap() {
		List<AlertListItem> alertItems = gatAppConfig.getAlertLists();
		if (alertItems == null || alertItems.isEmpty()) {
			return;
		}

		alertCodeMap.clear();
		for (AlertListItem alert : alertItems) {
			if (alert != null && alert.getDescription() != null && !alert.getDescription().trim().isEmpty()) {
				String codeStr = alert.getCode();
				if (codeStr == null || codeStr.trim().isEmpty()) {
					int position = alertCodeMap.size() + 1;
					codeStr = String.format("%03d", position);
				}
				alertCodeMap.put(codeStr, alert.getDescription());
			}
		}
	}

	/**
	 * Initializes the grid that displays alert preferences
	 */
	private void initGrid() {
		UserPreferenceGridInitializer.initializeGrid(this.grid, getAlertList());

	}
	/**
	 * Synchronizes user preferences by fetching from backend and updating UI components
	 */
	private void fetchUserPreferences() {
		try {
			UserPreferenceSearchQuery searchQuery = UserPreferenceReqDecorator.toUserPreferenceSearch().apply(null);
			List<UserPeferenceSearchResp> responses = gatService.userPreferenceSearch(searchQuery);

			String emailAddress = SessionUtil.getEmail() != null ? SessionUtil.getEmail().toUpperCase() : null;
			String phoneNumber = SessionUtil.getPhoneNumber()!=null?SessionUtil.getPhoneNumber():null;
			
			UserPreferenceSearchCriteria criteria = new UserPreferenceSearchCriteria();
			criteria.setEmailAddress(emailAddress);
			criteria.setPhoneNumber(phoneNumber);
			userPreferencesForm.getBinder().readBean(criteria);
			
			if("notfound".equalsIgnoreCase(phoneNumber) || phoneNumber.isBlank())
			{
				Notifications.showError("Verify phone number.  If incorrect, contact administrator to change prior to setting up SMS notifications");
			}
			
			if (responses == null || responses.isEmpty()) {
				log.info("No user preferences found");
				return;
			}
			
			UserPeferenceSearchResp userPrefResp = responses.get(0);
			if (userPrefResp == null) {
				log.info("No valid user preferences found in response");
				return;
			}

			

			String prefsString = userPrefResp.getPreferences();
			log.debug("Received preferences: " + prefsString);

			List<UserPreferenceVO> parsedPreferences = UserPreferenceRespDecorator.parsePreferenceCodes(prefsString);
			userPreferencesForm.setCurrentPreferences(parsedPreferences);
			UserPreferenceGridInitializer.updateGridWithPreferences(grid, alertCodeMap, parsedPreferences);
			
		} catch (Exception e) {
			log.error("Error loading user preferences", e);
			Notifications.showError("Failed to load user preferences. Please try again.");
		}
	}

	/**
	 * Gets the list of alert types to display in the grid
	 * 
	 * @return List of alert type names
	 */
	private List<String> getAlertList() {
		if (!alertCodeMap.isEmpty()) {
			return new java.util.ArrayList<>(alertCodeMap.values());
		}

		List<AlertListItem> configAlerts = gatAppConfig.getAlertLists();
		if (configAlerts == null) {
			return Collections.emptyList();
		}

		List<String> alertList = configAlerts.stream().map(AlertListItem::getDescription)
				.filter(desc -> desc != null && !desc.isEmpty()).collect(Collectors.toList());
		Collections.sort(alertList);
		return alertList;
	}

	/**
	 * Builds the view with header, forms, grid and action buttons
	 */
	private void buildView() {
		VerticalLayout container = new VerticalLayout();
		container.addClassName("setup-alerts-container");
		container.setAlignItems(Alignment.STRETCH);

		H3 title = new H3("User Alert Preferences");
		HorizontalLayout headerLayout = new HorizontalLayout(title);
		headerLayout.setAlignItems(FlexComponent.Alignment.CENTER);
		headerLayout.addClassName("setup-header");

		Component deliveryCard = createCard("Delivery methods", userPreferencesForm);

		H5 alertInfo = new H5("Based on the alert types, select Email and/or SMS notification for each alert type.");
		VerticalLayout alertLayout = new VerticalLayout(alertInfo, grid);
		alertLayout.setPadding(true);
		alertLayout.setSpacing(true);
		alertLayout.addClassName("alert-info");

		Component alertTypesCard = createCard("", alertLayout);

		HorizontalLayout actionButtons = createActionButtons();

		container.add(headerLayout, deliveryCard, alertTypesCard, actionButtons);
		add(container);
	}

	/**
	 * Creates a card component with title and content
	 * 
	 * @param title   Card title
	 * @param content Card content
	 * @return Card component
	 */
	private Component createCard(String title, Component content) {
		VerticalLayout layout = new VerticalLayout();
		layout.setPadding(false);
		layout.setSpacing(false);

		if (title != null && !title.isEmpty()) {
			layout.add(new H5(title));
		}

		layout.add(content);
		layout.addClassName("card-layout");

		Div cardDiv = new Div(layout);
		cardDiv.addClassName("custom-card");
		return cardDiv;
	}

	/**
	 * Creates action buttons for the view
	 * 
	 * @return Layout containing action buttons
	 */
	private HorizontalLayout createActionButtons() {
		Button saveButton = new Button("Save", e -> handleSave());
		Button cancelButton = new Button("Cancel", e -> handleCancel());

		saveButton.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
		cancelButton.addThemeVariants(ButtonVariant.LUMO_TERTIARY);

		HorizontalLayout actions = new HorizontalLayout(saveButton, cancelButton);
		actions.setSpacing(true);
		actions.getThemeList().add("spacing-xl");
		actions.setWidthFull();
		actions.setJustifyContentMode(JustifyContentMode.CENTER);

		return actions;
	}

	/**
	 * Handles save button click
	 */
	private void handleSave() {
		if (!userPreferencesForm.getBinder().isValid()) {
			Notifications.showError(ERROR_MESSAGE);
			return;
		}

		UserPreferenceSearchCriteria formData = new UserPreferenceSearchCriteria();
		if (userPreferencesForm.getBinder().writeBeanIfValid(formData)) {
			try {
				log.debug("Saving user preferences...");

				List<UserPreferenceVO> gridPreferences = grid.getListDataView().getItems().collect(Collectors.toList());

				if (log.isDebugEnabled()) {
					log.debug("Grid preferences count: " + gridPreferences.size());
					for (UserPreferenceVO pref : gridPreferences) {
						log.debug("Preference: " + pref.getAlertsTypeCode() + ", Email: " + pref.getEmail() + ", SMS: "
								+ pref.getSms());
					}
				}

				String formattedPreferences = formatPreferencesForSaving();

				log.debug("Formatted preferences: " + formattedPreferences);

				UserPreferenceSearchQuery updateQuery = UserPreferenceSearchQuery.builder()
						.userid(SessionUtil.getUserId() != null  ? SessionUtil.getUserId().toUpperCase() : null)
						.ipaddress(IpAddressUtil.getIpAddress())
						.appusername(SessionUtil.getFirstName() != null ? SessionUtil.getFirstName().toUpperCase(): null)
						.appserver("localhost")
						.searchtype("ALERT PREF UPDATE").startrow("").endrow("").sortby("ASC")
						.EmailAddress(formData.getEmailAddress()).PhoneNumber(formData.getPhoneNumber())
						.preferences(formattedPreferences).build();

				if (log.isDebugEnabled()) {
					log.debug("Sending update with: " + "userId=" + updateQuery.getUserid() + ", " + "email="
							+ updateQuery.getEmailAddress() + ", " + "phone=" + updateQuery.getPhoneNumber() + ", "
							+ "prefs=" + updateQuery.getPreferences());
				}

				boolean success = gatService.userPreferenceUpdate(updateQuery);
				gatService.userPreferenceKhafkaUpdate(updateQuery);
				if (success) {
					Notifications.show(SUCCESS_MESSAGE, NotificationVariant.LUMO_SUCCESS);
					// Refresh UI with latest preferences
					fetchUserPreferences();
				} else {
					log.warn("userPreferenceUpdate returned false");
					Notifications.showError("Failed to save preferences. Please try again.");
				}
			} catch (Exception e) {
				log.error("Error saving preferences", e);
				Notifications.showError("Failed to save preferences: " + e.getMessage());
			}
		}
	}

	/**
	 * Handles save event from the form
	 */
	private void handleFormSave(UserPreferencesForm.SaveEvent event) {
		try {
			log.debug("Handling form save event...");

			UserPreferenceSearchCriteria formData = event.getCriteria();
			List<UserPreferenceVO> gridPreferences = event.getPreferences();

			if (log.isDebugEnabled()) {
				log.debug("Grid preferences count: " + gridPreferences.size());
				for (UserPreferenceVO pref : gridPreferences) {
					log.debug("Preference: " + pref.getAlertsTypeCode() + ", Email: " + pref.getEmail() + ", SMS: "
							+ pref.getSms());
				}
			}

			UserPreferenceSearchQuery updateQuery = UserPreferenceReqDecorator
					.toUserPreferenceUpdate(formData.getEmailAddress(), formData.getPhoneNumber(), gridPreferences)
					.apply(null);

			boolean success = gatService.userPreferenceUpdate(updateQuery);

			if (success) {
				Notifications.show(SUCCESS_MESSAGE, NotificationVariant.LUMO_SUCCESS);
				userPreferencesForm.setCurrentPreferences(gridPreferences);
				fetchUserPreferences();
			} else {
				log.warn("userPreferenceUpdate returned false");
				Notifications.showError("Failed to save preferences. Please try again.");
			}
		} catch (Exception e) {
			log.error("Error saving preferences", e);
			Notifications.showError("Failed to save preferences: " + e.getMessage());
		}
	}

	/**
	 * Handles form cancel event
	 */
	private void handleFormCancel() {
		Notifications.show(CANCEL_MESSAGE);
		fetchUserPreferences();
	}

	/**
	 * Formats the selected preferences for saving to the backend
	 * 
	 * @return JSON string of preferences in the format ["001S","002E","003SE"]
	 */
	private String formatPreferencesForSaving() {
		StringBuilder resultJson = new StringBuilder("[");
		boolean isFirst = true;

		for (UserPreferenceVO pref : grid.getListDataView().getItems().collect(Collectors.toList())) {
			if (!Boolean.TRUE.equals(pref.getSms()) && !Boolean.TRUE.equals(pref.getEmail())) {
				continue;
			}

			String code = pref.getAlertsTypeCode();
			if (code == null || code.isEmpty()) {
				code = getCodeForAlertName(pref.getAlertTypeName());
			}

			StringBuilder notificationType = new StringBuilder();
			if (Boolean.TRUE.equals(pref.getSms())) {
				notificationType.append("S");
			}
			if (Boolean.TRUE.equals(pref.getEmail())) {
				notificationType.append("E");
			}

			if (!isFirst) {
				resultJson.append(",");
			} else {
				isFirst = false;
			}

			resultJson.append("\"").append(code).append(notificationType).append("\"");
		}

		resultJson.append("]");
		return resultJson.toString();
	}

	/**
	 * Finds the alert code for a given alert name
	 * 
	 * @param alertName Alert type name
	 * @return Corresponding alert code or "000" if not found
	 */
	private String getCodeForAlertName(String alertName) {
		if (alertName == null) {
			return "000";
		}

		if (reverseAlertCodeMap == null) {
			reverseAlertCodeMap = new HashMap<>(alertCodeMap.size());
			for (Map.Entry<String, String> entry : alertCodeMap.entrySet()) {
				reverseAlertCodeMap.put(entry.getValue(), entry.getKey());
			}
		}

		return reverseAlertCodeMap.getOrDefault(alertName, "000");
	}
	


	/**
	 * Handles cancel button click
	 */
	private void handleCancel() {
		Notifications.show(CANCEL_MESSAGE);
		fetchUserPreferences();
	}
}
