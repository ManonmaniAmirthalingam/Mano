package com.ebtedge.fns.gateway.views.analytics;

import com.ebtedge.fns.gateway.config.GatAppConfig;
import com.ebtedge.fns.gateway.util.RouteUrls;
import com.ebtedge.fns.gateway.util.SessionUtil;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.html.Anchor;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.*;
import com.vaadin.flow.server.VaadinSession;
import com.vaadin.flow.spring.annotation.UIScope;
import jakarta.annotation.security.PermitAll;
import lombok.extern.slf4j.Slf4j;
import org.vaadin.lineawesome.LineAwesomeIconUrl;

@PageTitle("Analytics")
@Route(RouteUrls.ANALYTICS)
@Menu(order = 2, icon = LineAwesomeIconUrl.CHART_BAR)
@PermitAll
@UIScope
@Slf4j
public class AnalyticsView extends VerticalLayout {

    public AnalyticsView(GatAppConfig gatAppConfig) {
        String gatsInsightUrl = gatAppConfig.getGatsInsightUrl();
        String userId = SessionUtil.getUserId();
        StringBuffer buffer = new StringBuffer();
        buffer
                .append(gatsInsightUrl)
                .append("?")
                .append("userID=" + userId);
        gatsInsightUrl = buffer.toString();
        log.info("GatsInsight url : " + gatsInsightUrl);
        Anchor anchor = new Anchor(gatsInsightUrl);
        anchor.setTarget("_blank"); // Opens the link in a new tab add(anchor);
        add(anchor);
        // Automatically click the anchor to trigger the redirection
        anchor.getElement().callJsFunction("click");

        /**
         * once after opening the GatsInsight in a new tab,GATS UI will load the previous screen.
         */
        String previousUrl = (String) VaadinSession.getCurrent().getAttribute("previousUrl");
        if (previousUrl == null || previousUrl.isEmpty()) {
            previousUrl = "transaction/search";
            UI.getCurrent().getPage().setLocation(previousUrl);
        } else {
            UI.getCurrent().getPage().setLocation(previousUrl);
        }
        log.info("previousUrl : " + previousUrl);
    }
}
