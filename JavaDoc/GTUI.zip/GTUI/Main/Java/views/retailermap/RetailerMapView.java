package com.ebtedge.fns.gateway.views.retailermap;

import com.ebtedge.config.helper.ConfigUtil;
import com.ebtedge.fns.gateway.config.GatAppConfig;
import com.ebtedge.fns.gateway.decorators.RetailerMapReqDecorator;
import com.ebtedge.fns.gateway.decorators.RetailerMapRespDecorator;
import com.ebtedge.fns.gateway.exception.GatException;
import com.ebtedge.fns.gateway.forms.RetailerMapForm;
import com.ebtedge.fns.gateway.initializers.RetailersMapInitializer;
import com.ebtedge.fns.gateway.model.*;
import com.ebtedge.fns.gateway.util.*;
import com.ebtedge.yb.criteria.RetailerMapSearchQuery;
import com.ebtedge.yb.entity.RetailersMapResp;
import com.ebtedge.yb.service.GatService;
import com.flowingcode.vaadin.addons.googlemaps.GoogleMap;
import com.flowingcode.vaadin.addons.googlemaps.GoogleMapMarker;
import com.flowingcode.vaadin.addons.googlemaps.LatLon;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.notification.NotificationVariant;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.FlexLayout;
import com.vaadin.flow.component.splitlayout.SplitLayout;
import com.vaadin.flow.router.*;
import com.vaadin.flow.server.VaadinSession;
import com.vaadin.flow.spring.annotation.UIScope;
import com.vaadin.flow.theme.lumo.LumoUtility;
import lombok.extern.slf4j.Slf4j;
import org.vaadin.lineawesome.LineAwesomeIconUrl;
import software.xdev.vaadin.grid_exporter.GridExportLocalizationConfig;
import software.xdev.vaadin.grid_exporter.GridExporter;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * View for Transaction Search. This page will take care of initializing Transaction search from, grid and all other details related to transaction search.
 *
 * @author e5616051
 * @version 1.0.0
 * @see {@link RetailerMapForm}
 * @see {@link RetailersMapInitializer}
 * @since 1.0.0
 */

@PageTitle("SNAP Retailers")
@Route(RouteUrls.RETAILER_SEARCH)
@Menu(order = 3, icon = LineAwesomeIconUrl.LOCATION_ARROW_SOLID)
@Slf4j
@UIScope
public class RetailerMapView extends Div implements BeforeLeaveObserver, BeforeEnterObserver {

    private final Grid<RetailerMapVO> grid = new Grid<>(RetailerMapVO.class, false);
    private final GatService gatService;
    private final ConfigUtil configUtil;
    private final GatAppConfig gatAppConfig;
    Div mapDisplayDiv = new Div();
    Div retailerSearchDiv = new Div();
    GoogleMap googleMap = null;
    List<GoogleMapMarker> gMarkersList = new ArrayList<>();
    RetailerMapForm retailerMapForm = null;
    private final Div totalRecordsDisplayDiv = new Div();
    private int totalRecordCount = 0; // Store the total record count

    RetailerMapCriteria searchCriteria;

    /**
     * Before leaving this page, pageName will be stored in the vaadin session.
     * This previousUrl is referred in AnalyticsView.
     * once after opening the GatsInsight in a new tab,GATS UI will load the previous screen.
     */
    @Override
    public void beforeLeave(BeforeLeaveEvent event) {
        String currentPage = "retailersearch";
        VaadinSession.getCurrent().setAttribute("previousUrl", currentPage);
    }

    /**
     * Callback executed before navigation to attaching Component chain is made.
     *
     * @param event before navigation event with event details
     */
    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        boolean isSessionValid = SessionUtil.isSessionValid();
        if (!isSessionValid) {
            SessionUtil.invalidateSession();
            event.forwardToUrl(gatAppConfig.getLogoutUrl());
        }
    }

    /**
     * Initializes Retailers Search view.
     *
     * @param gatService   {@link GatService}
     * @param configUtil {@Link ConfigUtil}
     * @param gatAppConfig {@link GatAppConfig}
     */
    public RetailerMapView(GatService gatService, ConfigUtil configUtil, GatAppConfig gatAppConfig) {
        addClassNames("retailer-detail-view");

        this.gatService = gatService;
        this.configUtil = configUtil;
        this.gatAppConfig = gatAppConfig;
        initMap();
        initializeForm();
        setSizeFull();
        this.grid.setPageSize(Integer.parseInt(gatAppConfig.getGridInitialSize()));
        RetailersMapInitializer.initializeGrid(this.grid);
        retailerMapForm.addExportEventListener(event -> exportGridData());
        retailerMapForm.addClearEventListener(event -> {
            removeMarkers(gMarkersList);
            gMarkersList.clear();

            grid.setVisible(false);
            totalRecordsDisplayDiv.setVisible(false); // Hide the Total Record Count
            grid.setItems();
            totalRecordsDisplayDiv.removeAll(); // Clear the Total Record Count text
            grid.sort(null);
            searchCriteria = null; // Reset the stored search criteria
            totalRecordCount = 0; // Reset the total record count
        });

        SplitLayout splitLayout = initMainPageSplitLayout();
        add(splitLayout);
    }

    /**
     * Initializes Retailers search view with Primary and secondary layouts. The Primary view contains the Google Map (60%),
     * and the secondary view contains the Retailers Search Criteria and grid (40%).
     *
     * @return SplitLayout
     */
    private SplitLayout initMainPageSplitLayout() {
        SplitLayout splitLayout = new SplitLayout();
      
        splitLayout.addToPrimary(createSecondaryLayout());
        splitLayout.addToSecondary(createPrimaryLayout()); 
        splitLayout.getPrimaryComponent().addClassName(LumoUtility.Overflow.AUTO);
        splitLayout.getSecondaryComponent().addClassName(LumoUtility.Overflow.AUTO);
        
      
        splitLayout.setSplitterPosition(55);
        splitLayout.setSizeFull();
        
        return splitLayout;
    }

    /**
     * Creates layout for Retailers search view. This layout contains Retailers Search Criteria, search results grid,
     * and total record count info.
     *
     * @return
     */
    private Div createPrimaryLayout() {

        retailerSearchDiv.addClassNames("retailer-search-main-view");

        Icon vaadinIcon = VaadinIcon.CLOSE_SMALL.create();
        vaadinIcon.addClassNames("retailer-search-close-icon");
        vaadinIcon.addClickListener(event -> {
            this.grid.setVisible(false);
            totalRecordsDisplayDiv.setVisible(false);
            totalRecordsDisplayDiv.removeAll();
            this.grid.setItems();
            grid.sort(null);
        });

        Span detailTitle = new Span("Search for SNAP Retailers");
        detailTitle.addClassNames("retailer-search-title");

        FlexLayout flexLayout = new FlexLayout(vaadinIcon, detailTitle);
        flexLayout.setFlexDirection(FlexLayout.FlexDirection.ROW);
        flexLayout.setAlignItems(FlexComponent.Alignment.START);
        flexLayout.addClassNames("retailer-search-title-flex");

        
        totalRecordsDisplayDiv.addClassNames("retailer-total-records-display-div");
        totalRecordsDisplayDiv.setVisible(false);

        Div searchSummaryDiv = new Div();
        searchSummaryDiv.setSizeFull();
        searchSummaryDiv.add(totalRecordsDisplayDiv, this.grid);
        searchSummaryDiv.addClassNames(LumoUtility.Padding.Left.SMALL);

        retailerSearchDiv.add(flexLayout, retailerMapForm);
        retailerSearchDiv.add(searchSummaryDiv);
        retailerSearchDiv.setSizeFull();
        retailerSearchDiv.setVisible(true);
        return retailerSearchDiv;

    }

    /**
     * Creates secondary layout for Retailers search view. This layout contains the Google Map display.
     *
     * @return Div containing the Google Map
     */
    private Div createSecondaryLayout() {

        mapDisplayDiv.addClassNames("map-display-div");
        mapDisplayDiv.setSizeFull();

        Div secondaryLayoutMainDiv = new Div();
        secondaryLayoutMainDiv.addClassNames(LumoUtility.Padding.Left.MEDIUM);

        mapDisplayDiv.add(this.googleMap);

        secondaryLayoutMainDiv.add(mapDisplayDiv);
        secondaryLayoutMainDiv.setVisible(true);

        return secondaryLayoutMainDiv;
    }

    /**
     * Initialize Retailers Search form {@link RetailerMapForm}
     */
    private void initializeForm() {
        retailerMapForm = new RetailerMapForm(gatService, getStateCodeAndDesc(), getBusinessTypeCodeAndDesc());
        retailerMapForm.addSearchEventListener(this::searchRetailers);
    }

    private List<String> getStateCodeAndDesc() {
        return this.gatAppConfig
                .getStateCodes()
                .stream()
                .map(GatAppConfig::getNameAndAbbr)
                .sorted()
                .collect(Collectors.toList());
    }

    private List<String> getBusinessTypeCodeAndDesc() {
        return this.gatAppConfig
                .getBusinessTypes()
                .stream()
                .map(GatAppConfig::getBusinessCodeDesc)
                .sorted()
                .collect(Collectors.toList());
    }

    /**
     * perform Retailers search
     *
     * @param event
     */
    private void searchRetailers(RetailerMapForm.RetailersSearchEvent event) {

        try {
            searchCriteria = event.getRetailerMapCriteria();
            final List<RetailersMapResp>[] cachedFirstPageData = new List[1];
            AtomicInteger counter = new AtomicInteger(1);
            this.grid.sort(null);

            this.grid.setItems(query -> {
                List<RetailerMapSort> sortOrders = FormUtil.getRetailerMapGridSortOrder(query);
                searchCriteria.setGridSort(sortOrders);
                searchCriteria.setSearchtype("LOCATION SEARCH");
                RetailerMapSearchQuery retailerMapSearchQuery = RetailerMapReqDecorator.toRetailerMapCriteria().apply(searchCriteria);
                int offset = query.getOffset();
                int limit = query.getLimit();
                counter.set(offset + 1); // Updating the counter for row numbers

                retailerMapSearchQuery.setStartRow(Integer.toString(offset));
                retailerMapSearchQuery.setEndRow(Integer.toString(limit));
                if (offset != 0) {
                    retailerMapSearchQuery.setEndRow(Integer.toString(offset + Integer.parseInt(gatAppConfig.getGridInitialSize())));
                    retailerMapSearchQuery.setStartRow(Integer.toString(offset + 1));
                    retailerMapSearchQuery.setSearchType("LOCATION SEARCH NEXTSET");
                }

                if(sortOrders != null && !sortOrders.isEmpty()) {
                    retailerMapSearchQuery.setSearchType("LOCATION SEARCH SORT");
                }

                List<RetailersMapResp> retailersMapRespList = fetchRetailersSearchData(retailerMapSearchQuery);
                if (retailersMapRespList != null && retailersMapRespList.size() > 0) {
                    this.googleMap.enableMarkersClustering();
                    retailersMapRespList = findRetailersSearchByDays(retailersMapRespList, searchCriteria.getSelectedDays());
                    addRetailerMarkers(retailersMapRespList, this.googleMap);
                    totalRecordCount = retailersMapRespList.size(); //Integer.parseInt(retailersMapRespList.get(0)
                            //.getTotal_row_count());
                    totalRecordsDisplayDiv.removeAll();
                    totalRecordsDisplayDiv.add("Total Record Count: " + totalRecordCount);
                    totalRecordsDisplayDiv.setVisible(true);
                } else {
                    totalRecordCount = 0;
                    totalRecordsDisplayDiv.removeAll();
                    totalRecordsDisplayDiv.setVisible(false);
                    removeMarkers(gMarkersList);
                }
                return retailersMapRespList.stream()
                        .map(tranSearchResp -> {
                            RetailerMapVO vo = RetailerMapRespDecorator.toFinancialVO().apply(tranSearchResp);
                            return vo;
                        })
                        .collect(Collectors.toList())
                        .stream();
            });
        } catch (Exception e) {
            log.error("Error while fetching the data: {}", e);
            Notification notification = new Notification(e.getMessage(), 3000, Notification.Position.TOP_CENTER);
            notification.addThemeVariants(NotificationVariant.LUMO_ERROR);
            notification.open();
        }
        this.grid.setVisible(true);
    }

    private List<RetailersMapResp> findRetailersSearchByDays(List<RetailersMapResp> retailersMapResps, int days)
    {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMddyyyyHHmmss");
        LocalDateTime now = LocalDateTime.parse(LocalDateTime.now().format(formatter), formatter);
        LocalDateTime then = LocalDateTime.parse(((LocalDateTime.now().minusDays(days)).format(formatter)), formatter);
        return retailersMapResps.stream().filter(retailersMapResp -> ((retailersMapResp.getLasttxn_ts() != null) &&
                (now.isAfter(LocalDateTime.parse(retailersMapResp.getLasttxn_ts(), formatter))) && (then.isBefore(LocalDateTime.parse(retailersMapResp.getLasttxn_ts(), formatter))))
        ).collect(Collectors.toList());
    }

    private List<RetailersMapResp> fetchRetailersSearchData(RetailerMapSearchQuery retailerMapSearchQuery) {
        if (!SessionUtil.isSessionValid()) {
            log.error("Session is invalid during fetchRetailersSearchData. Redirecting to logout.");
            SessionUtil.invalidateSession();
            getUI().ifPresent(ui -> ui.getPage().setLocation(gatAppConfig.getLogoutUrl()));
            return List.of();
        }
        return gatService.retailersSearch(retailerMapSearchQuery);
    }

    private void exportGridData() {
        log.info("Export to Grid button clicked");

        // Read the export limit from the configuration
        int exportLimit = Integer.parseInt(gatAppConfig.getExportLimit());

        if (totalRecordCount > exportLimit) {
            log.warn("Export limit exceeded. Record count: {}", totalRecordCount);
            Notifications.showError("Export limit exceeded. You can only download up to " + exportLimit + " records.");
        } else if (totalRecordCount > 0) {
            // Retrieve search values from the form
            RetailerMapCriteria searchCriteria = retailerMapForm.getBinder().getBean();

            // Generate title
            String title = "Retailers Details";

            // Generate date range
            String dateRange = "";
            /*if (searchCriteria.getStartDate() != null && searchCriteria.getEndDate() != null) {
                dateRange = getDateRangeText(
                        searchCriteria.getStartDate().format(DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm")),
                        searchCriteria.getEndDate().format(DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm"))
                );
            }*/
            // Generate "Generated on" timestamp
            String generatedDate = getGeneratedOn();

            // Build search values dynamically
            StringBuilder searchValuesBuilder = new StringBuilder();

            if (searchCriteria.getMerchantstate() != null && !searchCriteria.getMerchantstate().isEmpty()) {
                searchValuesBuilder.append("State: \"")
                        .append(String.join(", ", searchCriteria.getMerchantstate())).append("\"\n");
            }
            if (searchCriteria.getCounty_name() != null && !searchCriteria.getCounty_name().isEmpty()) {
                searchValuesBuilder.append("County: \"").append(searchCriteria.getCounty_name()).append("\"\n");
            }
            if (searchCriteria.getMerchantcity() != null && !searchCriteria.getMerchantcity().isEmpty()) {
                searchValuesBuilder.append("City: \"").append(searchCriteria.getMerchantcity()).append("\"\n");
            }
            if (searchCriteria.getMerchantzip() != null && !searchCriteria.getMerchantzip().isEmpty()) {
                searchValuesBuilder.append("Zip Code: \"").append(searchCriteria.getMerchantzip()).append("\"\n");
            }
            if (searchCriteria.getMerchantaddress() != null && !searchCriteria.getMerchantaddress().isEmpty()) {
                searchValuesBuilder.append("Address: \"").append(searchCriteria.getMerchantaddress()).append("\"\n");
            }
            if (searchCriteria.getStoretype() != null && !searchCriteria.getStoretype().isEmpty()) {
                searchValuesBuilder.append("Business Store Type: \"").append(searchCriteria.getStoretype()).append("\"\n");
            }

            // Finalize search values
            String searchValues = searchValuesBuilder.toString().trim();

            // Generate dynamic file name
            String fileName = "Retailers_Details_" +
                    DateTimeFormatter.ofPattern("yyyy_MM_dd_HH_mm").format(LocalDateTime.now(ZoneOffset.UTC));

            // Customize localization for the export wizard
            GridExportLocalizationConfig localizationConfig = new GridExportLocalizationConfig()
                    .with(GridExportLocalizationConfig.EXPORT_GRID, "Export Data");

            // Initialize the GridExporter with the custom localization and dynamic title
            GridExporter.newWithDefaults(grid)
                    .withLocalizationConfig(localizationConfig)
                    .withFileName(fileName) // Set the dynamic file name
                    .withAvailableFormats(
                            new PredefinedTitleProvider.PredefinedTitlePdfFormat(title, dateRange, generatedDate, searchValues)
                    )
                    .loadFromProvider(new PredefinedTitleProvider(title, dateRange, generatedDate, searchValues))
                    .open();
        } else {
            log.warn("Grid is empty, nothing to export");
            Notifications.showError("Grid is empty, nothing to export");
        }
    }

    /**
     * Generate the "Generated on" timestamp.
     *
     * @return String
     */
    private String getGeneratedOn() {
        Calendar cal = Calendar.getInstance();
        String timestamp = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss ").format(cal.getTime());
        timestamp += cal.getTimeZone().getDisplayName(false, TimeZone.SHORT);
        return "Generated on: " + timestamp;
    }

    /**
     * Generate the date range string to display from the transaction search form.
     *
     * @param startDate Start date as a string
     * @param endDate   End date as a string
     * @return String
     */
    private String getDateRangeText(String startDate, String endDate) {
        return "Date Range: " + startDate + " - " + endDate;
    }

    private void initMap()
    {
        //this.googleMap = new GoogleMap("AIzaSyCObObbNBprupOymS1o0Xd7LhNxF7S3ZZA",null,null);
        this.googleMap = new GoogleMap(gatAppConfig.getGoogleMapApikey(),null,null);
        this.googleMap.setMapType(GoogleMap.MapType.HYBRID);
        this.googleMap.goToCurrentLocation();
        this.googleMap.setZoom(12);
        this.googleMap.setSizeFull();
        this.googleMap.getLatitude();
        this.googleMap.getLongitude();
    }

    private void addRetailerMarkers(List<RetailersMapResp> retailersMapResps, GoogleMap googleMap1)
    {
        removeMarkers(gMarkersList);
        gMarkersList.clear();
        //log.info("gMarkersList Size = "+gMarkersList.size());
        if(retailersMapResps.size() >0) {
            googleMap1.setCenter(new LatLon(Double.parseDouble(retailersMapResps.get(0).getLatitude()), Double.parseDouble(retailersMapResps.get(0).getLongitude())));
            for (RetailersMapResp retailersMapResp : retailersMapResps) {
                String colorCode = getColorCode(retailersMapResp.getLasttxn_ts()) + ".png";
                String iconUrl = "http://maps.google.com/mapfiles/ms/icons/" + colorCode;
                GoogleMapMarker mapMarker = googleMap1.addMarker(retailersMapResp.getStore_name() + "\n"
                                //+ retailersMapResp.getLoc_address() + "\n "
                                //+ retailersMapResp.getLoc_city()+", "+retailersMapResp.getLoc_state() +"\n"
                                + (retailersMapResp.getBusinesstype() != null ? retailersMapResp.getBusinesstype() : "N/A") + "\n"
                                + (retailersMapResp.getLasttxn_ts() != null ? DateTimeConvertors.formatDBTimestamp(retailersMapResp.getLasttxn_ts()) : "N/A"),
                        new LatLon(Double.parseDouble(retailersMapResp.getLatitude()), Double.parseDouble(retailersMapResp.getLongitude())), false, iconUrl);
                mapMarker.addInfoWindow("<h1 background='green';>" + retailersMapResp.getStore_name() + "</h1>\n" +
                        "<hr>\n" +
                        "<span>" + retailersMapResp.getStndrd_st_addr() + "</span>\n" +
                        "<span>" + retailersMapResp.getLoc_city() + "</span>\n" + "<span>" + retailersMapResp.getLoc_state() + "," + retailersMapResp.getLoc_zip() + "</span>\n" +
                        "<p><b>County:</b>" + retailersMapResp.getCounty_name() + " </p>\n" +
                        "<p><b>SNAP Clasification:</b>" + (retailersMapResp.getBusinesstype() != null ? retailersMapResp.getBusinesstype() : "N/A") + "</p>\n" +
                        "<p><b>FNS Number:</b>" + retailersMapResp.getFns_number() + "</p>\n" +
                        "<p><b>Last Transaction Time:</b>" + (retailersMapResp.getLasttxn_ts() != null ? DateTimeConvertors.formatDBTimestamp(retailersMapResp.getLasttxn_ts()) : "N/A") + "</p>\n");

                gMarkersList.add(mapMarker);
            }
        }
        //log.info("Final gMarkersList Size = "+gMarkersList.size());
    }

    private String getColorCode(String timeStamp)
    {
        String colorCode = "red";

        if(!(timeStamp == null)) {
            int hrs = getHours(timeStamp);
            if (hrs <= 6)
                colorCode = "green";
            else if (hrs <= 24)
                colorCode = "blue";
            else if (hrs <= 48)
                colorCode = "yellow";
            else if (hrs <= 120)
                colorCode = "orange";
            else if (hrs > 120)
                colorCode = "red";
        }

        return colorCode;
    }

    private int getHours(String lastTransDate)
    {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");
        SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
        try {
            Date tranDate = df.parse(DateTimeConvertors.formatDBTimestamp(lastTransDate));
            Date currDate = df.parse(LocalDateTime.now().format(dtf));
            //System.out.println("tranDate - "+tranDate+", Current DAte -"+currDate);
            long diffTime = currDate.getTime() - tranDate.getTime();
            //System.out.println("diffTime - "+diffTime);
            return  (int) ((diffTime / (1000*60*60)));
        } catch (Exception e) {
            log.error("Error while formating date: {} {} ", lastTransDate, e);
            throw new GatException("Error formatting date");
        }
    }

    private void removeMarkers(List gMarkersList)
    {
        for(Object mapMarker : gMarkersList)
            googleMap.removeMarker((GoogleMapMarker)mapMarker);
    }
}
