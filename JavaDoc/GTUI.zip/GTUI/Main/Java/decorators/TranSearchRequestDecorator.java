package com.ebtedge.fns.gateway.decorators;

import com.ebtedge.fns.gateway.model.TranSearchCriteria;
import com.ebtedge.fns.gateway.model.TranSummaryGridSort;
import com.ebtedge.fns.gateway.util.DateTimeConvertors;
import com.ebtedge.fns.gateway.util.IpAddressUtil;
import com.ebtedge.fns.gateway.util.SessionUtil;
import com.ebtedge.yb.criteria.TranSearchCriteriaQuery;
import org.apache.commons.lang3.StringUtils;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;

/**
 * Request decorator class for transaction search. It converts Form search criteria into Transaction search criteria
 *
 * @author e3023044
 * @version 1.0.0
 * @since 1.0.0
 */
public class TranSearchRequestDecorator {

    /**
     * Converts {@link TranSearchCriteria} to {@link TranSearchCriteriaQuery}
     * TODO: Hardcoded values needs to be removed post SSO integration.
     *
     * @return Function<SearchCriteria, TranSearchCriteria>
     */
    public static Function<TranSearchCriteria, TranSearchCriteriaQuery> toTranSearchCriteria() {

        Function<TranSearchCriteria, TranSearchCriteriaQuery> function =
                (request) -> TranSearchCriteriaQuery
                        .builder()
                        .state(convertToDBSyntax(request.getStates()))
                        .startTs(DateTimeConvertors.formatLocalDateToDbTimestamp(request.getStartDate()) + "00")
                        .endTs(DateTimeConvertors.formatLocalDateToDbTimestamp(request.getEndDate()) + "59")
                        .cardNumber(getCardNumber(request))
                        .isCardNumberWildcard(isWildcardSearch(request.getCard()))
                        .fnsNumber(StringUtils.isNotBlank(request.getFnsNumber()) ? request.getFnsNumber() : null)
                        .isFnsNumberWildCard("N")
                        .storeType(convertToDBSyntax(request.getBusinessType()))
                        .terminalId(StringUtils.isNotBlank(request.getTerminalId()) ? request.getTerminalId() : null)
                        .isTerminalIdWildCard("N")
                        .minFraudScore(StringUtils.isNotBlank(request.getMinScore()) ? request.getMinScore() : null)
                        .minFraudScore(StringUtils.isNotBlank(request.getMaxScore()) ? request.getMaxScore() : null)
                        .isOutOfStateTrx(isOutOfStateTrx(request.getFlags()))
                        .isInternetTran(isInternetTran(request.getFlags()))
                        .isOnlyAlert(isAlertTrans(request.getFlags()))
                        .is24HourStore(is24HoursStore(request.getFlags()))
                        .sortby(getSortOrder(request.getGridSort()))
                        .searchType(request.getSearchType())
                        .sortByField(getSortOrderProperty(request.getGridSort()))
                        .appServer("localhost")
                        .appUserId(SessionUtil.getUserId() != null  ? SessionUtil.getUserId().toUpperCase() : null)
                        .appUserEmail(SessionUtil.getEmail() != null ? SessionUtil.getEmail().toUpperCase() : null)
                        .appUserFirstName(SessionUtil.getFirstName() != null ? SessionUtil.getFirstName().toUpperCase(): null)
                        .appUserLastName(SessionUtil.getLastName() != null ? SessionUtil.getLastName().toUpperCase(): null)
                        .appUserMidName(SessionUtil.getMiddleName() != null ? SessionUtil.getMiddleName().toUpperCase(): null)
                        .ipAddress(IpAddressUtil.getIpAddress())
                        .build();
        return function;
    }


    /**
     * Determines full card number search, wildcard search or contains search.
     *
     * @param request
     * @return
     */
    private static String getCardNumber(TranSearchCriteria request) {
        String card = request.getCard();
        if (StringUtils.isNotBlank(card) && card.contains("*")) {
            return "%" + card.replace("*", "");
        } else if (StringUtils.isNotBlank(card) && (card.length() == 16 || card.length() == 19))
            return card;
        else if (StringUtils.isNotBlank(card)) {
            return "%" + card + "%";
        }
        return null;
    }

    /**
     * Determine if user searching with wildcard or full card number.
     * The length 16 and 19 are considered full card number search and all other searches will be considered wildcard.
     * If card number is prefixed with "*" then it will look for card number ending with the value otherwise contains value.
     *
     * @param input card number
     * @return "Y" or "N"
     */
    private static String isWildcardSearch(String input) {
        if (StringUtils.isNotBlank(input) && input.contains("*"))
            return "Y";
        if (StringUtils.isNotBlank(input) && (input.length() != 16 && input.length() != 19))
            return "Y";
        return "N";
    }

    /**
     * Convert Set<String> user selected into database query specific format.
     *
     * @param states
     * @return string as per the database syntax.
     */
    private static String convertToDBSyntax(Set<String> states) {
        if (states == null || states.isEmpty())
            return null;
        else {
            Set<String> stateList = new HashSet<>();
            for (String s : states) {
                s = s.substring(0, s.indexOf("-")).trim();
                String tempState = "''" + s + "''";
                stateList.add(tempState);
            }
            return "" + stateList.toString().replace("[", "").replace("]", "") + "";
        }
    }


    /**
     * TODO: This needs to be changed. Currently DB SQL function is only taking one businessType
     * as search parameter that is the reason we are just taking first items from the set and sending it.
     *
     * @param businessTypes list of business types that user selects
     * @return business type code
     */
    private static String getBusinessType(Set<String> businessTypes) {
        if (businessTypes != null && businessTypes.size() > 0) {
            Object[] array = businessTypes.toArray();
            String item = (String) array[0];
            item = item.substring(0, item.indexOf("-")).trim();
            return item;
        }
        return null;
    }


    /**
     * Determine if out of state transaction is selected.
     *
     * @param flags
     * @return "Y" or "N"
     */
    private static String isOutOfStateTrx(Set<String> flags) {
        if (flags != null) {
            Optional<String> outOfState = flags.stream()
                    .filter(s -> s.equalsIgnoreCase("Out Of State"))
                    .findFirst();
            if (outOfState.isPresent()) {
                return "Y";
            }
        }
        return "N";
    }

    /**
     * Determine if Alert transaction is selected.
     *
     * @param flags
     * @return "Y" or "N"
     */
    private static String isAlertTrans(Set<String> flags) {
        if (flags != null) {
            Optional<String> outOfState = flags.stream()
                    .filter(s -> s.equalsIgnoreCase("Alert Trans"))
                    .findFirst();
            if (outOfState.isPresent()) {
                return "Y";
            }
        }
        return "N";
    }

    /**
     * Determine if internet transaction is selected.
     *
     * @param flags
     * @return "Y" or "N"
     */
    private static String isInternetTran(Set<String> flags) {
        if (flags != null) {
            Optional<String> outOfState = flags.stream()
                    .filter(s -> s.equalsIgnoreCase("Internet"))
                    .findFirst();
            if (outOfState.isPresent()) {
                return "Y";
            }
        }
        return "N";
    }


    /**
     * Determine if 24 Hour Stores is selected.
     *
     * @param flags
     * @return "Y" or "N"
     */
    private static String is24HoursStore(Set<String> flags) {
        if (flags != null) {
            Optional<String> outOfState = flags.stream()
                    .filter(s -> s.equalsIgnoreCase("24 Hour Stores"))
                    .findFirst();
            if (outOfState.isPresent()) {
                return "Y";
            }
        }
        return "N";
    }


    /**
     * Determines sort order.
     *
     * @param gridSort
     * @return "DESC" or "ASC"
     */
    private static String getSortOrder(List<TranSummaryGridSort> gridSort) {
        if (gridSort != null && gridSort.size() > 0) {
            TranSummaryGridSort tranSummaryGridSort = gridSort.get(0);
            return tranSummaryGridSort.isDescending() ? "DESC" : "ASC";
        }
        return "DESC";
    }

    /**
     * Determine sort field name from the user selection.
     *
     * @param gridSort
     * @return selected field name
     */
    private static String getSortOrderProperty(List<TranSummaryGridSort> gridSort) {

        if (gridSort != null && gridSort.size() > 0) {
            TranSummaryGridSort tranSummaryGridSort = gridSort.get(0);
            return tranSummaryGridSort.getPropertyName();
        }
        return null;
    }
}
