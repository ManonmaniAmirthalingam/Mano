package com.ebtedge.fns.gateway.decorators;

import com.ebtedge.fns.gateway.model.FinancialTranVO;
import com.ebtedge.fns.gateway.util.DateTimeConvertors;
import com.ebtedge.yb.entity.TranSearchResp;
import lombok.Builder;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Used for converting DB response into UI specific object for Transaction search.
 *
 * @author e3023044
 * @version 1.0.0
 * @since 1.0.0
 */
public class TranSearchRespDecorator {

    /**
     * Convert {@link TranSearchResp} to {@link FinancialTranVO}
     *
     * @return Function<TranSearchResp, FinancialTranVO>
     */
    public static Function<TranSearchResp, FinancialTranVO> toFinancialVO() {

        Function<TranSearchResp, FinancialTranVO> function =
                (tranSearchResp) -> {
                    FinancialTranVO financialTranVO = FinancialTranVO.builder()
                            .tranTs(DateTimeConvertors.formatDBTimestamp(tranSearchResp.getStateTs()))
                            .tranTypeCode(StringUtils.isNotBlank(tranSearchResp.getTrantype()) ? tranSearchResp.getTrantype().trim() : "-")
                            .tranTypeDesc(StringUtils.isNotBlank(tranSearchResp.getTrandesc()) ? tranSearchResp.getTrandesc().trim() : "-")
                            .tranAmount(tranSearchResp.getTransactionAmount())
                            .cardNumber(tranSearchResp.getCardNumber())
                            .terminalId(tranSearchResp.getTerminalId())
                            .fnsNumber(tranSearchResp.getFnsNumber())
                            .merchantName(tranSearchResp.getCardAcceptorName())
                            .merchantAddress(tranSearchResp.getCardAcceptorAddress())
                            .merchantCity(tranSearchResp.getCardAcceptorCity())
                            .merchantState(tranSearchResp.getCardAcceptorState())
                            .responseCode(tranSearchResp.getResponseCode())
                            .responseCodeDesc(StringUtils.isNotBlank(tranSearchResp.getRspcodedesc()) ? tranSearchResp.getRspcodedesc() : "-")
                            .fraudScore(tranSearchResp.getFnScore())
                            .businessTypeCode(StringUtils.isNotBlank(tranSearchResp.getFcsType()) ? tranSearchResp.getFcsType() : "")
                            .businessTypeDesc(StringUtils.isNotBlank(tranSearchResp.getBusinesstype()) ? tranSearchResp.getBusinesstype() : "")
                            .terminalClass(tranSearchResp.getTerminalClass())
                            .presentationData(tranSearchResp.getPresentationData())
                            .secCondCode(tranSearchResp.getSecurityCondition())
                            .terminalTypeCode(tranSearchResp.getTerminalTypeCode())
                            .terminalCapabilityCode(tranSearchResp.getTerminalCapabilityCode())
                            .posEntryMode(tranSearchResp.getPosEntryMode())
                            .redeName(tranSearchResp.getStoreName())
                            .redeStreetName(tranSearchResp.getLocAddress())
                            .redeCity(tranSearchResp.getLocCity())
                            .redeState(tranSearchResp.getLocState())
                            .redeZip(tranSearchResp.getLocZip())
                            .intDeliveryAddr(tranSearchResp.getDeliveryStreet())
                            .intDeliveryCity(tranSearchResp.getDeliveryCity())
                            .intDeliveryState(tranSearchResp.getDeliveryState())
                            .intDeliveryZip(tranSearchResp.getDeliveryZipcode())
                            .intDeliveryShippingIndCode(tranSearchResp.getDeliveryShippingInd())
                            .alertFlag(tranSearchResp.getAlertFlag())
                            .open24HoursFlag(tranSearchResp.getOpen24Flag())
                            .panEntryModeCode(tranSearchResp.getPanEntryMode())
                            .panEntryModeDesc(tranSearchResp.getPanEntryModeDesc())
                            .pinEntryMode(tranSearchResp.getPinEntryMode())
                            .pinEntryModeDesc(tranSearchResp.getPinEntryModeDesc())
                            .cardAcceptorId(tranSearchResp.getCardAcceptorId())
                            .intDeliveryShippingIndDesc(getShippingIndicatorDes(tranSearchResp.getDeliveryShippingInd()))
                            .acqInstIdentificationCode(tranSearchResp.getAcqInstIdentificationCode())
                            .geoState(tranSearchResp.getLocState())
                            .geoZip(tranSearchResp.getLocZip())
                            .mcc(tranSearchResp.getMerchantType())
                            .build();
                    setBalances(financialTranVO, tranSearchResp);
                    return financialTranVO;
                };
        return function;
    }

    /**
     * It loops through all 12 available balances and update the balance values accordingly in brean.
     *
     * @param financialTranVO
     * @param tranSearchResp
     */
    private static void setBalances(FinancialTranVO financialTranVO, TranSearchResp tranSearchResp) {

        List<Balances> balanceList = new ArrayList<>();

        balanceList.add(Balances.builder()
                .balType(tranSearchResp.getAmountType1())
                .balAmount(tranSearchResp.getAdditionalAmount1())
                .build());

        balanceList.add(Balances.builder()
                .balType(tranSearchResp.getAmountType2())
                .balAmount(tranSearchResp.getAdditionalAmount2())
                .build());

        balanceList.add(Balances.builder()
                .balType(tranSearchResp.getAmountType3())
                .balAmount(tranSearchResp.getAdditionalAmount3())
                .build());

        balanceList.add(Balances.builder()
                .balType(tranSearchResp.getAmountType4())
                .balAmount(tranSearchResp.getAdditionalAmount4())
                .build());

        balanceList.add(Balances.builder()
                .balType(tranSearchResp.getAmountType5())
                .balAmount(tranSearchResp.getAdditionalAmount5())
                .build());

        balanceList.add(Balances.builder()
                .balType(tranSearchResp.getAmountType6())
                .balAmount(tranSearchResp.getAdditionalAmount6())
                .build());

        balanceList.add(Balances.builder()
                .balType(tranSearchResp.getAmountType7())
                .balAmount(tranSearchResp.getAdditionalAmount7())
                .build());

        balanceList.add(Balances.builder()
                .balType(tranSearchResp.getAmountType8())
                .balAmount(tranSearchResp.getAdditionalAmount8())
                .build());

        balanceList.add(Balances.builder()
                .balType(tranSearchResp.getAmountType9())
                .balAmount(tranSearchResp.getAdditionalAmount9())
                .build());

        balanceList.add(Balances.builder()
                .balType(tranSearchResp.getAmountType10())
                .balAmount(tranSearchResp.getAdditionalAmount10())
                .build());

        balanceList.add(Balances.builder()
                .balType(tranSearchResp.getAmountType11())
                .balAmount(tranSearchResp.getAdditionalAmount11())
                .build());

        balanceList.add(Balances.builder()
                .balType(tranSearchResp.getAmountType12())
                .balAmount(tranSearchResp.getAdditionalAmount12())
                .build());
        balanceList = balanceList.stream()
                .filter(balances -> StringUtils.isNotBlank(balances.getBalType()) && StringUtils.isNotBlank(balances.getBalAmount()))
                .collect(Collectors.toList());
        for (Balances balances : balanceList) {
            switch (balances.getBalType()) {
                case "02":
                    financialTranVO.setFoodEndingBal(balances.getBalAmount());
                    break;
                case "18":
                    financialTranVO.setFoodBeginningBal(balances.getBalAmount());
                    break;
                case "42":
                    financialTranVO.setSurchargeAmount(balances.getBalAmount());
                    break;
                case "5S":
                    financialTranVO.setIncentiveEligible(balances.getBalAmount());
                    break;
                case "5T":
                    financialTranVO.setIncentiveEarned(balances.getBalAmount());
                    break;
                case "5U":
                    financialTranVO.setIncentiveMTD(balances.getBalAmount());
                    break;
            }
        }
    }

    /**
     * Hold Balance type and its actual value.
     */
    @Data
    @Builder
    private static class Balances {
        private String balType;
        private String balAmount;
    }

    /**
     * @param shippingIndCode
     * @return
     */
    private static String getShippingIndicatorDes(String shippingIndCode) {

        if ("0".equalsIgnoreCase(shippingIndCode)) {
            return "Data not available";
        }

        if ("1".equalsIgnoreCase(shippingIndCode)) {
            return "Direct delivery";
        }

        if ("2".equalsIgnoreCase(shippingIndCode)) {
            return "Customer pickup";
        }

        if ("3".equalsIgnoreCase(shippingIndCode)) {
            return "Commercial Shipping";
        }

        if ("9".equalsIgnoreCase(shippingIndCode)) {
            return "Other";
        }

        return "";
    }
}
