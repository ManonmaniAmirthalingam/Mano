package com.ebtedge.fns.gateway.decorators;

import com.ebtedge.fns.gateway.model.UserActivityGridVO;
import com.ebtedge.fns.gateway.model.UserActivityPayloadVO;
import com.ebtedge.fns.gateway.util.DateTimeConvertors;
import com.ebtedge.yb.entity.UserActivitySearchResp;
import com.ebtedge.yb.entity.UserActivitySearchRespPayload;

import java.util.function.Function;

/**
 * Decorator class to convert UserActivitySearchResp to UserActivityGridVO.
 * This class is responsible for transforming the response from the service layer
 * into a format suitable for the UI layer.
 */
public class UserActivityRespDecorator {

    public static Function<UserActivitySearchResp, UserActivityGridVO> toUserActivityGridVO() {

        Function<UserActivitySearchResp, UserActivityGridVO> function =
                (userActivitySearchResp) -> {
                    return UserActivityGridVO.builder()
                            .userActivityTimestamp(DateTimeConvertors.formatDBTimestamp(userActivitySearchResp.getEventTs()))
                            .userActivity(userActivitySearchResp.getActionDesc())
                            .payload(userActivitySearchResp.getPayload() != null ? convertToPayloadVO(userActivitySearchResp.getPayload()) : null)
                            .firstName(userActivitySearchResp.getFirstName())
                            .middleName(userActivitySearchResp.getMiddleName())
                            .lastName(userActivitySearchResp.getLastName())
                            .userId(userActivitySearchResp.getUserId())
                            .emailAddress(userActivitySearchResp.getEmail())
                            .build();
                };
        return function;
    }

    /**
     * Converts UserActivitySearchRespPayload to UserActivityPayloadVO.
     *
     * @param payload the UserActivitySearchRespPayload object
     * @return the converted UserActivityPayloadVO object
     */
    private static UserActivityPayloadVO convertToPayloadVO(UserActivitySearchRespPayload payload) {
        return UserActivityPayloadVO.builder()
                .startTs(payload.getStartTs() != null ? DateTimeConvertors.formatUserActivityDBTimestamp(payload.getStartTs()) : "NA")
                .endTs((payload.getEndTs() != null ? DateTimeConvertors.formatUserActivityDBTimestamp(payload.getEndTs()) : "NA"))
                .srchUsrId(payload.getSrchUsrId() != null ? payload.getSrchUsrId() : "")
                .isSrchUsrIdWildcard(payload.getIsSrchUsrIdWildcard() != null ? payload.getIsSrchUsrIdWildcard() : "")
                .srchUsrFname(payload.getSrchUsrFname() != null ? payload.getSrchUsrFname() : "")
                .isSrchUsrFnameWildcard(payload.getIsSrchUsrFnameWildcard() != null ? payload.getIsSrchUsrFnameWildcard() : "")
                .srchUsrLname(payload.getSrchUsrLname() != null ? payload.getSrchUsrLname() : "")
                .isSrchUsrLnameWildcard(payload.getIsSrchUsrLnameWildcard() != null ? payload.getIsSrchUsrLnameWildcard() : "")
                .isSrchAllUsr(payload.getIsSrchAllUsr() != null ? payload.getIsSrchAllUsr() : "")
                .srchUsrType(payload.getSrchUsrType() != null ? payload.getSrchUsrType() : "")
                .ipAddress(payload.getIpAddress() != null ? payload.getIpAddress() : "")
                .appUserId(payload.getAppUserId() != null ? payload.getAppUserId() : "")
                .appUserFirstName(payload.getAppUserFirstName() != null ? payload.getAppUserFirstName() : "")
                .appUserMidName(payload.getAppUserMidName() != null ? payload.getAppUserMidName() : "")
                .appUserLastName(payload.getAppUserLastName() != null ? payload.getAppUserLastName() : "")
                .appUserEmail(payload.getAppUserEmail() != null ? payload.getAppUserEmail() : "")
                .appUserType(payload.getAppUserType() != null ? payload.getAppUserType() : "")
                .appServer(payload.getAppServer() != null ? payload.getAppServer() : "")
                .searchType(payload.getSearchType() != null ? payload.getSearchType() : "")
                .startRow(payload.getStartRow() != null ? payload.getStartRow() : "")
                .endRow(payload.getEndRow() != null ? payload.getEndRow() : "")
                .sortBy(payload.getSortBy() != null ? payload.getSortBy() : "")
                .sortField(payload.getSortField() != null ? payload.getSortField() : "")
                .build();
    }
}
