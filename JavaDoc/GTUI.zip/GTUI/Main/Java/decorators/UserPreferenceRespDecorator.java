package com.ebtedge.fns.gateway.decorators;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import com.ebtedge.fns.gateway.model.UserPreferenceVO;
import com.ebtedge.fns.gateway.util.SessionUtil;
import com.ebtedge.yb.entity.UserPeferenceSearchResp;

import lombok.extern.slf4j.Slf4j;

/**
 * Decorator class to transform UserPeferenceSearchResp to UserPreferenceVO
 */
@Slf4j
public class UserPreferenceRespDecorator {
	
	private static final Pattern PREF_PATTERN = Pattern.compile("\"(\\d+)([SE]+)\"");
	
	private UserPreferenceRespDecorator() {
	   
	}
	
	/**
	 * Converts UserPeferenceSearchResp to UserPreferenceVO
	 * 
	 * @return Function that transforms UserPeferenceSearchResp to UserPreferenceVO
	 */
	public static Function<UserPeferenceSearchResp, UserPreferenceVO> toUserPreferenceVO() {
		return userPreferenceResp -> {
		    if (userPreferenceResp == null) {
		        return null;
		    }
		    
		    String preferences = userPreferenceResp.getPreferences();
		    
			return UserPreferenceVO.builder()
					.emailAddress(SessionUtil.getEmail() != null ? SessionUtil.getEmail().toUpperCase() : null)
			        .phoneNumber(SessionUtil.getPhoneNumber()!=null?SessionUtil.getPhoneNumber():null)
				.alertsTypeCode(preferences)
				.sms(preferences != null && preferences.contains("S"))
				.email(preferences != null && preferences.contains("E"))
				.build();
		};
	}
	/**
	 * Parses the preferences string and extracts the alert codes with their notification types
	 * 
	 * @param preferences Raw preferences string from response (format: ["001S","002E", "003SE"])
	 * @return List of parsed preference codes with notification types
	 */
	public static List<UserPreferenceVO> parsePreferenceCodes(String preferences) {
		if (preferences == null || preferences.isEmpty()) {
			return Collections.emptyList();
		}
		
		List<UserPreferenceVO> result = new ArrayList<>();
		
		try {
		    
		    String cleanedPrefs = preferences.trim();
		    if (cleanedPrefs.startsWith("[") && cleanedPrefs.endsWith("]")) {
		        cleanedPrefs = cleanedPrefs.substring(1, cleanedPrefs.length() - 1);
		    }
		    
		   
		    String[] parts = cleanedPrefs.split(",");
		    
		    for (String part : parts) {
		        
		        String cleaned = part.trim().replace("\"", "");
		        if (cleaned.isEmpty()) {
		            continue;
		        }
		        
		       
		        if (cleaned.length() >= 3) {
		            String code = cleaned.substring(0, 3);
		            String notificationTypes = cleaned.substring(3);
		            
		            result.add(UserPreferenceVO.builder()
		                .alertsTypeCode(code)
		                .sms(notificationTypes.contains("S"))
		                .email(notificationTypes.contains("E"))
		                .build());
		        }
		    }
		} catch (Exception e) {
			
			log.info("Fallback to regex parsing for preference, Reason: {}", e);
		    String cleanedPrefs = preferences.replace("[", "").replace("]", "").replace("\\", "");
		    Matcher matcher = PREF_PATTERN.matcher(cleanedPrefs);
		    
		    while (matcher.find()) {
		        String code = matcher.group(1);
		        String notificationTypes = matcher.group(2);
		        
		        result.add(UserPreferenceVO.builder()
		            .alertsTypeCode(code)
		            .sms(notificationTypes.contains("S"))
		            .email(notificationTypes.contains("E"))
		            .build());
		    }
		}
		
		return result;
	}
}
