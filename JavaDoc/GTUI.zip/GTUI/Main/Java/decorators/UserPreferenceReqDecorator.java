package com.ebtedge.fns.gateway.decorators;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

import com.ebtedge.fns.gateway.model.UserPreferenceSearchCriteria;
import com.ebtedge.fns.gateway.model.UserPreferenceVO;
import com.ebtedge.fns.gateway.util.IpAddressUtil;
import com.ebtedge.fns.gateway.util.SessionUtil;
import com.ebtedge.yb.criteria.UserPreferenceSearchQuery;

/**
 * Decorator for transforming user preference requests for backend calls
 */
public class UserPreferenceReqDecorator {

	public static Function<Void, UserPreferenceSearchQuery> toUserPreferenceSearch() {
		return (request) -> UserPreferenceSearchQuery.builder()
				.userid(SessionUtil.getUserId() != null  ? SessionUtil.getUserId().toUpperCase() : null)
				.ipaddress(IpAddressUtil.getIpAddress())
				.appusername(SessionUtil.getFirstName() != null ? SessionUtil.getFirstName().toUpperCase(): null)
				.appserver("localhost")
				.searchtype("USER PREFERENCE SEARCH")
				.startrow("")
				.endrow("")
				.sortby("ASC")				
				.build();
		
		
		

	}

	public static Function<Void, UserPreferenceSearchQuery> toUserPreferenceUpdate(String emailAddress,
			String phoneNumber, List<UserPreferenceVO> preferences) {

		// Format preferences as ["001S","002E", "003SE"]
		List<String> formattedPrefs = new ArrayList<>();
		for (UserPreferenceVO pref : preferences) {
			if (pref.getAlertsTypeCode() != null
					&& (Boolean.TRUE.equals(pref.getEmail()) || Boolean.TRUE.equals(pref.getSms()))) {

				StringBuilder prefBuilder = new StringBuilder(pref.getAlertsTypeCode());
				if (Boolean.TRUE.equals(pref.getSms())) {
					prefBuilder.append("S");
				}
				if (Boolean.TRUE.equals(pref.getEmail())) {
					prefBuilder.append("E");
				}
				formattedPrefs.add("\"" + prefBuilder.toString() + "\"");
			}
		}

		String prefsString = "[" + String.join(",", formattedPrefs) + "]";

		return (request) -> UserPreferenceSearchQuery.builder()
				.userid(SessionUtil.getUserId() != null  ? SessionUtil.getUserId().toUpperCase() : null)
				.ipaddress(IpAddressUtil.getIpAddress())
				.appusername(SessionUtil.getFirstName() != null ? SessionUtil.getFirstName().toUpperCase(): null)
				.appserver("localhost")
				.searchtype("ALERT PREF UPDATE").startrow("").endrow("").sortby("ASC")
				.EmailAddress(SessionUtil.getEmail() != null ? SessionUtil.getEmail().toUpperCase() : null)
                .PhoneNumber(SessionUtil.getPhoneNumber()!=null?SessionUtil.getPhoneNumber():null)
				.preferences(prefsString).build();
	}
}
