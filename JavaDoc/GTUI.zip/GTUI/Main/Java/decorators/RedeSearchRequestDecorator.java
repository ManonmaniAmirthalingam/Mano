package com.ebtedge.fns.gateway.decorators;

import java.time.LocalTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Function;

import com.ebtedge.fns.gateway.util.IpAddressUtil;
import com.ebtedge.fns.gateway.util.SessionUtil;
import org.apache.commons.lang3.StringUtils;

import com.ebtedge.fns.gateway.model.RedeSearchCriteria;
import com.ebtedge.fns.gateway.model.RedeSummaryGridSort;
import com.ebtedge.fns.gateway.util.DateTimeConvertors;
import com.ebtedge.yb.criteria.RedeSearchCriteriaQuery;

public class RedeSearchRequestDecorator { 
	public static Function<RedeSearchCriteria, RedeSearchCriteriaQuery> toRedeSearchCriteria() {

        Function<RedeSearchCriteria, RedeSearchCriteriaQuery> function =
                (request) ->{ 
                	     RedeSearchCriteriaQuery.RedeSearchCriteriaQueryBuilder builder = RedeSearchCriteriaQuery
                        .builder()
                        .fnsNumber(StringUtils.isNotBlank(request.getFnsNumber()) ? request.getFnsNumber() : null)
                        .isFnsNumberWildCard("N")
                        .terminalId(StringUtils.isNotBlank(request.getTerminalId()) ? request.getTerminalId() : null)
                        .isTerminalIdWildCard("N")
                        .scoretype(convertToDBSyntax(request.getScoreType())) // Dynamically set scoretype
                        .minScore(StringUtils.isNotBlank(request.getMinScore()) ? request.getMinScore() : null)
                        .maxScore(StringUtils.isNotBlank(request.getMaxScore()) ? request.getMaxScore() : null)
                        .startTs(DateTimeConvertors.formatLocalDateToDbTimestamp(request.getStartDate()))
                        .endTs(DateTimeConvertors.formatLocalDateToDbTimestamp(request.getEndDate()))
                        .status(request.getStatus())
                        .sortby(getSortOrder(request.getGridSort()))
                        .searchType(request.getSearchType())
                        .sortByField(getSortOrderProperty(request.getGridSort()))
                        .appServer("localhost")
                        .appUserId(SessionUtil.getUserId() != null  ? SessionUtil.getUserId().toUpperCase() : null)
                        .appUserEmail(SessionUtil.getEmail() != null ? SessionUtil.getEmail().toUpperCase() : null)
                        .appUserFirstName(SessionUtil.getFirstName() != null ? SessionUtil.getFirstName().toUpperCase(): null)
                        .appUserLastName(SessionUtil.getLastName() != null ? SessionUtil.getLastName().toUpperCase(): null)
                        .appUserMidName(SessionUtil.getMiddleName() != null ? SessionUtil.getMiddleName().toUpperCase(): null)
                        .ipAddress(IpAddressUtil.getIpAddress());
                        // If "My Items" filter is enabled, add the current user ID to the assignedUser filter
                        if (request.getMyItems() != null && request.getMyItems()) {
                            builder.assignedUser(SessionUtil.getUserId() != null ? SessionUtil.getUserId().toUpperCase() : null);
                        }
                        
                        return builder.build();
                    };
        return function;
    }

   
    /**
     * Determines sort order.
     *
     * @param gridSort
     * @return "DESC" or "ASC"
     */
    private static String getSortOrder(List<RedeSummaryGridSort> gridSort) {
        if (gridSort != null && gridSort.size() > 0) {
        	RedeSummaryGridSort redeSummaryGridSort = gridSort.get(0);
            return redeSummaryGridSort.isDescending() ? "DESC" : "ASC";
        }
        return "DESC";
    }

    /**
     * Determine sort field name from the user selection.
     *
     * @param gridSort
     * @return selected field name
     */
    private static String getSortOrderProperty(List<RedeSummaryGridSort> gridSort) {

        if (gridSort != null && gridSort.size() > 0) {
        	RedeSummaryGridSort redeSummaryGridSort = gridSort.get(0);
            return redeSummaryGridSort.getPropertyName();
        }
        return null;
    }
    
    private static String convertToDBSyntax(Set<String> scoreTypes) {
        if (scoreTypes == null || scoreTypes.isEmpty())
            return null;
        else {
            Set<String> stateList = new HashSet<>();
            for (String s : scoreTypes) {
               
                String tempState = s;
                stateList.add(tempState);  
            }
            return "" + stateList.toString().replace("[","").replace("]","") + "";
        }
    }
}
