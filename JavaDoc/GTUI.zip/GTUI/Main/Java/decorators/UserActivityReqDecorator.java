package com.ebtedge.fns.gateway.decorators;

import com.ebtedge.fns.gateway.model.UserActivityGridSort;
import com.ebtedge.fns.gateway.model.UserActivitySearchCriteria;
import com.ebtedge.fns.gateway.util.DateTimeConvertors;
import com.ebtedge.fns.gateway.util.IpAddressUtil;
import com.ebtedge.fns.gateway.util.SessionUtil;
import com.ebtedge.yb.criteria.UserActivitySearchQuery;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalTime;
import java.util.List;
import java.util.function.Function;

/**
 * Decorator class to convert UserActivitySearchCriteria to UserActivitySearchQuery.
 * This class is responsible for transforming the request from the UI layer
 * into a format suitable for the service layer.
 */
public class UserActivityReqDecorator {

    public static Function<UserActivitySearchCriteria, UserActivitySearchQuery> toUserActivitySearchQuery() {

        // TODO: Remove hardcoded Values once authentication is implemented
        Function<UserActivitySearchCriteria, UserActivitySearchQuery> function =
                (request) -> UserActivitySearchQuery
                        .builder()
                        .startTs(DateTimeConvertors.formatLocalDateToDbTimestamp(request.getStartDate()))
                        .endTs(DateTimeConvertors.formatLocalDateToDbTimestamp(request.getEndDate()))
                        .srchUsrType("ADMIN")
                        .searchType(request.getSearchType())
                        .sortBy(getSortOrder(request.getGridSort()))
                        .sortField(getSortOrderProperty(request.getGridSort()))
                        .srchUsrId(StringUtils.isNotBlank(request.getUserId()) ? "%" + request.getUserId() + "%" : null)
                        .isSrchUsrIdWildcard(StringUtils.isNotBlank(request.getUserId()) ? "Y" : null)
                        .srchUsrFname(StringUtils.isNotBlank(request.getFirstName()) ? request.getFirstName() + "%" : null)
                        .isSrchUsrFnameWildcard(StringUtils.isNotBlank(request.getFirstName()) ? "Y" : null)
                        .srchUsrLname(StringUtils.isNotBlank(request.getLastName()) ? request.getLastName() + "%" : null)
                        .isSrchUsrLnameWildcard(StringUtils.isNotBlank(request.getLastName()) ? "Y" : null)
                        .appServer("localhost")
                        .appUserId(SessionUtil.getUserId() != null  ? SessionUtil.getUserId().toUpperCase() : null)
                        .appUserEmail(SessionUtil.getEmail() != null ? SessionUtil.getEmail().toUpperCase() : null)
                        .appUserFirstName(SessionUtil.getFirstName() != null ? SessionUtil.getFirstName().toUpperCase(): null)
                        .appUserLastName(SessionUtil.getLastName() != null ? SessionUtil.getLastName().toUpperCase(): null)
                        .appUserMidName(SessionUtil.getMiddleName() != null ? SessionUtil.getMiddleName().toUpperCase(): null)
                        .ipAddress(IpAddressUtil.getIpAddress())
                        .build();
        return function;
    }


    /**
     * Determines sort order.
     *
     * @param gridSort
     * @return "DESC" or "ASC"
     */
    private static String getSortOrder(List<UserActivityGridSort> gridSort) {
        if (gridSort != null && !gridSort.isEmpty()) {
            UserActivityGridSort userActivityGridSort = gridSort.get(0);
            return userActivityGridSort.isDescending() ? "DESC" : "ASC";
        }
        return "DESC";
    }

    /**
     * Determine sort field name from the user selection.
     *
     * @param gridSort
     * @return selected field name
     */
    private static String getSortOrderProperty(List<UserActivityGridSort> gridSort) {
        if (gridSort != null && gridSort.size() > 0) {
            UserActivityGridSort userActivityGridSort = gridSort.get(0);
            return userActivityGridSort.getPropertyName();
        }
        return null;
    }
}
