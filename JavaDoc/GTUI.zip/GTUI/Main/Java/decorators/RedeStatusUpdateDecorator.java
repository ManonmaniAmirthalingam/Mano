package com.ebtedge.fns.gateway.decorators;

import java.util.function.Function;

import com.ebtedge.fns.gateway.model.RedeStatusUpdateRequest;
import com.ebtedge.fns.gateway.util.IpAddressUtil;
import com.ebtedge.fns.gateway.util.SessionUtil;
import com.ebtedge.yb.criteria.RedeStatusUpdateCriteriaQuery;


/**
 * Decorator for converting the REDE status update request to the format expected by the backend.
 */
public class RedeStatusUpdateDecorator {    
	
	
	/**
     * Converts {@link RedeStatusUpdateRequest} to {@link StatusUpdateCriteriaQuery}
     * 
     * @return Function that converts the request
     */
    public static Function<RedeStatusUpdateRequest, RedeStatusUpdateCriteriaQuery> toStatusUpdateCriteria() {
        return request -> RedeStatusUpdateCriteriaQuery.builder()
                .fns_number(request.getFnsNumber())
                .terminal_id(request.getTerminalId())
                .status(request.getStatus())
                .recordsource("WEB INTERFACE")
                .appServer("localhost")
                .userid(SessionUtil.getUserId() != null  ? SessionUtil.getUserId().toUpperCase() : null)
                .appUserId(SessionUtil.getUserId() != null  ? SessionUtil.getUserId().toUpperCase() : null)
                .appUserEmail(SessionUtil.getEmail() != null ? SessionUtil.getEmail().toUpperCase() : null)
                .appUserFirstName(SessionUtil.getFirstName() != null ? SessionUtil.getFirstName().toUpperCase(): null)
                .appUserLastName(SessionUtil.getLastName() != null ? SessionUtil.getLastName().toUpperCase(): null)
                .appUserMidName(SessionUtil.getMiddleName() != null ? SessionUtil.getMiddleName().toUpperCase(): null)
                .ipaddress(IpAddressUtil.getIpAddress())
                .build();
    }
}
