package com.ebtedge.fns.gateway.decorators;

import com.ebtedge.fns.gateway.exception.GatException;
import com.ebtedge.fns.gateway.model.RetailerMapVO;
import com.ebtedge.fns.gateway.util.DateTimeConvertors;
import com.ebtedge.yb.entity.RetailersMapResp;
import lombok.extern.slf4j.Slf4j;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.function.Function;

@Slf4j
public class RetailerMapRespDecorator {

    public static Function<RetailersMapResp, RetailerMapVO> toFinancialVO() {

        return (retailersMapResp) -> RetailerMapVO.builder()
                .lasttxn_ts(retailersMapResp.getLasttxn_ts() != null
                                ? DateTimeConvertors.formatDBTimestamp(retailersMapResp.getLasttxn_ts())
                                : "")
                .colorCode(getColorCodeGroup(retailersMapResp.getLasttxn_ts() != null
                        ? DateTimeConvertors.formatDBTimestamp(retailersMapResp.getLasttxn_ts())
                        : ""))
                .fns_number(retailersMapResp.getFns_number())
                .store_name(retailersMapResp.getStore_name())
                .open24_flag(retailersMapResp.getOpen24_flag())
                .county(retailersMapResp.getCounty())
                .county_name(retailersMapResp.getCounty_name())
                .fcs_type(retailersMapResp.getFcs_type())
                .businesstype(retailersMapResp.getBusinesstype())
                .loc_number(retailersMapResp.getLoc_number())
                .loc_address(retailersMapResp.getLoc_address())
                .loc_city(retailersMapResp.getLoc_city())
                .loc_state(retailersMapResp.getLoc_state())
                .loc_zip(retailersMapResp.getLoc_zip())
                .loc_add_addr_info(retailersMapResp.getLoc_add_addr_info())
                .stndrd_st_addr(retailersMapResp.getStndrd_st_addr())
                .stndrd_city(retailersMapResp.getStndrd_city())
                .stndrd_state(retailersMapResp.getStndrd_state())
                .stndrd_zip_code(retailersMapResp.getStndrd_zip_code())
                .latitude(retailersMapResp.getLatitude())
                .longitude(retailersMapResp.getLongitude())
                .total_row_count(retailersMapResp.getTotal_row_count())
                .build();
    }

    private static String getColorCodeGroup(String timeStamp)
    {
        String colorCodeGroup = "";

        if(!(timeStamp == null || timeStamp.length() < 1)) {
            int hrs = getHours(timeStamp);
            if (hrs <= 6)
                colorCodeGroup = "6 hrs";
            else if (hrs <= 24)
                colorCodeGroup = "24 hrs";
            else if (hrs <= 48)
                colorCodeGroup = "2 days";
            else if (hrs <= 120)
                colorCodeGroup = "5 days";
            else if (hrs > 120)
                colorCodeGroup = "6-30 days";
        }

        return colorCodeGroup;
    }

    private static int getHours(String lastTransDate)
    {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");
        SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
        try {
            Date tranDate = df.parse(lastTransDate);
            Date currDate = df.parse(LocalDateTime.now().format(dtf));
            //System.out.println("tranDate - "+tranDate+", Current DAte -"+currDate);
            long diffTime = currDate.getTime() - tranDate.getTime();
            //System.out.println("diffTime - "+diffTime);
            return  (int) ((diffTime / (1000*60*60)));
        } catch (Exception e) {
            log.error("Error while formating date: {} {} ", lastTransDate, e);
            throw new GatException("Error formatting date");
        }
    }
}
