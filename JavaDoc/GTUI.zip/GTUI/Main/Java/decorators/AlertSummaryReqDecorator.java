package com.ebtedge.fns.gateway.decorators;

import com.ebtedge.fns.gateway.model.AlertSearchCriteria;
import com.ebtedge.fns.gateway.model.AlertSummaryGridSort;
import com.ebtedge.fns.gateway.util.DateTimeConvertors;
import com.ebtedge.fns.gateway.util.IpAddressUtil;
import com.ebtedge.fns.gateway.util.SessionUtil;
import com.ebtedge.yb.criteria.AlertSummaryCriteria;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Function;


public class AlertSummaryReqDecorator {


    public static Function<AlertSearchCriteria, AlertSummaryCriteria> toAlertSearchCriteria() {

        Function<AlertSearchCriteria, AlertSummaryCriteria> function =
                (request) -> AlertSummaryCriteria
                        .builder()
                        .searchtype(request.getSearchType())
                        .alertid(StringUtils.isNotBlank(request.getAlertId()) ? request.getAlertId() : null)
                        .cardNumber(getCardNumber(request))
                        .isCardNumberWildcard(isWildcardSearch(request.getCard()))
                        .fnsNumber(StringUtils.isNotBlank(request.getFnsNumber()) ? request.getFnsNumber() : null)
                        .terminalId(StringUtils.isNotBlank(request.getTerminalId()) ? request.getTerminalId() : null)
                        .startDate(DateTimeConvertors.formatLocalDateToDbTimestamp(request.getStartDate()))
                        .endDate(DateTimeConvertors.formatLocalDateToDbTimestamp(request.getEndDate()))
                        .rule(convertToDBSyntax(request.getRuleName()))
                        .sortby("ASC")
                        .sortby(getSortOrder(request.getGridSort()))
                        .sortfield(getSortOrderProperty(request.getGridSort()))
                        .ipAddress(IpAddressUtil.getIpAddress())
                        .appServer("localhost")
                        .appUsername(SessionUtil.getUserId() != null  ? SessionUtil.getUserId().toUpperCase() : null)
                        .appUserEmail(SessionUtil.getEmail() != null ? SessionUtil.getEmail().toUpperCase() : null)
                        .appUserFirstName(SessionUtil.getFirstName() != null ? SessionUtil.getFirstName().toUpperCase(): null)
                        .appUserLastName(SessionUtil.getLastName() != null ? SessionUtil.getLastName().toUpperCase(): null)
                        .appUserMidName(SessionUtil.getMiddleName() != null ? SessionUtil.getMiddleName().toUpperCase(): null)
                        .build();
        return function;
    }


    /**
     * Determines full card number search, wildcard search or contains search.
     *
     * @param request
     * @return
     */
    private static String getCardNumber(AlertSearchCriteria request) {
        String card = request.getCard();
        if (StringUtils.isNotBlank(card) && card.contains("*")) {
            return "%" + card.replace("*", "");
        } else if (StringUtils.isNotBlank(card) && (card.length() == 16 || card.length() == 19))
            return card;
        else if (StringUtils.isNotBlank(card)) {
            return "%" + card + "%";
        }
        return null;
    }

    private static String convertToDBSyntax(Set<String> ruleNames) {
        if (ruleNames == null || ruleNames.isEmpty())
            return null;
        else {
            Set<String> stateList = new HashSet<>();
            for (String s : ruleNames) {

                String tempState = s;
                stateList.add(tempState);
            }
            return "" + stateList.toString().replace("[", "").replace("]", "") + "";
        }
    }

    private static String isWildcardSearch(String input) {
        if (StringUtils.isNotBlank(input) && input.contains("*"))
            return "Y";
        if (StringUtils.isNotBlank(input) && (input.length() != 16 && input.length() != 19))
            return "Y";
        return "N";
    }

    /**
     * Determines sort order.
     *
     * @param list
     * @return "DESC" or "ASC"
     */
    private static String getSortOrder(List<AlertSummaryGridSort> list) {
        if (list != null && list.size() > 0) {
            AlertSummaryGridSort alertSummaryGridSort = list.get(0);
            return alertSummaryGridSort.isDescending() ? "DESC" : "ASC";
        }
        return "DESC";
    }

    private static String getSortOrderProperty(List<AlertSummaryGridSort> gridSort) {

        if (gridSort != null && gridSort.size() > 0) {
            AlertSummaryGridSort alertSummaryGridSort = gridSort.get(0);
            return alertSummaryGridSort.getPropertyName();
        }
        return null;
    }
}
