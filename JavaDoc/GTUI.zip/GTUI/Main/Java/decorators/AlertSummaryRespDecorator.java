package com.ebtedge.fns.gateway.decorators;

import java.util.function.Function;

import com.ebtedge.fns.gateway.model.AlertSummaryVO;
import com.ebtedge.fns.gateway.util.DateTimeConvertors;
import com.ebtedge.yb.entity.AlertSummaryResp;

public class AlertSummaryRespDecorator {


    public static Function<AlertSummaryResp, AlertSummaryVO> toAlertSummaryVO() {

        Function<AlertSummaryResp, AlertSummaryVO> function =
                (alertSummaryResp) ->
        				AlertSummaryVO.builder()
        						.alertid(alertSummaryResp.getAlertid())
        						.alertDateTime(DateTimeConvertors.formatDBTimestamp(alertSummaryResp.getAlert_timestamp()))
        						.cardNumber(alertSummaryResp.getCard_number())
        						.fnsNumber(alertSummaryResp.getFns_number())
        						.terminalId(alertSummaryResp.getTerminal_id())
        						.ruleName(alertSummaryResp.getRule())
        						.alertContent(alertSummaryResp.getAlert_details())
        						.phone(alertSummaryResp.getMobile_details())
        						.email(alertSummaryResp.getEmail_details())
                                .build();
        return function;
        
       
    }
}
