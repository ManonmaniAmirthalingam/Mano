package com.ebtedge.fns.gateway.decorators;

import java.util.function.Function;

import com.ebtedge.fns.gateway.forms.RedeSearchForm;
import com.ebtedge.fns.gateway.model.RedeGridVO;
import com.ebtedge.fns.gateway.util.DateTimeConvertors;
import com.ebtedge.yb.entity.RedeSearchResp;

import lombok.extern.slf4j.Slf4j;
@Slf4j
public class RedeSearchRespDecorator {

    public static Function<RedeSearchResp, RedeGridVO> toFinancialVO() {
        return (redeTranSearchResp) -> RedeGridVO.builder()
        		.last_foodstamp_ts(
        			    redeTranSearchResp.getLast_foodstamp_ts() != null
        			        ? DateTimeConvertors.formatDBTimestamp(redeTranSearchResp.getLast_foodstamp_ts())
        			        : "")
                .fns_number(redeTranSearchResp.getFns_number())
                .terminal_id(redeTranSearchResp.getTerminal_id())
                .txn_acceptor_name(redeTranSearchResp.getTxn_acceptor_name())
                .txn_acceptor_address(redeTranSearchResp.getTxn_acceptor_address())
                .txn_acceptor_city(redeTranSearchResp.getTxn_acceptor_city())
                .txn_acceptor_state(redeTranSearchResp.getTxn_acceptor_state())
                .txn_acceptor_zip(formatZip(redeTranSearchResp.getTxn_acceptor_zip()))
                .rede_acceptor_name(redeTranSearchResp.getRede_acceptor_name())
                .rede_acceptor_address(redeTranSearchResp.getRede_acceptor_address())
                .rede_acceptor_city(redeTranSearchResp.getRede_acceptor_city())
                .rede_acceptor_state(redeTranSearchResp.getRede_acceptor_state())
                .rede_acceptor_zip(formatZip(redeTranSearchResp.getRede_acceptor_zip()))
                .final_score(redeTranSearchResp.getFinal_score()) 
                .name_score(formatScore(redeTranSearchResp.getName_score())) 
                .address_score(formatScore(redeTranSearchResp.getAddress_score())) 
                .city_score(formatScore(redeTranSearchResp.getCity_score()))
                .state_score(formatScore(redeTranSearchResp.getState_score()))
                .zip_score(formatScore(redeTranSearchResp.getZip_score()))
                .status(redeTranSearchResp.getStatus())
                .last_mod_by(redeTranSearchResp.getLast_mod_by())
                .build(); 
    }
    
    
    /**
     * Formats ZIP codes to add a hyphen for 9-digit ZIPs.
     *
     * @param zip The ZIP code to format.
     * @return The formatted ZIP code.
     */
    private static String formatZip(String zip) {
        if (zip == null || zip.trim().isEmpty()) {
            return "";
        }
        if (zip.length() == 9) {
            return zip.substring(0, 5) + "-" + zip.substring(5); // Add hyphen for 9-digit ZIPs
        }
        return zip; // Return as is for other cases
    }
    
    /**
     * Formats the score value.
     *
     * @param score The score to format.
     * @return The formatted score.
     */
    private static String formatScore(String score) {
        if (score == null || score.trim().isEmpty() || score.equals(".00")) {
            return "0"; // Replace null, empty, or ".00" with "0"
        }
        try {
            // Validate that the score is numeric
            double numericScore = Double.parseDouble(score.trim());
            
            // Check if the score is a whole number
            if (numericScore == (int) numericScore) {
                return String.valueOf((int) numericScore); // Return as an integer if it's a whole number
            }
            return String.valueOf(numericScore); // Return as-is for decimal values
        }  catch (NumberFormatException e) {
            log.error("Failed to parse score: '{}'. Defaulting to '0'.", score, e); // Log the error with the invalid score
            return "0"; // Default to "0" if parsing fails
        }
    }
}