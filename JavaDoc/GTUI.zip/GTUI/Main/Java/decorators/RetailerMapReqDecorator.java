package com.ebtedge.fns.gateway.decorators;

import com.ebtedge.fns.gateway.model.RedeSummaryGridSort;
import com.ebtedge.fns.gateway.model.RetailerMapCriteria;
import com.ebtedge.fns.gateway.model.RetailerMapSort;
import com.ebtedge.fns.gateway.util.DateTimeConvertors;
import com.ebtedge.fns.gateway.util.IpAddressUtil;
import com.ebtedge.fns.gateway.util.SessionUtil;
import com.ebtedge.yb.criteria.RetailerMapSearchQuery;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Function;

public class RetailerMapReqDecorator {

    public static Function<RetailerMapCriteria, RetailerMapSearchQuery> toRetailerMapCriteria() {

        Function<RetailerMapCriteria, RetailerMapSearchQuery> function =
                (request) -> RetailerMapSearchQuery
                        .builder()
                        .fnsNumber(StringUtils.isNotBlank(request.getFnsnumber()) ? request.getFnsnumber() : null)
                        .isFnsNumberWildCard("N")
                        .storeType(convertToDBSyntax(request.getStoretype()))
                        .merchantName(StringUtils.isNotBlank(request.getMerchantname()) ? request.getMerchantname() : null)
                        .isMerchantNameWildCard(null)
                        /*.storeLatitudeStart("32.02588")
                        .storeLongitudeStart("-102.08252")
                        .storeLatitudeEnd("42.58065")
                        .storeLongitudeEnd("-87.82787")*/

                        .storeLatitudeStart(StringUtils.isNotBlank(request.getStorelatitude_strt()) ? request.getStorelatitude_strt() : null)
                        .storeLongitudeStart(StringUtils.isNotBlank(request.getStorelongitude_strt()) ? request.getStorelongitude_strt() : null)
                        .storeLatitudeEnd(StringUtils.isNotBlank(request.getStorelatitude_end()) ? request.getStorelatitude_end() : null)
                        .storeLongitudeEnd(StringUtils.isNotBlank(request.getStorelongitude_end()) ? request.getStorelongitude_end() : null)
                        .merchantaddress(StringUtils.isNotBlank(request.getMerchantaddress()) ? request.getMerchantaddress() : null)
                        .merchantCounty(StringUtils.isNotBlank(request.getCounty_name()) ? request.getCounty_name() : null)
                        .merchantCity(StringUtils.isNotBlank(request.getMerchantcity()) ? request.getMerchantcity() : null)
                        .merchantState(convertToDBSyntax(request.getMerchantstate()))
                        .merchantzip(StringUtils.isNotBlank(request.getMerchantzip()) ? request.getMerchantzip() : null)
                        /*.ipAddress("127.0.0.1")
                        .appUserId("302304HD")
                        .appUserFirstName("Martin")
                        .appUserLastName("J")
                        .appUserMidName("Borus")
                        .appUserEmail("Borus.Martin.J@fisglobal.com")
                        .appUserType(null)
                        .appServer("localhost")
                        .searchType("LOCATION SEARCH")
                        .sortby(null)
                        .sortByField(null)*/

                        .ipAddress(IpAddressUtil.getIpAddress())
                        .appUserId(SessionUtil.getUserId() != null  ? SessionUtil.getUserId().toUpperCase() : null)
                        .appUserFirstName(SessionUtil.getFirstName() != null ? SessionUtil.getFirstName().toUpperCase(): null)
                        .appUserLastName(SessionUtil.getLastName() != null ? SessionUtil.getLastName().toUpperCase(): null)
                        .appUserMidName(SessionUtil.getMiddleName() != null ? SessionUtil.getMiddleName().toUpperCase(): null)
                        .appUserEmail(SessionUtil.getEmail() != null ? SessionUtil.getEmail().toUpperCase() : null)
                        .appUserType(null)
                        .appServer("localhost")
                        .searchType(request.getSearchtype())
                        .sortby(getSortOrder(request.getGridSort()))
                        .sortByField(getSortOrderProperty(request.getGridSort()))
                        .build();
        return function;
    }


    /**
     * Determines sort order.
     *
     * @param gridSort
     * @return "DESC" or "ASC"
     */
    private static String getSortOrder(List<RetailerMapSort> gridSort) {
        if (gridSort != null && gridSort.size() > 0) {
            RetailerMapSort retailerMapSort = gridSort.get(0);
            return retailerMapSort.isDescending() ? "DESC" : "ASC";
        }
        return "DESC";
    }

    /**
     * Determine sort field name from the user selection.
     *
     * @param gridSort
     * @return selected field name
     */
    private static String getSortOrderProperty(List<RetailerMapSort> gridSort) {

        if (gridSort != null && gridSort.size() > 0) {
            RetailerMapSort retailerMapSort = gridSort.get(0);
            return retailerMapSort.getPropertyName();
        }
        return null;
    }

    /**
     * Convert Set<String> user selected into database query specific format.
     *
     * @param states
     * @return string as per the database syntax.
     */
    private static String convertToDBSyntax(Set<String> states) {
        if (states == null || states.isEmpty())
            return null;
        else {
            Set<String> stateList = new HashSet<>();
            for (String s : states) {
                s = s.substring(0, s.indexOf("-")).trim();
                String tempState = "''" + s + "''";
                stateList.add(tempState);
            }
            return "" + stateList.toString().replace("[", "").replace("]", "") + "";
        }
    }

    private static String convertToDBSyntax(String states) {
        if (states == null || states.isEmpty())
            return null;
        else {
            states = states.substring(0, states.indexOf("-")).trim();
            //String tempState = "''" + states + "''";
            return "" + states.replace("[", "").replace("]", "") + "";
        }
    }

    /**
     * TODO: This needs to be changed. Currently DB SQL function is only taking one businessType
     * as search parameter that is the reason we are just taking first items from the set and sending it.
     *
     * @param businessTypes list of business types that user selects
     * @return business type code
     */
    private static String getBusinessType(Set<String> businessTypes) {
        if (businessTypes != null && businessTypes.size() > 0) {
            Object[] array = businessTypes.toArray();
            String item = (String) array[0];
            item = item.substring(0, item.indexOf("-")).trim();
            return item;
        }
        return null;
    }

}
