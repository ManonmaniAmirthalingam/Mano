package com.ebtedge.fns.gateway.exception;

/**
 * Custom exception class for GAT application.
 *
 * @author e3023044
 * @version 1.0.0
 * @since 1.0.0
 */
public class GatException extends RuntimeException {

    public GatException(String message) {
        super(message);
    }
}
