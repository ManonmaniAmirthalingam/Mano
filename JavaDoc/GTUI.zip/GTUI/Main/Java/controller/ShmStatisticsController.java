package com.ebtedge.fns.gateway.controller;

import com.ebtedge.fns.gateway.config.GatAppConfig;
import com.ebtedge.fns.gateway.service.ShmStatisticsService;
import com.ebtedge.fns.gateway.stats.MonitorStatistics;
import java.time.Duration;
import java.time.LocalDateTime;

import com.ebtedge.fns.gateway.util.RouteUrls;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

/**
 * Controller for retrieving system health monitor statistics. Provides endpoints to retrieve
 * monitoring data over a specified or default time range.
 */
@RestController
@RequestMapping(RouteUrls.SYSTEM_HEALTH + "/stats")
@RequiredArgsConstructor
@Tag(
        name = "System Health Monitor",
        description = "API endpoints for retrieving system health monitor statistics")
public class ShmStatisticsController {

    private final ShmStatisticsService monitorStatisticsService;
    private final GatAppConfig gatAppConfig;

    /**
     * Retrieves monitoring statistics for a specified time range or within a default retention
     * period if no time range is provided. Validates the time range and uses configurations for
     * effective start and end times if the parameters are null.
     *
     * @param from the start time (inclusive) as a {@link LocalDateTime}, may be null. If null, the
     *     system uses the configured data retention duration to determine the start time.
     * @param to the end time (inclusive) as a {@link LocalDateTime}, may be null. If null, the
     *     system uses the current time as the default end time.
     * @return a {@link MonitorStatistics} object containing the monitoring statistics for the
     *     specified or default time range.
     */
    @GetMapping(produces = {"application/json"})
    @Operation(
            summary = "Retrieve system monitoring statistics",
            description =
                    "Returns monitoring statistics for a specified time range. "
                            + "Uses configured retention period if no range is specified.")
    public MonitorStatistics getStats(
            @Parameter(description = "Start time (inclusive)")
                    @RequestParam(required = false)
                    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
                    LocalDateTime from,
            @Parameter(description = "End time (inclusive)")
                    @RequestParam(required = false)
                    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
                    LocalDateTime to) {

        LocalDateTime effectiveFrom = getEffectiveFromDateTime(from);
        LocalDateTime effectiveTo = getEffectiveToDateTime(to);

        return monitorStatisticsService.getMonitorStats(effectiveFrom, effectiveTo);
    }

    private LocalDateTime getEffectiveFromDateTime(LocalDateTime from) {
        if (from != null) {
            return from;
        }
        Duration dataRetention = gatAppConfig.getDataRetentionDuration();
        return LocalDateTime.now().minus(dataRetention);
    }

    private LocalDateTime getEffectiveToDateTime(LocalDateTime to) {
        return to != null ? to : LocalDateTime.now();
    }
}
