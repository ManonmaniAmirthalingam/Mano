package com.ebtedge.fns.gateway.forms;

import com.ebtedge.fns.gateway.components.DateTimeRangePicker;
import com.ebtedge.fns.gateway.components.ExportButton;
import com.ebtedge.fns.gateway.model.DateTimeRange;
import com.ebtedge.fns.gateway.model.TranSearchCriteria;
import com.ebtedge.fns.gateway.security.UserPermission;
import com.ebtedge.fns.gateway.util.FormUtil;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue;
import com.vaadin.flow.component.accordion.Accordion;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.checkbox.CheckboxGroup;
import com.vaadin.flow.component.combobox.MultiSelectComboBox;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.notification.NotificationVariant;
import com.vaadin.flow.component.orderedlayout.FlexLayout;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.NumberField;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.BeanValidationBinder;
import com.vaadin.flow.data.binder.Binder;
import com.vaadin.flow.shared.Registration;
import com.vaadin.flow.theme.lumo.LumoUtility;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.Assert;

import java.time.*;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Form component for Transaction Search.
 *
 * @author e3023044
 * @version 1.0.0
 * @since 1.0.0
 */
@Slf4j
public class TransactionSearchForm extends FormLayout {
    private static final String SPACE_SMALL = "var(--lumo-space-s)";
    @Getter private final TextField card = new TextField("Card Number");
    @Getter private final TextField fnsNumber = new TextField("FNS Number");
    @Getter private final TextField terminalId = new TextField("Terminal ID");
    MultiSelectComboBox<String> merchantState = new MultiSelectComboBox<>("Merchant State");
    MultiSelectComboBox<String> storeType = new MultiSelectComboBox<>("Business Store Type");

    NumberField minFraudScore = new NumberField();
    NumberField maxFraudScore = new NumberField();
    private final DateTimeRangePicker dateTimeRange = new DateTimeRangePicker();
    CheckboxGroup<String> flags = new CheckboxGroup<>("Flags");

    // Action buttons for Tran Search
    Button resetBtn = new Button("Reset");
    Button searchBtn = new Button("Search");
    private final ExportButton exportBtn = new ExportButton(List.of(UserPermission.GWAllowTranSearchExport));

    Binder<TranSearchCriteria> binder = new BeanValidationBinder<>(TranSearchCriteria.class);

    private final Duration dataRetentionDuration;

    public TransactionSearchForm(List<String> stateCodes, List<String> storeType, Duration dataRetentionDuration) {
        this.dataRetentionDuration = dataRetentionDuration;
        binder.bindInstanceFields(this);
        addClassName("transaction-search-form");
        setPlaceholders();
        initFormFields(stateCodes, storeType);
        initializeBinder();
        Accordion accordion = FormUtil.initSearchLayoutAccordion("Transaction Search Criteria", getTranSearchLayout());
        add(accordion);
        searchBtn.addClickListener(buttonClickEvent -> validateAndSearchTrans());
        resetBtn.addClickListener(buttonClickEvent -> clearSearchFields());
        exportBtn.addClickListener(buttonClickEvent -> fireEvent(new ExportEvent(this)));
    }

    /**
     * @return Vertical Layout of Tran search criteria fields
     */
    private VerticalLayout getTranSearchLayout() {
        HorizontalLayout buttons = new HorizontalLayout(searchBtn, resetBtn, exportBtn);
        Div fraudScore = new Div("Fraud Score Range");
        fraudScore.addClassNames("fraud-score-div");
        HorizontalLayout fraudScoreLayout = new HorizontalLayout();
        fraudScoreLayout.addClassNames("fraud-score-layout");
        Span separator = new Span("-");
        separator.addClassNames("score-separator");
        fraudScoreLayout.add(minFraudScore, separator, maxFraudScore);
        fraudScore.add(fraudScoreLayout);
        buttons.setClassName("tran-search-buttons");
        VerticalLayout verticalLayout = getFormVerticalLayout(fraudScore, buttons);
        return verticalLayout;

    }

    private VerticalLayout getFormVerticalLayout(Div fraudScore, HorizontalLayout buttons) {
        HorizontalLayout cell11 = new HorizontalLayout(card, fnsNumber, terminalId, merchantState);
        HorizontalLayout cell21 = new HorizontalLayout(fraudScore, storeType, flags);
        VerticalLayout column1 = new VerticalLayout(cell11, cell21);
        column1.getStyle().setPaddingRight(SPACE_SMALL);
        VerticalLayout column2 = new VerticalLayout(dateTimeRange);
        HorizontalLayout row1 = new HorizontalLayout(column1, column2);
        row1.setSpacing(false);
        HorizontalLayout row2 = new HorizontalLayout(buttons);

        VerticalLayout verticalLayout = new VerticalLayout();
        verticalLayout.addClassNames(LumoUtility.Padding.Horizontal.SMALL, LumoUtility.Padding.Vertical.SMALL);
        verticalLayout.add(row1, row2);
        return verticalLayout;
    }

    /**
     * clears form inputs
     */
    private void clearSearchFields() {
        this.card.clear();
        this.fnsNumber.clear();
        this.terminalId.clear();
        this.merchantState.clear();
        this.dateTimeRange.clear();
        this.flags.clear();
        this.storeType.clear();
        this.minFraudScore.clear();
        this.maxFraudScore.clear();
        exportBtn.reset();
        fireEvent(new ClearEvent(this));
    }

    private void setPlaceholders() {
        this.card.setPlaceholder("Enter Card Number");
        this.fnsNumber.setPlaceholder("Enter FNS #");
        this.terminalId.setPlaceholder("Enter Terminal ID #");
        this.terminalId.setClassName("terminal-id");
        this.merchantState.setPlaceholder("Select States");
        this.dateTimeRange.setPlaceholders(
                "Select Start Date", "Select Start Time", "Select End Date", "Select End Time");
        this.storeType.setPlaceholder("Select Business Type");
        this.minFraudScore.setPlaceholder("Min");
        this.minFraudScore.addClassNames("min-score");
        this.maxFraudScore.addClassNames("max-score");
        this.maxFraudScore.setPlaceholder("Max");
        this.minFraudScore.setEnabled(false);
        this.maxFraudScore.setEnabled(false);
    }


    /**
     * initialize form input field placeholders
     */
    private void initFormFields(List<String> stateCodes, List<String> businessTypes) {
        LocalDateTime maxToday = LocalDateTime.of(LocalDate.now(), LocalTime.MAX);
        dateTimeRange.setRequiredIndicatorVisible(true);
        dateTimeRange.setMin(getConfiguredMinTime());
        dateTimeRange.setMax(maxToday);
        dateTimeRange.setFlexDirection(FlexLayout.FlexDirection.COLUMN);
        this.merchantState.setItems(stateCodes);
        this.storeType.setItems(businessTypes);
        this.storeType.addThemeName("business-type");
        this.card.addValueChangeListener(event -> {
            if(event != null){
                String input = event.getValue();
                String output = FormUtil.toUpperCase(input);
                card.setValue(output);
            }
        });
        this.fnsNumber.addValueChangeListener(event -> {
            if(event != null){
                String input = event.getValue();
                String output = FormUtil.toUpperCase(input);
                fnsNumber.setValue(output);
            }
        });

        this.terminalId.addValueChangeListener(event -> {
            if(event != null){
                String input = event.getValue();
                String output = FormUtil.toUpperCase(input);
                terminalId.setValue(output);
            }
        });
        this.flags.setItems("Alert Trans", "Out of State", "Internet", "24 Hour Stores");
        searchBtn.addThemeName("search-button");
        resetBtn.addThemeName("reset-button");

    }

    private LocalDateTime getConfiguredMinTime() {
        Assert.notNull(dataRetentionDuration, "Data retention duration must be configured");
        return LocalDate.now().atStartOfDay().minus(dataRetentionDuration);
    }

    private void validateAndSearchTrans() {
        if (!isFormValid()) {
            Notification notification = new Notification("Please enter search criteria and try again!", 3000, Notification.Position.TOP_CENTER);
            notification.addThemeVariants(NotificationVariant.LUMO_ERROR);
            notification.open();
        } else if (!this.binder.isValid()) {
            log.warn("Binder is invalid, please try again!");
            Notification notification = new Notification("Invalid search criteria, please try again!", 3000, Notification.Position.TOP_CENTER);
            notification.addThemeVariants(NotificationVariant.LUMO_ERROR);
            notification.open();
        } else if (!isStartAndEndDateTimesValid()) {
            log.warn("Start Date Time is after End Date and Time ");
            Notification notification = new Notification("Invalid Start & End Date Times", 3000, Notification.Position.TOP_CENTER);
            notification.addThemeVariants(NotificationVariant.LUMO_ERROR);
            notification.open();
        } else if (!isFraudScoreValid()) {
            log.warn("Invalid fraud score range");
            Notification notification = new Notification("Invalid Fraud Score Range", 3000, Notification.Position.TOP_CENTER);
            notification.addThemeVariants(NotificationVariant.LUMO_ERROR);
            notification.open();
        } else {
            TranSearchCriteria tranSearchCriteria = TranSearchCriteria
                    .builder()
                    .card(card.getValue())
                    .fnsNumber(fnsNumber.getValue())
                    .terminalId(terminalId.getValue())
                    .states(merchantState.getValue())
                    .dateTimeRange(dateTimeRange.getValue())
                    .flags(flags.getValue())
                    .minScore(minFraudScore.getValue() != null ? Integer.toString(minFraudScore.getValue().intValue()): null)
                    .maxScore(maxFraudScore.getValue() != null ? Integer.toString(maxFraudScore.getValue().intValue()) : null)
                    .businessType(storeType.getValue())
                    .build();
            this.binder.setBean(tranSearchCriteria);
            fireEvent(new SearchEvent(this, binder.getBean()));
            exportBtn.enable();
        }
    }

    public static abstract class TranSearchFormEvent extends ComponentEvent<TransactionSearchForm> {

        private TranSearchCriteria tranSearchCriteria;

        public TranSearchFormEvent(TransactionSearchForm source, TranSearchCriteria tranSearchCriteria) {
            super(source, false);
            this.tranSearchCriteria = tranSearchCriteria;
        }

        public TranSearchCriteria getTranSearchCriteria() {
            return tranSearchCriteria;
        }
    }

    public static class SearchEvent extends TranSearchFormEvent {
        SearchEvent(TransactionSearchForm source, TranSearchCriteria tranSearchCriteria) {
            super(source, tranSearchCriteria);
        }
    }

    public Registration addSearchEventListener(ComponentEventListener<SearchEvent> listener) {
        return addListener(SearchEvent.class, listener);
    }

    public static class ClearEvent extends ComponentEvent<TransactionSearchForm> {
        public ClearEvent(TransactionSearchForm source) {
            super(source, false);
        }
    }

    public static class ExportEvent extends ComponentEvent<TransactionSearchForm> {
        public ExportEvent(TransactionSearchForm source) {
            super(source, false);
        }
    }

    public Registration addClearEventListener(ComponentEventListener<ClearEvent> listener) {
        return addListener(ClearEvent.class, listener);
    }

    public Registration addExportEventListener(ComponentEventListener<ExportEvent> listener) {
        return addListener(ExportEvent.class, listener);
    }

    private boolean isFormValid() {
        List<HasValue<?, ?>> hasValueList = this.binder
                .getFields()
                .filter(hasValue -> hasValue.getValue() != null)
                .filter(hasValue -> StringUtils.isNotBlank(hasValue.getValue().toString()))
                .filter(hasValue -> !"[]".equalsIgnoreCase(hasValue.getValue().toString()))
                .collect(Collectors.toList());
        if (hasValueList == null || hasValueList.size() == 0) {
            log.warn("No value provided in the search criteria");
            return false;
        }
        return true;
    }

    private void initializeBinder() {

        binder
                .forField(card)
                .withValidator(value -> (StringUtils.isNotBlank(value) && (value.length() < 5 || value.length() > 19)) || (!value.matches("[0-9*]*")) ? false : true, "Invalid card")
                .bind(TranSearchCriteria::getCard, TranSearchCriteria::setCard);

        binder.forField(terminalId)
        		.withValidator(value -> (StringUtils.isNotBlank(value) && value.length() > 8) || (!value.matches("^[a-zA-Z0-9]*$")) ? false : true, "Invalid Terminal ID")
                .bind(TranSearchCriteria::getTerminalId, TranSearchCriteria::setTerminalId);

        binder.forField(fnsNumber)
        .withValidator(value -> (StringUtils.isNotBlank(value) && (value.length() < 7 || value.length() > 7)) || (!value.matches("^[0-9]*$")) ? false : true, "Invalid FNS Number")
                .bind(TranSearchCriteria::getFnsNumber, TranSearchCriteria::setFnsNumber);

        binder.forField(dateTimeRange)
                .asRequired("Start Date/Time and End Date/Time are required.")
                .bind(TranSearchCriteria::getDateTimeRange, TranSearchCriteria::setDateTimeRange);
    }

    boolean isStartAndEndDateTimesValid() {
        DateTimeRange range = this.dateTimeRange.getValue();
        return range != null
                && range.getStart() != null
                && range.getEnd() != null
                && !dateTimeRange.isInvalid();
    }

    private boolean isFraudScoreValid() {
        Double minFraudScore = this.minFraudScore.getValue();
        Double maxFraudScore = this.maxFraudScore.getValue();
        if (minFraudScore != null && maxFraudScore != null) {
            Integer minScore = this.minFraudScore.getValue().intValue();
            Integer maxScore = this.maxFraudScore.getValue().intValue();
            if (minScore > maxScore) {
                return false;
            }
        }
        return true;
    }

    public Binder<TranSearchCriteria> getBinder() {
        return this.binder;
    }
}
