package com.ebtedge.fns.gateway.forms;

import com.ebtedge.fns.gateway.components.DateTimeRangePicker;
import com.ebtedge.fns.gateway.components.ExportButton;
import com.ebtedge.fns.gateway.model.DateTimeRange;
import com.ebtedge.fns.gateway.model.UserActivitySearchCriteria;
import com.ebtedge.fns.gateway.security.UserPermission;
import com.ebtedge.fns.gateway.util.FormUtil;
import com.ebtedge.fns.gateway.util.Notifications;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue;
import com.vaadin.flow.component.accordion.Accordion;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.Binder;
import com.vaadin.flow.shared.Registration;
import com.vaadin.flow.theme.lumo.LumoUtility;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.Assert;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * UserActivitySearchForm is a form layout for searching user activities.
 * It contains fields for user ID, first name, last name, start date, and end date,
 * along with buttons for searching, resetting, and exporting the search results.
 */
@Slf4j
public class UserActivitySearchForm extends FormLayout {

    TextField userId = new TextField("User ID");
    TextField firstName = new TextField("First Name");
    TextField lastName = new TextField("Last Name");
    private final DateTimeRangePicker dateTimeRange = new DateTimeRangePicker();

    Button searchButton = new Button("Search");
    Button resetButton = new Button("Reset");
    private final ExportButton exportButton = new ExportButton(List.of(UserPermission.GWAllowUserActivityExport));

    Binder<UserActivitySearchCriteria> binder = new Binder<>(UserActivitySearchCriteria.class);

    private final Duration dataRetentionDuration;

    public UserActivitySearchForm(Duration dataRetentionDuration) {
        this.dataRetentionDuration = dataRetentionDuration;
        binder.bindInstanceFields(this);
        initFormFields();
        initializeBinder();
        Accordion accordion = FormUtil.initSearchLayoutAccordion("User Activity Search Criteria", initSearchLayout());
        add(accordion);
    }


    /**
     * Initializes the layout for the search form, including the fields and buttons.
     *
     * @return a VerticalLayout containing the search fields and buttons
     */
    private VerticalLayout initSearchLayout() {
        HorizontalLayout fieldsLayout = new HorizontalLayout(userId, firstName, lastName, dateTimeRange);
        fieldsLayout.addClassNames(LumoUtility.Display.FLEX, LumoUtility.FlexDirection.COLUMN, LumoUtility.FlexDirection.Breakpoint.Medium.ROW, LumoUtility.Gap.MEDIUM);
        fieldsLayout.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.BASELINE);

        HorizontalLayout buttonsLayout = new HorizontalLayout(searchButton, resetButton, exportButton);
        buttonsLayout.addClassNames(LumoUtility.Display.FLEX, LumoUtility.FlexDirection.COLUMN, LumoUtility.FlexDirection.Breakpoint.Medium.ROW, LumoUtility.Gap.MEDIUM);
        buttonsLayout.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.BASELINE);

        VerticalLayout verticalLayout = new VerticalLayout();
        verticalLayout.add(fieldsLayout, buttonsLayout);
        return verticalLayout;
    }

    /**
     * Initializes the form fields and their properties.
     */
    private void initFormFields() {

        // Set placeholder and required properties for text fields
        userId.setPlaceholder("Enter User ID");
        firstName.setPlaceholder("Enter First Name");
        lastName.setPlaceholder("Enter Last Name");
        LocalDateTime maxToday = LocalDateTime.of(LocalDate.now(), LocalTime.MAX);
        dateTimeRange.setPlaceholders("Enter Start Date", "Enter Start Time", "Enter End Date", "Enter End Time");
        dateTimeRange.setRequiredIndicatorVisible(true);
        dateTimeRange.setMin(getConfiguredMinTime());
        dateTimeRange.setMax(maxToday);

        userId.addValueChangeListener(event -> {
            if(event != null){
                String input = event.getValue();
                String output = FormUtil.toUpperCase(input);
                userId.setValue(output);
            }
        });

        firstName.addValueChangeListener(event -> {
            if(event != null){
                String input = event.getValue();
                String output = FormUtil.toUpperCase(input);
                firstName.setValue(output);
            }
        });

        lastName.addValueChangeListener(event -> {
            if(event != null){
                String input = event.getValue();
                String output = FormUtil.toUpperCase(input);
                lastName.setValue(output);
            }
        });

        searchButton.addThemeName("search-button");
        resetButton.addThemeName("reset-button");

        searchButton.addClickListener(e -> validateAndSearchActivity());
        resetButton.addClickListener(e -> resetSearchFields());
        exportButton.addClickListener(e -> fireEvent(new ExportEvent(this)));
    }

    public void setFieldEditable(String fieldName, boolean isEditable) {
        if ("userId".equals(fieldName)) {
            this.userId.setReadOnly(!isEditable);
        } else if ("firstName".equals(fieldName)) {
            this.firstName.setReadOnly(!isEditable);
        } else if ("lastName".equals(fieldName)) {
            this.lastName.setReadOnly(!isEditable);
        }
    }

    /**
     * Validates the form fields and triggers the search event if valid.
     */
    private void validateAndSearchActivity() {
        if (!isFormValid()) {
            Notifications.showError("Please enter search criteria and try again!");
            return;
        }

        if (!validateDateFields()) {
            return;
        }

        if (!this.binder.isValid()) {
            log.warn("Binder is invalid, please try again!");
            Notifications.showError("Invalid search criteria, please try again!");
            return;
        }

        // All validations passed, proceed with search logic
        UserActivitySearchCriteria searchCriteria = UserActivitySearchCriteria.builder()
                .userId(userId.getValue())
                .firstName(firstName.getValue())
                .lastName(lastName.getValue())
                .dateTimeRange(dateTimeRange.getValue())
                .build();

        this.binder.setBean(searchCriteria);
        fireEvent(new SearchEvent(this, searchCriteria));
        exportButton.enable();
    }

    private boolean isFormValid() {
        List<HasValue<?, ?>> hasValueList = this.binder
                .getFields()
                .filter(hasValue -> hasValue.getValue() != null)
                .filter(hasValue -> StringUtils.isNotBlank(hasValue.getValue().toString()))
                .filter(hasValue -> !"[]".equalsIgnoreCase(hasValue.getValue().toString()))
                .collect(Collectors.toList());
        if (hasValueList == null || hasValueList.size() == 0) {
            log.warn("No value provided in the search criteria");
            return false;
        }
        return true;
    }

    /**
     * Validates the start and end date fields in the form.
     *
     * @return true if the fields are valid, false otherwise
     */
    private boolean validateDateFields() {
        if (dateTimeRange.isInvalid()) {
            Notifications.showError("Invalid Start & End Date Times");
            return false;
        }
        DateTimeRange range = dateTimeRange.getValue();
        if (range == null || range.getStart() == null || range.getEnd() == null) {
            Notifications.show("Start Date/Time and End Date/Time are required.");
            return false;
        }
        return true;
    }

    /**
     * Resets the form fields to their default values.
     */
    private void resetSearchFields() {
        if (!userId.isReadOnly()) {
            userId.clear();
        }
        if (!firstName.isReadOnly()) {
            firstName.clear();
        }
        if (!lastName.isReadOnly()) {
            lastName.clear();
        }
        dateTimeRange.clear();
        exportButton.setEnabled(false);// Disable the export button and apply the disabled-button theme
        exportButton.removeThemeName("search-button");
        exportButton.addThemeName("disabled-button");
        fireEvent(new ClearGridEvent(this));
    }

    /**
     * Initializes the binder to bind the form fields to the UserActivitySearchCriteria model.
     */
    private void initializeBinder() {
        binder
                .forField(userId)
                .withValidator(userId -> userId == null || userId.isEmpty() || (userId.length() >= 4 && userId.length() <= 50), "Invalid User ID")
                .bind(UserActivitySearchCriteria::getUserId, UserActivitySearchCriteria::setUserId);

        binder
                .forField(firstName)
                .withValidator(firstName -> firstName == null || firstName.isEmpty() || (firstName.length() >= 2 && firstName.length() <= 50), "Invalid First Name")
                .bind(UserActivitySearchCriteria::getFirstName, UserActivitySearchCriteria::setFirstName);

        binder
                .forField(lastName)
                .withValidator(lastName -> lastName == null || lastName.isEmpty() || (lastName.length() >= 2 && lastName.length() <= 50), "Invalid Last Name")
                .bind(UserActivitySearchCriteria::getLastName, UserActivitySearchCriteria::setLastName);

        binder
                .forField(dateTimeRange)
                .asRequired("Start Date/Time and End Date/Time are required.")
                .bind(UserActivitySearchCriteria::getDateTimeRange, UserActivitySearchCriteria::setDateTimeRange);
    }

    /**
     * Custom event class for search events triggered by the search button.
     */
    public static class SearchEvent extends ComponentEvent<UserActivitySearchForm> {
        private final UserActivitySearchCriteria searchCriteria;

        public SearchEvent(UserActivitySearchForm source, UserActivitySearchCriteria searchCriteria) {
            super(source, false);
            this.searchCriteria = searchCriteria;
        }

        public UserActivitySearchCriteria getSearchCriteria() {
            return searchCriteria;
        }
    }

    private LocalDateTime getConfiguredMinTime() {
        Assert.notNull(dataRetentionDuration, "Data retention duration must be configured");
        return LocalDateTime.now().minus(dataRetentionDuration);
    }

    /**
     * Adds a listener for search events triggered by the search button.
     *
     * @param listener the listener to be added
     * @return a Registration object to remove the listener later if needed
     */
    public Registration addSearchEventListener(ComponentEventListener<UserActivitySearchForm.SearchEvent> listener) {
        return addListener(UserActivitySearchForm.SearchEvent.class, listener);
    }

    public static class ExportEvent extends ComponentEvent<UserActivitySearchForm> {
        public ExportEvent(UserActivitySearchForm source) {
            super(source, true);
        }
    }

    public Registration addExportEventListener(ComponentEventListener<UserActivitySearchForm.ExportEvent> listener) {
        return addListener(UserActivitySearchForm.ExportEvent.class, listener);
    }

    public static class ClearGridEvent extends ComponentEvent<UserActivitySearchForm> {
        public ClearGridEvent(UserActivitySearchForm source) {
            super(source, true);
        }
    }

    public Registration addClearGridEventListener(ComponentEventListener<UserActivitySearchForm.ClearGridEvent> listener) {
        return addListener(UserActivitySearchForm.ClearGridEvent.class, listener);
    }

    public Binder<UserActivitySearchCriteria> getBinder() {
        return this.binder;
    }
}