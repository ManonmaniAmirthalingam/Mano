package com.ebtedge.fns.gateway.forms;

import com.ebtedge.fns.gateway.components.ExportButton;
import com.ebtedge.fns.gateway.model.RetailerMapCriteria;
import com.ebtedge.fns.gateway.security.UserPermission;
import com.ebtedge.fns.gateway.util.FormUtil;
import com.ebtedge.yb.service.GatService;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue;
import com.vaadin.flow.component.accordion.Accordion;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.combobox.MultiSelectComboBox;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.RangeInput;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.notification.NotificationVariant;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.select.Select;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.BeanValidationBinder;
import com.vaadin.flow.data.binder.Binder;
import com.vaadin.flow.shared.Registration;
import com.vaadin.flow.theme.lumo.LumoUtility;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class RetailerMapForm extends FormLayout {

    private final GatService gatService;

    TextField merchantAddress = new TextField("Address");
    Select<String> merchantState = new Select<>();

    Select<String> county = new Select<>();

    Select<String> merchantCity = new Select<>();

    TextField merchantZip = new TextField("Merchant State");

    MultiSelectComboBox<String> storeType = new MultiSelectComboBox<>("Business Store Type");

    private int selectedDays = 30;

    private RangeInput daysRangeInput;

    // Action buttons for Tran Search
    Button resetBtn = new Button("Reset");
    Button searchBtn = new Button("Search");
    private final ExportButton exportBtn = new ExportButton(List.of(UserPermission.GWAllowRetailerMapExport));

    Binder<RetailerMapCriteria> binder = new BeanValidationBinder<>(RetailerMapCriteria.class);

    public RetailerMapForm(GatService gatService, List<String> stateCodes, List<String> storeType) {
        this.gatService= gatService;
        binder.bindInstanceFields(this);
        addClassName("transaction-search-form");
        //setPlaceholders();
        initFormFields(stateCodes, storeType);
        initializeBinder();
        Accordion accordion = FormUtil.initSearchLayoutAccordion("Search for SNAP Retailers", getRetailersSearchLayout());
        add(accordion);
        searchBtn.addClickListener(buttonClickEvent -> validateAndSearchRetailers());
        resetBtn.addClickListener(buttonClickEvent -> clearSearchFields());
        exportBtn.addClickListener(buttonClickEvent -> fireEvent(new ExportEvent(this)));
    }

    private void initFormFields(List<String> stateCodes, List<String> businessTypes) {

        this.merchantAddress.setLabel("Address");
        this.merchantAddress.setPlaceholder("Enter street address");
        
        this.merchantState.setLabel("State");
        this.merchantState.setPlaceholder("Select a state");
        this.merchantState.setRequiredIndicatorVisible(true);
        this.merchantState.setEmptySelectionAllowed(true);
        this.merchantState.setEmptySelectionCaption("Select a state");
        this.merchantState.setErrorMessage("In order to Search, one or more fields (County, City or Zip) must be entered along with State");
        
        this.county.setLabel("County");
        this.county.setPlaceholder("Select a county");
        this.county.addThemeName("business-type");
        this.county.setEmptySelectionAllowed(true);
        this.county.setEmptySelectionCaption("Select a county");
        
        this.merchantCity.setLabel("City");
        this.merchantCity.setPlaceholder("Select a city");
        this.merchantCity.addThemeName("business-type");
        this.merchantCity.setEmptySelectionAllowed(true);
        this.merchantCity.setEmptySelectionCaption("Select a city");
        
        this.merchantZip.setLabel("Zip Code");
        this.merchantZip.setPlaceholder("Enter zip code");

        this.merchantState.setItems(stateCodes);
        this.merchantState.addThemeName("business-type");
        
        this.storeType.setLabel("Business Store Type");
        this.storeType.setPlaceholder("Select business types...");
        if (businessTypes != null && !businessTypes.isEmpty()) {
            this.storeType.setItems(businessTypes);
        }
        this.storeType.addThemeName("business-type");

        this.merchantState.addValueChangeListener(event -> {
            if(event != null){
                String input = event.getValue();
                //String output = FormUtil.toUpperCase(input);
                merchantState.setValue(input);
                this.county.setItems(getCountyNames(merchantState.getValue()));
                this.merchantCity.setItems(retailerCityByState(merchantState.getValue()));
            }
        });

        this.county.addValueChangeListener(event -> {
            if(event != null){
                String input = event.getValue();
                //String output = FormUtil.toUpperCase(input);
                county.setValue(input);
                this.merchantCity.setItems(getCityNames(merchantState.getValue(), county.getValue()));
            }
        });

        this.merchantCity.addValueChangeListener(event -> {
            if(event != null){
                String input = event.getValue();
                //String output = FormUtil.toUpperCase(input);
                merchantCity.setValue(input);
            }
        });
        searchBtn.addThemeName("search-button");
        resetBtn.addThemeName("reset-button");
    }

    @SuppressWarnings("unchecked")
    private List<String> getCountyNames(String state)
    {
        List<String> countyList = (List<String>) gatService.getCountyNames(convertToDBSyntax(state));
        Collections.sort(countyList);
        return countyList;
    }

    @SuppressWarnings("unchecked")
    private List<String> retailerCityByState(String state)
    {
        List<String> cityList = (List<String>) gatService.retailerCityByState(convertToDBSyntax(state));
        Collections.sort(cityList);
        return cityList;
    }

    @SuppressWarnings("unchecked")
    private List<String> getCityNames(String state, String county)
    {
        List<String> cities = gatService.getCityNames(convertToDBSyntax(state), county);
        Collections.sort(cities);
        return cities;
    }

    private static String convertToDBSyntax(String states) {
        if (states == null || states.isEmpty())
            return null;
        else {
            states = states.substring(0, states.indexOf("-")).trim();
            String tempState = "'" + states + "'";
            return "" + tempState.replace("[", "").replace("]", "") + "";
        }
    }

    private void initializeBinder() {

        binder.forField(merchantAddress)
                .withValidator(value -> StringUtils.isBlank(value) || (StringUtils.isNotBlank(value) && value.length() > 2), "Invalid Address")
                .bind(RetailerMapCriteria::getMerchantaddress, RetailerMapCriteria::setMerchantaddress);

        binder.forField(merchantState)
                .withValidator(value -> (StringUtils.isNotBlank(value) && value.length() == 2) ? false : true, "Invalid State")
                .bind(RetailerMapCriteria::getMerchantstate, RetailerMapCriteria::setMerchantstate);

        binder.forField(merchantCity)
                .withValidator(value -> (StringUtils.isBlank(value) || value.length() < 25), "Invalid City")
                .bind(RetailerMapCriteria::getMerchantcity, RetailerMapCriteria::setMerchantcity);

        binder.forField(merchantZip)
                .withValidator(value -> (StringUtils.isBlank(value) || value.length() > 4), "Invalid Zip Code")
                .bind(RetailerMapCriteria::getMerchantzip, RetailerMapCriteria::setMerchantzip);
    }

    private VerticalLayout getRetailersSearchLayout() {
        HorizontalLayout buttons = new HorizontalLayout(searchBtn, resetBtn, exportBtn);
        Div daysRange = new Div("Select Number of Days");
        daysRange.addClassNames("fraud-score-div");

        Div daysValueDisplay = new Div("Days: 30");
        daysValueDisplay.addClassNames("fraud-score-layout");

        HorizontalLayout daysRangeLayout = new HorizontalLayout();
        daysRangeLayout.addClassNames("fraud-score-layout");

        RangeInput rangeInput = new RangeInput();
        rangeInput.setMin(1);
        rangeInput.setMax(30);
        rangeInput.setValue(30.0);
        this.daysRangeInput = rangeInput;
        rangeInput.addValueChangeListener(event -> {
            int daysValue = event.getValue().intValue();
            selectedDays = daysValue;
            daysValueDisplay.removeAll();
            daysValueDisplay.add("Days: " + daysValue);
        });

        daysRangeLayout.add(rangeInput, daysValueDisplay);

        buttons.setClassName("tran-search-buttons");
        VerticalLayout verticalLayout = getFormVerticalLayout(daysRange, daysRangeLayout, buttons);
        return verticalLayout;
    }

    private VerticalLayout getFormVerticalLayout(Div daysRange, HorizontalLayout daysRangeLayout, HorizontalLayout buttons) {
        HorizontalLayout row1 = new HorizontalLayout(merchantState, county, merchantCity);
        HorizontalLayout row2 = new HorizontalLayout(merchantZip, merchantAddress, storeType);
        HorizontalLayout row3 = new HorizontalLayout(daysRange);
        HorizontalLayout row4 = new HorizontalLayout(daysRangeLayout);
        HorizontalLayout row5 = new HorizontalLayout(buttons);

        VerticalLayout verticalLayout = new VerticalLayout();
        verticalLayout.addClassNames(LumoUtility.Padding.Horizontal.SMALL, LumoUtility.Padding.Vertical.SMALL);
        verticalLayout.add(row1, row2, row3, row4, row5);
        return verticalLayout;
    }

    /**
     * clears form inputs
     */
    private void clearSearchFields() {
        this.merchantAddress.clear();
        this.merchantState.clear();
        this.county.clear();
        this.merchantCity.clear();
        this.merchantZip.clear();
        this.storeType.clear();
        this.selectedDays = 30;
        if (this.daysRangeInput != null) {
            this.daysRangeInput.setValue(30.0);
        }
        exportBtn.reset();
        fireEvent(new ClearEvent(this));
    }

    private void validateAndSearchRetailers() {
        if (!isFormValid()) {
            Notification notification = new Notification("Please enter search criteria and try again!", 3000, Notification.Position.TOP_CENTER);
            notification.addThemeVariants(NotificationVariant.LUMO_ERROR);
            notification.open();
        } else if (!isStateValidationPassed()) {
            Notification notification = new Notification("State is required. In order to Search, one or more fields (County, City or Zip) must be entered along with State.", 3000, Notification.Position.TOP_CENTER);
            notification.addThemeVariants(NotificationVariant.LUMO_ERROR);
            notification.open();
        } else if (!this.binder.isValid()) {
            log.warn("Binder is invalid, please try again!");
            Notification notification = new Notification("Invalid search criteria, please try again!", 3000, Notification.Position.TOP_CENTER);
            notification.addThemeVariants(NotificationVariant.LUMO_ERROR);
            notification.open();
        } else {
            RetailerMapCriteria retailerMapCriteria = RetailerMapCriteria
                    .builder()
                    .merchantaddress(merchantAddress.getValue())
                    .merchantcity(merchantCity.getValue())
                    .county_name(county.getValue())
                    .merchantstate(merchantState.getValue())
                    .merchantzip(merchantZip.getValue())
                    .storetype(storeType.getValue())
                    .selectedDays(selectedDays)
                    .build();
            this.binder.setBean(retailerMapCriteria);
            fireEvent(new RetailersSearchEvent(this, retailerMapCriteria));
            exportBtn.enable();
        }
    }

    private boolean isFormValid() {
        List<HasValue<?, ?>> hasValueList = this.binder
                .getFields()
                .filter(hasValue -> hasValue.getValue() != null)
                .filter(hasValue -> StringUtils.isNotBlank(hasValue.getValue().toString()))
                .filter(hasValue -> !"[]".equalsIgnoreCase(hasValue.getValue().toString()))
                .collect(Collectors.toList());
        if (hasValueList == null || hasValueList.size() == 0) {
            log.warn("No value provided in the search criteria");
            return false;
        }
        return true;
    }

    private boolean isStateValidationPassed() {
        boolean stateSelected = StringUtils.isNotBlank(merchantState.getValue());

        if (!stateSelected) {
            return false;
        }

        boolean countySelected = StringUtils.isNotBlank(county.getValue());
        boolean citySelected = StringUtils.isNotBlank(merchantCity.getValue());
        boolean zipSelected = StringUtils.isNotBlank(merchantZip.getValue());
        //boolean addressSelected = StringUtils.isNotBlank(merchantAddress.getValue());

        return countySelected || citySelected || zipSelected;// || addressSelected;
    }

    public static abstract class RetailerMapFormEvent extends ComponentEvent<RetailerMapForm> {

        private RetailerMapCriteria retailerMapCriteria;

        public RetailerMapFormEvent(RetailerMapForm source, RetailerMapCriteria retailerMapCriteria) {
            super(source, false);
            this.retailerMapCriteria = retailerMapCriteria;
        }

        public RetailerMapCriteria getRetailerMapCriteria() {
            return retailerMapCriteria;
        }
    }

    public static class RetailersSearchEvent extends RetailerMapFormEvent {
        RetailersSearchEvent(RetailerMapForm source, RetailerMapCriteria retailerMapCriteria) {
            super(source, retailerMapCriteria);
        }
    }

    public Registration addSearchEventListener(ComponentEventListener<RetailersSearchEvent> listener) {
        return addListener(RetailersSearchEvent.class, listener);
    }

    public static class ClearEvent extends ComponentEvent<RetailerMapForm> {
        public ClearEvent(RetailerMapForm source) {
            super(source, false);
        }
    }

    public Registration addClearEventListener(ComponentEventListener<ClearEvent> listener) {
        return addListener(ClearEvent.class, listener);
    }

    public static class ExportEvent extends ComponentEvent<RetailerMapForm> {
        public ExportEvent(RetailerMapForm source) {
            super(source, false);
        }
    }

    public Registration addExportEventListener(ComponentEventListener<ExportEvent> listener) {
        return addListener(ExportEvent.class, listener);
    }

    public Binder<RetailerMapCriteria> getBinder() {
        return this.binder;
    }
}
