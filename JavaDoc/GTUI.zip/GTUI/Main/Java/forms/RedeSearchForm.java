package com.ebtedge.fns.gateway.forms;
import java.time.*;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

import com.ebtedge.fns.gateway.components.DateTimeRangePicker;
import com.ebtedge.fns.gateway.components.ExportButton;
import com.ebtedge.fns.gateway.model.DateTimeRange;
import com.ebtedge.fns.gateway.security.UserPermission;
import com.ebtedge.fns.gateway.util.Notifications;
import org.apache.commons.lang3.StringUtils;

import com.ebtedge.fns.gateway.model.RedeSearchCriteria;
import com.ebtedge.fns.gateway.util.FormUtil;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue;
import com.vaadin.flow.component.accordion.Accordion;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.combobox.MultiSelectComboBox;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.orderedlayout.FlexComponent.Alignment;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.NumberField;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.BeanValidationBinder;
import com.vaadin.flow.data.binder.Binder;
import com.vaadin.flow.shared.Registration;
import com.vaadin.flow.theme.lumo.LumoUtility;

import lombok.extern.slf4j.Slf4j;
import org.springframework.util.Assert;

@Slf4j
public class RedeSearchForm extends FormLayout {
	private static final String SPACE_SMALL = "var(--lumo-space-s)";
    TextField terminalId = new TextField("Terminal ID");
    TextField fnsNumber = new TextField("FNS Number");
    NumberField minScoreStart = new NumberField();
    NumberField maxScoreEnd = new NumberField();
    private final DateTimeRangePicker dateTimeRange = new DateTimeRangePicker();
    MultiSelectComboBox<String> scoreType = new MultiSelectComboBox<>("Score Type"); // Multi selection ComboBox
    ComboBox<String> status = new ComboBox<>("Status"); 
	Checkbox myItems = new Checkbox("My Items"); 

    // Action buttons for Rede Search
    Button resetBtn = new Button("Reset");
    Button searchBtn = new Button("Search");
    private final ExportButton exportBtn = new ExportButton(List.of(UserPermission.GWAllowRedeCompExport));

    Binder<RedeSearchCriteria> binder = new BeanValidationBinder<>(RedeSearchCriteria.class);

    private final Duration dataRetentionDuration;

    public RedeSearchForm(List<String> scoreTypes, List<String> redeStatusList, Duration dataRetentionDuration) {
        this.dataRetentionDuration = dataRetentionDuration;
        binder.bindInstanceFields(this);
        addClassName("rede-search-form");
        setPlaceholders();
        initFormFields(scoreTypes,redeStatusList);
        initializeBinder();
        Accordion accordion = FormUtil.initSearchLayoutAccordion("REDE Comparison Search Criteria", getRedeSearchLayout());
        add(accordion);
        searchBtn.addClickListener(buttonClickEvent -> validateAndSearchRede());
        resetBtn.addClickListener(buttonClickEvent -> clearSearchFields());
        exportBtn.addClickListener(buttonClickEvent -> fireEvent(new ExportEvent(this)));
    }

    private VerticalLayout getRedeSearchLayout() {
        HorizontalLayout buttons = new HorizontalLayout(searchBtn, resetBtn, exportBtn); // Configure buttons layout
        buttons.setClassName("rede-search-buttons");
        Div scoreRange = new Div("Score Range");// Configure score range layout
        scoreRange.addClassNames("rede-score-div");
        HorizontalLayout scoreRangeLayout = new HorizontalLayout();
        scoreRangeLayout.addClassNames("rede-score-layout");
        Span separator = new Span("-");
        separator.addClassNames("score-separator");
        scoreRangeLayout.add(minScoreStart, separator, maxScoreEnd);
        scoreRange.add(scoreRangeLayout);
        VerticalLayout verticalLayout = getFormVerticalLayout(scoreRange, buttons);
        return verticalLayout;
    }
    
    private VerticalLayout getFormVerticalLayout(Div scoreRange, HorizontalLayout buttons) {
    	HorizontalLayout firstRow = new HorizontalLayout(terminalId, fnsNumber, scoreRange, scoreType); 		
		Div flagsLabel = new Div("Flags");
		flagsLabel.addClassName("rede-flags-label");
		VerticalLayout flagsLayout = new VerticalLayout(flagsLabel, myItems);
		flagsLayout.setSpacing(false);
		flagsLayout.setPadding(false);
		flagsLayout.setMargin(false);
		HorizontalLayout secondRow = new HorizontalLayout(status, flagsLayout);
		secondRow.setAlignItems(Alignment.CENTER);
		VerticalLayout leftColumn = new VerticalLayout(firstRow, secondRow);
		leftColumn.getStyle().setPaddingRight(SPACE_SMALL);
		VerticalLayout rightColumn = new VerticalLayout(dateTimeRange);
		HorizontalLayout mainContent = new HorizontalLayout(leftColumn, rightColumn);
		mainContent.setSpacing(false);
		HorizontalLayout buttonsRow = new HorizontalLayout(buttons);
		VerticalLayout formLayout = new VerticalLayout();
		formLayout.addClassNames(LumoUtility.Padding.Horizontal.SMALL, LumoUtility.Padding.Vertical.SMALL);
		formLayout.add(mainContent, buttonsRow);
		return formLayout;
    }
    private void clearSearchFields() {
        this.terminalId.clear();
        this.fnsNumber.clear();
        dateTimeRange.clear();
        this.minScoreStart.clear();
        this.maxScoreEnd.clear();
        scoreType.clear(); // Clear the MultiSelectComboBox
        status.clear();
		myItems.setValue(false);
        exportBtn.reset();
        fireEvent(new ClearEvent(this));
    }

    private void setPlaceholders() {
        this.terminalId.setPlaceholder("Enter Terminal ID #");
        this.fnsNumber.setPlaceholder("Enter FNS #");
        dateTimeRange.setPlaceholders("Enter Start Date", "Enter Start Time", "Enter End Date", "Enter End Time");
        this.minScoreStart.setPlaceholder("Min");
        this.minScoreStart.addClassNames("min-score");
        this.maxScoreEnd.setPlaceholder("Max");
        this.maxScoreEnd.addClassNames("max-score");
        this.scoreType.setPlaceholder("Select Score Types");
        this.status.setPlaceholder("Select Status");
    }

    private void initFormFields(List<String> scoreTypes, List<String> redeStatusList) {
        this.scoreType.setItems(scoreTypes);
        this.scoreType.setClearButtonVisible(true);
        this.scoreType.addClassName("score-type-dropdown");
		this.status.setItems(redeStatusList);
		this.status.setClearButtonVisible(true);
		this.status.addClassName("rede-status-dropdown");
		this.status.setItemLabelGenerator(item -> item);
		this.myItems.setValue(false);
		this.myItems.addClassName("my-items-checkbox");
        LocalDateTime maxToday = LocalDateTime.of(LocalDate.now(), LocalTime.MAX);
        dateTimeRange.setRequiredIndicatorVisible(true);
        dateTimeRange.setLocale(Locale.US);
        dateTimeRange.setMin(getConfiguredMinTime());
        dateTimeRange.setMax(maxToday);
        searchBtn.addThemeName("search-button");
        resetBtn.addThemeName("reset-button");
        fnsNumber.addValueChangeListener(event -> {
            if(event != null){
                String input = event.getValue();
                String output = FormUtil.toUpperCase(input);
                fnsNumber.setValue(output);
            }
        });

        terminalId.addValueChangeListener(event -> {
            if(event != null){
                String input = event.getValue();
                String output = FormUtil.toUpperCase(input);
                terminalId.setValue(output);
            }
        });
        restrictToSingleDigit(minScoreStart);
        restrictToSingleDigit(maxScoreEnd);
    }

    private LocalDateTime getConfiguredMinTime() {
        Assert.notNull(dataRetentionDuration, "Data retention duration cannot be null");
        return LocalDate.now().atStartOfDay().minus(dataRetentionDuration);
    }

    private void validateAndSearchRede() {
    	if (!validateFields()) {
	        return; // Stop further execution if validation fails
	    }
        if (!isFormValid()) {
            Notifications.showError("Please enter search criteria and try again!");
        } else if (!isScoreValid()) {
            Notifications.showError("Invalid Score Range");
        } else if (!this.binder.isValid()) {
            log.warn("Binder is invalid, please try again!");
            Notifications.showError("Invalid search criteria, please try again!");
        } else {
            RedeSearchCriteria redeSearchCriteria = RedeSearchCriteria
                    .builder()
                    .terminalId(terminalId.getValue())
                    .fnsNumber(fnsNumber.getValue())
                    .dateTimeRange(dateTimeRange.getValue())
                    .minScore(minScoreStart.getValue() != null ? Integer.toString(minScoreStart.getValue().intValue())
							: null)
					.maxScore(maxScoreEnd.getValue() != null ? Integer.toString(maxScoreEnd.getValue().intValue())
							: null)
                    .scoreType(scoreType.getValue()) // Include the selected score type
                    .status(status.getValue())
					.myItems(myItems.getValue())
                    .build();
            this.binder.setBean(redeSearchCriteria);
            fireEvent(new SearchEvent(this, redeSearchCriteria));
            exportBtn.enable();
        }
    }

    private boolean isFormValid() {
        List<HasValue<?, ?>> hasValueList = this.binder
                .getFields()
                .filter(hasValue -> hasValue.getValue() != null)
                .filter(hasValue -> StringUtils.isNotBlank(hasValue.getValue().toString()))
                .filter(hasValue -> !"[]".equalsIgnoreCase(hasValue.getValue().toString()))
                .collect(Collectors.toList());
        return hasValueList != null && !hasValueList.isEmpty();
    }

   

    private void initializeBinder() {
        binder.forField(terminalId)
        		.withValidator(terminalId -> (StringUtils.isNotBlank(terminalId) && terminalId.length() > 8) || (!terminalId.matches("^[a-zA-Z0-9]*$")) ? false : true, "Invalid Terminal ID")
                .bind(RedeSearchCriteria::getTerminalId, RedeSearchCriteria::setTerminalId);

        binder.forField(fnsNumber)
        .withValidator(value -> (StringUtils.isNotBlank(value) && (value.length() < 7 || value.length() > 7)) || (!value.matches("^[0-9]*$")) ? false : true, "Invalid FNS Number")
                .bind(RedeSearchCriteria::getFnsNumber, RedeSearchCriteria::setFnsNumber);

        binder.forField(dateTimeRange)
                .asRequired("Start Date/Time and End Date/Time are required.")
                .bind(RedeSearchCriteria::getDateTimeRange, RedeSearchCriteria::setDateTimeRange);
        // Add validation for maxScore
        binder.forField(minScoreStart).withValidator(value -> value == null || (value >= 0 && value <= 9),
				"Min Score Range must be between 0 and 9").bind(criteria -> {
					String val = criteria.getMinScore();
					try {
						return val != null ? Double.valueOf(val) : null;
					} catch (NumberFormatException e) {
						log.warn("Invalid minScore value in model: {}", val, e);
						return null;
					}
				}, (criteria, value) -> criteria
						.setMinScore(value != null ? Integer.toString(value.intValue()) : null));
        // Add validation for maxScore
		binder.forField(maxScoreEnd).withValidator(value -> value == null || (value >= 0 && value <= 9),
				"Max Score Range must be between 0 and 9").bind(criteria -> {
					String val = criteria.getMaxScore();
					try {
						return val != null ? Double.valueOf(val) : null;
					} catch (NumberFormatException e) {
						log.warn("Invalid maxScore value in model: {}", val, e);
						return null;
					}
				}, (criteria, value) -> criteria
						.setMaxScore(value != null ? Integer.toString(value.intValue()) : null));
		binder.forField(status).bind(RedeSearchCriteria::getStatus, RedeSearchCriteria::setStatus);
		binder.forField(myItems).bind(RedeSearchCriteria::getMyItems, RedeSearchCriteria::setMyItems);
    }

    private boolean isScoreValid() {
		Double min = minScoreStart.getValue();
		Double max = maxScoreEnd.getValue();
		if (min != null && (min < 0 || min > 9)) {
			return false;
		}
		if (max != null && (max < 0 || max > 9)) {
			return false;
		}
		if (min != null && max != null && min > max) {
			return false;
		}
		return true;
	}
    
    private boolean validateFields() {
        if (dateTimeRange.isInvalid()) {
            Notifications.showError("Invalid Start & End Date Times");
            return false;
        }
        DateTimeRange range = dateTimeRange.getValue();
        if (range == null || range.getStart() == null || range.getEnd() == null) {
            Notifications.showError("Start Date/Time and End Date/Time are required.");
            return false;
        }
        return true;
    }
    
    /**
     * Restricts the minScoreStart and maxScoreEnd NumberFields to accept only a single digit (0-9).
     *
     * @param field The NumberField to restrict (should be minScoreStart or maxScoreEnd)
     */
	private void restrictToSingleDigit(NumberField field) {
		field.getElement().executeJs("this.inputElement.addEventListener('beforeinput', function(e) { "
				+ "if (this.value.length >= 1 && e.data && e.inputType === 'insertText') { e.preventDefault(); } "
				+ "if (e.data && !/^\\d$/.test(e.data)) { e.preventDefault(); } " + "});");
	}
    
    public static abstract class RedeSearchFormEvent extends ComponentEvent<RedeSearchForm> {
        private RedeSearchCriteria searchCriteria;

        public RedeSearchFormEvent(RedeSearchForm source, RedeSearchCriteria searchCriteria) {
            super(source, false);
            this.searchCriteria = searchCriteria;
        }

        public RedeSearchCriteria getRedeSearchCriteria() {
            return searchCriteria;
        }
    }

    public static class SearchEvent extends RedeSearchFormEvent {
     public SearchEvent(RedeSearchForm source, RedeSearchCriteria searchCriteria) {
            super(source, searchCriteria);
        }
    }

    public static class ClearEvent extends ComponentEvent<RedeSearchForm> {
        public ClearEvent(RedeSearchForm source) {
            super(source, false);
        }
    }

    public static class ExportEvent extends ComponentEvent<RedeSearchForm> {
        public ExportEvent(RedeSearchForm source) {
            super(source, false);
        }
    }

    public Registration addSearchEventListener(ComponentEventListener<SearchEvent> listener) {
        return addListener(SearchEvent.class, listener);
    }

    public Registration addClearEventListener(ComponentEventListener<ClearEvent> listener) {
        return addListener(ClearEvent.class, listener);
    }

    public Registration addExportEventListener(ComponentEventListener<ExportEvent> listener) {
        return addListener(ExportEvent.class, listener);
    }
     
    
    public Binder<RedeSearchCriteria> getBinder() {
        return this.binder;
    } 
}
