
package com.ebtedge.fns.gateway.forms;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.ebtedge.fns.gateway.model.UserPreferenceSearchCriteria;
import com.ebtedge.fns.gateway.model.UserPreferenceVO;
import com.ebtedge.yb.service.GatService;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.Binder;
import com.vaadin.flow.shared.Registration;

public class UserPreferencesForm extends FormLayout {
	private Boolean isEmailRevealed = false;
	private Boolean isPhoneRevealed = false;

	private final TextField emailField = new TextField("Email Address");
	private final TextField phoneField = new TextField("Phone Number");
	private final Button saveButton = new Button("Save");
	private final Button cancelButton = new Button("Cancel");

	private Grid<UserPreferenceVO> preferencesGrid;
	private final Binder<UserPreferenceSearchCriteria> binder = new Binder<>(UserPreferenceSearchCriteria.class);
	private GatService gatService;
	private List<UserPreferenceVO> currentPreferences = new ArrayList<>();

	/**
	 * Constructs the form with inputs for email and phone
	 */
	public UserPreferencesForm() {
		addClassName("user-preferences-form");
		initFormField();
		initializeBinder();
		add(initDeliveryLayout());


	}

	private HorizontalLayout initDeliveryLayout() {
		HorizontalLayout deliveryLayout = new HorizontalLayout();
		deliveryLayout.setPadding(false);
		deliveryLayout.setSpacing(false);
		deliveryLayout.setWidthFull();
		deliveryLayout.getThemeList().add("spacing-l");
		deliveryLayout.addClassName("readonly-field");
		deliveryLayout.setAlignItems(FlexComponent.Alignment.BASELINE);
		
		
		
		Span phonewarning = new Span ("** Verify email and phone number before setting up notifications. If incorrect, contact your administrator "
				+ "to update prior to selecting notifications. **");
		phonewarning.addClassName("warningmessage");
		phonewarning
		.getStyle()
		.set("font-size", "13px")
		.set("margin-left", "10px")
		.set("white-space","normal")
		.set("min-width", "330px")
		.set("display", "block")
		.set("align-self", "center");
		deliveryLayout.add(emailField, phoneField,phonewarning);
		return deliveryLayout;
	}

	/**
	 * Initialize form fields with proper settings
	 */
	private void initFormField() {
		emailField.setPlaceholder("Enter Email Address");
		emailField.setRequired(true);
		emailField.setReadOnly(true);
		emailField.setMinWidth("200px");
		emailField.setMaxWidth("400px");
		emailField.setPrefixComponent(VaadinIcon.ENVELOPE.create());
		

		phoneField.setPlaceholder("Enter Phone Number");
		phoneField.setRequired(true);
		phoneField.setReadOnly(true);
		phoneField.setMinWidth("200px");
		phoneField.setPrefixComponent(VaadinIcon.PHONE.create());
		

		saveButton.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
		cancelButton.addThemeVariants(ButtonVariant.LUMO_TERTIARY);

		saveButton.addClickListener(event -> savePreferences());
		cancelButton.addClickListener(event -> cancelChanges());
	}

	/**
	 * Initialize form validation rules
	 */
	private void initializeBinder() {
		binder.forField(emailField).asRequired("Email is required")
				.withValidator(
						email -> email == null || email.matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$")
								|| email.equals("**********"),
						"Enter a valid email address")
				.bind(UserPreferenceSearchCriteria::getEmailAddress, UserPreferenceSearchCriteria::setEmailAddress);

		binder.forField(phoneField).asRequired("Phone Number is required")
				.withValidator(phone -> phone == null || phone.matches("\\d{10}") || phone.equals("**********"),
						"Enter a valid 10-digit phone number")
				.bind(UserPreferenceSearchCriteria::getPhoneNumber, UserPreferenceSearchCriteria::setPhoneNumber);
	}

	/**
	 * Mask a string with asterisks
	 * 
	 * @param input String to mask
	 * @return Masked string
	 */
	/**
	 * Mask a string with asterisks
	 * 
	 * @param input String to mask
	 * @return Masked string
	 */
	private String maskString(String input) {
		if (input == null || input.isEmpty()) {
			return "**********";
		}
		return "**********";
	}

	/**
	 * Mask email showing only first few characters
	 * 
	 * @param email Email address to mask
	 * @return Masked email address
	 */
	private String maskEmail(String email) {
		if (email == null || email.isEmpty()) {
			return "**********";
		}
		int atIndex = email.indexOf("@");
		if (atIndex <= 2) {
			return "****" + email.substring(atIndex);
		}
		return email.substring(0, 3) + "****" + email.substring(atIndex);
	}

	/**
	 * Mask phone number showing only first and last digits
	 * 
	 * @param phone Phone number to mask
	 * @return Masked phone number
	 */
	private String maskPhone(String phone) {
		if (phone == null || phone.isEmpty()) {
			return "**********";
		}
		if (phone.length() < 6) {
			return "****";
		}
		return phone.substring(0, 3) + "****" + phone.substring(phone.length() - 2);
	}

	/**
	 * Get the current email from preferences
	 * 
	 * @return Email address
	 */
	private String getCurrentEmailFromPreferences() {
		if (!currentPreferences.isEmpty()) {
			return currentPreferences.get(0).getEmailAddress();
		}
		return "";
	}

	/**
	 * Get the current phone from preferences
	 * 
	 * @return Phone number
	 */
	private String getCurrentPhoneFromPreferences() {
		if (!currentPreferences.isEmpty()) {
			return currentPreferences.get(0).getPhoneNumber();
		}
		return "";
	}

	/**
	 * Save preferences to the backend
	 */
	private void savePreferences() {
		if (!binder.isValid()) {
			Notification.show("Please correct form errors", 3000, Notification.Position.MIDDLE);
			return;
		}

		String email = isEmailRevealed ? emailField.getValue() : getCurrentEmailFromPreferences();
		String phone = isPhoneRevealed ? phoneField.getValue() : getCurrentPhoneFromPreferences();

		List<UserPreferenceVO> gridPrefs = getPreferencesFromGrid();

		UserPreferenceSearchCriteria criteria = new UserPreferenceSearchCriteria();
		criteria.setEmailAddress(email);
		criteria.setPhoneNumber(phone);

		fireEvent(new SaveEvent(this, criteria, gridPrefs));
	}

	/**
	 * Cancel preference changes
	 */
	private void cancelChanges() {
		UserPreferenceSearchCriteria emptyModel = new UserPreferenceSearchCriteria();
		binder.readBean(emptyModel);

		emailField.setValue("**********");
		phoneField.setValue("**********");
		isEmailRevealed = false;
		isPhoneRevealed = false;
		//revealEmail.setText("View");
		//revealPhone.setText("View");

		fireEvent(new CancelEvent(this));
	}

	/**
	 * Get preferences from the grid
	 * 
	 * @return List of preferences
	 */
	private List<UserPreferenceVO> getPreferencesFromGrid() {
		if (preferencesGrid == null) {
			return new ArrayList<>();
		}

		return preferencesGrid.getListDataView().getItems().filter(item -> item.getAlertsTypeCode() != null)
				.collect(Collectors.toList());
	}

	/**
	 * Reset the grid with current preferences
	 */
	private void resetGrid() {
		if (preferencesGrid != null) {
		}
	}

	/**
	 * Set grid reference and gateway service
	 * 
	 * @param grid    The preferences grid
	 * @param service The gateway service
	 */
	public void setGridAndService(Grid<UserPreferenceVO> grid, GatService service) {
		this.preferencesGrid = grid;
		this.gatService = service;
	}

	/**
	 * Set current preferences
	 * 
	 * @param preferences Current user preferences
	 */
	public void setCurrentPreferences(List<UserPreferenceVO> preferences) {
		this.currentPreferences = preferences != null ? new ArrayList<>(preferences) : new ArrayList<>();
	}

	/**
	 * Get the form's binder
	 * 
	 * @return Binder instance
	 */
	public Binder<UserPreferenceSearchCriteria> getBinder() {
		return this.binder;
	}

	/**
	 * Add buttons to the form
	 * 
	 * @return Layout with action buttons
	 */
	public HorizontalLayout createButtonLayout() {
		HorizontalLayout buttonLayout = new HorizontalLayout();
		buttonLayout.addClassName("button-layout");
		buttonLayout.setWidthFull();
		buttonLayout.setJustifyContentMode(FlexComponent.JustifyContentMode.END);
		buttonLayout.add(cancelButton, saveButton);
		return buttonLayout;
	}

	public abstract static class UserPreferencesFormEvent extends ComponentEvent<UserPreferencesForm> {
		private final UserPreferenceSearchCriteria criteria;
		private final List<UserPreferenceVO> preferences;

		protected UserPreferencesFormEvent(UserPreferencesForm source, UserPreferenceSearchCriteria criteria,
				List<UserPreferenceVO> preferences) {
			super(source, false);
			this.criteria = criteria;
			this.preferences = preferences;
		}

		public UserPreferenceSearchCriteria getCriteria() {
			return criteria;
		}

		public List<UserPreferenceVO> getPreferences() {
			return preferences;
		}
	}

	public static class SaveEvent extends UserPreferencesFormEvent {
		SaveEvent(UserPreferencesForm source, UserPreferenceSearchCriteria criteria,
				List<UserPreferenceVO> preferences) {
			super(source, criteria, preferences);
		}
	}

	public static class CancelEvent extends UserPreferencesFormEvent {
		CancelEvent(UserPreferencesForm source) {
			super(source, null, null);
		}
	}

	public Registration addSaveEventListener(ComponentEventListener<SaveEvent> listener) {
		return addListener(SaveEvent.class, listener);
	}

	public Registration addCancelEventListener(ComponentEventListener<CancelEvent> listener) {
		return addListener(CancelEvent.class, listener);
	}
}
