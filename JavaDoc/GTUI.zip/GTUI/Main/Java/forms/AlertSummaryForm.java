package com.ebtedge.fns.gateway.forms;

import com.ebtedge.fns.gateway.components.DateTimeRangePicker;
import com.ebtedge.fns.gateway.components.ExportButton;
import com.ebtedge.fns.gateway.model.AlertSearchCriteria;
import com.ebtedge.fns.gateway.security.UserPermission;
import com.ebtedge.fns.gateway.util.FormUtil;
import com.ebtedge.fns.gateway.util.Notifications;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue;
import com.vaadin.flow.component.accordion.Accordion;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.combobox.MultiSelectComboBox;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.BeanValidationBinder;
import com.vaadin.flow.data.binder.Binder;
import com.vaadin.flow.shared.Registration;
import com.vaadin.flow.theme.lumo.LumoUtility;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.Assert;

import java.time.*;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

/**
 * @author e3019107
 * Creates FormLayout for Alert Summary
 */
@Slf4j
public class AlertSummaryForm extends FormLayout {

	@Getter TextField alertId = new TextField("Alert ID");
	@Getter TextField card = new TextField("Card Number");
	@Getter  TextField terminalId = new TextField("Terminal ID");
	@Getter TextField fnsNumber = new TextField("FNS Number");
    MultiSelectComboBox<String> ruleName = new MultiSelectComboBox<>("Rule Name");
    private final DateTimeRangePicker dateTimeRange = new DateTimeRangePicker();

    private final List<String> ruleNames;
    private final Duration dataRetentionDuration;

    // Action buttons for Tran Search
    Button resetBtn = new Button("Reset");
    Button searchBtn = new Button("Search");
    private final ExportButton exportBtn = new ExportButton(List.of(UserPermission.GWAllowAlertsExport));

    Binder<AlertSearchCriteria> binder = new BeanValidationBinder<>(AlertSearchCriteria.class);


    public AlertSummaryForm(List<String> ruleNames, Duration dataRetentionDuration) {
        this.ruleNames = ruleNames;
        this.dataRetentionDuration = dataRetentionDuration;
        binder.bindInstanceFields(this);
        addClassName("alert-summary-form");
        initFormFieldsAndPlaceHolders();
        initializeBinder();
        Accordion accordion = FormUtil.initSearchLayoutAccordion("Alert Search Criteria ", getAlertSummaryLayout());
        add(accordion);
        resetBtn.addClickListener(buttonClickEvent -> clearSearchFields());
        exportBtn.addClickListener(buttonClickEvent -> fireEvent(new ExportEvent(this)));
    }

    /**
     * @return Vertical Layout of Tran search criteria fields
     */
    private VerticalLayout getAlertSummaryLayout() {

        HorizontalLayout row1 = new HorizontalLayout(alertId, card, fnsNumber, terminalId, ruleName, dateTimeRange);
        row1.addClassNames(LumoUtility.Display.FLEX, LumoUtility.FlexDirection.COLUMN, LumoUtility.FlexDirection.Breakpoint.Medium.ROW, LumoUtility.Gap.MEDIUM);
        row1.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.BASELINE);
        HorizontalLayout buttonLayout = new HorizontalLayout(searchBtn, resetBtn, exportBtn);
        buttonLayout.addClassNames(LumoUtility.Display.FLEX, LumoUtility.FlexDirection.COLUMN, LumoUtility.FlexDirection.Breakpoint.Medium.ROW, LumoUtility.Gap.MEDIUM);
        buttonLayout.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.BASELINE);
        VerticalLayout verticalLayout = new VerticalLayout();
        verticalLayout.addClassNames(LumoUtility.Padding.Horizontal.SMALL, LumoUtility.Padding.Vertical.SMALL);
        verticalLayout.add(row1, buttonLayout);
        return verticalLayout;

    }

    /**
     * clears form inputs
     */
    private void clearSearchFields() {

        this.alertId.clear();
        this.card.clear();
        this.fnsNumber.clear();
        this.terminalId.clear();
        this.ruleName.clear();
        this.dateTimeRange.clear();
        exportBtn.reset();
        fireEvent(new ClearGridEvent(this));
    }

    /**
     * initialize form input field placeholders
     */
    private void initFormFieldsAndPlaceHolders() {


        LocalDateTime maxToday = LocalDateTime.of(LocalDate.now(), LocalTime.MAX);


        this.card.setPlaceholder("Enter Card Number");
        this.card.setClassName("alert-card-num");
        this.fnsNumber.setPlaceholder("Enter FNS #");
        this.fnsNumber.setClassName("alert-fns-num");
        this.terminalId.setPlaceholder("Enter Terminal ID #");
        this.terminalId.setClassName("alert-terminal-id");

        this.alertId.setPlaceholder("Enter Alert ID");
        this.alertId.setClassName("alert-id");
        this.ruleName.setItems(ruleNames);

        this.ruleName.setPlaceholder("Rule Name");
        this.ruleName.setClassName("alert-rule-name");
        dateTimeRange.setPlaceholders("Enter Start Date", "Enter Start Time", "Enter End Date", "Enter End Time");
        dateTimeRange.setRequiredIndicatorVisible(true);
        dateTimeRange.setLocale(Locale.US);
        dateTimeRange.setMin(getConfiguredMinTime());
        dateTimeRange.setMax(maxToday);

        searchBtn.addThemeName("search-button");
        resetBtn.addThemeName("reset-button");
        searchBtn.addClickListener(buttonClickEvent -> validateAndSearchAlerts());
        resetBtn.addClickListener(buttonClickEvent -> clearSearchFields());
        card.addValueChangeListener(event -> {
            if(event != null){
                String input = event.getValue();
                String output = FormUtil.toUpperCase(input);
                card.setValue(output);
            }
        });
        fnsNumber.addValueChangeListener(event -> {
            if(event != null){
                String input = event.getValue();
                String output = FormUtil.toUpperCase(input);
                fnsNumber.setValue(output);
            }
        });

        terminalId.addValueChangeListener(event -> {
            if(event != null){
                String input = event.getValue();
                String output = FormUtil.toUpperCase(input);
                terminalId.setValue(output);
            }
        });

        this.alertId.addValueChangeListener(event -> {
            if(event != null){
                String input = event.getValue();
                if(StringUtils.isNotBlank(input))
                    alertId.setValue(input.trim());
            }
        });
        //exportBtn.addClickListener(e -> fireEvent(new ExportEvent(this)));

    }

    private void validateAndSearchAlerts() {
        if (!isFormValid()) {
            Notifications.showError("Please enter search criteria and try again!");
        } else if (!this.binder.isValid()) {
            log.warn("Binder is invalid, please try again!");
            Notifications.showError("Invalid search criteria, please try again!");
        } else if (isDateTimeRangeInvalid()) {
            log.warn("Date time range is invalid, please try again!");
            Notifications.showError("Invalid Start & End Date Times");
        } else {
            AlertSearchCriteria alertSearchCriteria = AlertSearchCriteria
                    .builder()
                    .alertId(alertId.getValue())
                    .card(card.getValue())
                    .fnsNumber(fnsNumber.getValue())
                    .terminalId(terminalId.getValue())
                    .ruleName(ruleName.getValue())
                    .dateTimeRange(dateTimeRange.getValue())
                    .build();
            this.binder.setBean(alertSearchCriteria);
            fireEvent(new SearchEvent(this, binder.getBean()));
            exportBtn.enable();
        }
    }

    public static abstract class AlertSummaryFormEvent extends ComponentEvent<AlertSummaryForm> {

        private AlertSearchCriteria searchCriteria;

        public AlertSummaryFormEvent(AlertSummaryForm source, AlertSearchCriteria searchCriteria) {
            super(source, false);
            this.searchCriteria = searchCriteria;
        }

        public AlertSearchCriteria getAlertSearchCriteria() {
            return searchCriteria;
        }
    }

    public static class SearchEvent extends AlertSummaryFormEvent {
        SearchEvent(AlertSummaryForm source, AlertSearchCriteria searchCriteria) {
            super(source, searchCriteria);
        }
    }

    public Registration addSearchEventListener(ComponentEventListener<SearchEvent> listener) {
        return addListener(SearchEvent.class, listener);
    }

    private boolean isFormValid() {
        List<HasValue<?, ?>> hasValueList = this.binder
                .getFields()
                .filter(hasValue -> hasValue.getValue() != null)
                .filter(hasValue -> StringUtils.isNotBlank(hasValue.getValue().toString()))
                .filter(hasValue -> !"[]".equalsIgnoreCase(hasValue.getValue().toString()))
                .collect(Collectors.toList());
        if (hasValueList == null || hasValueList.size() == 0) {
            log.warn("No value provided in the search criteria");
            return false;
        }
        return true;
    }

    private void initializeBinder() {

        binder.forField(alertId)
                .withValidator(value -> (StringUtils.isNotBlank(value) && (value.length() < 4 || value.length() > 10)) || (!value.matches("^[a-zA-Z0-9]*$")) ? false : true, "Invalid Alert Id")
                .bind(AlertSearchCriteria::getAlertId, AlertSearchCriteria::setAlertId);


        binder.forField(card)
                .withValidator(value -> (StringUtils.isNotBlank(value) && (value.length() < 5 || value.length() > 19)) || (!value.matches("[0-9*]*")) ? false : true, "Invalid card")
                .bind(AlertSearchCriteria::getCard, AlertSearchCriteria::setCard);

        binder.forField(terminalId)
                .withValidator(value -> (StringUtils.isNotBlank(value) &&  value.length() > 8) || (!value.matches("^[a-zA-Z0-9]*$")) ? false : true, "Invalid Terminal ID")
                .bind(AlertSearchCriteria::getTerminalId, AlertSearchCriteria::setTerminalId);


        binder.forField(fnsNumber)
                .withValidator(value -> (StringUtils.isNotBlank(value) && (value.length() < 7 || value.length() > 7)) || (!value.matches("^[0-9]*$")) ? false : true, "Invalid FNS Number")
                .bind(AlertSearchCriteria::getFnsNumber, AlertSearchCriteria::setFnsNumber);

        binder.forField(dateTimeRange)
                .asRequired("Start Date/Time and End Date/Time are required.")
                .bind(AlertSearchCriteria::getDateTimeRange, AlertSearchCriteria::setDateTimeRange);
    }

    private LocalDateTime getConfiguredMinTime() {
        Assert.notNull(dataRetentionDuration, "Data retention duration must be configured");
        return LocalDate.now().atStartOfDay().minus(dataRetentionDuration);
    }

    boolean isDateTimeRangeInvalid() {
        return dateTimeRange.isInvalid()
                || dateTimeRange.getValue() == null
                || (dateTimeRange.getValue().getStart() == null
                        || dateTimeRange.getValue().getEnd() == null);
    }

    public static class ClearEvent extends ComponentEvent<AlertSummaryForm> {
        public ClearEvent(AlertSummaryForm source) {
            super(source, false);
        }
    }

    public static class ExportEvent extends ComponentEvent<AlertSummaryForm> {
        public ExportEvent(AlertSummaryForm source) {
            super(source, false);
        }
    }

    public Registration addExportEventListener(ComponentEventListener<ExportEvent> listener) {
        return addListener(ExportEvent.class, listener);
    }

    public Registration addClearEventListener(ComponentEventListener<ClearEvent> listener) {
        return addListener(ClearEvent.class, listener);
    }

    public Registration addClearGridEventListener(ComponentEventListener<AlertSummaryForm.ClearGridEvent> listener) {
        return addListener(AlertSummaryForm.ClearGridEvent.class, listener);
    }

    public static class ClearGridEvent extends ComponentEvent<AlertSummaryForm> {
        public ClearGridEvent(AlertSummaryForm source) {
            super(source, true);
        }
    }

    public Binder<AlertSearchCriteria> getBinder() {
        return this.binder;
    }
}
