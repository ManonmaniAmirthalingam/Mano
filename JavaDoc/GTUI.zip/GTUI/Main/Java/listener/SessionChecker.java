package com.ebtedge.fns.gateway.listener;

import com.ebtedge.fns.gateway.config.GatAppConfig;
import com.ebtedge.fns.gateway.security.CurrentUserAccess;
import com.ebtedge.fns.gateway.util.RouteUrls;
import com.ebtedge.fns.gateway.util.SessionUtil;
import com.ebtedge.fns.gateway.views.errors.AccessDeniedView;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterListener;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import static com.ebtedge.fns.gateway.util.RouteUrls.TRANSACTION_SEARCH;

/**
 * Validates user sessions for protected routes and handles session invalidation. Transaction routes
 * are excluded from session validation.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class SessionChecker implements BeforeEnterListener {

    private final GatAppConfig gatAppConfig;
    private final CurrentUserAccess currentUserAccess;

    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        if (isTransactionRoute(event)) {
            return;
        }

        boolean isSessionValid = SessionUtil.isSessionValid();
        if (!isSessionValid) {
            SessionUtil.invalidateSession();
            event.forwardToUrl(gatAppConfig.getLogoutUrl());
        } else if (!currentUserAccess.hasAccessToUrl(event.getLocation().getPath())) {
            log.warn(
                    "User {} attempted to access unauthorized route {}",
                    SessionUtil.getUserId(),
                    event.getLocation().getPath());
            event.forwardTo(AccessDeniedView.class);
        }
    }

    private boolean isTransactionRoute(BeforeEnterEvent event) {
        String targetRoute = event.getLocation().getPath();
        return RouteUrls.getRouteUrl(targetRoute).map(TRANSACTION_SEARCH::equals).orElse(false);
    }
}
