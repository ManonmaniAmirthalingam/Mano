package com.ebtedge.fns.gateway.listener;

import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterListener;
import com.vaadin.flow.server.VaadinSession;
import org.springframework.stereotype.Component;

/**
 * Tracks route navigation in the application, storing the previous URL for navigation purposes.
 * Excludes analytics-related pages from tracking.
 */
@Component
public class RouteTracker implements BeforeEnterListener {

    private static final String ANALYTICS_PREFIX = "analytics";
    private static final String PREVIOUS_URL_ATTRIBUTE = "previousUrl";

    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        String currentPage = getCurrentPage(event);
        if (currentPage.startsWith(ANALYTICS_PREFIX)) {
            return;
        }
        storePreviousUrl(currentPage);
    }

    private String getCurrentPage(BeforeEnterEvent event) {
        return event.getLocation().getPath();
    }

    private void storePreviousUrl(String url) {
        VaadinSession.getCurrent().setAttribute(PREVIOUS_URL_ATTRIBUTE, url);
    }
}
