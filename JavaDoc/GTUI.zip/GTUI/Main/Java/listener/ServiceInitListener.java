package com.ebtedge.fns.gateway.listener;

import com.vaadin.flow.server.ServiceInitEvent;
import com.vaadin.flow.server.VaadinRequest;
import com.vaadin.flow.server.VaadinServiceInitListener;
import com.vaadin.flow.server.VaadinServletRequest;
import com.vaadin.flow.server.VaadinSession;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;

import com.vaadin.flow.server.VaadinService;
import com.vaadin.flow.router.BeforeEnterListener;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Component;

/**
 * Initializes Vaadin service by registering session checking and route tracking listeners. This
 * listener is called when the Vaadin service is being initialized.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class ServiceInitListener implements VaadinServiceInitListener {

    private final SessionChecker sessionChecker;
    private final RouteTracker routeTracker;
    private static final String SM_PARAM_USERID = "sm_user";
    private static final String SM_PARAM_SSO_TOKEN = "SMSESSION";
    private static final String SM_PARAM_FN = "firstname";
    private static final String SM_PARAM_LN = "lastname";
    private static final String SM_PARAM_EMAIL = "email";
    private static final String SM_PARAM_PHONE = "PhoneNo";

    @Override
    public void serviceInit(ServiceInitEvent event) {
        VaadinService service = event.getSource();
        registerBeforeEnterListeners(service);
        readSmUserInfo(service);
    }

    private void registerBeforeEnterListeners(VaadinService service) {
        registerListener(service, sessionChecker);
        registerListener(service, routeTracker);
    }
    
    private void readSmUserInfo(VaadinService service) {
    	
    	log.info("Getting the UserInfo from httpRequest header.");
    	
        service.addSessionInitListener(sessionInitEvent -> {VaadinRequest request = sessionInitEvent.getRequest();
	        if (request instanceof VaadinServletRequest) {
	        	
	        	HttpServletRequest httpRequest = ((VaadinServletRequest) request).getHttpServletRequest();
	        	log.info("Fetching values from httpRequest" + httpRequest);
	        	String smUser = httpRequest.getHeader(SM_PARAM_USERID);
	        	String smFname = httpRequest.getHeader(SM_PARAM_FN);
	        	String smLName = httpRequest.getHeader(SM_PARAM_LN);
				String smEmail = httpRequest.getHeader(SM_PARAM_EMAIL);
				String smPhoneNo = httpRequest.getHeader(SM_PARAM_PHONE);
				String smSession = "";
				Cookie cookie = getCookie(httpRequest, SM_PARAM_SSO_TOKEN);
					if (cookie != null) {
						smSession = cookie.getValue();
						
					}
			
				 log.info("Values from request header : smUser: {}, smFname: {}, smLName: {}, smEmail:{}, smPhoneNo:{}, smSession:{}",
						 smUser, smFname, smLName, smEmail, smPhoneNo,smSession);
				 
				VaadinSession session = sessionInitEvent.getSession();
				session.setAttribute("userId", smUser);
				session.setAttribute("firstName", smFname);
				session.setAttribute("lastName", smLName);
				session.setAttribute("emailId", smEmail);
				session.setAttribute("phoneNo", smPhoneNo);
				session.setAttribute("ssoToken", smSession);
	        }
        });
    }

    private void registerListener(VaadinService service, BeforeEnterListener listener) {
        service.addUIInitListener(uiEvent -> uiEvent.getUI().addBeforeEnterListener(listener));
    }
    

	/**
	 * Get a cookie from the HTTP request.
	 */
	public static Cookie getCookie(HttpServletRequest request, String cookieName) {
		Cookie result = null;

		Cookie[] cookies = request.getCookies();
		if (cookies != null) {
			for (int i = 0; i < cookies.length; i++) {
				Cookie cookie = cookies[i];
				if (cookieName.equals(cookie.getName())) {
					result = cookie;
					break;
				}
			}
		}

		return result;
	}
}
