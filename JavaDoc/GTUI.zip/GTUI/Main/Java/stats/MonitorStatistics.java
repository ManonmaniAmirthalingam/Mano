package com.ebtedge.fns.gateway.stats;

import com.ebtedge.fns.gateway.model.ShmAlert;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@RequiredArgsConstructor
public class MonitorStatistics {

    @JsonIgnore
    @Getter private final Map<ShmAlert, Integer> alertAccumulations;

    @JsonProperty("alertAccumulations")
    public TreeMap<String, TreeMap<String, Map<Instant, Integer>>> getAlertAccumulationsAsNestedMap() {
        return alertAccumulations.entrySet().stream()
                .collect(
                        Collectors.groupingBy(
                                e -> e.getKey().getAlertEntity(),
                                TreeMap::new,
                                Collectors.groupingBy(
                                        e -> e.getKey().getAlertTriggerId(),
                                        TreeMap::new,
                                        Collectors.toMap(
                                                entry -> entry.getKey().getTimestamp(),
                                                Map.Entry::getValue,
                                                Integer::sum
                                        ))));
    }
}
