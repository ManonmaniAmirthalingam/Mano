package com.ebtedge.fns.gateway.util;

import com.ebtedge.fns.gateway.delegate.AuthorizationDelegate;
import com.ebtedge.fns.gateway.domain.UserInfo;
import com.ebtedge.fns.gateway.views.transearch.TransactionSearchView;
import com.ebtedge.user.admin.bean.AuthRequest;
import com.ebtedge.user.admin.domain.EbtUser;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.Location;
import com.vaadin.flow.router.QueryParameters;
import com.vaadin.flow.server.VaadinSession;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
public class SSOUtil {

    @Autowired
    AuthorizationDelegate authorizationDelegate;

    public boolean handleSSO(BeforeEnterEvent event) {
        try {
        	
        	 // Fallback: Check if sessionUserInfo is already present
            UserInfo sessionUserInfo = SessionUtil.getUserInfo();
            if (sessionUserInfo != null) {
                log.debug("Session info is already present: {}", sessionUserInfo);
                return true;
            }
        	
            Location location = event.getLocation();
            
            VaadinSession session = VaadinSession.getCurrent();
         
            String ssoToken = "9876543210";
            String userId = null;
            String firstName = "";
            String lastName = "";
            String middleName = "";
            String email = "testemail@fisglobal.com";
            String phone="1111111111";
            
            
            log.info("Getting the UserInfo from session");
            
            userId = (String)session.getAttribute("userId");
            firstName = (String)session.getAttribute("firstName");
            lastName = (String)session.getAttribute("lastName");
            email = (String)session.getAttribute("emailId");
            phone = (String)session.getAttribute("phoneNo");
            String smSession = (String)session.getAttribute("ssoToken");
                        
           log.info("SSO and User info from session: userId: {}, smSession: {}, firstName:{}, lastName:{}, email:{}, phone:{}",
                        userId, smSession, firstName, lastName, email, phone);
             
            if (StringUtils.isBlank(userId)) {
                return false;
            }else {

              	if(StringUtils.isBlank(smSession)) {
            		log.info("setting default value ssoToken");
            		smSession = ssoToken;
            	}
                AuthRequest authRequest = new AuthRequest();
                authRequest.setSsoToken(smSession);
                authRequest.setUsername(userId);

                EbtUser ebtUser = authorizationDelegate.authorizeUser(authRequest);
                if (ebtUser != null) {
                    log.info("Authorization flow completed for the user: {}", ebtUser);
                    UserInfo userInfo = UserInfo
                            .builder()
                            .userId(ebtUser.getUserId())
                            .firstName(firstName)
                            .lastName(StringUtils.isBlank(lastName) ? "" : lastName)
                            .middleName(StringUtils.isBlank(middleName) ? "" : middleName)
                            .email(StringUtils.isBlank(email) ? "" : email)
							.phoneNumber(StringUtils.isBlank(phone) ? "" : phone)
                            .roles(new HashSet<>(ebtUser.getManagedRoles()))
                            .isAdminUser(ebtUser.getManagedRoles().stream().anyMatch(s -> s.equalsIgnoreCase("GWUserActivityAdminUser")))
                            .build();
                    VaadinSession.getCurrent().setAttribute("userInfo", userInfo);
                    UI.getCurrent().navigate(TransactionSearchView.class);
                } else {
                    log.error("Authorization response is null, hence logging out: ");
                    return false;
                }
                return true;
            }
           
        } catch (Exception e) {
            log.error("error while getting state, ssoToken and userId info from agency portal: {}", e);
            return false;
        }
    }
}
