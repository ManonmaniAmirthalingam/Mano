package com.ebtedge.fns.gateway.util;

import com.ebtedge.fns.gateway.domain.UserInfo;
import com.vaadin.flow.server.ServiceInitEvent;
import com.vaadin.flow.server.SessionDestroyEvent;
import com.vaadin.flow.server.SessionDestroyListener;
import com.vaadin.flow.server.SessionInitEvent;
import com.vaadin.flow.server.SessionInitListener;
import com.vaadin.flow.server.VaadinServiceInitListener;
import com.vaadin.flow.server.VaadinSession;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class SessionTimeoutHandler implements VaadinServiceInitListener, SessionInitListener, SessionDestroyListener {

    @Value("${ebtgovs.session.timeout}")
    private int sessionTimeoutValue;

    @Override
    public void serviceInit(ServiceInitEvent event) {
        event.getSource().addSessionInitListener(this);
        event.getSource().addSessionDestroyListener(this);
    }

    @Override
    public void sessionInit(SessionInitEvent event) {
        VaadinSession session = event.getSession();
        session.getSession().setMaxInactiveInterval(sessionTimeoutValue);
    }

    @Override
    public void sessionDestroy(SessionDestroyEvent event) {
        VaadinSession session = event.getSession();
        UserInfo userInfo = session.getAttribute(UserInfo.class);
        //TODO: Add logout event to DB
        if (userInfo != null) {
            log.debug("Session destroy called with valid userInfo. UserId: {}, SessionId: {}", userInfo.getUserId(), session.getSession().getId());
            session.setAttribute(UserInfo.class, null);
            session.close();
        }
    }
}