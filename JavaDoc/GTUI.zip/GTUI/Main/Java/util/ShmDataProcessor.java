package com.ebtedge.fns.gateway.util;

import com.ebtedge.fns.gateway.model.*;
import com.ebtedge.fns.gateway.rule.shm.ShmRuleInput;
import com.ebtedge.fns.gateway.rule.RuleEvaluationResults;
import com.ebtedge.fns.gateway.rule.shm.*;
import com.ebtedge.fns.gateway.service.ShmEntityAssociationService;
import com.ebtedge.yb.entity.ShmEntity;
import com.ebtedge.yb.entity.ShmEntityAssociation;
import com.ebtedge.yb.entity.ShmStateBin;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.*;
import java.util.function.Supplier;
import java.util.stream.Collectors;

/**
 * Service class responsible for processing System Health Monitor (SHM) data and generating various
 * types of grid views (Link, Gateway, System, and State) based on the evaluation of SHM rules.
 *
 * <p>The class utilizes the {@link ShmEntityAssociationService} to retrieve entity associations and
 * the {@link ShmRuleEngine} to perform rule evaluation.
 *
 * <p>This class is a Spring-managed component and supports dependency injection.
 */
@Component
@RequiredArgsConstructor
public class ShmDataProcessor {
    private final ShmEntityAssociationService entityAssociationService;
    private final ShmRuleEngine ruleEngine;

    /**
     * Processes a given System Health Monitoring (SHM) entity to evaluate its link-related metrics,
     * rule violations, and overall health status within a specified time range.
     *
     * @param entity the SHM entity to be processed for link-related data
     * @param from the start of the time range for data processing
     * @param to the end of the time range for data processing
     * @return a {@link ShmLinkGridVO} object populated with processed link-related information,
     *     including metrics, rule violations, and hierarchical child nodes
     */
    public ShmLinkGridVO processLink(ShmEntity entity, LocalDateTime from, LocalDateTime to) {
        return processEntity(entity.getName(), from, to, ShmLinkGridVO::new);
    }

    /**
     * Processes a given System Health Monitoring (SHM) entity to evaluate its gateway-specific
     * data, including metrics, rule violations, and overall health status within a specified time
     * range.
     *
     * @param entity the SHM entity to be processed for gateway-related data
     * @param from the start of the time range for data processing
     * @param to the end of the time range for data processing
     * @return a {@link ShmGatewayGridVO} object populated with processed gateway-related
     *     information, including metrics, rule violations, and hierarchical child nodes
     */
    public ShmGatewayGridVO processGateway(ShmEntity entity, LocalDateTime from, LocalDateTime to) {
        return processEntity(entity.getName(), from, to, ShmGatewayGridVO::new);
    }

    /**
     * Processes a given System Health Monitoring (SHM) entity to evaluate its system-specific data,
     * including metrics, rule violations, and overall health status within a specified time range.
     *
     * @param entity the SHM entity to be processed for system-related data
     * @param from the start of the time range for data processing
     * @param to the end of the time range for data processing
     * @return a {@link ShmSystemGridVO} object populated with processed system-related information,
     *     including metrics, rule violations, and hierarchical child nodes
     */
    public ShmSystemGridVO processSystem(ShmEntity entity, LocalDateTime from, LocalDateTime to) {
        return processEntity(entity.getName(), from, to, ShmSystemGridVO::new);
    }

    /**
     * Processes a given System Health Monitoring (SHM) state bin to evaluate its state-specific
     * data, including metrics, rule violations, and overall health status within a specified time
     * range.
     *
     * @param card the {@link ShmStateBin} object representing the state and binary mapping to be
     *     processed
     * @param from the start of the time range for data processing
     * @param to the end of the time range for data processing
     * @return a {@link ShmStateBinGridVO} object populated with processed state-specific
     *     information, including metrics, rule violations, and overall health status
     */
    public ShmStateBinGridVO processState(ShmStateBin card, LocalDateTime from, LocalDateTime to) {
        ShmStateBinGridVO stateBinGridVO =
                processEntity(card.getBin(), from, to, ShmStateBinGridVO::new);
        stateBinGridVO.setState(card.getState());
        return stateBinGridVO;
    }

    private <T extends BaseShmGridVO> T processEntity(
            String entity, LocalDateTime from, LocalDateTime to, Supplier<T> gridVOSupplier) {
        var results = evaluateRules(entity, from, to);
        var ruleViolations = results.getAllViolations();
        T gridVO = gridVOSupplier.get();
        gridVO.setEntity(entity);
        gridVO.setHealthStatus(determineHealthStatus(results));
        gridVO.setRuleViolations(ruleViolations);
        gridVO.setCount(calculateViolationCount(ruleViolations));
        gridVO.setChildren(createChildrenNodes(entity, results, gridVOSupplier));
        return gridVO;
    }

    private <T extends BaseShmGridVO> List<T> createChildrenNodes(
            String entity,
            RuleEvaluationResults<ShmRuleViolation> parentRuleExecutionResults,
            Supplier<T> gridVOSupplier) {
        return entityAssociationService.findByEntityName(entity).parallelStream()
                .map(
                        association ->
                                createChildNode(
                                        association, parentRuleExecutionResults, gridVOSupplier))
                .toList();
    }

    private <T extends BaseShmGridVO> T createChildNode(
            ShmEntityAssociation association,
            RuleEvaluationResults<ShmRuleViolation> parentRuleExecutionResults,
            Supplier<T> gridVOSupplier) {
        Set<ShmRuleViolation> childViolations = new HashSet<>();
        parentRuleExecutionResults
                .getAllViolations()
                .forEach(
                        violation -> {
                            Map<ShmAlert, Integer> alertAccumulation =
                                    violation.getAlertAccumulation().entrySet().stream()
                                            .filter(
                                                    entry ->
                                                            entry.getKey()
                                                                    .getAlertEntity()
                                                                    .equals(
                                                                            association
                                                                                    .getAlertEntity()))
                                            .collect(
                                                    Collectors.toMap(
                                                            Map.Entry::getKey,
                                                            Map.Entry::getValue));
                            if (!alertAccumulation.isEmpty()) {
                                childViolations.add(
                                        ShmRuleViolation.builder()
                                                .ruleType(violation.getRuleType())
                                                .entity(association.getAlertEntity())
                                                .alertAccumulation(alertAccumulation)
                                                .build());
                            }
                        });

        T gridVO = gridVOSupplier.get();
        gridVO.setEntity(association.getAlertEntity());
        gridVO.setHealthStatus(determineHealthStatus(childViolations));
        gridVO.setRuleViolations(childViolations);
        gridVO.setCount(calculateViolationCount(childViolations));
        gridVO.setSubtype(true);
        return gridVO;
    }

    private RuleEvaluationResults<ShmRuleViolation> evaluateRules(
            String entityId, LocalDateTime from, LocalDateTime to) {
        ShmRuleInput input = createRuleInput(entityId, from, to);
        return ruleEngine.evaluateAll(input);
    }

    private ShmRuleInput createRuleInput(String entity, LocalDateTime from, LocalDateTime to) {
        return ShmRuleInput.builder().from(from).to(to).entity(entity).build();
    }

    private int calculateViolationCount(Set<ShmRuleViolation> violations) {
        return violations.stream()
                .map(ShmRuleViolation::getAlertAccumulation)
                .map(Map::values)
                .flatMap(Collection::stream)
                .mapToInt(Integer::intValue)
                .sum();
    }

    private ShmStatus determineHealthStatus(RuleEvaluationResults<ShmRuleViolation> results) {
        return results.isViolated() ? ShmStatus.UNHEALTHY : ShmStatus.HEALTHY;
    }

    private ShmStatus determineHealthStatus(Set<ShmRuleViolation> violations) {
        return violations.isEmpty() ? ShmStatus.HEALTHY : ShmStatus.UNHEALTHY;
    }
}
