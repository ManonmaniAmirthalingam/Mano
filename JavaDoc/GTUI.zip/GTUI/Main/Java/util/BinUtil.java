package com.ebtedge.fns.gateway.util;

import lombok.experimental.UtilityClass;

import java.util.regex.Pattern;

/** Utility class for binary-related operations. */
@UtilityClass
public class BinUtil {

    private static final Pattern CARD_BIN_PATTERN = Pattern.compile("\\d+");

    /**
     * Validates whether the given string represents a valid BIN (Bank Identification Number).
     *
     * @param binNumber the string to be validated as a BIN number
     * @return true if the input string matches the pattern for a valid BIN number, false otherwise
     */
    public static boolean isBinNumber(String binNumber) {
        return CARD_BIN_PATTERN.matcher(binNumber).matches();
    }
}
