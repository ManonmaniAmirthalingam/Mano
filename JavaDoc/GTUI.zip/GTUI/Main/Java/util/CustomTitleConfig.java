package com.ebtedge.fns.gateway.util;

import java.util.Objects;

import software.xdev.vaadin.grid_exporter.format.SpecificConfig;

public class CustomTitleConfig implements SpecificConfig {
    protected String title;
    protected String dateRange; // Add date range field
    protected String generatedDate; // Add generated date field
    protected String searchValues; // Add search values field

    public String getTitle() {
        return this.title;
    }

    public void setTitle(final String title) {
        this.title = Objects.requireNonNull(title);
    }

    public String getDateRange() {
        return this.dateRange;
    }

    public void setDateRange(final String dateRange) {
        this.dateRange = dateRange;
    }

    public String getGeneratedDate() {
        return this.generatedDate;
    }

    public void setGeneratedDate(final String generatedDate) {
        this.generatedDate = generatedDate;
    }

    public String getSearchValues() {
        return this.searchValues;
    }

    public void setSearchValues(final String searchValues) {
        this.searchValues = searchValues;
    }

    public boolean notTitleEmpty() {
        return this.getTitle() != null && !this.getTitle().isBlank();
    }
}