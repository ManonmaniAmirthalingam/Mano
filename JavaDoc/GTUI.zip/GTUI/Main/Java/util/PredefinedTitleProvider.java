package com.ebtedge.fns.gateway.util;

import java.util.List;
import java.util.function.Supplier;

import software.xdev.dynamicreports.jasper.builder.JasperReportBuilder;
import software.xdev.dynamicreports.jasper.builder.export.Exporters;
import software.xdev.dynamicreports.jasper.builder.export.JasperCsvExporterBuilder;
import software.xdev.dynamicreports.jasper.builder.export.JasperHtmlExporterBuilder;
import software.xdev.dynamicreports.jasper.builder.export.JasperPdfExporterBuilder;
import software.xdev.dynamicreports.jasper.builder.export.JasperPptxExporterBuilder;
import software.xdev.dynamicreports.jasper.builder.export.JasperXlsxExporterBuilder;
import software.xdev.dynamicreports.report.builder.DynamicReports;
import software.xdev.dynamicreports.report.builder.component.ComponentBuilder;
import software.xdev.dynamicreports.report.builder.component.Components;
import software.xdev.dynamicreports.report.constant.HorizontalTextAlignment;
import software.xdev.dynamicreports.report.constant.SplitType;
import software.xdev.vaadin.grid_exporter.GridExporterProvider;
import software.xdev.vaadin.grid_exporter.Translator;
import software.xdev.vaadin.grid_exporter.column.ColumnConfiguration;
import software.xdev.vaadin.grid_exporter.format.SpecificConfig;
import software.xdev.vaadin.grid_exporter.grid.GridDataExtractor;
import software.xdev.vaadin.grid_exporter.jasper.config.JasperConfigsLocalization;
import software.xdev.vaadin.grid_exporter.jasper.config.header.HeaderConfigComponent;
import software.xdev.vaadin.grid_exporter.jasper.config.highlight.HighlightConfigComponent;
import software.xdev.vaadin.grid_exporter.jasper.format.AbstractJasperReportFormat;

public class PredefinedTitleProvider extends GridExporterProvider {
	public PredefinedTitleProvider(final String title, final String dateRange, final String generatedDate,
			final String searchValues) {
		super(JasperConfigsLocalization.DEFAULT_VALUES,
				List.of(new PredefinedTitleXlsxFormat(title, dateRange, generatedDate, searchValues),
						new PredefinedTitleCsvFormat(title, dateRange, generatedDate, searchValues),
						new PredefinedTitleTextFormat(title, dateRange, generatedDate, searchValues),
						new PredefinedTitlePptxFormat(title, dateRange, generatedDate, searchValues),
						new PredefinedTitleHtmlFormat(title, dateRange, generatedDate, searchValues)));
	}

	// PDF Format
	public static class PredefinedTitlePdfFormat extends AbstractJasperReportFormat<JasperPdfExporterBuilder> {
		private final String title;
		private final String dateRange;
		private final String generatedDate;
		private final String searchValues;

		public PredefinedTitlePdfFormat(final String title, final String dateRange, final String generatedDate,
				final String searchValues) {
			super("PDF", "pdf", "application/pdf", true, true, JasperReportBuilder::toPdf, Exporters::pdfExporter);
			this.title = title;
			this.dateRange = dateRange;
			this.generatedDate = generatedDate;
			this.searchValues = searchValues;

			this.withConfigComponents(
					translator -> new PreDefinedTitleConfigComponent(translator, title, dateRange, generatedDate,
							searchValues),
					HeaderConfigComponent::new, HighlightConfigComponent::new, CustomPageConfigComponent::new);
		}

		@Override
		protected <T> JasperReportBuilder buildReport(final GridDataExtractor<T> gridDataExtractor,
				final List<ColumnConfiguration<T>> columnsToExport, final List<? extends SpecificConfig> configs) {
			final JasperReportBuilder report = super.buildReport(gridDataExtractor, columnsToExport, configs);

			ComponentBuilder<?, ?> titleList = Components.verticalList(
		            Components.text(this.title)
		                    .setStyle(this.jasperGridReportStyles.titleStyle()
		                            .bold()
		                            .setHorizontalTextAlignment(HorizontalTextAlignment.CENTER)
		                            .setTextAlignment(HorizontalTextAlignment.CENTER, null)
		                            .setFontSize(16)),
		            Components.text(this.dateRange)
		                    .setStyle(this.jasperGridReportStyles.footerStyle()
		                            .setHorizontalTextAlignment(HorizontalTextAlignment.CENTER)
		                            .setTextAlignment(HorizontalTextAlignment.CENTER, null)
		                            .setFontSize(12)),
		            Components.text(this.generatedDate)
		                    .setStyle(this.jasperGridReportStyles.footerStyle()
		                            .setHorizontalTextAlignment(HorizontalTextAlignment.CENTER)
		                            .setTextAlignment(HorizontalTextAlignment.CENTER, null)
		                            .setFontSize(12)),
		            Components.text(this.searchValues)
		                    .setStyle(this.jasperGridReportStyles.footerStyle()
		                            .setHorizontalTextAlignment(HorizontalTextAlignment.CENTER)
		                            .setTextAlignment(HorizontalTextAlignment.CENTER, null)
		                            .setFontSize(12))
		    );
			titleList = titleList.setStyle(DynamicReports.stl.style()
			        .setHorizontalTextAlignment(HorizontalTextAlignment.CENTER)
			        .setPadding(10));			
			report.title(titleList);
			report.setDetailSplitType(SplitType.PREVENT);
			return report;
		}
	}

	// Excel (XLSX) Format
	public static class PredefinedTitleXlsxFormat extends AbstractJasperReportFormat<JasperXlsxExporterBuilder> {
		private final String title;
		private final String dateRange;
		private final String generatedDate;
		private final String searchValues;

		public PredefinedTitleXlsxFormat(final String title, final String dateRange, final String generatedDate,
				final String searchValues) {
			super("Excel", "xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", true, true,
					JasperReportBuilder::toXlsx, Exporters::xlsxExporter);
			this.title = title;
			this.dateRange = dateRange;
			this.generatedDate = generatedDate;
			this.searchValues = searchValues;

			this.withConfigComponents(
					translator -> new PreDefinedTitleConfigComponent(translator, title, dateRange, generatedDate,
							searchValues),
					CustomHeaderConfigComponent::new, HighlightConfigComponent::new, CustomPageConfigComponent::new);
		}

		@Override
		protected <T> JasperReportBuilder buildReport(final GridDataExtractor<T> gridDataExtractor,
				final List<ColumnConfiguration<T>> columnsToExport, final List<? extends SpecificConfig> configs) {
			final JasperReportBuilder report = super.buildReport(gridDataExtractor, columnsToExport, configs);

			report.title(Components.verticalList(
		            Components.text(this.title)
		                    .setStyle(this.jasperGridReportStyles.titleStyle()
		                            .bold()
		                            .setHorizontalTextAlignment(HorizontalTextAlignment.CENTER)
		                            .setFontSize(16)),
		            Components.text(this.dateRange)
		                    .setStyle(this.jasperGridReportStyles.footerStyle()
		                            .setHorizontalTextAlignment(HorizontalTextAlignment.CENTER)
		                            .setFontSize(12)),
		            Components.text(this.generatedDate)
		                    .setStyle(this.jasperGridReportStyles.footerStyle()
		                            .setHorizontalTextAlignment(HorizontalTextAlignment.CENTER)
		                            .setFontSize(12)),
		            Components.text(this.searchValues)
		                    .setStyle(this.jasperGridReportStyles.footerStyle()
		                            .setHorizontalTextAlignment(HorizontalTextAlignment.CENTER)
		                            .setFontSize(12))
		    ));
			
			// We no longer need to add column headers manually here
		    // The CustomHeaderConfigComponent already handles showing headers for Excel
		    // by setting value.setExportHeader(true)
			
		    report.setIgnorePagination(true); // Ensure pagination is disabled for Excel
			return report;
		}
	}

	// CSV Format
	public static class PredefinedTitleCsvFormat extends AbstractJasperReportFormat<JasperCsvExporterBuilder> {
		private final String title;
		private final String dateRange;
		private final String generatedDate;
		private final String searchValues;

		public PredefinedTitleCsvFormat(final String title, final String dateRange, final String generatedDate,
				final String searchValues) {
			super("CSV", "csv", "text/csv", true, true, JasperReportBuilder::toCsv, Exporters::csvExporter);
			this.title = title;
			this.dateRange = dateRange;
			this.generatedDate = generatedDate;
			this.searchValues = searchValues;

			this.withConfigComponents(
					translator -> new PreDefinedTitleConfigComponent(translator, title, dateRange, generatedDate,
							searchValues),
					CustomHeaderConfigComponent::new, HighlightConfigComponent::new, CustomPageConfigComponent::new);
		}

		@Override
		protected <T> JasperReportBuilder buildReport(final GridDataExtractor<T> gridDataExtractor,
				final List<ColumnConfiguration<T>> columnsToExport, final List<? extends SpecificConfig> configs) {
			final JasperReportBuilder report = super.buildReport(gridDataExtractor, columnsToExport, configs);

			report.title(Components.verticalList(
		            Components.text(this.title)
		                    .setStyle(this.jasperGridReportStyles.titleStyle()
		                            .bold()
		                            .setHorizontalTextAlignment(HorizontalTextAlignment.CENTER)
		                            .setFontSize(16)),
		            Components.text(this.dateRange)
		                    .setStyle(this.jasperGridReportStyles.footerStyle()
		                            .setHorizontalTextAlignment(HorizontalTextAlignment.CENTER)
		                            .setFontSize(12)),
		            Components.text(this.generatedDate)
		                    .setStyle(this.jasperGridReportStyles.footerStyle()
		                            .setHorizontalTextAlignment(HorizontalTextAlignment.CENTER)
		                            .setFontSize(12)),
		            Components.text(this.searchValues)
		                    .setStyle(this.jasperGridReportStyles.footerStyle()
		                            .setHorizontalTextAlignment(HorizontalTextAlignment.CENTER)
		                            .setFontSize(12))
		    ));

			// We no longer need to add column headers manually here
		    // The CustomHeaderConfigComponent already handles showing headers for CSV
		    // by setting value.setExportHeader(true)
			
		    report.setIgnorePagination(true); // Ensure pagination is disabled for CSV
			return report;
		}
	}

	
	// PPTX Format
	public static class PredefinedTitlePptxFormat extends AbstractJasperReportFormat<JasperPptxExporterBuilder> {
		private final String title;
		private final String dateRange;
		private final String generatedDate;
		private final String searchValues;

		public PredefinedTitlePptxFormat(final String title, final String dateRange, final String generatedDate,
				final String searchValues) {
			super("PPTX", "pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation", true,
					true, JasperReportBuilder::toPptx, Exporters::pptxExporter);
			this.title = title;
			this.dateRange = dateRange;
			this.generatedDate = generatedDate;
			this.searchValues = searchValues;

			this.withConfigComponents(
					translator -> new PreDefinedTitleConfigComponent(translator, title, dateRange, generatedDate,
							searchValues),
					HeaderConfigComponent::new, HighlightConfigComponent::new, CustomPageConfigComponent::new);
		}

		@Override
		protected <T> JasperReportBuilder buildReport(final GridDataExtractor<T> gridDataExtractor,
				final List<ColumnConfiguration<T>> columnsToExport, final List<? extends SpecificConfig> configs) {
			final JasperReportBuilder report = super.buildReport(gridDataExtractor, columnsToExport, configs);

			report.title(Components.verticalList(
		            Components.text(this.title)
		                    .setStyle(this.jasperGridReportStyles.titleStyle()
		                            .bold()
		                            .setHorizontalTextAlignment(HorizontalTextAlignment.CENTER)
		                            .setFontSize(16)),
		            Components.text(this.dateRange)
		                    .setStyle(this.jasperGridReportStyles.footerStyle()
		                            .setHorizontalTextAlignment(HorizontalTextAlignment.CENTER)
		                            .setFontSize(12)),
		            Components.text(this.generatedDate)
		                    .setStyle(this.jasperGridReportStyles.footerStyle()
		                            .setHorizontalTextAlignment(HorizontalTextAlignment.CENTER)
		                            .setFontSize(12)),
		            Components.text(this.searchValues)
		                    .setStyle(this.jasperGridReportStyles.footerStyle()
		                            .setHorizontalTextAlignment(HorizontalTextAlignment.CENTER)
		                            .setFontSize(12))
		    ));

			return report;
		}
	}

	// HTML Format
	public static class PredefinedTitleHtmlFormat extends AbstractJasperReportFormat<JasperHtmlExporterBuilder> {
		private final String title;
		private final String dateRange;
		private final String generatedDate;
		private final String searchValues;

		public PredefinedTitleHtmlFormat(final String title, final String dateRange, final String generatedDate,
				final String searchValues) {
			super("HTML", "html", "text/html", true, true, JasperReportBuilder::toHtml, Exporters::htmlExporter);
			this.title = title;
			this.dateRange = dateRange;
			this.generatedDate = generatedDate;
			this.searchValues = searchValues;

			this.withConfigComponents(
					translator -> new PreDefinedTitleConfigComponent(translator, title, dateRange, generatedDate,
							searchValues),
					HeaderConfigComponent::new, HighlightConfigComponent::new, CustomPageConfigComponent::new);
		}

		@Override
		protected <T> JasperReportBuilder buildReport(final GridDataExtractor<T> gridDataExtractor,
				final List<ColumnConfiguration<T>> columnsToExport, final List<? extends SpecificConfig> configs) {
			final JasperReportBuilder report = super.buildReport(gridDataExtractor, columnsToExport, configs);

			report.title(Components.verticalList(
		            Components.text(this.title)
		                    .setStyle(this.jasperGridReportStyles.titleStyle()
		                            .bold()
		                            .setHorizontalTextAlignment(HorizontalTextAlignment.CENTER)
		                            .setFontSize(16)),
		            Components.text(this.dateRange)
		                    .setStyle(this.jasperGridReportStyles.footerStyle()
		                            .setHorizontalTextAlignment(HorizontalTextAlignment.CENTER)
		                            .setFontSize(12)),
		            Components.text(this.generatedDate)
		                    .setStyle(this.jasperGridReportStyles.footerStyle()
		                            .setHorizontalTextAlignment(HorizontalTextAlignment.CENTER)
		                            .setFontSize(12)),
		            Components.text(this.searchValues)
		                    .setStyle(this.jasperGridReportStyles.footerStyle()
		                            .setHorizontalTextAlignment(HorizontalTextAlignment.CENTER)
		                            .setFontSize(12))
		    ));

			return report;
		}
	}

	public static class PreDefinedTitleConfigComponent extends CustomTitleConfigComponent {
		private final String title;
		private final String dateRange;
		private final String generatedDate;
		private final String searchValues;

		public PreDefinedTitleConfigComponent(final Translator translator, final String title, final String dateRange,
				final String generatedDate, final String searchValues) {
			super(translator);
			this.title = title;
			this.dateRange = dateRange;
			this.generatedDate = generatedDate;
			this.searchValues = searchValues;
		}

		@Override
		public Supplier<CustomTitleConfig> getNewConfigSupplier() {
			return () -> {
				CustomTitleConfig titleConfig = new CustomTitleConfig();
				titleConfig.setTitle(this.title);
				titleConfig.setDateRange(this.dateRange);
				titleConfig.setGeneratedDate(this.generatedDate);
				titleConfig.setSearchValues(this.searchValues);
				return titleConfig;
			};
		}
	}
}