package com.ebtedge.fns.gateway.util;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.checkbox.Checkbox;

import software.xdev.vaadin.grid_exporter.Translator;
import software.xdev.vaadin.grid_exporter.format.SpecificConfigComponent;
import software.xdev.vaadin.grid_exporter.jasper.config.header.HeaderConfig;

public class CustomHeaderConfigComponent extends SpecificConfigComponent<HeaderConfig> {
	protected final Checkbox chbxExportHeader = new Checkbox();
	private String formatName;

	public CustomHeaderConfigComponent(final Translator translator) {
		this(translator, "", false);
	}
		public CustomHeaderConfigComponent(final Translator translator, String formatName) {
		this(translator, formatName, false);
	}
	
	public CustomHeaderConfigComponent(final Translator translator, String formatName, boolean forceHeader) {
		super(translator, HeaderConfig::new, "");
		this.formatName = formatName != null ? formatName.toUpperCase() : "";
		this.initUI();
		this.registerBindings();
		
		if (forceHeader) {
			this.chbxExportHeader.setValue(true);
			this.chbxExportHeader.setEnabled(false); 
		}
	}
	protected void initUI() {
		// Configure the "Export Header" checkbox
		this.chbxExportHeader.setLabel(this.translate("Export Header"));
		this.chbxExportHeader.setValue(true); // Default to checked
		// Add the checkboxes to the layout
		this.getContent().add(this.chbxExportHeader);
	}

	protected void registerBindings() {
		this.binder.forField(this.chbxExportHeader).bind(HeaderConfig::isExportHeader, HeaderConfig::setExportHeader);
	}
	
	/**
	 * Sets the current format being used for export
	 * @param formatName The name of the format being used
	 */
	public void setFormat(String formatName) {
		if (formatName != null) {
			this.formatName = formatName.toUpperCase();
		}
	}
		@Override
	public void updateFrom(final HeaderConfig value) {
		super.updateFrom(value);
		
		// Get the parent component to find the format we're in
		Component parent = this.getParent().orElse(null);
		if (parent != null && parent.getParent().isPresent()) {
			Component grandparent = parent.getParent().get();
			if (grandparent != null && grandparent.getId().isPresent()) {
				this.formatName = grandparent.getId().get();
			}
		}
		
		if (this.formatName.contains("PDF") || this.formatName.contains("HTML")) {
			value.setExportHeader(true);
			this.chbxExportHeader.setValue(true);
			this.chbxExportHeader.setVisible(true);
		} 
		else {
			this.chbxExportHeader.setVisible(true);
		}
	}
}