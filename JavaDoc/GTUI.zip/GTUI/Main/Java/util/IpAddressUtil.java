package com.ebtedge.fns.gateway.util;

import com.vaadin.flow.server.VaadinRequest;
import com.vaadin.flow.server.VaadinService;

public class IpAddressUtil {

    public static String getIpAddress() {
        VaadinRequest request = VaadinService.getCurrentRequest();
        if (request != null) {
            return request.getRemoteAddr();
        }
        return "127.0.0.1";
    }
}
