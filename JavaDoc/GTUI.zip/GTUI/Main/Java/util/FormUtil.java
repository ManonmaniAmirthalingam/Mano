package com.ebtedge.fns.gateway.util;

import com.ebtedge.fns.gateway.model.*;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.accordion.Accordion;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.data.provider.Query;
import com.vaadin.flow.data.provider.SortDirection;
import com.vaadin.flow.theme.lumo.LumoUtility;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Utility class for All the Form components in the application.
 *
 * @author e3023044
 * @version 1.0.0
 * @since 1.0.0
 */
public class FormUtil {

    /**
     * Initializes an Accordion component for the search layout with a given title and content layout.
     *
     * @param title         the title of the accordion
     * @param contentLayout the content layout to be displayed inside the accordion
     * @return an initialized Accordion component
     */
    public static Accordion initSearchLayoutAccordion(String title, Component contentLayout) {
        Accordion accordion = new Accordion();
        accordion.setMinWidth("100%");
        accordion.addClassNames(LumoUtility.FontSize.MEDIUM, LumoUtility.FontWeight.MEDIUM, LumoUtility.Padding.Left.MEDIUM);
        accordion.add(title, contentLayout);
        return accordion;
    }

    /**
     * Provides Grid sort property names
     *
     * @param query
     * @return List<TranSummaryGridSort>
     */
    public static List<TranSummaryGridSort> getTranSummaryGridSortOrder(Query<FinancialTranVO, Void> query) {
        return query
                .getSortOrders()
                .stream()
                .map(sortOrder -> new TranSummaryGridSort(sortOrder.getSorted(), sortOrder.getDirection().equals(SortDirection.ASCENDING)))
                .collect(Collectors.toList());
    }

    public static List<AlertSummaryGridSort> getAlertSummaryGridSortOrder(Query<AlertSummaryVO, Void> query) {

        return query
                .getSortOrders()
                .stream()
                .map(sortOrder -> new AlertSummaryGridSort(sortOrder.getSorted(), sortOrder.getDirection().equals(SortDirection.ASCENDING)))
                .collect(Collectors.toList());
    }

    /**
     * Provides Grid sort property names
     *
     * @param query
     * @return List<UserActivityGridSort>
     */
    public static List<UserActivityGridSort> getUserActivityGridSortOrder(Query<UserActivityGridVO, Void> query) {
        return query
                .getSortOrders()
                .stream()
                .map(sortOrder -> new UserActivityGridSort(sortOrder.getSorted(), sortOrder.getDirection().equals(SortDirection.ASCENDING)))
                .collect(Collectors.toList());
    }

    public static void initDatePicker(DatePicker datePicker, LocalDate maxDate) {
        datePicker.setRequired(true);
        datePicker.setMin(LocalDate.now().minusDays(30)); // setting min date to 30 days before
        datePicker.setMax(maxDate);
    }
    
    /**
     * Provides Grid sort property names
     *
     * @param query
     * @return List<RedeSummaryGridSort>
     */
    public static List<RedeSummaryGridSort> getRedeSummaryGridSortOrder(Query<RedeGridVO, Void> query) {
        return query
                .getSortOrders()
                .stream()
                .map(sortOrder -> new RedeSummaryGridSort(sortOrder.getSorted(), sortOrder.getDirection().equals(SortDirection.ASCENDING)))
                .collect(Collectors.toList());
    }

    /**
     * This method is used for removing spaces and convert to uppercase.
     * @param input TextField input.
     * @return converted string.
     */
    public static String toUpperCase(String input){
        if(StringUtils.isNotBlank(input)){
            return input.toUpperCase().trim();
        }
        return input;
    }

    /**
     * Provides Grid sort property names
     *
     * @param query
     * @return List<RetailerMapSort>
     */
    public static List<RetailerMapSort> getRetailerMapGridSortOrder(Query<RetailerMapVO, Void> query) {
        return query
                .getSortOrders()
                .stream()
                .map(sortOrder -> new RetailerMapSort(sortOrder.getSorted(), sortOrder.getDirection().equals(SortDirection.ASCENDING)))
                .collect(Collectors.toList());
    }
}
