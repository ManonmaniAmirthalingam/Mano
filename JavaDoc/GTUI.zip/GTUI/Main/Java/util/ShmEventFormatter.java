package com.ebtedge.fns.gateway.util;

import com.ebtedge.fns.gateway.model.ShmAlert;
import com.ebtedge.fns.gateway.service.ShmStateBinService;
import com.ebtedge.fns.gateway.views.monitor.ShmView;
import com.ebtedge.yb.entity.ShmStateBin;
import com.vaadin.flow.spring.annotation.RouteScope;
import com.vaadin.flow.spring.annotation.RouteScopeOwner;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.util.Map;

/**
 * The ShmEventFormatter class is responsible for formatting alert events into HTML string
 * representations based on different templates. It utilizes the provided templates to generate
 * formatted strings that display alert details such as timestamps, trigger ID, entity, message, and
 * additional state or bin-related information.
 */
@Component
@Scope(value = "vaadin-route", proxyMode = ScopedProxyMode.TARGET_CLASS)
@RouteScope
@RouteScopeOwner(ShmView.class)
@RequiredArgsConstructor
public class ShmEventFormatter {

    private static final String ALERT_HTML_TEMPLATE =
            """
        <div>
        <Strong>Timestamp (CST):</Strong> {0}<br/>
        <Strong>Trigger ID</Strong>: {1}<br/>
        <Strong>Entity:</Strong> {2}<br/>
        <Strong>Message:</Strong> {3}<br/>
        </div>"""
                    .stripIndent()
                    .replaceAll("\n", "");
    private static final String STATE_BIN_ALERT_HTML_TEMPLATE =
            """
        <div class="p-m">
        <Strong>Timestamp (CST):</Strong> {0}<br/>
        <Strong>Trigger ID</Strong>: {1}<br/>
        <Strong>State:</Strong> {2}<br/>
        <Strong>BIN:</Strong> {3}<br/>
        <Strong>Message:</Strong> {4}<br/>
        </div>"""
                    .stripIndent()
                    .replaceAll("\n", "");

    private final ShmStateBinService stateBinService;

    /**
     * Formats a given alert entry into an HTML string representation using predefined templates.
     * The output includes timestamps, trigger ID, associated entity, and message details. If the
     * associated entity represents a BIN (Bank Identification Number), additional state information
     * is included.
     *
     * @param alertEntry a {@code Map.Entry} containing a {@code ShmAlert} as the key and an integer
     *     value. The {@code ShmAlert} contains details of the alert to be formatted.
     * @return a formatted HTML string representation of the alert, with timestamps, trigger ID,
     *     entity, message, and possibly state information for BIN entities.
     */
    public String formatHtml(Map.Entry<ShmAlert, Integer> alertEntry) {
        ShmAlert alert = alertEntry.getKey();
        if (BinUtil.isBinNumber(alert.getAlertEntity())) {
            String state =
                    stateBinService
                            .findByBin(alert.getAlertEntity())
                            .map(ShmStateBin::getState)
                            .orElse(StringUtils.EMPTY);
            return MessageFormat.format(
                    STATE_BIN_ALERT_HTML_TEMPLATE,
                    DateTimeConvertors.formatTimestamp(
                            alert.getTimestamp(), DateTimeConvertors.CENTRAL_TIMEZONE),
                    alert.getAlertTriggerId(),
                    state,
                    alert.getAlertEntity(),
                    alert.getAlertMsg());
        }
        return MessageFormat.format(
                ALERT_HTML_TEMPLATE,
                DateTimeConvertors.formatTimestamp(
                        alert.getTimestamp(), DateTimeConvertors.CENTRAL_TIMEZONE),
                alert.getAlertTriggerId(),
                alert.getAlertEntity(),
                alert.getAlertMsg());
    }
}
