package com.ebtedge.fns.gateway.util;

import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.textfield.TextField;

import software.xdev.vaadin.grid_exporter.Translator;
import software.xdev.vaadin.grid_exporter.format.SpecificConfigComponent;
import software.xdev.vaadin.grid_exporter.jasper.config.JasperConfigsLocalization;

public class CustomTitleConfigComponent extends SpecificConfigComponent<CustomTitleConfig> {
    protected final TextField txtTitle = new TextField();
    protected final TextField txtDateRange = new TextField(); // Add date range field
    protected final TextField txtGeneratedDate = new TextField(); // Add generated date field
    protected final TextField txtSearchValues = new TextField(); // Add search values field

    public CustomTitleConfigComponent(final Translator translator) {
        super(translator, CustomTitleConfig::new, JasperConfigsLocalization.TITLE);

        this.initUIs();

        this.registerBindings();
    }

    protected void initUIs() {
        this.txtTitle.setLabel("Title");
        this.txtDateRange.setLabel("Date Range"); // Label for date range
        this.txtGeneratedDate.setLabel("Generated Date"); // Label for generated date
        this.txtSearchValues.setLabel("Search Values"); // Label for search values
        // Set the fields to read-only
        this.txtTitle.setReadOnly(true);
        this.txtDateRange.setReadOnly(true);
        this.txtGeneratedDate.setReadOnly(true);
        this.txtSearchValues.setReadOnly(true);
        // Apply gray color styling to indicate read-only fields
        this.txtTitle.getStyle().set("color", "gray");
        this.txtDateRange.getStyle().set("color", "gray");
        this.txtGeneratedDate.getStyle().set("color", "gray");
        this.txtSearchValues.getStyle().set("color", "gray");
        FormLayout formLayout = new FormLayout();
        formLayout.add(this.txtTitle, this.txtDateRange, this.txtGeneratedDate, this.txtSearchValues);

        // Set responsive layout with two columns
        formLayout.setResponsiveSteps(
            new FormLayout.ResponsiveStep("0", 1), // 1 column for small screens
            new FormLayout.ResponsiveStep("500px", 2) // 2 columns for larger screens
        );

        this.getContent().add(formLayout);
    }

    protected void registerBindings() {
        this.binder.forField(this.txtTitle)
            .bind(CustomTitleConfig::getTitle, CustomTitleConfig::setTitle);

        this.binder.forField(this.txtDateRange)
            .bind(CustomTitleConfig::getDateRange, CustomTitleConfig::setDateRange);

        this.binder.forField(this.txtGeneratedDate)
            .bind(CustomTitleConfig::getGeneratedDate, CustomTitleConfig::setGeneratedDate);

        this.binder.forField(this.txtSearchValues)
            .bind(CustomTitleConfig::getSearchValues, CustomTitleConfig::setSearchValues);
    }
}