package com.ebtedge.fns.gateway.util;

import java.nio.charset.StandardCharsets;
import java.util.List;

import software.xdev.vaadin.grid_exporter.column.ColumnConfiguration;
import software.xdev.vaadin.grid_exporter.format.AbstractFormat;
import software.xdev.vaadin.grid_exporter.format.SpecificConfig;
import software.xdev.vaadin.grid_exporter.grid.GridDataExtractor;

/**
 * Plain Text Format with predefined title.
 * This class provides a way to export Grid data to plain text format with monospaced font and aligned columns.
 * Uses an internal record for efficient data processing.
 */
public class PredefinedTitleTextFormat extends AbstractFormat {
    
    private final PredefinedTitleTextRecord textRecord;
    
    public PredefinedTitleTextFormat(final String title, final String dateRange, final String generatedDate,
            final String searchValues) {
        super("Text", "txt", "application/octet-stream");
        this.textRecord = new PredefinedTitleTextRecord(title, dateRange, generatedDate, searchValues);
    }
    
    @Override
    public <T> byte[] export(
        GridDataExtractor<T> gridDataExtractor,
        List<ColumnConfiguration<T>> columnsToExport,
        List<? extends SpecificConfig> configs) {
        
        return textRecord.export(gridDataExtractor, columnsToExport, configs);
    }
    
    private record PredefinedTitleTextRecord(
        String title,
        String dateRange,
        String generatedDate,
        String searchValues
    ) {
        
        private static final String COLUMN_SEPARATOR = " | ";
        private static final String SEPARATOR_LINE = "-+-";
        
        public PredefinedTitleTextRecord {
        }
        
        public <T> byte[] export(
            GridDataExtractor<T> gridDataExtractor,
            List<ColumnConfiguration<T>> columnsToExport,
            List<? extends SpecificConfig> configs) {
            
            if (columnsToExport.isEmpty()) {
                return new byte[0];
            }
            
            List<List<String>> rowData = gridDataExtractor.getSortedAndFilteredData(columnsToExport);
            int[] maxWidths = calculateMaxWidths(columnsToExport, rowData);
            int maxLineWidth = calculateMaxLineWidth(maxWidths);
            
            int estimatedCapacity = calculateEstimatedCapacity(rowData.size(), maxLineWidth);
            StringBuilder sb = new StringBuilder(estimatedCapacity);
            
            appendTitleSection(sb, maxLineWidth);
            appendTableContent(sb, columnsToExport, rowData, maxWidths);
            
            return sb.toString().getBytes(StandardCharsets.UTF_8);
        }
        
        private static int calculateEstimatedCapacity(int rowCount, int maxLineWidth) {
            return (maxLineWidth + 1) * (4 + 1 + 1 + rowCount) + 100;
        }
        
        private static <T> int[] calculateMaxWidths(List<ColumnConfiguration<T>> columnsToExport, List<List<String>> rowData) {
            int columnCount = columnsToExport.size();
            int[] maxWidths = new int[columnCount];
            
            for (int i = 0; i < columnCount; i++) {
                maxWidths[i] = columnsToExport.get(i).getHeader().length();
            }
            
            int maxColumns = maxWidths.length;
            for (List<String> row : rowData) {
                int rowSize = Math.min(row.size(), maxColumns);
                for (int i = 0; i < rowSize; i++) {
                    String value = row.get(i);
                    if (value != null && value.length() > maxWidths[i]) {
                        maxWidths[i] = value.length();
                    }
                }
            }
            
            return maxWidths;
        }
        
        private void appendTitleSection(StringBuilder sb, int maxWidth) {
            sb.append(centerText(title, maxWidth)).append('\n');
            sb.append(centerText(dateRange, maxWidth)).append('\n');
            sb.append(centerText(generatedDate, maxWidth)).append('\n');
            sb.append(centerText(searchValues, maxWidth)).append("\n\n");
        }
        
        private static <T> void appendTableContent(StringBuilder sb, List<ColumnConfiguration<T>> columnsToExport, 
                                                 List<List<String>> rowData, int[] maxWidths) {
            appendHeaders(sb, columnsToExport, maxWidths);
            appendSeparatorLine(sb, maxWidths);
            appendDataRows(sb, rowData, maxWidths);
        }
        
        private static <T> void appendHeaders(StringBuilder sb, List<ColumnConfiguration<T>> columnsToExport, int[] maxWidths) {
            int lastIndex = columnsToExport.size() - 1;
            for (int i = 0; i < columnsToExport.size(); i++) {
                String header = columnsToExport.get(i).getHeader();
                sb.append(pad(header, maxWidths[i]));
                if (i < lastIndex) {
                    sb.append(COLUMN_SEPARATOR);
                }
            }
            sb.append('\n');
        }
        
        private static void appendSeparatorLine(StringBuilder sb, int[] maxWidths) {
            int lastIndex = maxWidths.length - 1;
            for (int i = 0; i < maxWidths.length; i++) {
                sb.append("-".repeat(maxWidths[i]));
                if (i < lastIndex) {
                    sb.append(SEPARATOR_LINE);
                }
            }
            sb.append('\n');
        }
        
        private static void appendDataRows(StringBuilder sb, List<List<String>> rowData, int[] maxWidths) {
            int lastColumnIndex = maxWidths.length - 1;
            for (List<String> row : rowData) {
                int rowSize = row.size();
                for (int i = 0; i < maxWidths.length; i++) {
                    String value = (i < rowSize) ? row.get(i) : "";
                    sb.append(pad(value, maxWidths[i]));
                    if (i < lastColumnIndex) {
                        sb.append(COLUMN_SEPARATOR);
                    }
                }
                sb.append('\n');
            }
        }
        
        private static int calculateMaxLineWidth(int[] maxWidths) {
            if (maxWidths.length == 0) return 0;
            if (maxWidths.length == 1) return maxWidths[0];
            
            int totalWidth = 0;
            for (int width : maxWidths) {
                totalWidth += width;
            }
            totalWidth += (maxWidths.length - 1) * COLUMN_SEPARATOR.length();
            return totalWidth;
        }
        
        private static String centerText(String text, int width) {
            if (text == null || text.isEmpty()) {
                return "";
            }
            
            int textLength = text.length();
            if (textLength >= width) {
                return text;
            }
            
            int padding = (width - textLength) / 2;
            if (padding == 0) {
                return text;
            }
            
            return " ".repeat(padding) + text;
        }
        
        private static String pad(String value, int width) {
            if (value == null || value.isEmpty()) {
                return " ".repeat(width);
            }
            
            int valueLength = value.length();
            if (valueLength >= width) {
                return value;
            }
            
            if (width - valueLength > 20) {
                return value + " ".repeat(width - valueLength);
            }
            
            return String.format("%-" + width + "s", value);
        }
    }
}
