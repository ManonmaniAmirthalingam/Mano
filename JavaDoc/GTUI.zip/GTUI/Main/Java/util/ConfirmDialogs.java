package com.ebtedge.fns.gateway.util;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.confirmdialog.ConfirmDialog;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import lombok.Builder;
import lombok.Value;

import java.util.function.Supplier;

/**
 * A utility class to handle the creation and management of confirmation dialogs. The class provides
 * methods for opening simple confirmation dialogs with default settings, or customized dialogs with
 * additional components and configurations. This is a non-instantiable class.
 */
public final class ConfirmDialogs {
    private ConfirmDialogs() {
        throw new AssertionError("Utility class should not be instantiated");
    }

    @Value
    @Builder
    public static class DialogConfig {
        @Builder.Default String title = "Confirm";
        @Builder.Default String confirmButtonText = "Yes";
        @Builder.Default String cancelButtonText = "Cancel";
        @Builder.Default boolean closeOnEsc = true;
        @Builder.Default boolean closeOnOutsideClick = false;
    }

    /**
     * Opens a simple confirmation dialog with default settings.
     *
     * @param message The message to display
     * @param onConfirm Action to execute on confirmation
     */
    public static void confirm(String message, Runnable onConfirm) {
        createSimpleDialog(message, onConfirm).open();
    }

    /**
     * Opens a custom confirmation dialog with a component.
     *
     * @param title Dialog title
     * @param content Custom component to display
     * @param onConfirm Confirmation handler returning boolean to indicate if the dialog should
     *     close
     */
    public static void confirmWithComponent(
            String title, Component content, Supplier<Boolean> onConfirm) {
        createCustomDialog(DialogConfig.builder().title(title).build(), content, onConfirm).open();
    }

    private static ConfirmDialog createSimpleDialog(String message, Runnable onConfirm) {
        DialogConfig defaultConfig = DialogConfig.builder().build();
        return new ConfirmDialog(
                defaultConfig.getTitle(),
                message,
                defaultConfig.getConfirmButtonText(),
                event -> onConfirm.run(),
                defaultConfig.getCancelButtonText(),
                (event) -> {});
    }

    private static Dialog createCustomDialog(
            DialogConfig config, Component content, Supplier<Boolean> onConfirm) {
        Dialog dialog = new Dialog();
        configureDialog(dialog, config);

        dialog.add(
                createDialogLayout(
                        config,
                        content,
                        () -> handleConfirmation(dialog, onConfirm),
                        dialog::close));

        return dialog;
    }

    private static void configureDialog(Dialog dialog, DialogConfig config) {
        dialog.setCloseOnEsc(config.isCloseOnEsc());
        dialog.setCloseOnOutsideClick(config.isCloseOnOutsideClick());
    }

    private static Component createDialogLayout(
            DialogConfig config, Component content, Runnable onConfirm, Runnable onCancel) {
        VerticalLayout layout =
                new VerticalLayout(
                        new H2(config.getTitle()),
                        content,
                        createButtonsLayout(config, onConfirm, onCancel));
        layout.setPadding(false);
        layout.setSpacing(true);
        return layout;
    }

    private static Component createButtonsLayout(
            DialogConfig config, Runnable onConfirm, Runnable onCancel) {
        Button confirmButton = new Button(config.getConfirmButtonText(), e -> onConfirm.run());
        confirmButton.addThemeVariants(ButtonVariant.LUMO_PRIMARY);

        Button cancelButton = new Button(config.getCancelButtonText(), e -> onCancel.run());
        cancelButton.addThemeVariants(ButtonVariant.LUMO_TERTIARY);

        HorizontalLayout buttonsLayout = new HorizontalLayout(cancelButton, confirmButton);
        buttonsLayout.setWidthFull();
        buttonsLayout.setJustifyContentMode(FlexComponent.JustifyContentMode.BETWEEN);
        return buttonsLayout;
    }

    private static void handleConfirmation(Dialog dialog, Supplier<Boolean> onConfirm) {
        if (Boolean.TRUE.equals(onConfirm.get())) {
            dialog.close();
        }
    }
}
