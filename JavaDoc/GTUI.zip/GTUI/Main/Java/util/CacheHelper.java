package com.ebtedge.fns.gateway.util;

import lombok.extern.slf4j.Slf4j;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Supplier;

/**
 * Utility class that provides an abstraction for managing a thread-safe, lazily-initialized cache
 * of data with support for refresh and invalidation operations.
 *
 * @param <T> the type of elements the cache will store
 */
@Slf4j
public final class CacheHelper<T> {
    private final AtomicReference<List<T>> cache = new AtomicReference<>();
    private final Supplier<List<T>> dataLoader;
    private final String cacheName;

    private CacheHelper(Supplier<List<T>> dataLoader, String cacheName) {
        this.dataLoader = dataLoader;
        this.cacheName = cacheName;
    }

    /**
     * Creates a new cache helper instance with the specified data loader and cache name. This is
     * the preferred method for constructing CacheHelper instances.
     *
     * @param <T> the type of elements to be cached
     * @param dataLoader supplier function that loads the data when cache needs to be populated
     * @param cacheName identifier for the cache, used in logging
     * @return a new CacheHelper instance
     * @throws NullPointerException if dataLoader or cacheName is null
     */
    public static <T> CacheHelper<T> create(Supplier<List<T>> dataLoader, String cacheName) {
        return new CacheHelper<>(dataLoader, cacheName);
    }

    /**
     * Retrieves the cached data, initializing it if necessary using the data loader. Uses a
     * double-checked locking pattern for thread-safe lazy initialization. Returns an unmodifiable
     * list to prevent external modifications to the cached data.
     *
     * @return an unmodifiable list containing the cached data
     * @throws RuntimeException if the data loader fails to load the data
     */
    public List<T> getCachedData() {
        List<T> currentCache = cache.get();
        if (currentCache == null) {
            synchronized (cache) {
                currentCache = cache.get();
                if (currentCache == null) {
                    log.debug("Initializing cache for: {}", cacheName);
                    currentCache = Collections.unmodifiableList(dataLoader.get());
                    cache.set(currentCache);
                }
            }
        }
        return currentCache;
    }

    /**
     * Forces a refresh of the cached data by invoking the data loader and updating the cache with
     * the new data. The operation is synchronized to ensure thread safety.
     *
     * @throws RuntimeException if the data loader fails to load the data
     */
    public void refreshCache() {
        synchronized (cache) {
            log.debug("Refreshing cache for: {}", cacheName);
            List<T> newData = Collections.unmodifiableList(dataLoader.get());
            cache.set(newData);
        }
    }

    /**
     * Invalidates the current cache by setting it to null. The next call to {@link
     * #getCachedData()} will trigger a reload of the data. The operation is synchronized to ensure
     * thread safety.
     */
    public void invalidateCache() {
        synchronized (cache) {
            log.debug("Invalidating cache for: {}", cacheName);
            cache.set(null);
        }
    }
}
