package com.ebtedge.fns.gateway.util;

import lombok.experimental.UtilityClass;

import java.util.List;
import java.util.Optional;

/**
 * Utility class that provides route URL constants and helper methods for managing and retrieving
 * route URL mappings in a consistent manner.
 */
@UtilityClass
public final class RouteUrls {
    public static final String TRANSACTION_SEARCH = "/transaction/search";
    public static final String ANALYTICS = "/analytics";
    public static final String REDE_SEARCH = "/rede/search";
    public static final String RETAILER_SEARCH = "/retailersearch";
    public static final String ALERTS = "/alerts";
    public static final String SYSTEM_HEALTH = "/system-health";
    public static final String USER_ACTIVITY = "/user-activity";
    public static final String USER_PREFERENCES = "/user-preferences";

    public static final List<String> MAIN_ROUTES =
            List.of(
                    TRANSACTION_SEARCH,
                    ANALYTICS,
                    REDE_SEARCH,
                    RETAILER_SEARCH,
                    ALERTS,
                    SYSTEM_HEALTH,
                    USER_ACTIVITY,
                    USER_PREFERENCES);

    // --- Error pages ---
    public static final String ACCESS_DENIED = "/access-denied";

    public static Optional<String> getRouteUrl(String url) {
        String strippedUrl = removeLeadingSlash(url);
        for (String routeUrl : MAIN_ROUTES) {
            if (strippedUrl.startsWith(removeLeadingSlash(routeUrl))) return Optional.of(routeUrl);
        }
        return Optional.empty();
    }

    public static String removeLeadingSlash(String url) {
        if (url.startsWith("/")) return url.substring(1);
        return url;
    }
}
