package com.ebtedge.fns.gateway.util;

import com.ebtedge.fns.gateway.exception.GatException;
import lombok.extern.slf4j.Slf4j;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;

/**
 * Util class for Date Time formatters.
 *
 * @author e3023044
 * @version 1.0.0
 * @since 1.0.0
 */
@Slf4j
public class DateTimeConvertors {
    public static final ZoneId CENTRAL_TIMEZONE = ZoneId.of("America/Chicago");
    private static final String YB_DATE_FORMAT = "yyyyMMddHHmm";
    private static final String UI_OUTPUT_TIMESTAMP_FORMAT = "MM/dd/yyyy HH:mm:ss";
    private static final String SQL_FUNCTION_RESP_TIMESTAMP_FORMAT = "MMddyyyyHHmmss";
    private static final String USER_ACTIVITY_SQL_FUNCTION_RESP_TIMESTAMP_FORMAT = "yyyyMMddHHmmss";
    private static final String USER_ACTIVITY_UI_OUTPUT_TIMESTAMP_FORMAT = "MM/dd/yyyy HH:mm";

    private static final DateTimeFormatter UI_DATE_TIME_FORMATTER =
            DateTimeFormatter.ofPattern(UI_OUTPUT_TIMESTAMP_FORMAT);

    private static final DateTimeFormatter SQL_FUNCTION_DATE_TIME_FORMATTER =
            DateTimeFormatter.ofPattern(YB_DATE_FORMAT);

    private static final DateTimeFormatter SQL_FUNCTION_DATE_TIME_FORMATTER_FULL =
            DateTimeFormatter.ofPattern(USER_ACTIVITY_SQL_FUNCTION_RESP_TIMESTAMP_FORMAT);

    /**
     * Converts LocalDateTime to YB DB specific format for performing search
     *
     * @return string in yyyyMMddHHmm format
     */
    public static String formatLocalDateToDbTimestamp(LocalDateTime localDate) {
        try {
            return SQL_FUNCTION_DATE_TIME_FORMATTER.format(localDate);
        } catch (Exception e) {
            log.error("Error while formating date: {} {} ", localDate.toString(), e);
            throw new GatException("Error formatting date");
        }
    }

    public static String toDbTimestampFull(LocalDateTime localDateTime) {
        try {
            return SQL_FUNCTION_DATE_TIME_FORMATTER_FULL.format(localDateTime);
        } catch (Exception e) {
            log.error("Error while formating date: {} {} ", localDateTime, e);
            throw new GatException("Error formatting date");
        }
    }

    /**
     * Convert from MMddyyyyHHmmss to yyyy-MM-dd HH:mm:ss
     *
     * @param input in MMddyyyyHHmmss format
     * @return string in yyyy-MM-dd HH:mm:ss format
     */
    public static String formatDBTimestamp(String input) {
        DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern(SQL_FUNCTION_RESP_TIMESTAMP_FORMAT);
        DateTimeFormatter output = DateTimeFormatter.ofPattern(UI_OUTPUT_TIMESTAMP_FORMAT);
        try {
            TemporalAccessor parsed = inputFormatter.parse(input);
            return output.format(parsed);
        } catch (Exception e) {
            log.error("Error while formating date: {} {} ", input, e);
            throw new GatException("Error formatting date");
        }
    }

    /**
     * Convert from yyyyMMddHHmmss to MM/dd/yyyy HH:mm
     *
     * @param input in yyyyMMddHHmmss or yyyyMMddHHmm format
     * @return string in MM/dd/yyyy HH:mm format
     */
    public static String formatUserActivityDBTimestamp(String input) {
        DateTimeFormatter inputFormatter;
        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern(USER_ACTIVITY_UI_OUTPUT_TIMESTAMP_FORMAT);

        // Determine the input format based on the length of the input string
        if (input.length() == 14) {
            inputFormatter = DateTimeFormatter.ofPattern(USER_ACTIVITY_SQL_FUNCTION_RESP_TIMESTAMP_FORMAT);
        } else if (input.length() == 12) {
            inputFormatter = DateTimeFormatter.ofPattern(YB_DATE_FORMAT);
        } else {
            throw new IllegalArgumentException("Invalid date format. Expected yyyyMMddHHmmss or yyyyMMddHHmm.");
        }

        try {
            TemporalAccessor parsedDate = inputFormatter.parse(input);
            return outputFormatter.format(parsedDate);
        } catch (Exception e) {
            log.error("Error while formating date: {} {} ", input, e);
            throw new GatException("Error formatting date");
        }
    }

    public static LocalDateTime parseYBTimestamp(String input) {
        DateTimeFormatter inputFormatter =
                DateTimeFormatter.ofPattern(SQL_FUNCTION_RESP_TIMESTAMP_FORMAT);
        try {
            return LocalDateTime.parse(input, inputFormatter);
        } catch (Exception e) {
            log.error("Error while parsing date: {}", input, e);
            throw new GatException("Error parsing date");
        }
    }

    public static String formatTimestamp(Instant timestamp, ZoneId zoneId) {
        return UI_DATE_TIME_FORMATTER.format(timestamp.atZone(zoneId));
    }
}
