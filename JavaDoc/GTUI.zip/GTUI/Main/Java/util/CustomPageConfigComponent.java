package com.ebtedge.fns.gateway.util;

import java.util.List;

import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.textfield.IntegerField;

import software.xdev.dynamicreports.report.constant.PageOrientation;
import software.xdev.dynamicreports.report.constant.PageType;
import software.xdev.vaadin.grid_exporter.Translator;
import software.xdev.vaadin.grid_exporter.format.SpecificConfigComponent;
import software.xdev.vaadin.grid_exporter.jasper.config.JasperConfigsLocalization;
import software.xdev.vaadin.grid_exporter.jasper.config.page.PageConfig;

public class CustomPageConfigComponent extends SpecificConfigComponent<PageConfig> {
    protected final ComboBox<PageType> cbPageType = new ComboBox<>();
    protected final ComboBox<PageOrientation> cbPageOrientation = new ComboBox<>();
    protected final Checkbox chbxPageNumbering = new Checkbox();
    protected final IntegerField intfPageMargin = new IntegerField();

    public CustomPageConfigComponent(final Translator translator) {
        super(translator, PageConfig::new, JasperConfigsLocalization.PAGE);

        this.initUIs();
        this.registerBindings();
    }

    protected void initUIs() {
        this.cbPageType.setLabel(this.translate(JasperConfigsLocalization.FORMAT_PAGE_TYPE));
        this.cbPageType.setItemLabelGenerator(PageType::name);

        this.cbPageOrientation.setLabel(this.translate(JasperConfigsLocalization.ORIENTATION));
        this.cbPageOrientation.setItemLabelGenerator(po ->
            this.translate(JasperConfigsLocalization.ORIENTATION + "." + po.name().toLowerCase()));

        this.chbxPageNumbering.setLabel(this.translate(JasperConfigsLocalization.SHOW_PAGE_NUMBERS));

        this.intfPageMargin.setLabel(this.translate(JasperConfigsLocalization.MARGIN));
        this.intfPageMargin.setStepButtonsVisible(true);
        this.intfPageMargin.setMin(PageConfig.PAGE_MARGIN_MIN);
        this.intfPageMargin.setMax(PageConfig.PAGE_MARGIN_MAX);

        this.getContent().add(this.cbPageType, this.cbPageOrientation, this.chbxPageNumbering, this.intfPageMargin);
    }

    protected void registerBindings() {
        this.binder.forField(this.cbPageType)
            .asRequired()
            .bind(PageConfig::getSelectedPageType, PageConfig::setSelectedPageType);

        this.binder.forField(this.cbPageOrientation)
            .asRequired()
            .bind(PageConfig::getSelectedPageOrientation, PageConfig::setSelectedPageOrientation);

        this.binder.forField(this.chbxPageNumbering)
            .bind(PageConfig::isUsePageNumbering, PageConfig::setUsePageNumbering);

        this.binder.forField(this.intfPageMargin)
            .asRequired()
            .bind(PageConfig::getPageMargin, PageConfig::setPageMargin);
    }
    @Override
    public void updateFrom(final PageConfig value) {
        // Filter the available PageType values to include only the desired formats
        List<PageType> allowedPageTypes = value.getAvailablePageTypes().stream()
            .filter(pageType -> 
                                pageType == PageType.ARCH_E || 
                                pageType == PageType.ARCH_D ||
                                pageType == PageType.B0 || 
                                pageType == PageType.B1 || 
                                pageType == PageType.B2 ||
                                pageType == PageType.C0 || 
                                pageType == PageType.C1 
                                )
            .toList();

        // Set the filtered PageType values in the ComboBox
        this.cbPageType.setItems(allowedPageTypes);

        // Set the available PageOrientation values
        this.cbPageOrientation.setItems(value.getAvailablePageOrientations());

        // Set default PageType to C0 if available
        if (allowedPageTypes.contains(PageType.ARCH_E)) {
            value.setSelectedPageType(PageType.ARCH_E);
        }

        super.updateFrom(value);
    }
}