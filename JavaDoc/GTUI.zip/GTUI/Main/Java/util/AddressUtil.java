package com.ebtedge.fns.gateway.util;

import com.ebtedge.fns.gateway.service.AddressExtractService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

/** A utility for address. */
@Slf4j
@Component
public class AddressUtil {

    private static AddressExtractService addressExtractService;

    private AddressUtil(@Autowired AddressExtractService addressExtractService) {
        AddressUtil.addressExtractService = addressExtractService;
    }

    /**
     * Method for getting name part of a street.
     *
     * @param address the street address
     * @return optional name of the street
     */
    public static Optional<String> getStreetName(String address) {
        return addressExtractService.extractStreetName(address);
    }

    /**
     * Method for getting number part of a street.
     *
     * @param address the street address
     * @return optional number of the street
     */
    public static Optional<String> getStreetNumber(String address) {
        return addressExtractService.extractStreetNumber(address);
    }
}
