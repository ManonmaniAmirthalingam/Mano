package com.ebtedge.fns.gateway.util;

import com.ebtedge.fns.gateway.domain.UserInfo;
import com.vaadin.flow.server.VaadinRequest;
import com.vaadin.flow.server.VaadinSession;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SessionUtil {

    public static UserInfo getUserInfo() {
        VaadinSession vaadinSession = VaadinSession.getCurrent();
        if (vaadinSession != null) {
            Object userInfo = VaadinSession.getCurrent().getAttribute("userInfo");
            if (userInfo != null) {
                UserInfo user = (UserInfo) userInfo;
                return user;
            }
        }
        return null;
    }

    public static String getUserId() {
        VaadinSession vaadinSession = VaadinSession.getCurrent();
        if (vaadinSession != null) {
            Object userInfo = VaadinSession.getCurrent().getAttribute("userInfo");
            if (userInfo != null) {
                UserInfo user = (UserInfo) userInfo;
                return user.getUserId();
            }
        }
        return "NotFound";
    }

    public static String getFirstName() {
        VaadinSession vaadinSession = VaadinSession.getCurrent();
        if (vaadinSession != null) {
            Object userInfo = VaadinSession.getCurrent().getAttribute("userInfo");
            if (userInfo != null) {
                UserInfo user = (UserInfo) userInfo;
                return user.getFirstName();
            }
        }
        return "NotFound";
    }


    public static String getLastName() {
        VaadinSession vaadinSession = VaadinSession.getCurrent();
        if (vaadinSession != null) {
            Object userInfo = VaadinSession.getCurrent().getAttribute("userInfo");
            if (userInfo != null) {
                UserInfo user = (UserInfo) userInfo;
                return user.getLastName();
            }
        }
        return "NotFound";
    }

    public static String getMiddleName() {
        VaadinSession vaadinSession = VaadinSession.getCurrent();
        if (vaadinSession != null) {
            Object userInfo = VaadinSession.getCurrent().getAttribute("userInfo");
            if (userInfo != null) {
                UserInfo user = (UserInfo) userInfo;
                return user.getMiddleName();
            }
        }
        return "NotFound";
    }

    public static String getEmail() {
        VaadinSession vaadinSession = VaadinSession.getCurrent();
        if (vaadinSession != null) {
            Object userInfo = VaadinSession.getCurrent().getAttribute("userInfo");
            if (userInfo != null) {
                UserInfo user = (UserInfo) userInfo;
                return user.getEmail();
            }
        }
        return "NotFound";
    }
    
    public static String getPhoneNumber()
    {
    	VaadinSession vaadinSession = VaadinSession.getCurrent();
        if (vaadinSession != null) {
            Object userInfo = VaadinSession.getCurrent().getAttribute("userInfo");
            if (userInfo != null) {
                UserInfo user = (UserInfo) userInfo;
                return user.getPhoneNumber();
            }
        }
        return "NotFound";
    }

    /**
     * check if session is present or not.
     *
     * @return true if session is present and false if not.
     */
    public static boolean isSessionValid() {
        VaadinSession vaadinSession = VaadinSession.getCurrent();
        if (vaadinSession != null && vaadinSession.getAttribute("userInfo") != null) {
            return true;
        }
        log.error("Session is not present, hence logging out");
        return false;
    }

    /**
     * Invalidate the current session.
     */
    public static void invalidateSession() {
        VaadinRequest request = VaadinRequest.getCurrent();
        if (request != null) {
            request.getWrappedSession().invalidate(); // Invalidate the HTTP session
            log.error("Session invalidated successfully.");
        } else {
            log.warn("VaadinRequest is null. Unable to invalidate session.");
        }
    }
}