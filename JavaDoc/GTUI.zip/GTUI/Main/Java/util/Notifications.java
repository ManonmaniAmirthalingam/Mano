package com.ebtedge.fns.gateway.util;

import com.ebtedge.fns.gateway.config.NotificationProperties;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.notification.Notification.Position;
import com.vaadin.flow.component.notification.NotificationVariant;

import lombok.experimental.UtilityClass;

import org.springframework.util.Assert;

/**
 * Utility class for displaying notifications in the Vaadin UI.
 * Provides a centralized way to show various types of notifications with configurable duration and position.
 *
 * <p>This class must be initialized with {@link #init(NotificationProperties)} before use,
 * typically done by {@link com.ebtedge.fns.gateway.initializers.NotificationsInitializer}
 * during application startup.</p>
 */
@UtilityClass
public class Notifications {

    /**
     * Display duration for notifications in milliseconds.
     */
    private int displayDuration;

    /**
     * Position for notifications on the screen.
     */
    private Position position;

    /**
     * Initializes the notification system with the specified properties.
     *
     * @param properties configuration properties for notifications
     */
    public void init(NotificationProperties properties) {
        Assert.notNull(properties, "Notification properties must not be null");
        Notifications.displayDuration = properties.getDisplayDuration();
        Notifications.position = properties.getPosition();
    }

    /**
     * Shows a notification with the default duration and position.
     *
     * @param message  the message to display
     * @param variants optional theme variants to apply to the notification
     */
    public void show(String message, NotificationVariant... variants) {
        show(message, displayDuration, position, variants);
    }

    /**
     * Shows an error notification with the default duration and position.
     * The notification will be styled with the error theme variant.
     *
     * @param message the error message to display
     */
    public void showError(String message) {
        show(message, displayDuration, position, NotificationVariant.LUMO_ERROR);
    }

    /**
     * Creates a notification with custom duration and position.
     *
     * @param message   the message to display
     * @param variants  optional theme variants to apply to the notification
     * @return a Notification instance
     */
    public Notification create(String message, NotificationVariant... variants) {
        return create(message, displayDuration, position, variants);
    }

    /**
     * Creates a notification with custom duration and position.
     *
     * @param message   the message to display
     * @param duration  how long the notification should be visible, in milliseconds
     * @param position  where on the screen the notification should be shown
     * @param variants  optional theme variants to apply to the notification
     * @return a Notification instance
     */
    private Notification create(String message, int duration, Position position, NotificationVariant... variants) {
        Notification notification = new Notification(message, duration, position);
        notification.addThemeVariants(variants);
        return notification;
    }

    /**
     * Shows a notification with custom duration and position.
     *
     * @param message   the message to display
     * @param duration  how long the notification should be visible, in milliseconds
     * @param position  where on the screen the notification should be shown
     * @param variants  optional theme variants to apply to the notification
     */
    private void show(String message, int duration, Position position, NotificationVariant... variants) {
        create(message, duration, position, variants).open();
    }
}