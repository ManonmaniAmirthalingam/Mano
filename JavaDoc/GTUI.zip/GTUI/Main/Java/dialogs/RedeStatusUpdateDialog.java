package com.ebtedge.fns.gateway.dialogs;

import java.util.List;
import java.util.stream.Collectors;

import com.ebtedge.fns.gateway.model.RedeGridVO;
import com.ebtedge.fns.gateway.model.RedeStatusUpdateRequest;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.H3;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.shared.Registration;

/**
 * Dialog for updating REDE status
 */
public class RedeStatusUpdateDialog extends Dialog {
	private final ComboBox<String> statusComboBox = new ComboBox<>("New Status");
	private final Button saveButton = new Button("Save");
	private final Button cancelButton = new Button("Cancel");
	private final RedeGridVO redeGridVO;
	private final String originalStatus;

	public RedeStatusUpdateDialog(RedeGridVO redeGridVO, List<String> statusOptions) {
		this.redeGridVO = redeGridVO;
		this.originalStatus = redeGridVO.getStatus() != null ? redeGridVO.getStatus().trim() : "";
		setCloseOnEsc(true);
		setCloseOnOutsideClick(false);
		setWidth("550px");
		setDraggable(true);
		setResizable(false);
		addClassName("rede-status-update-dialog");
		VerticalLayout layout = new VerticalLayout();
		layout.setAlignItems(FlexComponent.Alignment.STRETCH);
		layout.setJustifyContentMode(FlexComponent.JustifyContentMode.BETWEEN);
		layout.setSpacing(true);
		layout.setPadding(false);
		layout.add(createHeaderLayout());
		layout.add(createFormLayout(statusOptions));
		layout.add(createButtonLayout());
		add(layout);
	}	
	
	private Component createHeaderLayout() {
		H3 title = new H3("Update REDE Status");
		title.addClassName("rede-status-update-dialog-title");
		VerticalLayout layout = new VerticalLayout(title);
		layout.setPadding(false);
		layout.setSpacing(false);
		layout.setAlignItems(FlexComponent.Alignment.CENTER);
		return layout;
	}

	private Component createFormLayout(List<String> statusOptions) {
		VerticalLayout layout = new VerticalLayout();
		layout.setPadding(false);
		layout.setSpacing(true);
		VerticalLayout recordInfoContainer = new VerticalLayout();
		recordInfoContainer.addClassName("rede-status-update-info-container");
		recordInfoContainer.setPadding(false);
		recordInfoContainer.setSpacing(false);
		recordInfoContainer.add(createInfoField("Terminal ID", redeGridVO.getTerminal_id()));
		recordInfoContainer.add(createInfoField("FNS Number", redeGridVO.getFns_number()));
		recordInfoContainer.add(
	    createInfoField("Current Status", redeGridVO.getStatus() != null ? redeGridVO.getStatus() : "New"));
		VerticalLayout comboContainer = new VerticalLayout();
		comboContainer.addClassName("rede-status-update-combo-container");
		comboContainer.setPadding(false);
		comboContainer.setSpacing(false);
		Span comboLabel = new Span("Select New Status:");
		comboLabel.addClassName("rede-status-update-combo-label");
		List<String> trimmedStatusOptions = statusOptions.stream().map(String::trim).collect(Collectors.toList());
		statusComboBox.setItems(trimmedStatusOptions);
		statusComboBox.setWidth("100%");
		statusComboBox.setValue(redeGridVO.getStatus() != null ? redeGridVO.getStatus().trim() : null);
		statusComboBox.setPlaceholder("Choose a status");
		statusComboBox.addClassName("rede-status-combo");

		statusComboBox.addValueChangeListener(event -> {
			String selectedStatus = event.getValue();
			boolean hasChanged = selectedStatus != null && !selectedStatus.equals(originalStatus);
			saveButton.setEnabled(hasChanged);
			if (hasChanged) {
				saveButton.removeThemeName("disabled-button");
			} else {
				saveButton.addThemeName("disabled-button");
			}
		});
		
		comboContainer.add(comboLabel, statusComboBox);
		layout.add(recordInfoContainer);
		layout.add(comboContainer);
		return layout;
	}

	private Component createInfoField(String label, String value) {
		HorizontalLayout layout = new HorizontalLayout();
		layout.addClassName("rede-status-update-info-field");
		layout.setWidthFull();
		Span labelSpan = new Span(label + ":");
		labelSpan.addClassName("rede-status-update-info-label");
		Span valueSpan = new Span(value);
		valueSpan.addClassName("rede-status-update-info-value");
		layout.add(labelSpan, valueSpan);
		layout.setAlignItems(FlexComponent.Alignment.CENTER);
		return layout;
	}

	private Component createButtonLayout() {
		HorizontalLayout buttonLayout = new HorizontalLayout();
		buttonLayout.addClassName("rede-status-update-buttons");
		buttonLayout.setJustifyContentMode(FlexComponent.JustifyContentMode.END);
		saveButton.setIcon(new Icon(VaadinIcon.CHECK_CIRCLE));
		saveButton.addThemeName("search-button");
		saveButton.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
		saveButton.getStyle().set("font-weight", "bold");
		saveButton.setEnabled(false);
		saveButton.addThemeName("disabled-button");
		
		saveButton.addClickListener(e -> {
			String newStatus = statusComboBox.getValue();
			if (newStatus != null && !newStatus.isEmpty() && !newStatus.equals(originalStatus)) {
				RedeStatusUpdateRequest request = RedeStatusUpdateRequest.builder()
						.fnsNumber(redeGridVO.getFns_number())
						.terminalId(redeGridVO.getTerminal_id())
						.status(newStatus)
						.build();
				fireEvent(new SaveEvent(this, request));
				close();
			}
		});
		cancelButton.setIcon(new Icon(VaadinIcon.CLOSE_CIRCLE));
		cancelButton.addThemeName("reset-button");
		cancelButton.getStyle().set("font-weight", "bold");
		cancelButton.addClickListener(e -> {
			close();
		});

		buttonLayout.add(saveButton, cancelButton);
		return buttonLayout;
	}

	public static abstract class RedeStatusDialogEvent extends ComponentEvent<RedeStatusUpdateDialog> {
		private RedeStatusUpdateRequest request;

		protected RedeStatusDialogEvent(RedeStatusUpdateDialog source, RedeStatusUpdateRequest request) {
			super(source, false);
			this.request = request;
		}

		public RedeStatusUpdateRequest getRequest() {
			return request;
		}
	}

	public static class SaveEvent extends RedeStatusDialogEvent {
		SaveEvent(RedeStatusUpdateDialog source, RedeStatusUpdateRequest request) {
			super(source, request);
		}
	}

	public Registration addSaveListener(ComponentEventListener<SaveEvent> listener) {
		return addListener(SaveEvent.class, listener);
	}
}
