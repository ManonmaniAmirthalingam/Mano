package com.ebtedge.fns.gateway.initializers;

import com.ebtedge.fns.gateway.model.UserActivityGridVO;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.data.renderer.LitRenderer;
import lombok.extern.slf4j.Slf4j;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
public class UserActivityGridInitializer {

    /**
     * Initializes User Activity grid with {@link UserActivityGridVO}
     *
     * @param grid
     */
    public static void initializeGrid(Grid<UserActivityGridVO> grid) {
        setGridEmptyState(grid);

        grid.addColumn(UserActivityGridVO::getRownumbers).setHeader("Row #").setAutoWidth(true);

        grid.addColumn(UserActivityGridVO::getUserActivityTimestamp).setHeader("Activity Timestamp (Central Time Zone)")
                .setAutoWidth(true).setSortable(true).setSortProperty("event_ts")
                .setHeaderPartName("grid-timestamp-header")
                .setPartNameGenerator(item -> "grid-timestamp-type");

        grid.addColumn(UserActivityGridVO::getUserActivity).setHeader("Activity")
                .setSortable(true).setSortProperty("event_desc")
                .setHeaderPartName("grid-activity-type-header")
                .setPartNameGenerator(item -> "grid-activity-type");

        grid.addColumn(UserActivityGridInitializer::formatUserActivityDetails).setHeader("Activity Details")
                .setHeaderPartName("grid-activity-desc-header")
                .setPartNameGenerator(item -> "grid-activity-desc-type");

        grid.addColumn(UserActivityGridVO::getFirstName).setHeader("First Name")
                .setAutoWidth(true).setSortable(true).setSortProperty("first_name")
                .setHeaderPartName("grid-activity-fn-header")
                .setPartNameGenerator(item -> "grid-activity-fn");

        grid.addColumn(UserActivityGridVO::getMiddleName).setHeader("Middle Name")
                .setAutoWidth(true).setSortable(true).setSortProperty("middle_name")
                .setHeaderPartName("grid-activity-mn-header")
                .setPartNameGenerator(item -> "grid-activity-mn");

        grid.addColumn(UserActivityGridVO::getLastName).setHeader("Last Name")
                .setAutoWidth(true).setSortable(true).setSortProperty("last_name")
                .setHeaderPartName("grid-activity-ln-header")
                .setPartNameGenerator(item -> "grid-activity-ln");

        grid.addColumn(UserActivityGridVO::getUserId).setHeader("User ID")
                .setAutoWidth(true).setSortable(true).setSortProperty("user_id")
                .setHeaderPartName("grid-activity-user-id-header")
                .setPartNameGenerator(item -> "grid-activity-user-id");

        grid.addColumn(UserActivityGridVO::getEmailAddress).setHeader("Email Address")
                .setAutoWidth(true).setSortable(true).setSortProperty("email")
                .setHeaderPartName("grid-activity-email-header")
                .setPartNameGenerator(item -> "grid-activity-email");

        grid.setVisible(false);
        grid.addThemeVariants(GridVariant.LUMO_ROW_STRIPES);
        grid.setSizeFull();
    }

    /**
     * Formats user activity details by skipping null values.
     *
     * @param userActivityGridVO the user activity object
     * @return formatted string of user activity details
     */
    private static String formatUserActivityDetails(UserActivityGridVO userActivityGridVO) {
        Map<String, String> details = new LinkedHashMap<>();
        if (userActivityGridVO.getPayload() != null) {
            details.put("Date Range", (userActivityGridVO.getPayload().getStartTs() != null ? userActivityGridVO.getPayload().getStartTs() : "") +
                    (!userActivityGridVO.getPayload().getStartTs().isEmpty() && !userActivityGridVO.getPayload().getEndTs().isEmpty() ? " - " : "") +
                    (userActivityGridVO.getPayload().getEndTs() != null ? userActivityGridVO.getPayload().getEndTs() : ""));
            //TODO: As future enhancements, uncomment below to show all fields
//            details.put("State", userActivityGridVO.getPayload().getState());
//            details.put("Agency", userActivityGridVO.getPayload().getAgency());
//
//            details.put("Card", userActivityGridVO.getPayload().getCardnumber());
//            details.put("FNS", userActivityGridVO.getPayload().getFnsnumber());
//            details.put("Store", userActivityGridVO.getPayload().getStoretype());
//            details.put("Terminal", userActivityGridVO.getPayload().getTerminalid());
//            details.put("Card Acceptor", userActivityGridVO.getPayload().getCardaccptrname());
//            details.put("Type", userActivityGridVO.getPayload().getTrnsctntype());
//            details.put("Amount", userActivityGridVO.getPayload().getTrnsctn_amount_from() + "-" + userActivityGridVO.getPayload().getTrnsctn_amount_to());
//            details.put("IP", userActivityGridVO.getPayload().getIpAddress());
//            details.put("User Id", userActivityGridVO.getPayload().getAppUserId());

            return details.entrySet().stream()
                    .filter(entry -> entry.getValue() != null && !entry.getValue().isEmpty())
                    .map(entry -> entry.getKey() + ": " + entry.getValue())
                    .collect(Collectors.joining(", "));
        } else {
            return "No data available";
        }
    }

    /**
     * Initializes grid empty state
     *
     * @param grid
     */
    //TODO: Move this to common place to reuse
    private static void setGridEmptyState(Grid<UserActivityGridVO> grid) {
        Div emptyGrid = new Div();
        emptyGrid.add("***** No data found for the given search criteria *****");
        emptyGrid.addClassNames("empty-grid");
        grid.setEmptyStateComponent(emptyGrid);
    }
}
