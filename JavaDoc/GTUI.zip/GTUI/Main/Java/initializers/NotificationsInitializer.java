package com.ebtedge.fns.gateway.initializers;

import com.ebtedge.fns.gateway.config.GatAppConfig;
import com.ebtedge.fns.gateway.util.Notifications;
import org.springframework.stereotype.Component;

/**
 * Spring component responsible for initializing the application's notification system.
 * This initializer is automatically created during application startup and configures
 * the global notification settings using the application configuration.
 *
 * <p>The initialization is performed once during component creation through its constructor,
 * ensuring that notification settings are properly configured before any notifications
 * are displayed in the application.</p>
 *
 * @see com.ebtedge.fns.gateway.util.Notifications
 * @see com.ebtedge.fns.gateway.config.GatAppConfig
 */
@Component
public class NotificationsInitializer {

    /**
     * Creates a new NotificationsInitializer and initializes the notification system.
     *
     * @param appConfig The application configuration containing notification settings.
     *                  This parameter is automatically injected by Spring.
     */
    public NotificationsInitializer(GatAppConfig appConfig) {
        Notifications.init(appConfig.getNotification());
    }
}