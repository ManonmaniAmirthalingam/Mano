package com.ebtedge.fns.gateway.initializers;

import org.apache.commons.lang3.StringUtils;

import com.ebtedge.fns.gateway.config.TppDescMappingConfig;
import com.ebtedge.fns.gateway.model.FinancialTranVO;
import com.vaadin.flow.component.grid.ColumnTextAlign;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.data.renderer.LitRenderer;

/**
 * Simple class for keeping all the code related to grid initialization.
 *
 * @author e3023044
 * @version 1.0.0
 * @since 1.0.0
 */
public class TranSearchGridInitializer {

    /**
     * Initializes Transaction Search grid with {@link FinancialTranVO}
     *
     * @param grid
     */
    public static void initializeGrid(Grid<FinancialTranVO> grid,TppDescMappingConfig tppDescMappingConfig) {
        setGridEmptyState(grid);
        grid.addColumn(FinancialTranVO::getRownumbers)
                .setHeader("Row #")
                .setAutoWidth(true);
        grid.addColumn(FinancialTranVO::getTranTs)
                .setHeader("Tran Timestamp")
                .setAutoWidth(true)
                .setSortProperty("state_ts")
                .setSortable(true);
        grid.addColumn(FinancialTranVO::getTranTypeCode)
                .setHeader("Tran Type")
                .setSortable(true)
                .setSortProperty("processing_code")
                .setTooltipGenerator(financialTranVO -> financialTranVO.getTranTypeDesc().trim())
                .setHeaderPartName("grid-tran-type-header")
                .setPartNameGenerator(item -> "grid-tran-type");
        grid.addColumn(FinancialTranVO::getTranAmount)
                .setHeader("Tran Amount")
                .setSortable(true)
                .setSortProperty("transaction_amount")
                .setHeaderPartName("grid-tran-amount-header")
                .setTextAlign(ColumnTextAlign.END)
                .setPartNameGenerator(item -> "grid-tran-amount");
        grid.addColumn(FinancialTranVO::getCardNumber)
                .setHeader("Card #")
                .setAutoWidth(true)
                .setSortProperty("card_number")
                .setSortable(true)
                .setHeaderPartName("grid-card-header")
                .setPartNameGenerator(item -> "grid-card");
        grid.addColumn(FinancialTranVO::getTerminalId)
                .setHeader("Terminal ID #")
                .setAutoWidth(true)
                .setSortable(true)
                .setSortProperty("terminal_id")
                .setHeaderPartName("grid-terminal-id-header")
                .setPartNameGenerator(item -> "grid-terminal-id");
        grid.addColumn(FinancialTranVO::getFnsNumber)
                .setHeader("FNS #")
                .setAutoWidth(true)
                .setSortable(true)
                .setSortProperty("fns_number")
                .setHeaderPartName("grid-fns-number-header")
                .setPartNameGenerator(item -> "grid-fns-number");
        grid.addColumn(FinancialTranVO::getMerchantName)
                .setHeader("Merchant Name")
                .setAutoWidth(true)
                .setSortable(true)
                .setSortProperty("card_acceptor_name")
                .setHeaderPartName("grid-merchant-name-header")
                .setPartNameGenerator(item -> "grid-merchant-name");
        grid.addColumn(FinancialTranVO::getMerchantAddress)
                .setHeader("Merchant Address")
                .setAutoWidth(true)
                .setSortable(true)
                .setSortProperty("card_acceptor_address")
                .setHeaderPartName("grid-merchant-address-header")
                .setPartNameGenerator(item -> "grid-merchant-address");
        grid.addColumn(FinancialTranVO::getMerchantCity)
                .setHeader("Merchant City")
                .setAutoWidth(true)
                .setSortable(true)
                .setSortProperty("card_acceptor_city")
                .addClassNames("grid-merchant-city");
        grid.addColumn(FinancialTranVO::getMerchantState)
                .setHeader("Merchant State")
                .setSortable(true)
                .setSortProperty("card_acceptor_state")
                .setHeaderPartName("grid-merchant-state-header")
                .setPartNameGenerator(item -> "grid-merchant-state");
        grid.addColumn(FinancialTranVO::getResponseCode)
                .setHeader("Response Code")
                .setSortable(true)
                .setSortProperty("response_code")
                .setTooltipGenerator(financialTranVO -> financialTranVO.getResponseCodeDesc().trim())
                .setHeaderPartName("grid-response-code-header")
                .setPartNameGenerator(item -> "grid-response-code");
        grid.addColumn(FinancialTranVO::getFraudScore)
                .setHeader("Fraud Score")
                .setSortable(true)
                .setSortProperty("fn_score")
                .setHeaderPartName("grid-fraud-score-header")
                .setPartNameGenerator(item -> "grid-fraud-score");
        grid.addColumn(FinancialTranVO::getBusinessTypeCode)
                .setHeader("Business Store Type")
                .setSortable(true)
                .setSortProperty("fcs_type")
                .setTooltipGenerator(financialTranVO -> financialTranVO.getBusinessTypeDesc().trim())
                .setHeaderPartName("grid-business-type-header")
                .setPartNameGenerator(item -> "grid-business-type");
        grid.addColumn(FinancialTranVO::getAlertFlag)
                .setHeader("Alert Flag")
                .setSortable(true)
                .setSortProperty("alert_flag")
                .setTooltipGenerator(financialTranVO -> financialTranVO.getAlertFlagDesc())
                .setHeaderPartName("grid-alert-flag-header")
                .setPartNameGenerator(item -> "grid-alert-flag");
     // Add Tran Info tab fields as hidden columns for Export
        grid.addColumn(financialTranVO -> StringUtils.isNotBlank(financialTranVO.getCardAcceptorId()) ? financialTranVO.getCardAcceptorId() : "")
                .setHeader("Card Acceptor ID")
                .setVisible(false);
        grid.addColumn(financialTranVO -> StringUtils.isNotBlank(financialTranVO.getTerminalClass()) ? financialTranVO.getTerminalClass() : "")
                .setHeader("Terminal Class")
                .setVisible(false);
        grid.addColumn(financialTranVO -> StringUtils.isNotBlank(financialTranVO.getPresentationData()) ? financialTranVO.getPresentationData() : "")
                .setHeader("Presentation Data")
                .setVisible(false);
        grid.addColumn(financialTranVO ->  StringUtils.isNotBlank(financialTranVO.getSecCondCode()) ? financialTranVO.getSecCondCode() : "")
                .setHeader("Security Condition")
                .setVisible(false);
        grid.addColumn(financialTranVO -> StringUtils.isNotBlank(financialTranVO.getTerminalTypeCode())? financialTranVO.getTerminalTypeCode() : "")
                .setHeader("Terminal Type")
                .setVisible(false);
        grid.addColumn(financialTranVO -> StringUtils.isNotBlank(financialTranVO.getTerminalCapabilityCode())? financialTranVO.getTerminalCapabilityCode() : "")
                .setHeader("Terminal Capability")
                .setVisible(false);
        grid.addColumn(financialTranVO -> StringUtils.isNotBlank(financialTranVO.getPanEntryModeCode())? financialTranVO.getPanEntryModeCode() : "")
                .setHeader("PAN Entry Mode")
                .setVisible(false);
        grid.addColumn(financialTranVO -> StringUtils.isNotBlank(financialTranVO.getPinEntryMode())? financialTranVO.getPinEntryMode() : "")
                .setHeader("PIN Entry Mode")
                .setVisible(false);
        grid.addColumn(financialTranVO -> getAcqInstCode(financialTranVO, tppDescMappingConfig))
                 .setHeader("TPP")
                .setVisible(false);
        grid.addColumn(FinancialTranVO::getMcc)
                .setHeader("MCC")
                .setVisible(false);
        grid.addColumn(FinancialTranVO::getGeoState)
                .setHeader("Geo State")
                .setVisible(false);
        grid.addColumn(FinancialTranVO::getGeoZip)
                .setHeader("Geo Zip")
                .setVisible(false);
        grid.addColumn(financialTranVO -> StringUtils.isNotBlank(financialTranVO.getFoodBeginningBal())? financialTranVO.getFoodBeginningBal() : "")
                .setHeader("Beginning Balance")
                .setVisible(false);
        grid.addColumn(financialTranVO -> StringUtils.isNotBlank(financialTranVO.getFoodEndingBal())? financialTranVO.getFoodEndingBal() : "")
                .setHeader("Ending Balance")
                .setVisible(false);
        grid.addColumn(financialTranVO -> StringUtils.isNotBlank(financialTranVO.getIncentiveEarned())? financialTranVO.getIncentiveEarned() : "")
               .setHeader("Incentive Earned")
               .setVisible(false);
        grid.addColumn(financialTranVO -> StringUtils.isNotBlank(financialTranVO.getIncentiveEligible())? financialTranVO.getIncentiveEligible() : "")
               .setHeader("Incentive Eligible")
               .setVisible(false);
        grid.addColumn(FinancialTranVO::getIncentiveMTD)
              .setHeader("Incentive MTD")
              .setVisible(false); 
        // Add REDE tab fields as hidden columns for Export
        grid.addColumn(financialTranVO -> StringUtils.isNotBlank(financialTranVO.getRedeName())? financialTranVO.getRedeName() : "")
              .setHeader("Store Name")
              .setVisible(false);
        grid.addColumn(financialTranVO -> StringUtils.isNotBlank(financialTranVO.getFnsNumber()) ? financialTranVO.getFnsNumber() : "")
              .setHeader("Store Number")
              .setVisible(false);
        grid.addColumn(financialTranVO -> getStoreAddressNumber(financialTranVO))
              .setHeader("Store Address Number")
              .setVisible(false);
        grid.addColumn(financialTranVO -> getStoreStreetName(financialTranVO))
              .setHeader("Store Street Name")
              .setVisible(false);
        grid.addColumn(financialTranVO -> StringUtils.isNotBlank(financialTranVO.getRedeCity()) ? financialTranVO.getRedeCity() : "")
              .setHeader("City")
              .setVisible(false);
        grid.addColumn(financialTranVO -> StringUtils.isNotBlank(financialTranVO.getRedeState()) ? financialTranVO.getRedeState() : "")
              .setHeader("State")
              .setVisible(false);
        grid.addColumn(financialTranVO -> StringUtils.isNotBlank(financialTranVO.getRedeZip()) ? financialTranVO.getRedeZip() : "")
              .setHeader("Zip Code")
              .setVisible(false);
        grid.addColumn(financialTranVO -> "")
              .setHeader("Additional Address Info")
              .setVisible(false);
        grid.addColumn(financialTranVO -> "Y".equalsIgnoreCase(financialTranVO.getOpen24HoursFlag()) ? "Yes" : StringUtils.isNotBlank(financialTranVO.getOpen24HoursFlag()) ? "No" : "")
              .setHeader("24 Hour Indicator")
              .setVisible(false);
        grid.addColumn(financialTranVO -> StringUtils.isNotBlank(financialTranVO.getBusinessTypeDesc()) ? financialTranVO.getBusinessTypeDesc() : "")
              .setHeader("Store Business Type")
              .setVisible(false); 
        // Add Internet Delivery tab fields as hidden columns for Export
        grid.addColumn(financialTranVO -> StringUtils.isNotBlank(financialTranVO.getIntDeliveryAddr())? financialTranVO.getIntDeliveryAddr() : "")
              .setHeader("Delivery Street")
              .setVisible(false);
        grid.addColumn(financialTranVO -> StringUtils.isNotBlank(financialTranVO.getIntDeliveryCity())? financialTranVO.getIntDeliveryCity() : "")
              .setHeader("Delivery City")
              .setVisible(false);
        grid.addColumn(financialTranVO -> StringUtils.isNotBlank(financialTranVO.getIntDeliveryState())? financialTranVO.getIntDeliveryState() : "")
              .setHeader("Delivery State")
              .setVisible(false);
        grid.addColumn(financialTranVO -> StringUtils.isNotBlank(financialTranVO.getIntDeliveryZip())? financialTranVO.getIntDeliveryZip() : "")
              .setHeader("Delivery ZIP")
              .setVisible(false);
        grid.addColumn(financialTranVO -> StringUtils.isNotBlank(financialTranVO.getIntDeliveryShippingIndCode())? financialTranVO.getIntDeliveryShippingIndCode() : "")
              .setHeader("Delivery Shipping Indicator")
              .setVisible(false); 
        grid.setVisible(false);
        grid.addThemeVariants(GridVariant.LUMO_ROW_STRIPES,
                GridVariant.LUMO_COMPACT,
                GridVariant.LUMO_WRAP_CELL_CONTENT);
    }

    /**
     * Initializes grid empty state
     *
     * @param grid
     */
    private static void setGridEmptyState(Grid<FinancialTranVO> grid) {
        Div emptyGrid = new Div();
        emptyGrid.add("***** No data present for the given search criteria *****");
        emptyGrid.addClassNames("empty-grid");
        grid.setEmptyStateComponent(emptyGrid);
    }
    
    public static String getStoreAddressNumber(FinancialTranVO financialTranVO) {
        String input = financialTranVO.getRedeStreetName();
        StringBuilder numbers = new StringBuilder();
        if (StringUtils.isNotBlank(input)) {
            for (int i = 0; i < input.length(); i++) {
                char c = input.charAt(i);
                if (Character.isDigit(c)) {
                    numbers.append(c);
                } else {
                    break; // Stop at the first non-digit character
                }
            }
        }
        return StringUtils.isNotBlank(numbers.toString()) ? numbers.toString() : "";
    }
    
    
    private static String getStoreStreetName(FinancialTranVO financialTranVO) {

        String input = financialTranVO.getRedeStreetName();
        String streetName = "";
        StringBuilder numbers = new StringBuilder();
        if (StringUtils.isNotBlank(input)) {
            for (int i = 0; i < input.length(); i++) {
                char c = input.charAt(i);
                if (Character.isDigit(c)) {
                    numbers.append(c);
                } else {
                    streetName = input.substring(i, input.length());
                }
            }
        } 
        return streetName;
        }
    
    public static String getAcqInstCode(FinancialTranVO financialTranVO, TppDescMappingConfig tppDescMappingConfig) {
        return StringUtils.isNotBlank(financialTranVO.getAcqInstIdentificationCode())
                ? tppDescMappingConfig.getDesc(financialTranVO.getAcqInstIdentificationCode())
                : "";
    }


}
