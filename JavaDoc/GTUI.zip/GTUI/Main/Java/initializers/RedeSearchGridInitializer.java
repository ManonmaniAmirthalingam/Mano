package com.ebtedge.fns.gateway.initializers;

import java.util.function.Consumer;

import com.ebtedge.fns.gateway.model.RedeGridVO;
import com.ebtedge.fns.gateway.security.CurrentUserAccess;
import com.ebtedge.fns.gateway.security.UserPermission;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.data.renderer.ComponentRenderer;

/**
 * Initializes the REDE Search grid with {@link RedeGridVO}.
 */
public class RedeSearchGridInitializer {
	
	public static final String ACTION_COLUMN_KEY = "action-column";

    /**
     * Initializes the grid with columns and settings.
     *
     * @param grid The grid to initialize.
     */
    public static void initializeGridWithoutActions(Grid<RedeGridVO> grid) {
        setGridEmptyState(grid);

        grid.addColumn(RedeGridVO::getRownumbers)
                .setHeader("Row #")
                .setAutoWidth(true);

        grid.addColumn(RedeGridVO::getLast_foodstamp_ts)
                .setHeader("Date/Time")
                .setAutoWidth(true)
                .setSortProperty("last_foodstamp_ts")
                .setSortable(true);

        grid.addColumn(RedeGridVO::getFns_number)
                .setHeader("FNS #")
                .setAutoWidth(true)
                .setSortProperty("fns_number")
                .setSortable(true);

        grid.addColumn(RedeGridVO::getTerminal_id)
                .setHeader("Merchant Terminal ID")
                .setAutoWidth(true)
                .setSortProperty("terminal_id")
                .setSortable(true);

        grid.addColumn(RedeGridVO::getFinal_score)
                .setHeader("Final Score")
                .setAutoWidth(true)
                .setSortProperty("final_score")
                .setSortable(true);

        grid.addColumn(RedeGridVO::getTxn_acceptor_name)
                .setHeader("Merchant Name")
                .setAutoWidth(true)
                .setSortProperty("txn_acceptor_name")
                .setSortable(true);

        grid.addColumn(RedeGridVO::getRede_acceptor_name)
                .setHeader("REDE Store Name")
                .setAutoWidth(true)
                .setSortProperty("rede_acceptor_name")
                .setSortable(true)
                .setHeaderPartName("grid-rede-store-name-header")
                .setPartNameGenerator(item -> "grid-rede-store-name");

        grid.addColumn(RedeGridVO::getName_score)
                .setHeader("Name Score")
                .setSortProperty("name_score")
                .setSortable(true)
                .setHeaderPartName("grid-name-score-header")
                .setPartNameGenerator(item -> "grid-name-score");
        grid.addColumn(RedeGridVO::getTxn_acceptor_address)
                .setHeader("Merchant Address")
                .setAutoWidth(true)
                .setSortProperty("txn_acceptor_address")
                .setSortable(true)
                .setHeaderPartName("grid-merchant-address-header")
                .setPartNameGenerator(item -> "grid-merchant-address");

        grid.addColumn(RedeGridVO::getRede_acceptor_address)
                .setHeader("REDE Address")
                .setAutoWidth(true)
                .setSortProperty("rede_acceptor_address")
                .setSortable(true)
                .setHeaderPartName("grid-rede-address-header")
                .setPartNameGenerator(item -> "grid-rede-address");

        grid.addColumn(RedeGridVO::getAddress_score)
                .setHeader("Address Score")
                .setSortProperty("address_score")
                .setSortable(true)
                .setHeaderPartName("grid-address-score-header")
                .setPartNameGenerator(item -> "grid-address-score");
        grid.addColumn(RedeGridVO::getTxn_acceptor_city)
                .setHeader("Merchant City")
                .setSortProperty("txn_acceptor_city")
                .setSortable(true);

        grid.addColumn(RedeGridVO::getRede_acceptor_city)
                .setHeader("REDE City")
                .setSortProperty("rede_acceptor_city")
                .setSortable(true);

        grid.addColumn(RedeGridVO::getCity_score)
                .setHeader("City Score")
                .setSortProperty("city_score")
                .setSortable(true)
                .setHeaderPartName("grid-city-score-header")
                .setPartNameGenerator(item -> "grid-city-score");

        grid.addColumn(RedeGridVO::getTxn_acceptor_state)
                .setHeader("Merchant State")
                .setSortProperty("txn_acceptor_state")
                .setSortable(true)
                .setHeaderPartName("grid-merchant-state-header")
                .setPartNameGenerator(item -> "grid-merchant-state");

        grid.addColumn(RedeGridVO::getRede_acceptor_state)
                .setHeader("REDE State")
                .setSortProperty("rede_acceptor_state")
                .setSortable(true)
                .setHeaderPartName("grid-rede-state-header")
                .setPartNameGenerator(item -> "grid-rede-state");

        grid.addColumn(RedeGridVO::getState_score)
                .setHeader("State Score")
                .setSortProperty("state_score")
                .setSortable(true)
                .setHeaderPartName("grid-state-score-header")
                .setPartNameGenerator(item -> "grid-state-score");

        grid.addColumn(RedeGridVO::getTxn_acceptor_zip)
                .setHeader("Merchant Zip")
                .setSortProperty("txn_acceptor_zip")
                .setSortable(true);

        grid.addColumn(RedeGridVO::getRede_acceptor_zip)
                .setHeader("REDE Zip")
                .setSortProperty("rede_acceptor_zip")
                .setSortable(true);

        grid.addColumn(RedeGridVO::getZip_score)
                .setHeader("Zip Score")
                .setSortProperty("zip_score")
                .setSortable(true)
                .setHeaderPartName("grid-zip-score-header")
                .setPartNameGenerator(item -> "grid-zip-score");
        
        grid.addColumn(RedeGridVO::getStatus)
                .setHeader("Status")
                .setAutoWidth(true)
                .setSortProperty("status")
                .setSortable(true)
                .setHeaderPartName("grid-rede-status-header")
                .setPartNameGenerator(item -> "grid-red-status");

        grid.addColumn(RedeGridVO::getLast_mod_by)
               .setHeader("Last Modified By")
               .setAutoWidth(true)
               .setSortProperty("last_mod_by")
               .setSortable(true);

        grid.setVisible(false);
        grid.addThemeVariants(GridVariant.LUMO_ROW_STRIPES, GridVariant.LUMO_COMPACT, GridVariant.LUMO_WRAP_CELL_CONTENT);
    }

    public static void initializeGrid(Grid<RedeGridVO> grid, Consumer<RedeGridVO> onStatusUpdate, CurrentUserAccess currentUserAccess) {
        setGridEmptyState(grid);

        initializeGridWithoutActions(grid);
        grid.addColumn(new ComponentRenderer<>(item -> {
            Button editButton = new Button(new Icon(VaadinIcon.EDIT));
            editButton.addThemeVariants(ButtonVariant.LUMO_SMALL);
            editButton.addThemeName("action-button");
            editButton.getElement().setAttribute("aria-label", "Edit status");
            editButton.getElement().setAttribute("title", "Update Status");
            editButton.setEnabled(currentUserAccess.hasPermission(UserPermission.GWAllowREDEScoreStatusUpdate));
            editButton.addClickListener(e -> {
                if (editButton.isEnabled()) {
                    onStatusUpdate.accept(item);
                }
            });
            return editButton;
        })).setHeader("Actions").setFlexGrow(0).setWidth("100px")
           .setKey(ACTION_COLUMN_KEY);
    }
    /**
     * Sets the empty state for the grid.
     *
     * @param grid The grid to set the empty state for.
     */
    private static void setGridEmptyState(Grid<RedeGridVO> grid) {
        Div emptyGrid = new Div();
        emptyGrid.add("***** No data present for the given search criteria *****");
        emptyGrid.addClassNames("empty-grid");
        grid.setEmptyStateComponent(emptyGrid);
    }
    
    
    /**
     * Check if a column is an action column that should be excluded from exports.
     *
     * @param column The column to check
     * @return true if the column is an action column, false otherwise
     */
    public static boolean isActionColumn(Grid.Column<?> column) {
        return ACTION_COLUMN_KEY.equals(column.getKey());
    }

}