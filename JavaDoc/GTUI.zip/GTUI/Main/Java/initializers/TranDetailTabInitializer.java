package com.ebtedge.fns.gateway.initializers;

import com.ebtedge.fns.gateway.components.DateTimeRangePicker;
import com.ebtedge.fns.gateway.components.SpinnerDialog;
import com.ebtedge.fns.gateway.config.TppDescMappingConfig;
import com.ebtedge.fns.gateway.model.DateTimeRange;
import com.ebtedge.fns.gateway.model.FinancialTranVO;
import com.ebtedge.fns.gateway.security.CurrentUserAccess;
import com.ebtedge.fns.gateway.security.UserPermission;
import com.ebtedge.fns.gateway.service.FnApiService;
import com.ebtedge.fns.gateway.util.AddressUtil;
import com.ebtedge.fns.gateway.util.ConfirmDialogs;
import com.ebtedge.fns.gateway.util.Notifications;
import com.ebtedge.fns.gateway.util.SessionUtil;
import com.vaadin.flow.component.*;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.notification.NotificationVariant;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.FlexLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.theme.lumo.LumoUtility;

import lombok.Value;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * Class for initializing Transaction Details tab
 *
 * @author e3023044
 * @version 1.0.0
 * @since 1.0.0
 */
@Slf4j
public class TranDetailTabInitializer {
    private static final Map<String, Function<FinancialTranVO, String>> MONITOR_BLOCK_FIELDS;
    private static final Map<String, Function<FinancialTranVO, String>> TRAN_INFO_FIELDS;
    private static final Map<String, Function<FinancialTranVO, String>> REDE_FIELDS;
    private static final Map<String, Function<FinancialTranVO, String>>
            INTERNET_DELIVERY_INFO_FIELDS;

    private static final String SPACING_S_THEME = "spacing-s";
    private static final String BLOCK_MONITOR_TAB_CSS_CLASS = "block-monitor-tab-details";
    private static final String TRAN_INFO_TAB_CSS_CLASS = "tran-info-tab-details";
    private static final String REDE_TAB_CSS_CLASS = "rede-tab-details";
    private static final String INTERNET_DELIVERY_TAB_CSS_CLASS = "internet-tab-details";
    private static final String DEFAULT_EMPTY_VALUE = "-";

    /**
     * Represents the maximum year allowed for terminal block-related operations in the application.
     * Ensures that any processing or validation involving terminal blocks does not exceed the
     * permissible year limit.
     *
     * <p>There is an input for the user to adjust the year on UI, it is safe to hard code the value
     * here as per requirement.
     */
    private static final int TERMINAL_BLOCK_MAX_YEAR = 2099;

    static {
        MONITOR_BLOCK_FIELDS = createMonitorBlockFields();
        TRAN_INFO_FIELDS = createTranInfoFields();
        REDE_FIELDS = createRedeFields();
        INTERNET_DELIVERY_INFO_FIELDS = createInternetDeliveryInfoFields();
    }

    private static Map<String, Function<FinancialTranVO, String>> createMonitorBlockFields() {
        Map<String, Function<FinancialTranVO, String>> fields = new LinkedHashMap<>();;
        fields.put("Card", FinancialTranVO::getCardNumber);
        fields.put("Terminal ID", FinancialTranVO::getTerminalId);
        fields.put("Card Acceptor ID", FinancialTranVO::getCardAcceptorId);
        return Collections.unmodifiableMap(fields);
    }

    private static Map<String, Function<FinancialTranVO, String>> createTranInfoFields() {
        Map<String, Function<FinancialTranVO, String>> fields = new LinkedHashMap<>();
        fields.put("Card Acceptor ID", FinancialTranVO::getCardAcceptorId);
        fields.put("Terminal Class", FinancialTranVO::getTerminalClass);
        fields.put("Presentation Data", FinancialTranVO::getPresentationData);
        fields.put("Security Condition", data -> getSecCondCodeDesc(data.getSecCondCode()));
        fields.put("Terminal Type", data -> getTerminalTypeDesc(data.getTerminalTypeCode()));
        fields.put(
                "Terminal Capability", data -> getTerCapCodeDesc(data.getTerminalCapabilityCode()));
        fields.put("PAN Entry Mode", TranDetailTabInitializer::getPanEntryMode);
        fields.put("PIN Entry Mode", TranDetailTabInitializer::getPinEntryMode);
        // TPP field will be replaced later with the actual displayed value
        fields.put("TPP", FinancialTranVO::getAcqInstIdentificationCode);
        fields.put("MCC", FinancialTranVO::getMcc);
        fields.put("Geo State", FinancialTranVO::getGeoState);
        fields.put("Geo Zip", FinancialTranVO::getGeoZip);
        fields.put("Beginning Balance", FinancialTranVO::getFoodBeginningBal);
        fields.put("Ending Balance", FinancialTranVO::getFoodEndingBal);
        fields.put("Incentive Earned", FinancialTranVO::getIncentiveEarned);
        fields.put("Incentive Eligible", FinancialTranVO::getIncentiveEligible);
        fields.put("Incentive MTD", FinancialTranVO::getIncentiveMTD);
        return fields;
    }

    private static Map<String, Function<FinancialTranVO, String>> createRedeFields() {
        Map<String, Function<FinancialTranVO, String>> fields = new LinkedHashMap<>();
        fields.put("Store Name", FinancialTranVO::getRedeName);
        fields.put(
                "Store Number",
                financialTranVO -> StringUtils.defaultString(financialTranVO.getFnsNumber()));
        fields.put(
                "Store Address Number",
                (financialTranVO ->
                        AddressUtil.getStreetNumber(financialTranVO.getRedeStreetName())
                                .orElse(null)));
        fields.put(
                "Store Street Name",
                (financialTranVO ->
                        AddressUtil.getStreetName(financialTranVO.getRedeStreetName())
                                .orElse(null)));
        fields.put("City", FinancialTranVO::getRedeCity);
        fields.put("State", FinancialTranVO::getRedeState);
        fields.put("Zip Code", FinancialTranVO::getRedeZip);
        fields.put(
                "Additional Address Info",
                TranDetailTabInitializer::getRedeStoreAdditionalAddressInfo);
        fields.put("24 Hour Indicator", TranDetailTabInitializer::get24HrBusinessIndicator);
        fields.put("Store Business Type", TranDetailTabInitializer::getBusinessType);
        return Collections.unmodifiableMap(fields);
    }

    private static Map<String, Function<FinancialTranVO, String>>
            createInternetDeliveryInfoFields() {
        Map<String, Function<FinancialTranVO, String>> fields = new LinkedHashMap<>();
        fields.put("Delivery Street", FinancialTranVO::getIntDeliveryAddr);
        fields.put("Delivery City", FinancialTranVO::getIntDeliveryCity);
        fields.put("Delivery State", FinancialTranVO::getIntDeliveryState);
        fields.put("Delivery Zip", FinancialTranVO::getIntDeliveryZip);
        fields.put("Delivery Shipping Indicator", TranDetailTabInitializer::getDeliveryShippingInd);
        return Collections.unmodifiableMap(fields);
    }

    public static VerticalLayout createMonitorBlockTabContent(
            FinancialTranVO financialTranVO,
            CurrentUserAccess currentUserAccess,
            FnApiService FNApiService) {
        return createWrapper(
                BLOCK_MONITOR_TAB_CSS_CLASS,
                () ->
                        Arrays.asList(
                                createDetails(MONITOR_BLOCK_FIELDS, financialTranVO),
                                createMonitorBlockActions(
                                        financialTranVO, currentUserAccess, FNApiService)));
    }

    public static VerticalLayout createTranInfoTabContent(
            FinancialTranVO financialTranVO, TppDescMappingConfig tppDescMappingConfig) {
        TRAN_INFO_FIELDS.put("TPP", data -> formatTppValue(data, tppDescMappingConfig));
        FormLayout formLayout = createDetails(TRAN_INFO_FIELDS, financialTranVO);
        return createWrapper(TRAN_INFO_TAB_CSS_CLASS, () -> Collections.singletonList(formLayout));
    }

    public static VerticalLayout createREDETabContent(FinancialTranVO financialTranVO) {
        return createWrapper(
                REDE_TAB_CSS_CLASS, () -> List.of(createDetails(REDE_FIELDS, financialTranVO)));
    }

    public static VerticalLayout createInternetDeliveryInfoTabContent(
            FinancialTranVO financialTranVO) {
        return createWrapper(
                INTERNET_DELIVERY_TAB_CSS_CLASS,
                () -> List.of(createDetails(INTERNET_DELIVERY_INFO_FIELDS, financialTranVO)));
    }

    private static VerticalLayout createWrapper(
            String className, Supplier<List<Component>> contentSupplier) {
        VerticalLayout layout = new VerticalLayout();
        layout.getThemeList().add(SPACING_S_THEME);
        layout.addClassNames(className);
        contentSupplier.get().forEach(layout::add);
        return layout;
    }

    private static FormLayout createDetails(
            Map<String, Function<FinancialTranVO, String>> fields, FinancialTranVO data) {
        FormLayout layout = new FormLayout();
        configureResponsiveLayout(layout);
        fields.forEach((label, transformer) -> addFormItem(layout, label, transformer.apply(data)));
        return layout;
    }

    private static void configureResponsiveLayout(FormLayout layout) {
        layout.setResponsiveSteps(
                new FormLayout.ResponsiveStep("0", 1, FormLayout.ResponsiveStep.LabelsPosition.TOP),
                new FormLayout.ResponsiveStep(
                        "375px", 1, FormLayout.ResponsiveStep.LabelsPosition.ASIDE));
    }

    private static void addFormItem(FormLayout layout, String label, String value) {
        layout.addFormItem(new Span(StringUtils.defaultIfBlank(value, DEFAULT_EMPTY_VALUE)), label);
    }

    private static String formatTppValue(
            FinancialTranVO financialTranVO, TppDescMappingConfig tppDescMappingConfig) {
        return StringUtils.isNotBlank(financialTranVO.getAcqInstIdentificationCode())
                ? tppDescMappingConfig.getDesc(financialTranVO.getAcqInstIdentificationCode())
                : "";
    }

    private static String getPanEntryMode(FinancialTranVO data) {
        StringBuilder sb = new StringBuilder();
        sb.append(StringUtils.defaultString(data.getPanEntryModeDesc()));
        if (StringUtils.isNotBlank(data.getPanEntryModeCode())) {
            sb.append(" (%s)".formatted(data.getPanEntryModeCode()));
        }
        return sb.toString().trim();
    }

    private static String getPinEntryMode(FinancialTranVO data) {
        StringBuilder sb = new StringBuilder();
        sb.append(StringUtils.defaultString(data.getPinEntryModeDesc()));
        if (StringUtils.isNotBlank(data.getPinEntryMode())) {
            sb.append(" (%s)".formatted(data.getPinEntryMode()));
        }
        return sb.toString().trim();
    }

    /**
     * @param financialTranVO
     * @return a display value for Delivery Shipping Indicator
     */
    public static String getDeliveryShippingInd(FinancialTranVO financialTranVO) {
        String value = StringUtils.EMPTY;
        if (StringUtils.isNotBlank(financialTranVO.getIntDeliveryShippingIndDesc())
                && StringUtils.isNotBlank(financialTranVO.getIntDeliveryShippingIndCode())) {
            value =
                    financialTranVO.getIntDeliveryShippingIndDesc()
                            + " ("
                            + (StringUtils.isNotBlank(
                                            financialTranVO.getIntDeliveryShippingIndCode())
                                    ? financialTranVO.getIntDeliveryShippingIndCode()
                                    : "")
                            + ")";
        } else if (StringUtils.isNotBlank(financialTranVO.getIntDeliveryShippingIndCode())) {
            value = "(" + financialTranVO.getIntDeliveryShippingIndCode() + ")";
        }
        return value;
    }

    /**
     * @param financialTranVO
     * @return a display value for Additional Address info.
     */
    private static String getRedeStoreAdditionalAddressInfo(FinancialTranVO financialTranVO) {
        // Todo: implement data retrieval
        return "";
    }

    /**
     * @param financialTranVO
     * @return a display value for 24 hours business indicator
     */
    private static String get24HrBusinessIndicator(FinancialTranVO financialTranVO) {
        return "Y".equalsIgnoreCase(financialTranVO.getOpen24HoursFlag())
                ? "Yes"
                : StringUtils.isNotBlank(financialTranVO.getOpen24HoursFlag()) ? "No" : "";
    }

    /**
     * @param financialTranVO
     * @return a display value for business type label and description
     */
    private static String getBusinessType(FinancialTranVO financialTranVO) {
        return StringUtils.isNotBlank(financialTranVO.getBusinessTypeDesc())
                ? financialTranVO.getBusinessTypeDesc()
                : "";
    }

    /**
     * TODO: This is only let UI team to test and complete their work. If stored procedure change is
     * complete send the description then this code will be removed. Hence value are hardcode
     * instead of reading it from application.yml
     *
     * @param securityCode
     * @return security condition code desc
     */
    private static String getSecCondCodeDesc(String securityCode) {

        if ("0".equalsIgnoreCase(securityCode)) {
            return "No security concern" + " (" + securityCode + ")";
        }

        if ("1".equalsIgnoreCase(securityCode)) {
            return "Suspected fraud" + " (" + securityCode + ")";
        }

        if ("2".equalsIgnoreCase(securityCode)) {
            return "Identification verified" + " (" + securityCode + ")";
        }

        if (StringUtils.isNotBlank(securityCode)) return "(" + securityCode + ")";
        else return "";
    }

    /**
     * TODO: This is only let UI team to test and complete their work. If stored procedure change is
     * complete send the description then this code will be removed. Hence value are hardcode
     * instead of reading it from application.yml
     *
     * @param terminalTypeCode
     * @return terminal type description
     */
    private static String getTerminalTypeDesc(String terminalTypeCode) {

        if ("01".equalsIgnoreCase(terminalTypeCode)) {
            return "POS terminal" + " (" + terminalTypeCode + ")";
        }

        if ("02".equalsIgnoreCase(terminalTypeCode)) {
            return "ATM" + " (" + terminalTypeCode + ")";
        }

        if ("04".equalsIgnoreCase(terminalTypeCode)) {
            return "ECR" + " (" + terminalTypeCode + ")";
        }

        if ("05".equalsIgnoreCase(terminalTypeCode)) {
            return "Dial terminal" + " (" + terminalTypeCode + ")";
        }

        if ("07".equalsIgnoreCase(terminalTypeCode)) {
            return "Fuel machine" + " (" + terminalTypeCode + ")";
        }

        if ("08".equalsIgnoreCase(terminalTypeCode)) {
            return "Scrip machine" + " (" + terminalTypeCode + ")";
        }

        if ("09".equalsIgnoreCase(terminalTypeCode)) {
            return "Coupon machine" + " (" + terminalTypeCode + ")";
        }

        if ("11".equalsIgnoreCase(terminalTypeCode)) {
            return "Point-of-banking terminal" + " (" + terminalTypeCode + ")";
        }

        if ("25".equalsIgnoreCase(terminalTypeCode)) {
            return "Internet" + " (" + terminalTypeCode + ")";
        }

        if (StringUtils.isNotBlank(terminalTypeCode)) return "(" + terminalTypeCode + ")";
        return "";
    }

    /**
     * TODO: This is only let UI team to test and complete their work. If stored procedure change is
     * complete send the description then this code will be removed. Hence value are hardcode
     * instead of reading it from application.yml
     *
     * @param terminalTypeCode
     * @return terminal capability code desc
     */
    private static String getTerCapCodeDesc(String terminalTypeCode) {

        if ("0".equalsIgnoreCase(terminalTypeCode)) {
            return "Terminal Capability Unknown / Not Specified" + " (" + terminalTypeCode + ")";
        }

        if ("1".equalsIgnoreCase(terminalTypeCode)) {
            return "Manual; no terminal" + " (" + terminalTypeCode + " )";
        }

        if ("2".equalsIgnoreCase(terminalTypeCode)) {
            return "Terminal supports magnetic stripe input)" + " (" + terminalTypeCode + ")";
        }

        if ("3".equalsIgnoreCase(terminalTypeCode)) {
            return "Terminal supports QR or Bar Code" + " (" + terminalTypeCode + ")";
        }

        if ("4".equalsIgnoreCase(terminalTypeCode)) {
            return "RFU" + " (" + terminalTypeCode + " )";
        }

        if ("5".equalsIgnoreCase(terminalTypeCode)) {
            return "Terminal supports chip / ICC" + " (" + terminalTypeCode + ")";
        }

        if ("6".equalsIgnoreCase(terminalTypeCode)) {
            return "Terminal supports key entry only" + " (" + terminalTypeCode + ")";
        }

        if ("7".equalsIgnoreCase(terminalTypeCode)) {
            return "Terminal supports contactless chip" + " (" + terminalTypeCode + ")";
        }

        if ("8".equalsIgnoreCase(terminalTypeCode) || "9".equalsIgnoreCase(terminalTypeCode)) {
            return "RFU" + " (" + terminalTypeCode + ")";
        }

        if (StringUtils.isNotBlank(terminalTypeCode)) return "(" + terminalTypeCode + ")";
        return "";
    }

    private static FlexLayout createMonitorBlockActions(
            FinancialTranVO financialTranVO,
            CurrentUserAccess currentUserAccess,
            FnApiService FNApiService) {
        FlexLayout layout = new FlexLayout();
        layout.addClassName(LumoUtility.Gap.SMALL);
        layout.addClassName(LumoUtility.FlexWrap.WRAP);
        List<MonitorBlockButtonConfig> actionConfigs = createActionConfigs();
        actionConfigs.stream()
                .map(
                        config ->
                                createActionButton(
                                        config, financialTranVO, currentUserAccess, FNApiService))
                .forEach(layout::add);
        return layout;
    }

    private static void handleMonitorCard(FinancialTranVO vo, FnApiService FNApiService) {
        log.debug("Monitor card button clicked. Card number: {}", vo.getCardNumber());
        String userId = Objects.requireNonNull(SessionUtil.getUserInfo()).getUserId();
        executeWithConfirmation(
                "Are you sure you want to monitor this Card?",
                () -> FNApiService.monitorCard(vo.getCardNumber(), userId),
                "Card %s has been successfully monitored.".formatted(vo.getCardNumber()),
                "Failed to monitor Card %s. Please contact administrator for details"
                        .formatted(vo.getCardNumber()));
    }

    private static void handleMonitorTerminal(FinancialTranVO vo, FnApiService FNApiService) {
        log.debug("Monitor terminal button clicked. Terminal ID: {}", vo.getTerminalId());
        String userId = Objects.requireNonNull(SessionUtil.getUserInfo()).getUserId();
        executeWithConfirmation(
                "Are you sure you want to monitor this Terminal ID?",
                () ->
                        FNApiService.monitorTerminal(
                                vo.getTerminalId(), vo.getCardAcceptorId(), userId),
                "Terminal %s has been successfully monitored.".formatted(vo.getTerminalId()),
                "Failed to monitor Terminal %s. Please contact administrator for details"
                        .formatted(vo.getTerminalId()));
    }

    private static void handleBlockTerminal(FinancialTranVO vo, FnApiService fnApiService) {
        log.debug("Block terminal button clicked. Terminal ID: {}", vo.getTerminalId());
        VerticalLayout dialogContent = new VerticalLayout();
        dialogContent.setPadding(false);
        dialogContent.add(new Span("Please input below required fields"));
        DateTimeRangePicker rangePicker = new DateTimeRangePicker();
        LocalDateTime today = LocalDateTime.now();
        DateTimeRange defaultRange =
                new DateTimeRange(
                        today,
                        LocalDateTime.of(
                                LocalDate.of(
                                        TERMINAL_BLOCK_MAX_YEAR,
                                        today.getMonth(),
                                        today.getDayOfMonth()),
                                today.toLocalTime()));
        rangePicker.setRequiredIndicatorVisible(true);
        rangePicker.setMin(LocalDateTime.of(LocalDate.now(), LocalTime.MIN));
        rangePicker.setValue(defaultRange);
        dialogContent.add(rangePicker);
        String userId = Objects.requireNonNull(SessionUtil.getUserInfo()).getUserId();
        ConfirmDialogs.confirmWithComponent(
                "Block Terminal",
                dialogContent,
                () -> {
                    if (rangePicker.isInvalid()) {
                        return false;
                    }
                    DateTimeRange range = rangePicker.getValue();
                    if (range == null || range.getStart() == null || range.getEnd() == null) {
                        rangePicker.setErrorMessage("Start date and end date are required.");
                        return false;
                    }
                    executeWithConfirmation(
                            "Are you sure you want to block this Terminal ID?",
                            () ->
                                    fnApiService.blockTerminal(
                                            vo.getTerminalId(),
                                            vo.getCardAcceptorId(),
                                            vo.getAcqInstIdentificationCode(),
                                            rangePicker.getValue(),
                                            userId),
                            "Terminal %s has been successfully blocked."
                                    .formatted(vo.getTerminalId()),
                            "Failed to block Terminal %s. Please contact administrator for details"
                                    .formatted(vo.getTerminalId()));
                    return true;
                });
    }

    private static List<MonitorBlockButtonConfig> createActionConfigs() {
        return List.of(
                new MonitorBlockButtonConfig(
                        "Monitor Card",
                        VaadinIcon.EYE,
                        UserPermission.GWAllowCardMonitor,
                        TranDetailTabInitializer::handleMonitorCard),
                new MonitorBlockButtonConfig(
                        "Monitor Terminal",
                        VaadinIcon.EYE,
                        UserPermission.GWAllowTerminalIdMonitor,
                        TranDetailTabInitializer::handleMonitorTerminal),
                new MonitorBlockButtonConfig(
                        "Block Terminal",
                        VaadinIcon.LOCK,
                        UserPermission.GWAllowTerminalIdBlock,
                        TranDetailTabInitializer::handleBlockTerminal));
    }

    private static Button createActionButton(
            MonitorBlockButtonConfig config,
            FinancialTranVO financialTranVO,
            CurrentUserAccess currentUserAccess,
            FnApiService FNApiService) {
        Button button =
                new MonitorBlockButtonBuilder(
                                config.getLabel(),
                                config.getIcon(),
                                event ->
                                        handleButtonClick(
                                                event, config, financialTranVO, FNApiService))
                        .build();

        button.setEnabled(currentUserAccess.hasPermission(config.getPermission()));
        return button;
    }

    private static void handleButtonClick(
            ClickEvent<Button> event,
            MonitorBlockButtonConfig config,
            FinancialTranVO financialTranVO,
            FnApiService FNApiService) {
        if (!event.getSource().isEnabled()) {
            return;
        }
        config.getAction().accept(financialTranVO, FNApiService);
    }

    private static void executeWithConfirmation(
            String message, Runnable action, String successMessage, String failedMessage) {
        var confirmationExecutor =
                new ConfirmationExecutor(
                        new ConfirmationParams(message, action, successMessage, failedMessage));
        confirmationExecutor.execute();
    }

    private static class ConfirmationParams {
        private final String message;
        private final Runnable action;
        private final String successMessage;
        private final String failedMessage;

        ConfirmationParams(
                String message, Runnable action, String successMessage, String failedMessage) {
            this.message = message;
            this.action = action;
            this.successMessage = successMessage;
            this.failedMessage = failedMessage;
        }
    }

    private static class ConfirmationExecutor {
        private final ConfirmationParams params;
        private final SpinnerDialog spinner;
        private final UI ui;
        private final ExecutorService executor;

        ConfirmationExecutor(ConfirmationParams params) {
            this.params = params;
            this.spinner = new SpinnerDialog();
            this.ui = UI.getCurrent();
            this.executor = Executors.newSingleThreadExecutor();
        }

        void execute() {
            ConfirmDialogs.confirm(
                    params.message,
                    () ->
                            CompletableFuture.runAsync(this::performAction, executor)
                                    .whenComplete(this::handleCompletion));
        }

        private void performAction() {
            ui.access(spinner::open);
            log.debug("Executing action: {}", params.message);
            params.action.run();
        }

        private void handleCompletion(Void result, Throwable ex) {
            ui.access(
                    () -> {
                        spinner.close();
                        showNotification(ex);
                    });
            executor.shutdown();
        }

        private void showNotification(Throwable ex) {
            Notification notification = createNotification(ex);
            ui.add(notification);
            scheduleNotificationOpen(notification);
        }

        private Notification createNotification(Throwable ex) {
            if (ex != null) {
                log.error("Error occurred while performing action: {}", params.message, ex);
                return Notifications.create(params.failedMessage, NotificationVariant.LUMO_ERROR);
            } else {
                log.debug("Action completed successfully: {}", params.message);
                return Notifications.create(
                        params.successMessage, NotificationVariant.LUMO_SUCCESS);
            }
        }

        private void scheduleNotificationOpen(Notification notification) {
            ui.getPage()
                    .executeJs("setTimeout(() => { $0.open(); }, 500);", notification.getElement());
        }
    }

    @Value
    private static class MonitorBlockButtonConfig {
        String label;
        VaadinIcon icon;
        UserPermission permission;
        BiConsumer<FinancialTranVO, FnApiService> action;
    }

    @Value
    static class MonitorBlockButtonBuilder {
        String label;
        VaadinIcon icon;
        ComponentEventListener<ClickEvent<Button>> clickListener;

        Button build() {
            VerticalLayout content = new VerticalLayout();
            content.setAlignItems(FlexComponent.Alignment.CENTER);

            Span buttonLabel = new Span(label);
            buttonLabel.addClassNames(LumoUtility.FontSize.SMALL, LumoUtility.FontWeight.BOLD);
            content.add(new Icon(icon), buttonLabel);

            Button button = new Button(content);
            button.setHeight("90px");
            button.addClickListener(clickListener);
            return button;
        }
    }
}
