package com.ebtedge.fns.gateway.initializers;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.ebtedge.fns.gateway.model.UserPreferenceVO;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.data.provider.ListDataProvider;

import lombok.extern.slf4j.Slf4j;

/**
 * Initializes and manages the User Preference grid and related functionality
 */
@Slf4j
public final class UserPreferenceGridInitializer {

	private UserPreferenceGridInitializer() {
	}

	/**
	 * Initializes the grid with alert types and checkbox columns
	 * 
	 * @param grid      The grid to initialize
	 * @param alertList List of alert types to display
	 */
	public static void initializeGrid(Grid<UserPreferenceVO> grid, List<String> alertList) {
		if (grid == null) {
			throw new IllegalArgumentException("Grid cannot be null");
		}

		grid.removeAllColumns();
		setAlertList(grid, alertList);

		grid.addColumn(UserPreferenceVO::getAlertTypeName).setHeader("Types of Alerts").setAutoWidth(true)
				.setResizable(true).setFlexGrow(1).setKey("alertType").setFrozen(true);

		grid.addComponentColumn(item -> createCheckbox(item, grid, true)).setHeader("SMS")
				.setTextAlign(com.vaadin.flow.component.grid.ColumnTextAlign.CENTER).setWidth("100px").setKey("sms");

		grid.addComponentColumn(item -> createCheckbox(item, grid, false)).setHeader("Email")
				.setTextAlign(com.vaadin.flow.component.grid.ColumnTextAlign.CENTER).setWidth("100px").setKey("email");

		grid.addThemeVariants(GridVariant.LUMO_ROW_STRIPES, GridVariant.LUMO_COMPACT);
		grid.setColumnReorderingAllowed(false);
	}

	/**
	 * Sets the alert list as grid items
	 * 
	 * @param grid      The grid to populate
	 * @param alertList List of alert types
	 */
	private static void setAlertList(Grid<UserPreferenceVO> grid, List<String> alertList) {
		if (alertList == null || alertList.isEmpty()) {
			grid.setItems(Collections.emptyList());
			return;
		}

		List<UserPreferenceVO> gridItems = alertList.stream().filter(Objects::nonNull).sorted().map(alert -> {
			String[] parts = alert.split("\\|", 2);
			String code = "";
			String description = alert;

			if (parts.length == 2) {
				code = parts[0];
				description = parts[1];
			}

			return UserPreferenceVO.builder().alertTypeName(description).alertsTypeCode(code).email(false).sms(false)
					.build();
		}).collect(Collectors.toList());

		grid.setItems(gridItems);
		grid.setAllRowsVisible(true);
		grid.addThemeVariants(GridVariant.LUMO_ROW_STRIPES);
	}

	/**
	 * Updates the grid with user preference data from response
	 * 
	 * @param Grid to be updated
	 * @param alertTypeMap    Map of alert codes to alert type names
	 * @param userPreferences List of parsed user preferences
	 */
	public static void updateGridWithPreferences(Grid<UserPreferenceVO> grid, Map<String, String> alertTypeMap,
			List<UserPreferenceVO> userPreferences) {

		if (grid == null || !(grid.getDataProvider() instanceof ListDataProvider)) {
			return;
		}

		if (alertTypeMap == null || userPreferences == null || userPreferences.isEmpty()) {
			return;
		}

		List<UserPreferenceVO> gridItems = ((ListDataProvider<UserPreferenceVO>) grid.getDataProvider()).getItems()
				.stream().collect(Collectors.toList());

		Map<String, UserPreferenceVO> preferencesMap = userPreferences.stream()
				.filter(pref -> pref.getAlertsTypeCode() != null).collect(Collectors.toMap(
						UserPreferenceVO::getAlertsTypeCode, Function.identity(), (existing, replacement) -> existing));

		Map<String, String> reverseAlertMap = alertTypeMap.entrySet().stream()
				.collect(Collectors.toMap(Map.Entry::getValue, Map.Entry::getKey, (existing, replacement) -> existing));

		boolean updated = false;

		for (UserPreferenceVO item : gridItems) {
			String alertName = item.getAlertTypeName();
			String alertCode = reverseAlertMap.get(alertName);

			if (alertCode != null && preferencesMap.containsKey(alertCode)) {
				UserPreferenceVO pref = preferencesMap.get(alertCode);
				boolean emailChanged = !Objects.equals(item.getEmail(), pref.getEmail());
				boolean smsChanged = !Objects.equals(item.getSms(), pref.getSms());

				if (emailChanged || smsChanged || item.getAlertsTypeCode() == null) {
					item.setEmail(pref.getEmail());
					item.setSms(pref.getSms());
					item.setAlertsTypeCode(alertCode);
					updated = true;
				}
			}
		}

		if (updated) {
			grid.setItems(gridItems);
			grid.getDataProvider().refreshAll();
		}
	}

	/**
	 * Creates a checkbox for SMS or Email preference
	 * 
	 * @param item  The preference item
	 * @param grid  The grid containing the item
	 * @param isSms Whether this is an SMS checkbox (true) or Email checkbox (false)
	 * @return Configured checkbox component
	 */
	private static Checkbox createCheckbox(UserPreferenceVO item, Grid<UserPreferenceVO> grid, boolean isSms) {
		Checkbox checkbox = new Checkbox();

		boolean initialValue = isSms ? Boolean.TRUE.equals(item.getSms()) : Boolean.TRUE.equals(item.getEmail());

		checkbox.setValue(initialValue);

		checkbox.addValueChangeListener(event -> {
			if (isSms) {
				item.setSms(event.getValue());
			} else {
				item.setEmail(event.getValue());
			}

			grid.getDataProvider().refreshItem(item);
		});

		return checkbox;
	}

	/**
	 * Find alert code by its name in the mapping
	 * 
	 * @param alertTypeMap The mapping of codes to names
	 * @param alertName    The alert name to search for
	 * @return The corresponding alert code or null if not found
	 */
	private static String findAlertCodeByName(Map<String, String> alertTypeMap, String alertName) {
		if (alertName == null || alertTypeMap == null) {
			return null;
		}

		return alertTypeMap.entrySet().stream().filter(entry -> alertName.equals(entry.getValue()))
				.map(Map.Entry::getKey).findFirst().orElse(null);
	}
}
