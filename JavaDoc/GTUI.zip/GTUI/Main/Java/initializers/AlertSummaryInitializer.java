package com.ebtedge.fns.gateway.initializers;

import com.ebtedge.fns.gateway.model.AlertSummaryVO;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.data.renderer.LitRenderer;

public class AlertSummaryInitializer {

public static void initializeGrid(Grid<AlertSummaryVO> grid) {
		
		setGridEmptyState(grid);
		grid.addColumn(AlertSummaryVO::getRownumbers)
				.setHeader("Row #")
				.setAutoWidth(true)
				.setHeaderPartName("row-num-header")
		        .setPartNameGenerator(item -> "row-num");
		grid.addColumn(AlertSummaryVO::getAlertDateTime)
				.setHeader("Alert Date/Time ")
				.setAutoWidth(true)
				.setSortProperty("alert_timestamp")
				.setSortable(true)
			    .setHeaderPartName("grid-alert-datetime-header")
	           .setPartNameGenerator(item -> "grid-alert-datetime");
		grid.addColumn(AlertSummaryVO::getAlertid)
				.setHeader("Alert ID")
				.setAutoWidth(true)
				.setSortable(true)
				.setSortProperty("alertid")
				.setHeaderPartName("grid-alert-id-header")
		        .setPartNameGenerator(item -> "grid-alert-id");
		grid.addColumn(AlertSummaryVO::getCardNumber)
				.setHeader("Card #")
				.setAutoWidth(true)
				.setSortable(true)
				.setSortProperty("card_number")
		    	.setHeaderPartName("grid-card-num-header")
		        .setPartNameGenerator(item -> "grid-card-num");
		grid.addColumn(AlertSummaryVO::getFnsNumber)
				.setHeader("FNS #")
				.setAutoWidth(true)
				.setSortable(true)
				.setSortProperty("fns_number")
				.setHeaderPartName("grid-fns-num-header")
		        .setPartNameGenerator(item -> "grid-fns-num");
		grid.addColumn(AlertSummaryVO::getTerminalId)
				.setHeader("Terminal ID")
				.setAutoWidth(true)
				.setSortable(true)
				.setSortProperty("terminal_id")
				.setHeaderPartName("grid-term-id-header")
		        .setPartNameGenerator(item -> "grid-term-id");
		grid.addColumn(AlertSummaryVO::getRuleName)
				.setHeader("Rule Name")
				.setAutoWidth(true)
				.setSortable(true)
				.setSortProperty("rule")
				.setHeaderPartName("grid-rule-name-header")
		        .setPartNameGenerator(item -> "grid-rule-name");
		grid.addColumn(AlertSummaryVO::getAlertContent)
				.setHeader("Alert Content")
				
				.setSortable(true)
				.setSortProperty("alert_details")
				.setHeaderPartName("grid-alert-content-header")
		      .setPartNameGenerator(item -> "grid-alert-content");
		grid.addColumn(AlertSummaryVO::getEmail)
				.setHeader("Email")
				.setAutoWidth(true)
				.setSortable(true)
				.setSortProperty("email_details")
				.setHeaderPartName("grid-email-header")
		       .setPartNameGenerator(item -> "grid-email");
		grid.addColumn(AlertSummaryVO::getPhone)
				.setHeader("Phone")
				.setAutoWidth(true)
				.setSortable(true)
				.setSortProperty("mobile_details")
				.setHeaderPartName("grid-phone-header")
		       .setPartNameGenerator(item -> "grid-phone");
		grid.addThemeVariants(GridVariant.LUMO_ROW_STRIPES, GridVariant.LUMO_COMPACT,GridVariant.LUMO_WRAP_CELL_CONTENT);
	    grid.setVisible(false);
	    grid.setSizeFull();
	   
       
	}

	/**
	 * Initializes grid empty state
	 *
	 * @param grid
	 */
	private static void setGridEmptyState(Grid<AlertSummaryVO> grid) {
	    Div emptyGrid = new Div();
	    emptyGrid.add("***** No data present for the given search criteria *****");
	    emptyGrid.addClassNames("empty-grid");
	    grid.setEmptyStateComponent(emptyGrid);
	}

}
