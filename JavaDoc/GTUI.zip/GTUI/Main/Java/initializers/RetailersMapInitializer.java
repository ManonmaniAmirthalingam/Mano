package com.ebtedge.fns.gateway.initializers;

import com.ebtedge.fns.gateway.model.RetailerMapVO;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.html.Div;

public class RetailersMapInitializer {

    /**
     * Initializes the grid with columns and settings.
     *
     * @param grid The grid to initialize.
     */
    public static void initializeGrid(Grid<RetailerMapVO> grid) {
        setGridEmptyState(grid);

        grid.addColumn(RetailerMapVO::getLasttxn_ts)
                .setAutoWidth(true).setHeader("Transaction Timestamp")
                .setSortable(true).setSortProperty("lasttxn_ts");

        grid.addColumn(RetailerMapVO::getColorCode)
                .setAutoWidth(true).setHeader("Color Code Group")
                .setSortable(true).setSortProperty("lasttxn_ts");

        grid.addColumn(RetailerMapVO::getStore_name)
                .setAutoWidth(true).setHeader("Retailer Name")
                .setSortable(true).setSortProperty("store_name");

        grid.addColumn(RetailerMapVO::getLoc_number)
                .setAutoWidth(true).setHeader("Street Number")
                .setSortable(true).setSortProperty("loc_number");

        grid.addColumn(RetailerMapVO::getStndrd_st_addr)
                .setAutoWidth(true).setHeader("Street Name")
                .setSortable(true).setSortProperty("stndrd_st_addr");

        grid.addColumn(RetailerMapVO::getLoc_city)
                .setAutoWidth(true).setSortProperty("loc_city")
                .setSortable(true).setHeader("City");

        grid.addColumn(RetailerMapVO::getCounty_name)
                .setAutoWidth(true).setHeader("County")
                .setSortable(true).setSortProperty("county_name");

        grid.addColumn(RetailerMapVO::getStndrd_zip_code)
                .setAutoWidth(true).setSortProperty("stndrd_zip_code")
                .setSortable(true).setHeader("Zip Code");

        grid.addColumn(RetailerMapVO::getLoc_state)
                .setAutoWidth(true).setSortProperty("loc_state")
                .setSortable(true).setHeader("State");

        grid.addColumn(RetailerMapVO::getBusinesstype)
                .setAutoWidth(true).setSortProperty("businesstype")
                .setSortable(true).setHeader("Store Type");

        grid.addColumn(RetailerMapVO::getFns_number)
                .setAutoWidth(true).setSortProperty("fns_number")
                .setSortable(true).setHeader("FNS #");

        grid.setVisible(false);
        grid.addThemeVariants(GridVariant.LUMO_ROW_STRIPES, GridVariant.LUMO_COMPACT, GridVariant.LUMO_WRAP_CELL_CONTENT);
}

    /**
     * Sets the empty state for the grid.
     *
     * @param grid The grid to set the empty state for.
     */
    private static void setGridEmptyState(Grid<RetailerMapVO> grid) {
        Div emptyGrid = new Div();
        emptyGrid.add("***** No data present for the given search criteria *****");
        emptyGrid.addClassNames("empty-grid");
        grid.setEmptyStateComponent(emptyGrid);
    }
}
