package com.ebtedge.fns.gateway.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents the data structure for the System Health Monitoring (SHM) Dashboard View Object. This
 * class serves as a container for organizing and encapsulating various monitoring grid data such as
 * links, gateways, systems, and state bins.
 *
 * <p>The class uses Lombok annotations for generating boilerplate methods such as getters, setters,
 * builders, and constructors. It adopts a hierarchical approach to aggregate monitoring data.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ShmDashboardVO {
    @Builder.Default private List<ShmLinkGridVO> links = new ArrayList<>();
    @Builder.Default private List<ShmGatewayGridVO> gateways = new ArrayList<>();
    @Builder.Default private List<ShmSystemGridVO> system = new ArrayList<>();
    @Builder.Default private List<ShmStateBinGridVO> states = new ArrayList<>();
}
