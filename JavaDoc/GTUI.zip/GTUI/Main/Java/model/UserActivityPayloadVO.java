package com.ebtedge.fns.gateway.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

/**
 * UserActivityPayloadVO is a value object that represents the payload data
 * associated with user activity.
 */
@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserActivityPayloadVO {
    private String startTs;
    private String endTs;
    private String srchUsrId;
    private String isSrchUsrIdWildcard;
    private String srchUsrFname;
    private String isSrchUsrFnameWildcard;
    private String srchUsrLname;
    private String isSrchUsrLnameWildcard;
    private String isSrchAllUsr;
    private String srchUsrType;
    private String ipAddress;
    private String appUserId;
    private String appUserFirstName;
    private String appUserMidName;
    private String appUserLastName;
    private String appUserEmail;
    private String appUserType;
    private String appServer;
    private String searchType;
    private String startRow;
    private String endRow;
    private String sortBy;
    private String sortField;
    private String state;
    private String agency;
    private String cardnumber;
    private String fnsnumber;
    private String storetype;
    private String terminalid;
    private String cardaccptrname;
    private String trnsctntype;
    private String trnsctn_amount_from;
    private String trnsctn_amount_to;
    private String appusername;
    private String isCardNumberWildcard;
    private String isFnsNumberWildcard;
    private String isTerminalIdWildcard;
    private String isCardAccptrNameWildcard;
    private String minFraudScore;
    private String maxFraudScore;
    private String entryMode;
    private String isOutOfStateTxn;
    private String isInternetTxn;
    private String isOnlyAlert;
    private String is24HrStore;
    private String isEvenDollarTxn;
    private String rule;
    private String scoreStart;
    private String scoreEnd;
    private String scoreType;
}
