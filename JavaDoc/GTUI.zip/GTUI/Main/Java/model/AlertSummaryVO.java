package com.ebtedge.fns.gateway.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AlertSummaryVO {

	private String alertid;
	private String alertDateTime;
	private String email;
	private String phone;
	private String cardNumber;
	private String fnsNumber;
	private String terminalId;
	private String alertContent;
	private String ruleName;
	private Integer rownumbers;
	
	
}
