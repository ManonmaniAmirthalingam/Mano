package com.ebtedge.fns.gateway.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Represents the System Health Monitoring (SHM) Link Grid View Object. This class serves as a
 * specialized implementation of the {@link BaseShmGridVO}, extending its attributes and behaviors
 * specific to link-related monitoring data.
 *
 * <p>This object is used in system health dashboards to provide a representation of links and their
 * corresponding status, metrics, and other related details within a grid structure.
 *
 * <p>The class leverages Lombok annotations to minimize boilerplate code for getter, setter,
 * equals, hashCode, and constructors.
 *
 * <p>It supports features such as hierarchical data representation and rule violation tracking as
 * inherited from the {@link BaseShmGridVO}.
 */
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@SuperBuilder
public class ShmLinkGridVO extends BaseShmGridVO {}
