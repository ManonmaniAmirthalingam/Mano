/*
 * package com.ebtedge.fns.gateway.model;
 * 
 * import lombok.AllArgsConstructor; import lombok.Builder; import lombok.Data;
 * import lombok.NoArgsConstructor;
 * 
 * import java.time.LocalDate; import java.time.LocalTime; import java.util.Set;
 * 
 * 
 * @Data
 * 
 * @AllArgsConstructor
 * 
 * @NoArgsConstructor
 * 
 * @Builder public class SearchCriteria {
 * 
 * private String card;
 * 
 * private String fnsNumber;
 * 
 * private String terminalId;
 * 
 * private Set<String> states;
 * 
 * private String score;
 * 
 * private LocalDate startDate;
 * 
 * private LocalDate endDate;
 * 
 * private Set<String> flags; private LocalTime startTime;
 * 
 * private LocalTime endTime;
 * 
 * 
 * public String getState(){ String[] array = (String[]) this.states.toArray();
 * return array[0]; }
 * 
 * 
 * }
 */