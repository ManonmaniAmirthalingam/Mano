package com.ebtedge.fns.gateway.model;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * UserActivityGridSort is a value object that represents the user activity grid sort information.
 */
@Data
@AllArgsConstructor
public class UserActivityGridSort {

    private String propertyName;

    private boolean descending;
}
