package com.ebtedge.fns.gateway.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.util.Assert;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

/**
 * Query class for Transaction search SQL function
 *
 * @author e3023044
 * @version 1.0.0
 * @since 1.0.0
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TranSearchCriteria {

    private String card;

    private String isCardNumberWildcard;

    private String fnsNumber;

    private String isFnsNumberWildcard;

    private String terminalId;

    private String isTerminalIdWildCard;

    private Set<String> states;

    private String score;

    private DateTimeRange dateTimeRange;

    private Set<String> flags;

    private String minScore;

    private String maxScore;

    private Set<String> businessType;

    private String isOutOfStateTran;

    private String isInternetTran;

    private String isOnlyAlertOnlyTran;

    private String is24HourStores;

    private String isEvenDollarTran;

    private String sortBy;

    private String sortByField;

    private String ipAddress;

    private String userId;

    private String firstName;

    private String middleName;

    private String lastName;

    private String email;

    private String appServer;

    private String searchType;

    private List<TranSummaryGridSort> gridSort;

    public LocalDateTime getStartDate() {
        Assert.notNull(dateTimeRange, "dateTimeRange must not be null");
        return dateTimeRange.getStart();
    }
    public LocalDateTime getEndDate() {
        Assert.notNull(dateTimeRange, "dateTimeRange must not be null");
        return dateTimeRange.getEnd();
    }
    
    public TranSearchCriteria toExportCriteria() {
        TranSearchCriteria exportCriteria = new TranSearchCriteria();
        exportCriteria.setCard(this.card);
        exportCriteria.setFnsNumber(this.fnsNumber);
        exportCriteria.setTerminalId(this.terminalId);
        exportCriteria.setDateTimeRange(this.dateTimeRange != null ? 
            new DateTimeRange(this.dateTimeRange.getStart(), this.dateTimeRange.getEnd()) : null);
        exportCriteria.setMinScore(this.minScore);
        exportCriteria.setMaxScore(this.maxScore);    

        if (this.states != null) {
            exportCriteria.setStates(new java.util.HashSet<>(this.states));
        }
        if (this.flags != null) {
            exportCriteria.setFlags(new java.util.HashSet<>(this.flags));
        }
        if (this.businessType != null) {
            exportCriteria.setBusinessType(new java.util.HashSet<>(this.businessType));
        }
        if (this.gridSort != null) {
            exportCriteria.setGridSort(new java.util.ArrayList<>(this.gridSort));
        }
      
        return exportCriteria;
    }
}
