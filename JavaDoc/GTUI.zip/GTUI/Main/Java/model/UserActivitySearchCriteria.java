package com.ebtedge.fns.gateway.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.util.Assert;

import java.time.LocalDateTime;
import java.util.List;

/**
 * UserActivitySearchCriteria is a model class that encaps
 * the search criteria for user activity.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserActivitySearchCriteria {

    private String userId;
    private String firstName;
    private String lastName;
    private DateTimeRange dateTimeRange;
    private String searchType;
    private List<UserActivityGridSort> gridSort;

    public LocalDateTime getStartDate() {
        Assert.notNull(dateTimeRange, "dateTimeRange must not be null");
        return dateTimeRange.getStart();
    }
    public LocalDateTime getEndDate() {
        Assert.notNull(dateTimeRange, "dateTimeRange must not be null");
        return dateTimeRange.getEnd();
    }
    
    public UserActivitySearchCriteria toExportCriteria() {
        UserActivitySearchCriteria searchCriteria = new UserActivitySearchCriteria();      
        searchCriteria.setUserId(this.userId);
        searchCriteria.setFirstName(this.firstName);
        searchCriteria.setLastName(this.lastName);
        searchCriteria.setDateTimeRange(this.dateTimeRange != null ? 
            new DateTimeRange(this.dateTimeRange.getStart(), this.dateTimeRange.getEnd()) : null);
        
        if (this.gridSort != null) {
            searchCriteria.setGridSort(new java.util.ArrayList<>(this.gridSort));
        }
        
        return searchCriteria;
    }
}

