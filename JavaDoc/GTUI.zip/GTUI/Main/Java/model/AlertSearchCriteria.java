package com.ebtedge.fns.gateway.model;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.util.Assert;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AlertSearchCriteria {
	
	private String alertId;

    private String card;

    private String terminalId;
    
    private String fnsNumber;
    
    private Set<String> ruleName;

    private DateTimeRange dateTimeRange;
    
    private String endrow;
    
    private String isCardNumberWildcard;

    private String searchType;
    
    private List<AlertSummaryGridSort> gridSort;

    @JsonProperty("ipaddress")
    private String ipAddress;

    @JsonProperty("appuserid")
    private String appUserid;

    @JsonProperty("appuserfirstname")
    private String appUserFirstName;

    @JsonProperty("appusermidname")
    private String appUserMidName;

    @JsonProperty("appuserlastname")
    private String appUserLastName;

    @JsonProperty("appuseremail")
    private String appUserEmail;

    @JsonProperty("appserver")
    private String appServer;

    public LocalDateTime getStartDate() {
        Assert.notNull(dateTimeRange, "dateTimeRange must not be null");
        return dateTimeRange.getStart();
    }
    public LocalDateTime getEndDate() {
        Assert.notNull(dateTimeRange, "dateTimeRange must not be null");
        return dateTimeRange.getEnd();
    }
    
    public AlertSearchCriteria toExportCriteria() {
        AlertSearchCriteria searchCriteria = new AlertSearchCriteria();
        searchCriteria.setAlertId(this.alertId);
        searchCriteria.setCard(this.card);
        searchCriteria.setFnsNumber(this.fnsNumber);
        searchCriteria.setDateTimeRange(this.dateTimeRange != null ? 
            new DateTimeRange(this.dateTimeRange.getStart(), this.dateTimeRange.getEnd()) : null);
        searchCriteria.setTerminalId(this.terminalId);
        if (this.ruleName != null) {
            searchCriteria.setRuleName(new java.util.HashSet<>(this.ruleName));
        }
        if (this.gridSort != null) {
            searchCriteria.setGridSort(new java.util.ArrayList<>(this.gridSort));
        }    
        return searchCriteria;
    }
}