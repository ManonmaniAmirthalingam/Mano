package com.ebtedge.fns.gateway.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Represents the System Health Monitoring (SHM) State Bin Grid View Object. This class is a
 * specialized implementation of {@link BaseShmGridVO}, adding attributes specific to monitoring
 * state bins within the system health context.
 *
 * <p>The {@code ShmStateBinGridVO} class introduces the {@code bin} property, which is used to
 * identify a specific bin being monitored at the state level.
 *
 * <p>It inherits all the attributes and functionalities of {@link BaseShmGridVO}, including shared
 * attributes like ID, name, health status, and rule violations, and adds another layer of
 * specialization tailored to state bin monitoring use cases.
 *
 * <p>This class is typically used in system dashboards to represent state-level bin data in a grid
 * structure, enabling better organization and presentation of monitoring metrics.
 */
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@SuperBuilder
public class ShmStateBinGridVO extends BaseShmGridVO {
    private String state;

    public String getBin() {
        return getEntity();
    }

    @Override
    public String getName() {
        return state;
    }
}
