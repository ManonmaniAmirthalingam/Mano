package com.ebtedge.fns.gateway.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class RedeGridVO {
	private String state;
	private String agency;
	private String dateinfo;
	private String fns_number;
	private String terminal_id;
	private String name_score;
	private String address_score;
	private String city_score;
	private String state_score;
	private String zip_score;
	private String final_score;
	private String score_1;
	private String score_2;
	private String score_3;
	private String score_4;
	private String status;
	private String last_foodstamp_ts;
	private String last_cash_ts;
	private String status_update_ts;
	private String score_update_ts;
	private String last_mod_ts;
	private String rede_acceptor_name;
	private String rede_acceptor_address;
	private String rede_acceptor_city;
	private String rede_acceptor_state;
	private String rede_acceptor_zip;
	private String geocode_latitude;
	private String geocode_longitude;
	private String txn_acceptor_name;
	private String txn_acceptor_address;
	private String txn_acceptor_city;
	private String txn_acceptor_state;
	private String txn_acceptor_zip;
	private String geocode_address;
	private String last_mod_by;
	private Integer rownumbers;
	private String total_row_count;
}
