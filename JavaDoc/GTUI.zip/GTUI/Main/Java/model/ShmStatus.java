package com.ebtedge.fns.gateway.model;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.theme.lumo.LumoUtility;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Represents the health status of a component in the System Health Monitoring (SHM) framework. The
 * status can be either "Healthy" or "Unhealthy", and is associated with a displayable UI component.
 *
 * <p>The enum provides a mechanism for generating a visual representation of the health status with
 * distinct styles and icons, enabling it to be rendered in a UI context.
 *
 * <p>Enum Constants: - HEALTHY: Indicates that the component is in a healthy state. - UNHEALTHY:
 * Indicates that the component is in an unhealthy state.
 *
 * <p>Key Features: - Each status has an associated string value that can be retrieved with
 * `getValue`. - Provides a method to generate a styled UI component (`getDisplayComponent`)
 * representing the status.
 *
 * <p>Display Component: - HEALTHY includes a success badge with a "check" icon. - UNHEALTHY
 * includes an error badge with an "exclamation circle" icon.
 *
 * <p>This class employs the Lombok annotations: - {@code @Getter}: Generates getter methods for all
 * fields. - {@code @AllArgsConstructor}: Generates a constructor to initialize all fields.
 */
@Getter
@AllArgsConstructor
public enum ShmStatus {
    HEALTHY("No Events"),
    UNHEALTHY("Events");

    private final String value;

    public Component getDisplayComponent() {
        Icon icon;
        String className;
        switch (this) {
            case HEALTHY -> {
                icon = VaadinIcon.CHECK.create();
                className = "badge success";
            }
            case UNHEALTHY -> {
                icon = VaadinIcon.EXCLAMATION_CIRCLE_O.create();
                className = "badge error";
            }
            default -> throw new IllegalStateException("Unhandled value: " + this);
        }
        icon.addClassName(LumoUtility.Padding.XSMALL);
        var component = new Span(icon, new Span(getValue()));
        component.getElement().getThemeList().add(className);
        return component;
    }
}
