package com.ebtedge.fns.gateway.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Represents a specialized grid view object in the System Health Monitoring (SHM) domain, focusing
 * specifically on gateway data. This class extends the base functionality of {@link BaseShmGridVO}
 * to provide gateway-specific properties or behaviors.
 *
 * <p>As a subclass of {@link BaseShmGridVO}, this class inherits all shared attributes and methods,
 * while also allowing for additional customization as needed for gateway monitoring.
 *
 * <p>The class utilizes Lombok annotations such as {@code @Data}, {@code @SuperBuilder}, and
 * {@code @EqualsAndHashCode} to reduce boilerplate code by automatically generating utility
 * methods, including getters, setters, equals, and hashCode.
 */
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@SuperBuilder
public class ShmGatewayGridVO extends BaseShmGridVO {}
