package com.ebtedge.fns.gateway.model;

import java.util.*;

import com.ebtedge.fns.gateway.rule.shm.ShmRuleViolation;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Represents the base structure for System Health Monitoring (SHM) grid views, serving as a
 * foundation for more specialized grid view objects. This class encapsulates shared attributes and
 * provides a flexible hierarchy for representing system health-related data in grid formats.
 *
 * <p>This class leverages Lombok annotations to reduce boilerplate code, such as getters, setters,
 * equals, hashCode, and constructors.
 *
 * <p>The type is part of a broader hierarchy where specific implementations extend this base class
 * and introduce additional fields or behaviors as needed.
 */
@Data
@SuperBuilder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
public class BaseShmGridVO {
    @EqualsAndHashCode.Include private String entity;
    private ShmStatus healthStatus;
    private int count;
    @Builder.Default private Set<ShmRuleViolation> ruleViolations = new HashSet<>();
    private boolean subtype;
    @Builder.Default private List<? extends BaseShmGridVO> children = new ArrayList<>();

    public String getName() {
        return entity;
    }
}
