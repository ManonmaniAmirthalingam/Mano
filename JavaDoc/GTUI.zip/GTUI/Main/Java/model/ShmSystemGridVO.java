package com.ebtedge.fns.gateway.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Represents the System Health Monitoring (SHM) System Grid View Object. This class is a
 * specialized implementation of the {@link BaseShmGridVO}, extending its attributes and behaviors
 * specific to system-related monitoring data.
 *
 * <p>This object is utilized to represent system-level health data in grid structures within the
 * context of system health monitoring dashboards.
 *
 * <p>The class inherits features from {@link BaseShmGridVO}, such as hierarchical data
 * representation, rule violation tracking, and other shared attributes. It also enables seamless
 * integration into a structured and extendable hierarchy for grid-based system health
 * visualizations.
 *
 * <p>This class uses Lombok annotations to reduce boilerplate code and provides generated methods
 * for common object operations like getters, setters, equals, and hashCode.
 */
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@SuperBuilder
public class ShmSystemGridVO extends BaseShmGridVO {}
