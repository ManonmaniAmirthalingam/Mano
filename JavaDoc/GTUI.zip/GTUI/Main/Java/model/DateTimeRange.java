package com.ebtedge.fns.gateway.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Represents a time period defined by start and end date-time values.
 * This class is typically used for specifying date-time ranges in search criteria,
 * filtering, and other time-based operations.
 *
 * <p>The range is defined by two {@link LocalDateTime} objects representing the start
 * and end points of the period. Either value can be null, representing an open-ended
 * range in that direction.</p>
 *
 * It provides getter and setter methods through Lombok's {@code @Data} annotation.</p>
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DateTimeRange {

    /**
     * The starting date and time of the range.
     * Can be null to indicate no lower bound.
     */
    private LocalDateTime start;

    /**
     * The ending date and time of the range.
     * Can be null to indicate no upper bound.
     */
    private LocalDateTime end;
}