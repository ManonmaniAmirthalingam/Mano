
package com.ebtedge.fns.gateway.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.util.Assert;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RedeSearchCriteria {

    private String fnsNumber;

    private String isFnsNumberWildcard;

    private String terminalId;

    private String isTerminalIdWildCard;

    private Set<String> scoreType;

    private String score;

    private String minScore;

    private String maxScore;

    private DateTimeRange dateTimeRange;

    private String scoreStart; // Add this field

    private String scoreEnd; // Add this field

    private List<RedeSummaryGridSort> gridSort;

    private String searchType;
    
    private String status;
    
    private Boolean myItems;

    public LocalDateTime getStartDate() {
        Assert.notNull(dateTimeRange, "dateTimeRange must not be null");
        return dateTimeRange.getStart();
    }
    public LocalDateTime getEndDate() {
        Assert.notNull(dateTimeRange, "dateTimeRange must not be null");
        return dateTimeRange.getEnd();
    }
    
    public RedeSearchCriteria toExportCriteria() {
        RedeSearchCriteria searchCriteria = new RedeSearchCriteria();   
        searchCriteria.setFnsNumber(this.fnsNumber);
        searchCriteria.setTerminalId(this.terminalId);
        searchCriteria.setMinScore(this.minScore);
        searchCriteria.setMaxScore(this.maxScore);
        searchCriteria.setDateTimeRange(this.dateTimeRange != null ? 
            new DateTimeRange(this.dateTimeRange.getStart(), this.dateTimeRange.getEnd()) : null);
        
        if (this.scoreType != null) {
            searchCriteria.setScoreType(new java.util.HashSet<>(this.scoreType));
        }
        if (this.gridSort != null) {
            searchCriteria.setGridSort(new java.util.ArrayList<>(this.gridSort));
        }
        searchCriteria.setStatus(this.status);
        searchCriteria.setMyItems(this.myItems); 
        
        return searchCriteria;
    } 
    
}
