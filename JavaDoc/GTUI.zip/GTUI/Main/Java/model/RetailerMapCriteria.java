package com.ebtedge.fns.gateway.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RetailerMapCriteria {

    private String fnsnumber;
    private String is_fnsnumber_wildcard;
    private Set<String> storetype;
    private String merchantname;
    private String is_merchantname_wildcard;
    private String storelatitude_strt;
    private String storelongitude_strt;
    private String storelatitude_end;
    private String storelongitude_end;
    private String merchantaddress;
    private String county_name;
    private String merchantcity;
    private String merchantstate;
    private String merchantzip;
    private String ipaddress;
    private String appuserid;
    private String appuserfirstname;
    private String appusermidname;
    private String appuserlastname;
    private String appuseremail;
    private String appusertype;
    private String appserver;
    private String searchtype;
    private String startrow;
    private String endrow;
    private String sortby;
    private String sortfield;

    private int selectedDays;

    private List<RetailerMapSort> gridSort;
}
