package com.ebtedge.fns.gateway.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AlertSummaryGridSort {

	  private String propertyName;
	  private boolean descending;

}
