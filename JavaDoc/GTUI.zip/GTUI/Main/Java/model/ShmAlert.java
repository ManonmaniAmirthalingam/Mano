package com.ebtedge.fns.gateway.model;

import lombok.Data;
import org.jetbrains.annotations.NotNull;

import java.time.Instant;

/**
 * Represents an alert in the System Health Monitoring (SHM) framework. This class encapsulates
 * details about an alert, including its timestamp, trigger identifier, associated entity, and a
 * message describing the alert.
 *
 * <p>Instances of this class are comparable based on their timestamps to facilitate sorting and
 * ordering of alerts in chronological order.
 *
 * <p>Lombok annotations, such as {@code @Data}, are used for generating boilerplate methods like
 * getters, setters, toString, equals, and hashCode.
 */
@Data
public class ShmAlert implements Comparable<ShmAlert> {
    private Instant timestamp;
    private String alertTriggerId;
    private String alertEntity;
    private String alertMsg;

    @Override
    public int compareTo(@NotNull ShmAlert o) {
        if (timestamp == null) return -1;
        if (o.timestamp == null) return 1;
        return timestamp.compareTo(o.timestamp);
    }
}
