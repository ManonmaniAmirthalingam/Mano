package com.ebtedge.fns.gateway.model;

import lombok.Builder;
import lombok.Data;

/***
 * Bean class for holding Grid transaction summary and detail data.
 *
 * @author e3023044
 * @version 1.0.0
 * @since 1.0.0
 */
@Data
@Builder
public class FinancialTranVO {

    // Summary fields

    /**
     * Transaction Timestamp. Computed field from DE012 + DE013
     */
    private String tranTs;

    /**
     * card acceptor name. Mapped from DE048.
     */
    private String merchantName;

    /**
     * Card Acceptor address. Extracted field from DE042
     */
    private String merchantAddress;

    /**
     * Card Acceptor City. Extracted field from DE042
     */
    private String merchantCity;

    /**
     * Card Acceptor state. Extracted field from DE042
     */
    private String merchantState;

    /**
     * Transaction Amount. Mapped from DE004
     */
    private String tranAmount;

    /**
     * Transaction response/status indicates whether transaction was approved or rejected. Mapped from DE39
     */
    private String responseCode;

    /**
     * Transaction response/status description indicates whether transaction was approved or rejected
     */
    private String responseCodeDesc;

    /**
     * FNS Number. Extracted field from DE111.
     */
    private String fnsNumber;

    /**
     * Card Number. Mapped from DE002
     */
    private String cardNumber;

    /**
     * Terminal Id, mapped from DE041
     */
    private String terminalId;


    /**
     * Transaction description code. Just short code for DE003
     */
    private String tranTypeCode;


    /**
     * Transaction Type description. Mapped from ProcessingCode ( DE003)
     */

    private String tranTypeDesc;

    /**
     * Business Type code
     */
    private String businessTypeCode;

    /**
     * Business Type description
     */
    private String businessTypeDesc;

    /**
     * Fraud Score, calculated by FN
     */
    private String fraudScore;

    /**
     * Alert Flag, computed column on DB side based on the alert data.
     */
    private String alertFlag;

    /**
     * Alert flag description
     */
    private String alertFlagDesc;

    // Details fields - Tran Info tab.

    /**
     * Terminal class. Extracted field from DE058
     */
    private String terminalClass;

    /**
     * Presentation Data, extracted field from DE058
     */
    private String presentationData;

    /**
     * Security condition code. Position 8 from DE058
     */
    private String secCondCode;

    /**
     * security condition code description.
     */
    private String secCondCodeDesc;


    /**
     * Terminal Type code. Extracted field from DE058
     */
    private String terminalTypeCode;

    /**
     * Terminal Type description
     */
    private String terminalTypeDesc;


    /**
     * Terminal Type capability code. Extracted field from DE058
     */
    private String terminalCapabilityCode;

    /**
     * POS entry mode. Extracted field from DE22
     */
    private String posEntryMode;


    /**
     * POS geographic zipcode. Extracted field from DE059
     */
    private String posLocZipcode;

    /**
     * Internet Delivery Address. Extracted field from DE111.
     */
    private String intDeliveryAddr;

    /**
     * Internet Delivery City. Extracted field from DE111
     */
    private String intDeliveryCity;

    /**
     * Internet Delivery state. Extracted field from DE111
     */
    private String intDeliveryState;

    /**
     * Internet Delivery zip. Extracted field from DE111
     */
    private String intDeliveryZip;

    /**
     * Internet Delivery shipping indicator code. Extracted field from DE111
     */
    private String intDeliveryShippingIndCode;

    /**
     * Internet Delivery shipping indicator description. Extracted field from DE111
     */
    private String intDeliveryShippingIndDesc;


    /**
     * Acquiring institution identification code. Mapped from DE32
     */
    private String acqInstIdentificationCode;


    /**
     * Acquiring institution identification code. Mapped from DE032
     */
    private String acqInstIdentificationDesc;


    /**
     * Food beginning balance. Extracted field from DE054
     */
    private String foodBeginningBal;


    /**
     * Food Ending balance. Extracted field from DE054
     */
    private String foodEndingBal;


    /**
     * Surcharge Amount. Extracted field from DE054
     */
    private String surchargeAmount;


    /**
     * Incentive Eligible. Extracted field from DE054
     */
    private String incentiveEligible;


    /**
     * Incentive Earned. Extracted field from DE054
     */
    private String incentiveEarned;


    /**
     * Incentive MTD. Extracted field from DE054
     */
    private String incentiveMTD;

    /**
     * Merchant  REDE Name
     */
    private String redeName;

    /**
     * Merchant  REDE number
     */
    private String redeNumber;


    /**
     * Merchant  REDE address number
     */
    private String redeAddressNumber;


    /**
     * Merchant  REDE street name
     */
    private String redeStreetName;

    /**
     * Merchant  REDE additional address
     */
    private String redeAdditionalAddressInfo;

    /**
     * Merchant  REDE city
     */
    private String redeCity;

    /**
     * Merchant  REDE state
     */
    private String redeState;


    /**
     * Merchant  REDE ZIP
     */
    private String redeZip;

    /**
     * Indicates if the stores is open 24 hours
     */
    private String open24HoursFlag;

    /**
     * PAN entry mode code
     */
    private String panEntryModeCode;

    /**
     * PAN Entry mode description
     */
    private String panEntryModeDesc;

    /**
     * PIN Entry Mode Code
     */
    private String pinEntryMode;

    /**
     * PIN Entry Mode code description
     */
    private String pinEntryModeDesc;

    /**
     * Card acceptor Id
     */
    private String cardAcceptorId;

    /**
     * Merchant Category Code
     */
    private String mcc;

    /**
     * Geo state
     */
    private String geoState;


    /**
     * GEO Zip
     */
    private String geoZip;
    
    
    private Integer rownumbers;

}