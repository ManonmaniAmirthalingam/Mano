package com.ebtedge.fns.gateway.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Model class for REDE status update request
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RedeStatusUpdateRequest {
    private String state;
    private String agency;
    private String fnsNumber;
    private String terminalId;
    private String status;
    private String userId;
    private String ipAddress;
    private String searchType;
}
