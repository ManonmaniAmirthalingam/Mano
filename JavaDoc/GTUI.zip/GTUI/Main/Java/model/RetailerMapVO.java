package com.ebtedge.fns.gateway.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class RetailerMapVO {

    private String lasttxn_ts;
    private String colorCode;
    private String store_name;
    private String open24_flag;
    private String county;
    private String county_name;
    private String fcs_type;
    private String businesstype;
    private String loc_number;
    private String loc_address;
    private String loc_city;
    private String loc_state;
    private String loc_zip;
    private String loc_add_addr_info;
    private String stndrd_st_addr;
    private String stndrd_city;
    private String stndrd_state;
    private String stndrd_zip_code;
    private String fns_number;
    private String latitude;
    private String longitude;
    private String total_row_count;
}
