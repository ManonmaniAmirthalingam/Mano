package com.ebtedge.fns.gateway.model;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * Hold transaction grid sort information
 *
 * @author e3023044
 * @version 1.0.0
 * @since 1.0.0
 */
@Data
@AllArgsConstructor
public class TranSummaryGridSort {

    private String propertyName;

    private boolean descending;

}
