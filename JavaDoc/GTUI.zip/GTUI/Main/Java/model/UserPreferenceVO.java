package com.ebtedge.fns.gateway.model;

import java.util.List;

import lombok.Builder;
import lombok.Data;

//the pojo that we are going the map the backend data to ui

@Data
@Builder
public class UserPreferenceVO {
	
	private String emailAddress;
	private String phoneNumber;
	private String alertTypeName;
	private String alertsTypeCode;
	private Boolean sms;
	private Boolean email;
	

}
