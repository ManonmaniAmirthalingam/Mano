package com.ebtedge.fns.gateway.model;

import lombok.Builder;
import lombok.Data;

/**
 * UserActivityGridVO is a value object that represents the user activity data
 * to be displayed in a grid format.
 */
@Data
@Builder
public class UserActivityGridVO {
    private String userActivityTimestamp;
    private String userActivity;
    private String firstName;
    private String middleName;
    private String lastName;
    private String userId;
    private String emailAddress;
    private UserActivityPayloadVO payload;
    private Integer rownumbers;
}
