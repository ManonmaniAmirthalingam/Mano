package com.ebtedge.fns.gateway.config;


import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
@PropertySource("file:${spring.config.location}/tpp-mapping.properties")
public class TppDescMappingConfig {

    private final Environment environment;

    @Autowired
    public TppDescMappingConfig(Environment environment) {
        this.environment = environment;
    }

    public String getDesc(String code) {
        String desc = environment.getProperty(code);
        if (StringUtils.isNotBlank(desc)) {
            return desc;
        }
        return code;
    }

}
