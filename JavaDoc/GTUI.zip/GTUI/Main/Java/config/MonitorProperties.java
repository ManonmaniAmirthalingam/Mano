package com.ebtedge.fns.gateway.config;

import lombok.Data;
import org.springframework.beans.factory.InitializingBean;

import java.time.Duration;
import java.util.Objects;

/**
 * Configuration properties for monitoring various system aspects. This class defines settings
 * related to the monitoring of system health. It ensures the necessary properties are configured
 * and validates their initialization.
 *
 * <p>Implements {@link InitializingBean} to perform validations after all properties are set.
 */
@Data
public class MonitorProperties implements InitializingBean {
    private SystemHealthProperties systemHealth = new SystemHealthProperties();

    @Override
    public void afterPropertiesSet() throws Exception {
        Objects.requireNonNull(systemHealth, "system-health must be configured");
        systemHealth.afterPropertiesSet();
    }

    @Data
    public static class SystemHealthProperties implements InitializingBean {
        private Integer maxPullSize;
        private Duration healthRecoveryDuration = Duration.ofMinutes(5);
        private Duration cacheDataRetentionDuration = Duration.ofMinutes(5);

        @Override
        public void afterPropertiesSet() throws Exception {
            Objects.requireNonNull(maxPullSize, "max-pull-size must be configured");
        }
    }
}
