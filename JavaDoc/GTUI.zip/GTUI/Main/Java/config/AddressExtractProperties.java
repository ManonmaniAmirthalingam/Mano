package com.ebtedge.fns.gateway.config;

import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.InitializingBean;

@Data
public class AddressExtractProperties implements InitializingBean {

    private String streetNumberRegex;
    private String streetNameRegex;

    @Override
    public void afterPropertiesSet() throws Exception {
        if (StringUtils.isBlank(streetNumberRegex))
            throw new IllegalArgumentException("street-number-regex must be configured");
        if (StringUtils.isBlank(streetNameRegex))
            throw new IllegalArgumentException("street-name-regex must be configured");
    }
}
