package com.ebtedge.fns.gateway.config;

import lombok.Data;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.time.Duration;
import java.util.List;
import java.util.Objects;

/**
 * Hold config info for the GAT application. Information would be read from application.yml
 *
 * @author e3023044
 * @version 1.0.0
 * @since 1.0.0
 */
@Configuration
@ConfigurationProperties(prefix = "app-config")
@Data
public class GatAppConfig implements InitializingBean {

    private String gridInitialSize;

    private NotificationProperties notification = new NotificationProperties();

    private String gatsInsightUrl;

    private String logoutUrl;

    private List<BusinessTypes> businessTypes;
    
    private String exportLimit;

    private Duration dataRetentionDuration;
    
    private List<StateCodes> stateCodes;
	
	private List<String> ruleNames; 
	
	private List<String> scoreTypes;
	
	private List<String> redeStatus;
	
	private List<AlertListItem> alertLists;

    private MonitorProperties monitor = new MonitorProperties();

    private AddressExtractProperties addressExtract;

    @Override
    public void afterPropertiesSet() throws Exception {
        Objects.requireNonNull(dataRetentionDuration, "data-retention-duration property must be configured");
        monitor.afterPropertiesSet();
        Objects.requireNonNull(addressExtract, "address-extract property must be configured");
        addressExtract.afterPropertiesSet();
    }

    private String googleMapApikey;

    @Data
    public static class BusinessTypes {
        private String code;
        private String description;
    }

    @Data
    public static class StateCodes {
        private String name;
        private String abbreviation;
    }
	
	@Data
    public static class AlertListItem {
        private String code;
        private String description;
    }

    public static String getBusinessCodeDesc(BusinessTypes businessTypes) {
        return businessTypes.getCode() + " - " + businessTypes.getDescription();
    }

    public static String getNameAndAbbr(StateCodes stateCodes) {
        return stateCodes.getAbbreviation() + " - " + stateCodes.getName();
    }
}
