package com.ebtedge.fns.gateway.config;

import com.vaadin.flow.component.notification.Notification;
import lombok.Data;

/**
 * Configuration properties for managing Vaadin notification display settings.
 * This class provides customizable properties for controlling how notifications
 * are displayed in the user interface.
 *
 * @see com.vaadin.flow.component.notification.Notification
 */
@Data
public class NotificationProperties {

    /**
     * The duration (in milliseconds) for which notifications are displayed.
     * The Default value is 5000 ms (5 seconds).
     */
    private Integer displayDuration = 5000;

    /**
     * The position where notifications will appear on the screen.
     * The Default position is TOP_CENTER.
     *
     * @see com.vaadin.flow.component.notification.Notification.Position
     */
    private Notification.Position position = Notification.Position.TOP_CENTER;
}