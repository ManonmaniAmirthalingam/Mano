package com.ebtedge.fns.gateway.service;

import com.ebtedge.fns.gateway.config.AddressExtractProperties;
import com.ebtedge.fns.gateway.config.GatAppConfig;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Service for extracting addresses. */
@Service
@RequiredArgsConstructor
public class AddressExtractService {
    private final GatAppConfig appConfig;

    private Pattern streetNamePattern;
    private Pattern streetNumberPattern;

    /**
     * Extract street name.
     *
     * @param address a street address
     * @return optional name of the street
     */
    public Optional<String> extractStreetName(String address) {
        return extract(address, streetNamePattern);
    }

    /**
     * Extract street number.
     *
     * @param address a street address
     * @return optional number of the street
     */
    public Optional<String> extractStreetNumber(String address) {
        return extract(address, streetNumberPattern);
    }

    private Optional<String> extract(String address, Pattern pattern) {
        if (StringUtils.isBlank(address)) {
            return Optional.empty();
        }

        String sanitizedAddress = sanitize(address);
        Matcher matcher = pattern.matcher(sanitizedAddress);
        if (matcher.find()) {
            for (int i = matcher.groupCount(); i >= 1; i--) {
                if (matcher.group(i) != null) {
                    return Optional.ofNullable(matcher.group(i)).map(String::trim);
                }
            }
        }

        return Optional.empty();
    }

    private String sanitize(String input) {
        return input.trim().replaceAll("\\s+", " ").replaceAll(",+$", "");
    }

    @PostConstruct
    private void initialize() {
        AddressExtractProperties addressExtractProperties = appConfig.getAddressExtract();
        streetNamePattern = createPattern(addressExtractProperties.getStreetNameRegex());
        streetNumberPattern = createPattern(addressExtractProperties.getStreetNumberRegex());
    }

    private Pattern createPattern(String regex) {
        return Pattern.compile(regex, Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    }
}
