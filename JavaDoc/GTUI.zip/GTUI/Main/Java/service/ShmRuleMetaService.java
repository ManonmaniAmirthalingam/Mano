package com.ebtedge.fns.gateway.service;

import com.ebtedge.fns.gateway.util.CacheHelper;
import com.ebtedge.yb.entity.ShmRuleMeta;
import com.ebtedge.yb.repository.ShmRuleMetaRepository;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * Service class responsible for managing and providing access to rule metadata for the system
 * health monitor (SHM). This service leverages a caching mechanism to enhance performance by
 * reducing repeated database queries.
 *
 * <p>The class interacts with the {@link ShmRuleMetaRepository} to fetch data and uses a
 * thread-safe {@link CacheHelper} to manage in-memory caching of the fetched {@link ShmRuleMeta}
 * entities.
 *
 * <p>The main responsibilities of this service include: - Caching rule metadata at service
 * initialization. - Providing access to all cached rule metadata. - Searching for specific rule
 * metadata by trigger ID.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class ShmRuleMetaService {
    private static final String CACHE_NAME = "ShmRuleMetaCache";

    private final ShmRuleMetaRepository ruleMetaRepository;
    private volatile CacheHelper<ShmRuleMeta> cacheHelper;

    /**
     * Retrieves all cached rule metadata for the system health monitor (SHM).
     *
     * @return a list of ShmRuleMeta objects containing the metadata for SHM rules
     */
    public List<ShmRuleMeta> getAll() {
        return cacheHelper.getCachedData();
    }

    /**
     * Finds a {@link ShmRuleMeta} object by its trigger ID from the cached data.
     *
     * @param triggerId the unique identifier of the trigger to search for
     * @return an {@link Optional} containing the {@link ShmRuleMeta} object if found; otherwise, an
     *     empty {@link Optional}
     */
    public Optional<ShmRuleMeta> findByTriggerId(String triggerId) {
        return cacheHelper.getCachedData().stream()
                .filter(e -> e.getTriggerId().equals(triggerId))
                .findFirst();
    }

    @PostConstruct
    protected void initialize() {
        cacheHelper = CacheHelper.create(ruleMetaRepository::findAll, CACHE_NAME);
        log.info(
                "System Health Monitor Rule Metadata cache initialized with {} entries",
                cacheHelper.getCachedData().size());
    }
}
