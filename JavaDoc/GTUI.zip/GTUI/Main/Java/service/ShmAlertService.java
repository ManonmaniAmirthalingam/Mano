package com.ebtedge.fns.gateway.service;

import com.ebtedge.fns.gateway.domain.UserInfo;
import com.ebtedge.fns.gateway.model.ShmAlert;
import com.ebtedge.fns.gateway.util.DateTimeConvertors;
import com.ebtedge.yb.criteria.ShmAlertCriteriaQuery;

import java.math.BigInteger;
import java.time.*;
import java.util.*;

import com.ebtedge.yb.service.GatService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * ShmAlertService is a service class responsible for retrieving and processing alert information
 * related to System Health Monitoring (SHM). It integrates with the GatService to perform database
 * operations and converts the results into ShmAlert objects.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class ShmAlertService {

    private final GatService gatService;

    /**
     * Finds alert details within a time range with limit
     *
     * @param from the start timestamp of the range (inclusive)
     * @param to the end timestamp of the range (exclusive)
     * @param limit the maximum number of alerts to retrieve
     * @param userInfo the user info to log into user activity
     * @param ipAddress the IP address to log into user activity
     * @return a list of {@link ShmAlert} objects matching the specified criteria
     */
    public List<ShmAlert> findByTimestampBetween(
            LocalDateTime from, LocalDateTime to, int limit, UserInfo userInfo, String ipAddress) {
        log.debug("Finding alerts between {} and {} with limit {}", from, to, limit);
        ShmAlertCriteriaQuery criteria = new ShmAlertCriteriaQuery();
        criteria.setStartTs(convertToYBTimestamp(from));
        criteria.setEndTs(convertToYBTimestamp(to));
        criteria.setIpAddress(ipAddress);
        if (userInfo != null) {
            criteria.setAppUserId(userInfo.getUserId());
            criteria.setAppUserFirstName(userInfo.getFirstName());
            criteria.setAppUserMidName(userInfo.getMiddleName());
            criteria.setAppUserLastName(userInfo.getLastName());
            criteria.setAppUserEmail(userInfo.getEmail());
        }
        criteria.setAppServer("localhost");
        criteria.setSortBy("DESC");
        criteria.setSortField("timestamp");
        criteria.setStartRow(BigInteger.ZERO.toString());
        criteria.setEndRow(String.valueOf(limit));
        return gatService.systemHealthAlertSearch(criteria).parallelStream()
                .map(
                        resp -> {
                            ShmAlert alert = new ShmAlert();
                            alert.setTimestamp(
                                    DateTimeConvertors.parseYBTimestamp(resp.getTimestamp())
                                            .toInstant(ZoneOffset.UTC));
                            alert.setAlertTriggerId(resp.getAlertTriggerId());
                            alert.setAlertEntity(resp.getAlertEntity());
                            alert.setAlertMsg(resp.getAlertMsg());
                            return alert;
                        })
                .toList();
    }

    private String convertToYBTimestamp(LocalDateTime ldt) {
        return DateTimeConvertors.toDbTimestampFull(
                ldt.atZone(DateTimeConvertors.CENTRAL_TIMEZONE)
                        .withZoneSameInstant(ZoneOffset.UTC)
                        .toLocalDateTime());
    }
}
