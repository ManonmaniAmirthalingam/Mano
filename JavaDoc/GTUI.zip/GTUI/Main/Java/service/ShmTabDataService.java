package com.ebtedge.fns.gateway.service;

import com.ebtedge.fns.gateway.config.GatAppConfig;
import com.ebtedge.fns.gateway.config.MonitorProperties;
import com.ebtedge.fns.gateway.domain.UserInfo;
import com.ebtedge.fns.gateway.model.*;
import com.ebtedge.fns.gateway.util.IpAddressUtil;
import com.ebtedge.fns.gateway.util.SessionUtil;
import com.ebtedge.fns.gateway.util.ShmDataProcessor;
import com.ebtedge.fns.gateway.views.monitor.ShmView;

import java.time.LocalDateTime;
import java.util.*;
import java.util.function.BiFunction;

import com.ebtedge.yb.entity.ShmEntityType;
import com.vaadin.flow.spring.annotation.RouteScope;
import com.vaadin.flow.spring.annotation.RouteScopeOwner;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Service;
import lombok.extern.slf4j.Slf4j;

/**
 * Service class responsible for managing and providing SHM (System Health Monitoring) tab data. It
 * centralizes data retrieval for various SHM data types and handles data ingestion.
 *
 * <p>This service processes and provides data for several system components including links,
 * gateways, system status, and state bins through internally managed data providers.
 *
 * <p>The class uses dependency injection for core components like data processing, entity services,
 * and data ingestion, ensuring seamless integration with other parts of the system.
 */
@Service
@Scope(value = "vaadin-route", proxyMode = ScopedProxyMode.TARGET_CLASS)
@RouteScope
@RouteScopeOwner(ShmView.class)
@RequiredArgsConstructor
@Slf4j
public class ShmTabDataService {
    private final ShmDataProcessor dataProcessor;
    private final ShmEntityService entityService;
    private final ShmStateBinService stateBinService;
    private final ShmDataIngestionService dataIngestionService;
    private final GatAppConfig appConfig;
    private static UserInfo userInfo;
    private static String ipAddress;

    private final Map<Class<?>, ViewModelDataProvider<?>> dataProviders = new HashMap<>();

    /**
     * Retrieves data for the given type within the specified time range. This method looks up the
     * appropriate data provider for the specified type and fetches the corresponding data.
     *
     * @param <T> the type of data to retrieve
     * @param tClass the class object representing the type of data to retrieve
     * @param from the start of the time range for data retrieval
     * @param to the end of the time range for data retrieval
     * @return a list of data objects of the specified type within the given time range
     * @throws IllegalArgumentException if no data provider exists for the specified type
     * @throws IllegalStateException if the data retrieval or ingestion process fails
     */
    @SuppressWarnings("unchecked")
    public <T> List<T> getData(Class<T> tClass, LocalDateTime from, LocalDateTime to) {
        try {
            log.debug("Retrieving {} data for period: {} to {}", tClass, from, to);
            return Optional.ofNullable(dataProviders.get(tClass))
                    .map(provider -> ((ViewModelDataProvider<T>) provider).getData(from, to))
                    .orElseThrow(
                            () -> new IllegalArgumentException("Unsupported data type: " + tClass));
        } catch (Exception e) {
            throw new IllegalStateException("Failed to retrieve monitor data", e);
        }
    }

    private List<ShmLinkGridVO> getLinkData(LocalDateTime from, LocalDateTime to) {
        return entityService.getAll().parallelStream()
                .filter(entity -> ShmEntityType.LINK == entity.getType())
                .map(entity -> dataProcessor.processLink(entity, from, to))
                .toList();
    }

    private List<ShmGatewayGridVO> getGatewayData(LocalDateTime from, LocalDateTime to) {
        return entityService.getAll().parallelStream()
                .filter(entity -> ShmEntityType.GATEWAY == entity.getType())
                .map(entity -> dataProcessor.processGateway(entity, from, to))
                .toList();
    }

    private List<ShmSystemGridVO> getSystemData(LocalDateTime from, LocalDateTime to) {
        return entityService.getAll().parallelStream()
                .filter(entity -> ShmEntityType.SYSTEM == entity.getType())
                .map(entity -> dataProcessor.processSystem(entity, from, to))
                .toList();
    }

    private List<ShmStateBinGridVO> getStateBinData(LocalDateTime from, LocalDateTime to) {
        return stateBinService.getAll().parallelStream()
                .map(stateBin -> dataProcessor.processState(stateBin, from, to))
                .toList();
    }

    private List<ShmDashboardVO> getDashboardData(LocalDateTime from, LocalDateTime to) {
        return List.of(
                ShmDashboardVO.builder()
                        .links(getLinkData(from, to))
                        .gateways(getGatewayData(from, to))
                        .system(getSystemData(from, to))
                        .states(getStateBinData(from, to))
                        .build());
    }

    private <T> ViewModelDataProvider<T> createProvider(
            BiFunction<LocalDateTime, LocalDateTime, List<T>> dataSupplier) {
        return new ViewModelDataProvider<>(
                dataSupplier, dataIngestionService, appConfig.getMonitor());
    }

    @PostConstruct
    private void initialize() {
        userInfo = SessionUtil.getUserInfo();
        ipAddress = IpAddressUtil.getIpAddress();
        dataProviders.put(ShmLinkGridVO.class, createProvider(this::getLinkData));
        dataProviders.put(ShmGatewayGridVO.class, createProvider(this::getGatewayData));
        dataProviders.put(ShmSystemGridVO.class, createProvider(this::getSystemData));
        dataProviders.put(ShmStateBinGridVO.class, createProvider(this::getStateBinData));
        dataProviders.put(ShmDashboardVO.class, createProvider(this::getDashboardData));
    }

    /**
     * ViewModelDataProvider is a generic utility class responsible for managing data retrieval and
     * ingestion for a specific type of data. It serves as an abstraction over the data supply
     * process and ensures that relevant data is ingested before retrieval.
     *
     * @param <T> the type of data this provider is responsible for managing
     */
    private static class ViewModelDataProvider<T> {
        private final BiFunction<LocalDateTime, LocalDateTime, List<T>> dataSupplier;
        private final ShmDataIngestionService dataIngestionService;
        private final MonitorProperties monitorProperties;

        public ViewModelDataProvider(
                BiFunction<LocalDateTime, LocalDateTime, List<T>> dataSupplier,
                ShmDataIngestionService dataIngestionService,
                MonitorProperties monitorProperties) {
            this.dataSupplier = dataSupplier;
            this.dataIngestionService = dataIngestionService;
            this.monitorProperties = monitorProperties;
        }

        /**
         * Retrieves data for a specific type within the provided time range after ensuring data has
         * been ingested for the specified period.
         *
         * @param from the start of the time range for data retrieval
         * @param to the end of the time range for data retrieval
         * @return a list of data objects of the specified type within the given time range
         */
        public List<T> getData(LocalDateTime from, LocalDateTime to) {
            ingestData(from, to);
            return dataSupplier.apply(from, to);
        }

        private void ingestData(LocalDateTime from, LocalDateTime to) {
            log.debug("Starting data ingestion from {} to {}", from, to);
            try {
                int count =
                        dataIngestionService.ingestData(
                                from,
                                to,
                                monitorProperties.getSystemHealth().getMaxPullSize(),
                                userInfo,
                                ipAddress);
                log.debug("Successfully ingested {} records", count);
            } catch (Exception e) {
                throw new IllegalStateException("Failed to ingest data", e);
            }
        }
    }
}
