package com.ebtedge.fns.gateway.service;

import com.ebtedge.fns.gateway.domain.UserInfo;
import com.ebtedge.fns.gateway.security.PermissionPolicyProvider;
import com.ebtedge.fns.gateway.security.UserPermission;

import lombok.RequiredArgsConstructor;

import org.springframework.stereotype.Service;

import java.util.Set;

/**
 * Service for managing and evaluating user permissions within the application. Provides
 * functionality to check if a user has the required roles to perform specific actions based on
 * predefined permission policies.
 */
@Service
@RequiredArgsConstructor
public class PermissionService {
    private final PermissionPolicyProvider permissionPolicyProvider;

    /**
     * Determines whether a user has the required permission based on their roles.
     *
     * @param permission the permission being checked; must not be null
     * @param userInfo the user information containing user roles; must not be null and must have
     *     roles defined
     * @return true if the user has the required permission, false otherwise
     */
    public boolean hasPermission(UserPermission permission, UserInfo userInfo) {
        if (permission == null) {
            return false;
        }
        if (!isValidUserInfo(userInfo)) {
            return false;
        }

        Set<String> allowedRoles = permissionPolicyProvider.getRolesForPermission(permission);
        if (allowedRoles.isEmpty()) {
            return false;
        }

        return hasMatchingRole(userInfo, allowedRoles);
    }

    private boolean isValidUserInfo(UserInfo userInfo) {
        return userInfo != null && userInfo.getRoles() != null;
    }

    private boolean hasMatchingRole(UserInfo userInfo, Set<String> allowedRoles) {
        return allowedRoles.stream().map(String::strip).anyMatch(userInfo::hasRole);
    }
}
