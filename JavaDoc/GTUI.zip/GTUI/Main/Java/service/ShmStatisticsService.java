package com.ebtedge.fns.gateway.service;

import com.ebtedge.fns.gateway.config.GatAppConfig;
import com.ebtedge.fns.gateway.model.ShmAlert;
import com.ebtedge.fns.gateway.stats.*;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Provides services for monitoring and tracking statistics related to system health and alerts.
 *
 * <p>This service tracks alerts, accumulates them over time, and computes statistics based on a
 * specified time range. It ensures the retention of ingested alerts is managed in a time-based
 * cache and provides methods to retrieve and analyze the accumulated alert data.
 *
 * <p>Dependencies: - {@code GatAppConfig}: Application configuration to retrieve retention duration
 * and related settings. - {@code ShmAlert}: Represents alerts being tracked. - {@code
 * MonitorStatistics}: Encapsulates the computed statistical data. - {@code Cache}: Caffeine-based
 * caching mechanism for managing ingested alerts. - {@code AtomicInteger}: Tracks the count of
 * processed alerts in a thread-safe manner.
 *
 * <p>Thread Safety: This class makes use of thread-safe structures like {@code ConcurrentHashMap}
 * and employs atomic operations to ensure safe processing of alerts in concurrent environments.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ShmStatisticsService {
    private final GatAppConfig appConfig;

    private volatile Cache<ShmAlert, Integer> alertAccumulationCache;

    /**
     * Retrieves monitoring statistics for a specified time range. The method validates the provided
     * time range and computes statistics based on the accumulated system health monitoring alerts.
     *
     * @param from the start of the time range as a {@link LocalDateTime}; must not be null.
     * @param to the end of the time range as a {@link LocalDateTime}; must not be null and must be
     *     after {@code from}.
     * @return a {@link MonitorStatistics} object that contains the computed statistics for the
     *     specified time range.
     * @throws IllegalArgumentException if {@code from} or {@code to} is null, or if {@code from} is
     *     after {@code to}.
     */
    public MonitorStatistics getMonitorStats(LocalDateTime from, LocalDateTime to) {
        validateTimeRange(from, to);
        return computeStatistics(
                from.atZone(ZoneId.systemDefault()).toInstant(),
                to.atZone(ZoneId.systemDefault()).toInstant());
    }

    /**
     * Tracks a given alert by validating its fields, checking if it has already been processed, and
     * processing it if valid and unprocessed.
     *
     * @param entry the alert entry consisting of a {@link ShmAlert} key and an associated integer
     *     value; must not be null.
     * @return {@code true} if the alert was successfully processed and tracked, {@code false}
     *     otherwise.
     * @throws NullPointerException if the alert entry is null or if any required fields of the
     *     alert are null.
     */
    public boolean track(Map.Entry<ShmAlert, Integer> entry) {
        try {
            ShmAlert alert = entry.getKey();
            Integer value = entry.getValue();
            Objects.requireNonNull(entry, "Alert cannot be null");
            Objects.requireNonNull(alert.getTimestamp(), "Alert's timestamp cannot be null");
            Objects.requireNonNull(alert.getAlertTriggerId(), "Alert's trigger ID cannot be null");
            Objects.requireNonNull(alert.getAlertEntity(), "Alert's entity cannot be null");

            Integer existingCount = alertAccumulationCache.getIfPresent(alert);
            if (existingCount != null) {
                log.debug("Alert already processed. Alert: {}", alert);
                return false;
            }

            alertAccumulationCache.put(alert, value);
            log.debug("Processed an alert: {}", alert);
            return true;
        } catch (Exception e) {
            log.error("Failed to track alert: {}", entry.getKey(), e);
            return false;
        }
    }

    private MonitorStatistics computeStatistics(Instant from, Instant to) {
        Map<ShmAlert, Integer> accumulation =
                alertAccumulationCache.asMap().entrySet().stream()
                        .filter(
                                entry ->
                                        (!entry.getKey().getTimestamp().isBefore(from))
                                                && (!entry.getKey().getTimestamp().isAfter(to)))
                        .collect(
                                Collectors.toUnmodifiableMap(
                                        Map.Entry::getKey, Map.Entry::getValue));
        MonitorStatistics stats = new MonitorStatistics(accumulation);
        log.debug(
                "Computed statistics from={} to={}, accumulations={}",
                from,
                to,
                stats.getAlertAccumulations().size());
        return stats;
    }

    private void validateTimeRange(LocalDateTime from, LocalDateTime to) {
        if (from == null || to == null) {
            throw new IllegalArgumentException("Time range cannot be null");
        }
        if (from.isAfter(to)) {
            throw new IllegalArgumentException("Start time must be before end time");
        }
    }

    private void validateRetentionDuration(Duration retention) {
        if (retention == null || retention.isNegative() || retention.isZero()) {
            throw new IllegalStateException("Invalid retention duration");
        }
    }

    @PostConstruct
    private void initialize() {
        try {
            Duration retention =
                    appConfig.getMonitor().getSystemHealth().getCacheDataRetentionDuration();
            validateRetentionDuration(retention);

            alertAccumulationCache = Caffeine.newBuilder().expireAfterWrite(retention).build();

            log.info(
                    "Initialized System Health Monitor Statistics service with retention duration: {}",
                    retention);
        } catch (Exception e) {
            log.error("Failed to initialize System Health Monitor Statistics service", e);
            throw new IllegalStateException("Service initialization failed", e);
        }
    }
}
