package com.ebtedge.fns.gateway.service;

import com.ebtedge.fns.gateway.util.CacheHelper;
import com.ebtedge.yb.entity.ShmStateBin;
import com.ebtedge.yb.repository.ShmStateBinRepository;
import java.util.List;
import java.util.Optional;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Service class responsible for managing the state and bin data related to the System Health
 * Monitor (SHM) module. This class caches the state-binary mappings for optimized performance and
 * efficient data retrieval.
 *
 * <p>It provides methods to retrieve all state-bin mappings and search for a specific mapping based
 * on a bin prefix. The service leverages {@link CacheHelper} for caching and maintaining
 * consistency of the data loaded from the {@link ShmStateBinRepository}.
 *
 * <p>The cache is initialized during application startup using the {@link #initialize()} method.
 * Logging information is generated during cache initialization to indicate the total number of
 * entries loaded into the cache.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class ShmStateBinService {
    private static final String CACHE_NAME = "ShmStateBinCache";

    private final ShmStateBinRepository stateBinRepository;
    private CacheHelper<ShmStateBin> cacheHelper;

    /**
     * Retrieves a list of all {@code ShmStateBin} objects stored in the cache. The data is returned
     * from an in-memory cache for optimal performance.
     *
     * @return a {@code List} of {@code ShmStateBin} objects representing the cached data
     */
    public List<ShmStateBin> getAll() {
        return cacheHelper.getCachedData();
    }

    /**
     * Finds the first occurrence of a {@code ShmStateBin} object in the cached data where the
     * {@code bin} property starts with the specified prefix.
     *
     * @param bin the prefix of the {@code bin} property to search for
     * @return an {@code Optional} containing the found {@code ShmStateBin} object if present,
     *     otherwise an empty {@code Optional}
     */
    public Optional<ShmStateBin> findByBin(String bin) {
        return cacheHelper.getCachedData().stream()
                .filter(e -> e.getBin().startsWith(bin))
                .findFirst();
    }

    @PostConstruct
    private void initialize() {
        cacheHelper = CacheHelper.create(stateBinRepository::findAll, CACHE_NAME);
        log.info(
                "System Health Monitor State Bin cache initialized with {} entries",
                cacheHelper.getCachedData().size());
    }
}
