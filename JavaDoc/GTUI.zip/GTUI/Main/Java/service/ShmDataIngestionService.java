package com.ebtedge.fns.gateway.service;

import com.ebtedge.fns.gateway.domain.UserInfo;
import com.ebtedge.fns.gateway.model.ShmAlert;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * Service responsible for ingesting and processing monitor alert data. This service interacts with
 * the {@code ShmAlertService} to retrieve alerts and uses the {@code ShmStatisticsService} to track
 * and process the alerts.
 */
@Service
@RequiredArgsConstructor
public class ShmDataIngestionService {
    private final ShmAlertService alertService;
    private final ShmStatisticsService statisticsService;

    /**
     * Ingests and processes alert data for a specified time range and user context. This method
     * fetches a list of alerts within the given time range, user-specific filters, and applies
     * processing logic to them.
     *
     * @param from the start of the time range for alert retrieval
     * @param to the end of the time range for alert retrieval
     * @param limit the maximum number of alerts to retrieve
     * @param userInfo the identifier of the user for whom alerts are retrieved
     * @param ipAddress the IP address filter for alert retrieval
     * @return the total number of alerts successfully processed
     * @throws IllegalArgumentException if time range validation fails
     */
    public int ingestData(
            LocalDateTime from, LocalDateTime to, int limit, UserInfo userInfo, String ipAddress) {
        validateTimeRange(from, to);
        List<ShmAlert> alerts =
                alertService.findByTimestampBetween(from, to, limit, userInfo, ipAddress);
        return processAlerts(alerts);
    }

    private int processAlerts(List<ShmAlert> alerts) {
        AtomicInteger ingestedCount = new AtomicInteger();
        Map<ShmAlert, Integer> alertCount =
                alerts.stream()
                        .collect(
                                Collectors.groupingBy(
                                        alert -> alert, Collectors.summingInt(alert -> 1)));
        alertCount
                .entrySet()
                .forEach(
                        entry -> {
                            if (processAlertEntry(entry)) {
                                ingestedCount.updateAndGet(v -> v + entry.getValue());
                            }
                        });
        return ingestedCount.get();
    }

    private boolean processAlertEntry(Map.Entry<ShmAlert, Integer> entry) {
        return statisticsService.track(entry);
    }

    /**
     * Validate time range
     *
     * @param from Start time
     * @param to End time
     */
    private void validateTimeRange(LocalDateTime from, LocalDateTime to) {
        if (from == null || to == null) {
            throw new IllegalArgumentException("Time range bounds cannot be null");
        }
        if (from.isAfter(to)) {
            throw new IllegalArgumentException("Start time cannot be after end time");
        }
    }
}
