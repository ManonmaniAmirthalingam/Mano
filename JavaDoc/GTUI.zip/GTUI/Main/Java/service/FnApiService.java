package com.ebtedge.fns.gateway.service;

import com.ebtedge.fn.client.FnPanWatchClient;
import com.ebtedge.fn.client.FnTerminalBlockClient;
import com.ebtedge.fn.client.FnTerminalWatchClient;
import com.ebtedge.fns.gateway.model.DateTimeRange;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Service;

/**
 * Service for interacting with Fraud Navigator (FN) API operations, specifically for monitoring and
 * blocking fraud-related activities for cards and terminals.
 *
 * <p>Responsibilities: - Provides functionality to monitor a specific card by adding it to a watch
 * list. - Provides functionality to monitor a terminal by adding it to a watch list. - Provides
 * functionality to block a terminal for a specific duration with configurable parameters.
 *
 * <p>Dependencies: - FnPanWatchClient for managing card monitoring by interacting with the PAN
 * watch list API. - FnTerminalWatchClient for managing terminal monitoring by interacting with the
 * terminal watch API. - FnTerminalBlockClient for managing terminal blocking functionality.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class FnApiService {

    private final FnPanWatchClient fnPanWatchClient;
    private final FnTerminalWatchClient fnTerminalWatchClient;
    private final FnTerminalBlockClient fnTerminalBlockClient;

    /**
     * Monitors a card by adding it to the PAN list.
     *
     * @param cardNumber The card number to monitor
     * @param userId The user ID
     */
    public void monitorCard(String cardNumber, String userId) {
        log.info("Monitoring Card: {}", cardNumber);
        fnPanWatchClient.addPanToWatchList(cardNumber, userId);
        log.info("Finished monitoring Card: {}", cardNumber);
    }

    /**
     * Monitors a terminal by adding it to the terminal list.
     *
     * @param deviceId The Device ID
     * @param merchantId The Merchant ID
     * @param userId The User ID
     */
    public void monitorTerminal(String deviceId, String merchantId, String userId) {
        log.info(
                "Monitoring Terminal. DeviceId: {}, MerchantId: {}, userId: {}",
                deviceId,
                merchantId,
                userId);
        fnTerminalWatchClient.addTerminalToWatchList(deviceId, merchantId, userId);
        log.info(
                "Finished monitoring Terminal. DeviceId: {}, MerchantId: {}, userId: {}",
                deviceId,
                merchantId,
                userId);
    }

    /**
     * Blocks a terminal for the specified duration using the provided parameters. This method logs
     * the blocking operation and delegates the request to the terminal block client.
     *
     * @param deviceId The unique identifier of the terminal device to be blocked.
     * @param merchantId The unique identifier of the merchant associated with the terminal.
     * @param acquirer The identifier of the acquiring institution.
     * @param range The date-time range specifying the start and end of the blocking period.
     * @param user The identifier of the user initiating the block operation.
     */
    public void blockTerminal(
            String deviceId, String merchantId, String acquirer, DateTimeRange range, String user) {
        log.info(
                "Blocking Terminal with Device ID = {}, Merchant ID = {}, Acquirer = {} in duration from {} to {} by user = {}",
                deviceId,
                merchantId,
                acquirer,
                range.getStart(),
                range.getEnd(),
                user);
        fnTerminalBlockClient.blockTerminal(
                deviceId, merchantId, acquirer, user, range.getStart(), range.getEnd());
        log.info(
                "Finished blocking the Terminal with Device ID = {}, Merchant ID = {}, Acquirer = {} in duration from {} to {} by user = {}",
                deviceId,
                merchantId,
                acquirer,
                range.getStart(),
                range.getEnd(),
                user);
    }
}
