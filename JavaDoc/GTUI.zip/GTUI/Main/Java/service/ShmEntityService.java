package com.ebtedge.fns.gateway.service;

import com.ebtedge.fns.gateway.util.CacheHelper;
import com.ebtedge.yb.entity.ShmEntity;
import com.ebtedge.yb.repository.ShmEntityRepository;

import java.util.List;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Service class for managing and caching {@link ShmEntity} instances.
 *
 * <p>This service provides methods to retrieve data from the cache and initializes the cache with
 * data from the underlying repository. The caching mechanism ensures efficient retrieval of data by
 * reducing frequent database access and maintaining a local in-memory representation.
 *
 * <p>Key functionality includes: - Fetching all cached {@link ShmEntity} objects. - Lazy
 * initialization of the cache with data from {@link ShmEntityRepository}. - Automatic setup of the
 * cache during component initialization.
 *
 * <p>Relies on {@link CacheHelper} for managing the cache and provides thread-safe access to cached
 * {@link ShmEntity} data.
 *
 * <p>Dependencies: - {@link ShmEntityRepository} for data retrieval from the database. - {@link
 * CacheHelper} to handle caching logic.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ShmEntityService {
    private static final String CACHE_NAME = "ShmEntityCache";

    private final ShmEntityRepository entityRepository;
    private volatile CacheHelper<ShmEntity> cacheHelper;

    /**
     * Retrieves all cached instances of {@link ShmEntity}.
     *
     * <p>This method ensures that the data is fetched from an in-memory cache, utilizing the
     * caching mechanism provided by {@link CacheHelper} to return an unmodifiable list of cached
     * entities. The cache is initialized using a lazy-loading pattern for efficiency.
     *
     * @return a list of cached {@link ShmEntity} instances
     */
    public List<ShmEntity> getAll() {
        return cacheHelper.getCachedData();
    }

    @PostConstruct
    protected void initialize() {
        cacheHelper = CacheHelper.create(entityRepository::findAll, CACHE_NAME);
        log.info(
                "System Health Monitor Entity cache initialized with {} entries",
                cacheHelper.getCachedData().size());
    }
}
