package com.ebtedge.fns.gateway.service;

import com.ebtedge.fns.gateway.util.CacheHelper;
import com.ebtedge.yb.entity.ShmEntityAssociation;
import com.ebtedge.yb.repository.ShmEntityAssociationRepository;

import java.util.List;
import java.util.function.Predicate;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Service class responsible for managing operations related to {@link ShmEntityAssociation}
 * entities. Provides functionality to retrieve and filter entity associations from a cached data
 * source. The cache for entity associations is initialized at startup and refreshed lazily as
 * needed.
 *
 * <p>This class interacts with the {@link ShmEntityAssociationRepository} repository for data
 * persistence and utilizes {@link CacheHelper} to manage an in-memory cache of entity associations.
 *
 * <p>The cache, identified by the name "ShmEntityAssociationCache", is used to reduce database
 * access and improve performance for frequently accessed data.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class ShmEntityAssociationService {
    private static final String CACHE_NAME = "ShmEntityAssociationCache";

    private final ShmEntityAssociationRepository entityAssociationRepository;
    private CacheHelper<ShmEntityAssociation> cacheHelper;

    /**
     * Retrieves a list of all {@link ShmEntityAssociation} objects from the cache. This method
     * ensures efficient access to entity associations by utilizing an in-memory cache initialized
     * at startup and refreshed as needed.
     *
     * @return a list of all {@link ShmEntityAssociation} objects available in the cache
     */
    public List<ShmEntityAssociation> getAll() {
        return cacheHelper.getCachedData();
    }

    /**
     * Finds and retrieves a list of {@link ShmEntityAssociation} objects from the cache that have
     * an entity name matching the given parameter.
     *
     * @param entityName the name of the entity to filter associations by
     * @return a list of {@link ShmEntityAssociation} objects with the specified entity name
     */
    public List<ShmEntityAssociation> findByEntityName(String entityName) {
        return findInCache(assoc -> assoc.getEntityName().equals(entityName));
    }

    @PostConstruct
    private void initialize() {
        cacheHelper = CacheHelper.create(entityAssociationRepository::findAll, CACHE_NAME);
        log.info(
                "System Health Monitor Entity Associations cache initialized with {} entries",
                cacheHelper.getCachedData().size());
    }

    private List<ShmEntityAssociation> findInCache(Predicate<ShmEntityAssociation> predicate) {
        return cacheHelper.getCachedData().stream().filter(predicate).toList();
    }
}
