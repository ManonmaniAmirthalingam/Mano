package com.ebtedge.fns.gateway.layout;

import com.ebtedge.yb.service.GatService;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.component.tabs.Tabs;
import com.vaadin.flow.router.*;
import com.vaadin.flow.theme.lumo.LumoUtility;

import java.util.HashMap;
import java.util.Map;

@Deprecated
public class TransactionsTabsLayout extends VerticalLayout implements RouterLayout, BeforeEnterObserver {


    public TransactionsTabsLayout() {

        RouteTabs routeTabs = new RouteTabs();
        routeTabs.add(new RouterLink("All", AllTrans.class));
        RouterLink outOfState = new RouterLink("Out of State", OutOfStateTrans.class);
        outOfState.addClassNames(LumoUtility.FlexWrap.NOWRAP, LumoUtility.AlignContent.CENTER);
        routeTabs.add(outOfState);
        routeTabs.add(new RouterLink("Even Dollar", EvenDollarTrans.class));
        routeTabs.add(new RouterLink("Decline", DeclinedTrans.class));
        routeTabs.add(new RouterLink("Miscoded Terminals", MiscodedTerminals.class));
        routeTabs.add(new RouterLink("High Value", HighValueTrans.class));
        routeTabs.add(new RouterLink("Compromized Cards", CompromisedCards.class));
        routeTabs.addClassNames(LumoUtility.AlignContent.CENTER, LumoUtility.TextAlignment.CENTER);
        setSizeFull();
        add(routeTabs);
    }

    @Route(value = "/transaction/search/out-of-state", layout = TransactionsTabsLayout.class)
    public static class OutOfStateTrans extends Div {

        public OutOfStateTrans(GatService ebtEventService) {
            /*List<FinancialTranVO> ebtEvents = ebtEventService.getEbtEventsByOutOfState("Y", 10);
            TransactionsGrid transactionsGrid = new TransactionsGrid(ebtEventService);
            Grid<EbtEvent> grid = transactionsGrid.getTranSearchResultsGrid();
            grid.setItems(ebtEvents);
            setSizeFull();
            add(grid);*/
        }
    }

    @Route(value = "/transaction/search/even-dollar", layout = TransactionsTabsLayout.class)
    public static class EvenDollarTrans extends Div {
        /**
         * Creates a new empty div.
         */
        public EvenDollarTrans(GatService ebtEventService) {
         /*   List<EbtEvent> ebtEvents = ebtEventService.getEbtEventsByEvenDollar("Y", 20);
            TransactionsGrid transactionsGrid = new TransactionsGrid(ebtEventService);
            Grid<EbtEvent> grid = transactionsGrid.getTranSearchResultsGrid();
            grid.setItems(ebtEvents);
            setSizeFull();
            add(grid);*/
        }
    }

    @Route(value = "/transaction/search/declined", layout = TransactionsTabsLayout.class)
    public static class DeclinedTrans extends Div {
        /**
         * Creates a new empty div.
         */
        public DeclinedTrans(GatService ebtEventService) {
          /*  List<EbtEvent> ebtEvents = ebtEventService.getEbtEventsByEvenDollar("Y", 10);
            TransactionsGrid transactionsGrid = new TransactionsGrid(ebtEventService);
            Grid<EbtEvent> grid = transactionsGrid.getTranSearchResultsGrid();
            grid.setItems(ebtEvents);
            setSizeFull();
            add(grid);*/
        }
    }

    @Route(value = "/transaction/search/miscoded", layout = TransactionsTabsLayout.class)
    public static class MiscodedTerminals extends Div {
        /**
         * Creates a new empty div.
         */
        public MiscodedTerminals(GatService ebtEventService) {
           /* List<EbtEvent> ebtEvents = ebtEventService.getEbtEventsByEvenDollar("Y", 5);
            TransactionsGrid transactionsGrid = new TransactionsGrid(ebtEventService);
            Grid<EbtEvent> grid = transactionsGrid.getTranSearchResultsGrid();
            grid.setItems(ebtEvents);
            setSizeFull();
            add(grid);*/
        }
    }

    @Route(value = "/transaction/search/all", layout = TransactionsTabsLayout.class)
    public static class AllTrans extends Div {
        /**
         * Creates a new empty div.
         */
        public AllTrans(GatService ebtEventService) {
          /*  List<EbtEvent> ebtEvents = ebtEventService.getEbtEvents();
            TransactionsGrid transactionsGrid = new TransactionsGrid(ebtEventService);
            Grid<EbtEvent> grid = transactionsGrid.getTranSearchResultsGrid();
            grid.setItems(ebtEvents);
            setSizeFull();
            add(grid);*/
        }
    }

    @Route(value = "/transaction/search/high-value", layout = TransactionsTabsLayout.class)
    public static class HighValueTrans extends Div {
        /**
         * Creates a new empty div.
         */
        public HighValueTrans(GatService ebtEventService) {
          /*  List<EbtEvent> ebtEvents = ebtEventService.getEbtEventsByEvenDollar("Y", 30);
            TransactionsGrid transactionsGrid = new TransactionsGrid(ebtEventService);
            Grid<EbtEvent> grid = transactionsGrid.getTranSearchResultsGrid();
            grid.setItems(ebtEvents);
            setSizeFull();
            add(grid);*/
        }
    }

    @Route(value = "/transaction/search/compromised-cards", layout = TransactionsTabsLayout.class)
    public static class CompromisedCards extends Div {
        /**
         * Creates a new empty div.
         */
        public CompromisedCards(GatService ebtEventService) {
           /* List<EbtEvent> ebtEvents = ebtEventService.getEbtEventsByEvenDollar("Y", 9);
            TransactionsGrid transactionsGrid = new TransactionsGrid(ebtEventService);
            Grid<EbtEvent> grid = transactionsGrid.getTranSearchResultsGrid();
            grid.setItems(ebtEvents);
            setSizeFull();
            add(grid);*/
        }
    }

    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        if (event.getNavigationTarget() == TransactionsTabsLayout.class) {
            event.forwardTo(AllTrans.class);
        }
    }

    private static class RouteTabs extends Tabs implements BeforeEnterObserver {
        private final Map<RouterLink, Tab> routerLinkTabMap = new HashMap<>();

        public void add(RouterLink routerLink) {
            routerLink.setHighlightCondition(HighlightConditions.sameLocation());
            routerLink.addClassNames(LumoUtility.AlignContent.CENTER, LumoUtility.TextColor.SUCCESS);
            routerLink.setHighlightAction(
                    (link, shouldHighlight) -> {
                        if (shouldHighlight) setSelectedTab(routerLinkTabMap.get(routerLink));
                    }
            );
            routerLinkTabMap.put(routerLink, new Tab(routerLink));
            add(routerLinkTabMap.get(routerLink));
        }

        @Override
        public void beforeEnter(BeforeEnterEvent event) {
            // In case no tabs will match
            setSelectedTab(null);
        }

    }
}