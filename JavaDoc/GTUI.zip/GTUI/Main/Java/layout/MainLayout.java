package com.ebtedge.fns.gateway.layout;

import com.ebtedge.fns.gateway.config.GatAppConfig;
import com.ebtedge.fns.gateway.domain.UserInfo;
import com.ebtedge.fns.gateway.security.CurrentUserAccess;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.applayout.AppLayout;
import com.vaadin.flow.component.applayout.DrawerToggle;
import com.vaadin.flow.component.contextmenu.ContextMenu;
import com.vaadin.flow.component.html.*;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.SvgIcon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.Scroller;
import com.vaadin.flow.component.sidenav.SideNav;
import com.vaadin.flow.component.sidenav.SideNavItem;
import com.vaadin.flow.router.Layout;
import com.vaadin.flow.server.VaadinRequest;
import com.vaadin.flow.server.VaadinSession;
import com.vaadin.flow.server.auth.AnonymousAllowed;
import com.vaadin.flow.server.menu.MenuConfiguration;
import com.vaadin.flow.server.menu.MenuEntry;
import com.vaadin.flow.theme.lumo.LumoUtility;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * Main layout component for GAT Application.
 * This contains left navbar, top drawer to view the page name and main content area
 *
 * @author e3023044
 * @version 1.0.0
 * @since 1.0.0
 */
@Layout
@AnonymousAllowed
public class MainLayout extends AppLayout {

    private final GatAppConfig gatAppConfig;
    private final CurrentUserAccess currentUserAccess;
    private final SideNav sideNav;
    private final List<MenuEntry> menuEntries;

    private Span userIdDisplay = new Span("Unknown user");
    private H1 viewTitle;

    public MainLayout(@Autowired GatAppConfig gatAppConfig, @Autowired CurrentUserAccess currentUserAccess) {
        this.gatAppConfig = gatAppConfig;
        this.currentUserAccess = currentUserAccess;
        this.sideNav = new SideNav();
        this.menuEntries = MenuConfiguration.getMenuEntries();
        setPrimarySection(Section.DRAWER);
        addDrawerContent();
        addHeaderContent();
        // Add listener to update user info when component attaches
        addAttachListener(event -> updateUserInfoFromSession());
    }

    private void updateUserInfoFromSession() {
        // Access the current UI and session
        UI.getCurrent().access(() -> {
            VaadinSession session = VaadinSession.getCurrent();
            if (session != null) {
                UserInfo userInfo = (UserInfo) session.getAttribute("userInfo");
                if (userInfo != null) {
                    userIdDisplay.setText("User: " + userInfo.getUserId());
                }
                updateSideNavItems();
            }
        });
    }


    /**
     * Create header content area.
     */
    private void addHeaderContent() {

        HorizontalLayout layout = new HorizontalLayout();

        viewTitle = new H1();
        viewTitle.addClassNames(LumoUtility.FontSize.LARGE, LumoUtility.Margin.MEDIUM);

        DrawerToggle toggle = new DrawerToggle();

        Icon icon = VaadinIcon.USER.create();
        ContextMenu contextMenu = new ContextMenu(icon);
        contextMenu.setOpenOnClick(true);

        contextMenu.addItem(userIdDisplay);
        contextMenu.addItem("Log Out",
                e -> {
                    getUI().get().getSession().close();
                    VaadinRequest.getCurrent().getWrappedSession().invalidate();
                    getUI().get().getPage().setLocation(gatAppConfig.getLogoutUrl());
                });

        layout.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.CENTER);
        layout.expand(viewTitle);
        layout.addClassNames(LumoUtility.Padding.Vertical.NONE, LumoUtility.Padding.Horizontal.MEDIUM);
        layout.setWidthFull();
        layout.add(toggle, viewTitle, icon);

        addToNavbar(true, layout);
    }

    /**
     * Create left nav content.
     */
    private void addDrawerContent() {

        Span appName = new Span("FNS Gateway");

        appName.setWidthFull();
        appName.addClassNames(LumoUtility.FontWeight.BOLD, LumoUtility.FontSize.LARGE, LumoUtility.Padding.Right.LARGE, LumoUtility.FlexWrap.NOWRAP);

        Image image = new Image("icons/fislogo.png", "");
        image.addClassNames(LumoUtility.Padding.Right.LARGE);

        Header header = new Header(image, appName);
        Scroller scroller = new Scroller(sideNav);

        addToDrawer(header, scroller, createFooter());
    }

    private void updateSideNavItems() {
        sideNav.removeAll();
        menuEntries.forEach(
                entry -> {
                    // Do not add a navigation item if the logged-in user has no access to its url
                    if (!currentUserAccess.hasAccessToUrl(entry.path())) return;
                    if (entry.icon() != null) {
                        sideNav.addItem(
                                new SideNavItem(
                                        entry.title(), entry.path(), new SvgIcon(entry.icon())));
                    } else {
                        sideNav.addItem(new SideNavItem(entry.title(), entry.path()));
                    }
                });
    }

    private Footer createFooter() {
        Footer layout = new Footer();
        return layout;
    }

    @Override
    protected void afterNavigation() {
        super.afterNavigation();
        updateUserInfoFromSession();
        viewTitle.setText(getCurrentPageTitle());
    }

    private String getCurrentPageTitle() {

        return MenuConfiguration.getPageHeader(getContent()).orElse("");
    }
}