package com.ebtedge.fns.gateway.delegate;

import com.ebtedge.config.bean.OrganizationVO;
import com.ebtedge.config.helper.ConfigUtil;
import com.ebtedge.user.admin.bean.AuthRequest;
import com.ebtedge.user.admin.domain.EbtUser;
import com.ebtedge.user.admin.exception.UserAdminException;
import com.ebtedge.user.admin.util.UserAdminAuthorizationUtil;
import com.efunds.security.useradmin.ebt.authorize.api.EbtAuthorizationResponse;
import com.efunds.security.useradmin.ebt.authorize.service.AuthorizeResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


@Slf4j
public class BaseDelegate {


    final ConfigUtil configUtil;
    final UserAdminAuthorizationUtil authorizationUtil;

    public BaseDelegate(ConfigUtil configUtil, UserAdminAuthorizationUtil authorizationUtil) {
        this.configUtil = configUtil;
        this.authorizationUtil = authorizationUtil;
    }


    protected List<OrganizationVO> getStates(String[] agencies) {

        ArrayList<OrganizationVO> stateList = new ArrayList<>();

        Arrays.asList(agencies)
                .stream()
                .forEach(agency -> {
                    String stateCode = agency.substring(0, 2);
                    String stateName = configUtil.getStateNameByAgency(agency);
                    OrganizationVO stateVO = new OrganizationVO();
                    stateVO.setStateName(stateName);
                    stateVO.setStateCode(stateCode);
                    List<OrganizationVO> filteredList = stateList.stream()
                            .filter(stateVO1 -> stateVO1.getStateCode().equalsIgnoreCase(agency.substring(0, 2)))
                            .collect(Collectors.toList());
                    if (filteredList != null && filteredList.size() > 0) {
                        OrganizationVO stateVO1 = filteredList.get(0);
                        stateVO1.getOrganizations().add(agency);
                    } else {
                        stateVO.getOrganizations().add(agency);
                        stateList.add(stateVO);
                    }
                });
        return stateList;
    }

    protected Optional<EbtUser> getUserInfoFromAuthResponse(AuthorizeResponse authorizeResponse, AuthRequest authRequest) {
        if (authorizeResponse != null) {
            EbtAuthorizationResponse authorizationResponse = authorizeResponse.getReturn();
            EbtUser ebtUser = new EbtUser();
            ebtUser.setUserId(authorizationResponse.getUserId());
            ebtUser.setFirstName(authorizationResponse.getFirstName());
            ebtUser.setLastName(authorizationResponse.getLastName());
            ebtUser.setMiddleName(authorizationResponse.getMiddleName());
            ebtUser.setManagedRoles(authorizationUtil.getManagedRoles(authorizeResponse));
            return Optional.of(ebtUser);
        } else {
            log.error("authorizeResponse method parameter is null, user info cannot be retrieved. ");
            throw new UserAdminException("user.not.found", HttpStatus.UNAUTHORIZED);
        }
    }
}
