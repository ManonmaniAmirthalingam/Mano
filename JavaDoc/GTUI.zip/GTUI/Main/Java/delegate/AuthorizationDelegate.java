package com.ebtedge.fns.gateway.delegate;

import com.ebtedge.config.helper.ConfigUtil;
import com.ebtedge.user.admin.bean.AuthRequest;
import com.ebtedge.user.admin.domain.EbtUser;
import com.ebtedge.user.admin.exception.UserAdminException;
import com.ebtedge.user.admin.service.AuthorizationService;
import com.ebtedge.user.admin.util.UserAdminAuthorizationUtil;
import com.efunds.security.useradmin.ebt.authorize.service.AuthorizeResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class AuthorizationDelegate extends BaseDelegate {

    @Autowired
    AuthorizationService authorizationService;

    public AuthorizationDelegate(ConfigUtil configUtil,
                                 UserAdminAuthorizationUtil authorizationUtil) {
        super(configUtil, authorizationUtil);
    }

    public EbtUser authorizeUser(AuthRequest request) {
        try {
            AuthorizeResponse authorizeResponse = authorizationService.findUser(request);
            EbtUser ebtUser = getUserInfoFromAuthResponse(authorizeResponse, request).get();
            return ebtUser;
        } catch (UserAdminException e) {
            log.error("UserAdmin Exception: {}", e);
        } catch (Exception e) {
            log.error("Error retrieving user authorization for the user: {} {}", request.getUsername(), e.getMessage());
        }
        return null;
    }
}
