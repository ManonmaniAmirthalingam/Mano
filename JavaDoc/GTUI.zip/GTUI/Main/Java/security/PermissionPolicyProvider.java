package com.ebtedge.fns.gateway.security;

import java.util.Set;

/**
 * Represents a provider that defines policies for mapping permissions to roles within an
 * application. This interface serves as a contract for classes implementing specific permission
 * policy retrieval logic.
 *
 * <p>It allows querying the roles associated with a particular permission, enabling fine-grained
 * control over user access management in the system.
 *
 * <p>Responsibilities: - Retrieve the set of roles that are permitted to perform a specific
 * operation associated with a given permission.
 *
 * <p>The implementation may define how these mappings are stored and retrieved (e.g., from
 * in-memory structures, configuration files, or external data sources).
 */
public interface PermissionPolicyProvider {

    /**
     * Retrieves the set of roles associated with the specified permission. This allows querying
     * which roles are permitted to execute actions related to the given permission within the
     * application security model.
     *
     * @param permission the permission for which the associated roles will be retrieved
     * @return a set of role names (as strings) that are authorized to perform the specified
     *     permission
     */
    Set<String> getRolesForPermission(UserPermission permission);
}
