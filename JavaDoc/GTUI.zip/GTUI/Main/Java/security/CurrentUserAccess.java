package com.ebtedge.fns.gateway.security;

import com.ebtedge.fns.gateway.domain.UserInfo;
import com.ebtedge.fns.gateway.service.PermissionService;
import com.ebtedge.fns.gateway.util.RouteUrls;
import com.ebtedge.fns.gateway.util.SessionUtil;
import io.jsonwebtoken.lang.Assert;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Optional;

import static com.ebtedge.fns.gateway.util.RouteUrls.*;

/**
 * The CurrentUserAccess component is responsible for determining whether the current user holds a
 * specific permission. It integrates with the {@link PermissionService} to check user permissions
 * based on their roles and the active session information.
 *
 * <p>This class retrieves the currently logged-in user's information using the {@link
 * SessionUtil#getUserInfo()} method. If the user is logged in and their information is available,
 * the {@link PermissionService#hasPermission} method is utilized to assess whether the user has the
 * specified permission.
 *
 * <p>This class ensures that invalid or null inputs, such as missing session information or null
 * permissions, are handled gracefully by returning `false`.
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class CurrentUserAccess {

    private final PermissionService permissionService;

    /**
     * Determines if the currently logged-in user has a specific permission.
     *
     * <p>The method retrieves the current user's information from the session using {@code
     * SessionUtil.getUserInfo()} and checks if the user possesses the specified permission by
     * calling {@code permissionService.hasPermission}. If the user's session is invalid or the
     * permission parameter is null, it returns false.
     *
     * @param permission the permission to check for the currently logged-in user; must not be null
     * @return true if the user has the specified permission, false otherwise
     */
    public boolean hasPermission(UserPermission permission) {
        Assert.notNull(permission, "permission must not be null");
        UserInfo userInfo = SessionUtil.getUserInfo();
        if (userInfo == null) return false;
        return permissionService.hasPermission(permission, userInfo);
    }

    /**
     * Determines whether the currently logged-in user has access to a given URL.
     *
     * <p>The method maps the provided URL to a predefined route using {@code
     * RouteUrls.getRouteUrl}. Based on the resolved route, it checks if the user holds the required
     * permission necessary to access the corresponding resource or page. If the URL is not mapped
     * to any known route or if the user lacks the necessary permission, the method returns {@code
     * false}.
     *
     * @param url the URL to check access for, must not be null or empty
     * @return true if the user has permission to access the given URL, false otherwise
     */
    public boolean hasAccessToUrl(String url) {
        Optional<String> routeUrlOpt = RouteUrls.getRouteUrl(url);
        return routeUrlOpt
                .map(
                        s ->
                                switch (s) {
                                    case TRANSACTION_SEARCH ->
                                            hasPermission(UserPermission.GWShowTranSearchPage);
                                    case ANALYTICS ->
                                            hasPermission(UserPermission.GWShowAnalyticsPage);
                                    case REDE_SEARCH ->
                                            hasPermission(UserPermission.GWShowRedeCompPage);
                                    case RETAILER_SEARCH ->
                                            hasPermission(UserPermission.GWShowRetailerLocatorPage);
                                    case ALERTS -> hasPermission(UserPermission.GWShowAlertsPage);
                                    case SYSTEM_HEALTH ->
                                            hasPermission(UserPermission.GWShowSystemHealthPage);
                                    case USER_ACTIVITY ->
                                            hasPermission(UserPermission.GWShowUserActivityPage);
                                    case USER_PREFERENCES ->
                                            hasPermission(UserPermission.GWShowUserPreferencesPage);
                                    default -> {
                                        log.warn("Url {} is not mapped to any permission", url);
                                        yield false;
                                    }
                                })
                .orElse(false);
    }
}
