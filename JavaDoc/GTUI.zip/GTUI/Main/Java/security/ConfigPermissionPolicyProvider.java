package com.ebtedge.fns.gateway.security;

import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * The ConfigPermissionPolicyProvider is a Spring component that provides a permission-to-role
 * mapping configuration for user access control within the application.
 *
 * <p>This class uses Spring's @ConfigurationProperties to bind configuration properties with the
 * prefix "app-config.security.access-control" to its internal structure. It allows the application
 * to define and manage user access roles for specific permissions in a centralized configuration
 * file.
 *
 * <p>The permission-to-role mapping is maintained as a Map, where the keys are instances of
 * UserPermission enums representing the permissions, and the values are sets of role names
 * (represented as Strings) authorized to perform the actions associated with each permission.
 *
 * <p>This class implements the PermissionPolicyProvider interface, enabling it to provide role
 * information for a given permission when queried.
 *
 * <p>Responsibilities of this class include: 1. Storing the mapping of permissions to roles as
 * configured in the application properties. 2. Providing mechanisms to retrieve the roles
 * associated with a specific permission.
 */
@Component
@ConfigurationProperties(prefix = "app-config.security.access-control")
public class ConfigPermissionPolicyProvider implements PermissionPolicyProvider {

    @Setter private Map<UserPermission, Set<String>> permissions = new HashMap<>();

    @Override
    public Set<String> getRolesForPermission(UserPermission permission) {
        return permissions.getOrDefault(permission, Set.of());
    }
}
