package com.ebtedge.fns.gateway.security;

/**
 * The UserPermission enum represents a set of permissions that can be assigned to users within the
 * application. Each permission corresponds to a specific page or action that the user may be
 * authorized to access or perform.
 *
 * <p>Responsibilities include: - Defining the permissions for accessing various features and
 * functionalities. - Supporting role-based access control by providing enumerations used in user
 * authorization logic.
 *
 * <p>Permissions include (but are not limited to): - Viewing certain pages (e.g., transaction
 * search, analytics, alerts, system health). - Performing specific actions, such as exporting data
 * or managing terminal IDs. - Allowing access to components like Gateway Insights, alerts, or user
 * preferences.
 *
 * <p>This enumeration forms the foundation for integrating with the role-based security
 * infrastructure of the system, ensuring that users are granted access to only the features for
 * which they have the requisite permissions.
 */
public enum UserPermission {
    GWShowTranSearchPage,
    GWShowAnalyticsPage,
    GWShowRedeCompPage,
    GWShowAlertsPage,
    GWShowUserActivityPage,
    GWShowSystemHealthPage,
    GWShowUserPreferencesPage,
    GWShowRetailerLocatorPage,
    GWShowRetailerMap,
    GWShowGatewayInsight,
    GWShowGatewayAT,
    GWAllowTranSearchExport,
    GWAllowRedeCompExport,
    GWAllowUserActivityExport,
    GWAllowCardMonitor,
    GWAllowTerminalIdMonitor,
    GWAllowTerminalIdBlock,
    GWAllowREDEScoreStatusUpdate,
    GWAllowAlertsExport,
    GWAllowRetailerMapExport
}
