package com.ebtedge.fns.gateway.components;

import com.ebtedge.fns.gateway.model.DateTimeRange;
import com.vaadin.flow.component.AbstractCompositeField;
import com.vaadin.flow.component.HasValidation;
import com.vaadin.flow.component.datetimepicker.DateTimePicker;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.orderedlayout.FlexLayout;
import com.vaadin.flow.theme.lumo.LumoUtility;

import lombok.Builder;
import lombok.Getter;

import org.apache.commons.lang3.StringUtils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** A custom component for selecting a date-time range with validation that supports data binding */
public class DateTimeRangePicker
        extends AbstractCompositeField<Div, DateTimeRangePicker, DateTimeRange>
        implements HasValidation {

    private static final String CSS_CLASS_NAME = "date-time-range-picker";
    private static final String START_LABEL_DEFAULT = "Start Date/Time";
    private static final String END_LABEL_DEFAULT = "End Date/Time";
    private static final String DATE_PLACEHOLDER_DEFAULT = "mm/dd/yyyy";
    private static final String TIME_PLACEHOLDER_DEFAULT = "hh:mm a";
    private static final String DATE_TIME_FORMAT = "MM/dd/yyyy HH:mm:ss";
    private static final String RANGE_ERROR_MESSAGE = "Start date cannot be after end date.";
    private static final String MIN_DATE_ERROR = "Date/time must not be before %s";
    private static final String MAX_DATE_ERROR = "Date/time must not be after %s";

    private static final DateTimeFormatter DATE_TIME_FORMATTER =
            DateTimeFormatter.ofPattern(DATE_TIME_FORMAT);

    @Getter private final DateTimePicker startPicker;
    @Getter private final DateTimePicker endPicker;
    private final ValidationDisplay validationDisplay;
    private FlexLayout layout;

    private LocalDateTime min;
    private LocalDateTime max;

    /** Creates a new DateTimeRangePicker with default labels */
    public DateTimeRangePicker() {
        this(START_LABEL_DEFAULT, END_LABEL_DEFAULT);
    }

    /** Creates a new DateTimeRangePicker with custom labels */
    public DateTimeRangePicker(String startLabel, String endLabel) {
        super(null);

        DateTimePickerConfig startConfig =
                DateTimePickerConfig.builder()
                        .label(startLabel)
                        .datePlaceholder(DATE_PLACEHOLDER_DEFAULT)
                        .timePlaceholder(TIME_PLACEHOLDER_DEFAULT)
                        .build();

        DateTimePickerConfig endConfig =
                DateTimePickerConfig.builder()
                        .label(endLabel)
                        .datePlaceholder(DATE_PLACEHOLDER_DEFAULT)
                        .timePlaceholder(TIME_PLACEHOLDER_DEFAULT)
                        .build();

        this.startPicker = createDateTimePicker(startConfig);
        this.endPicker = createDateTimePicker(endConfig);
        this.validationDisplay = new ValidationDisplay();

        initializeComponent();
    }

    public void setFlexDirection(FlexLayout.FlexDirection direction) {
        layout.setFlexDirection(direction);
    }

    public void setLocale(Locale locale) {
        startPicker.setLocale(locale);
        endPicker.setLocale(locale);
    }

    @Override
    public boolean isInvalid() {
        return startPicker.isInvalid()
                || endPicker.isInvalid()
                || isInvalidRange()
                || isOutsideDateConstraints();
    }

    @Override
    public void setInvalid(boolean invalid) {
        getElement().setAttribute("aria-invalid", invalid);
        getElement().getClassList().set("invalid", invalid);
        startPicker.setInvalid(invalid);
        endPicker.setInvalid(invalid);
        if (!invalid) {
            validationDisplay.setMessage(null);
        }
    }

    @Override
    public String getErrorMessage() {
        return validationDisplay.getMessage();
    }

    @Override
    public void setErrorMessage(String message) {
        validationDisplay.setMessage(message);
    }

    public void setMin(LocalDateTime min) {
        this.min = min;
        startPicker.setMin(min);
        endPicker.setMin(min);
        validateDateTimeConstraints();
    }

    public void setMax(LocalDateTime max) {
        this.max = max;
        startPicker.setMax(max);
        endPicker.setMax(max);
        validateDateTimeConstraints();
    }

    public void clear() {
        startPicker.clear();
        endPicker.clear();
        setModelValue(null, true);
        setInvalid(false);
        setErrorMessage(null);
    }

    @Override
    public void setRequiredIndicatorVisible(boolean required) {
        super.setRequiredIndicatorVisible(required);
        startPicker.setRequiredIndicatorVisible(required);
        endPicker.setRequiredIndicatorVisible(required);
    }

    public void setPlaceholders(
            String startDatePlaceholder,
            String startTimePlaceholder,
            String endDatePlaceholder,
            String endTimePlaceholder) {
        startPicker.setDatePlaceholder(startDatePlaceholder);
        startPicker.setTimePlaceholder(startTimePlaceholder);
        endPicker.setDatePlaceholder(endDatePlaceholder);
        endPicker.setTimePlaceholder(endTimePlaceholder);
    }

    @Override
    protected void setPresentationValue(DateTimeRange dateTimeRange) {
        startPicker.setValue(dateTimeRange.getStart());
        endPicker.setValue(dateTimeRange.getEnd());
    }

    private void initializeComponent() {
        layout = createFlexLayout();
        setupLayout(layout);
    }

    private DateTimePicker createDateTimePicker(DateTimePickerConfig config) {
        DateTimePicker picker =
                new DateTimePicker(StringUtils.defaultIfBlank(config.label, START_LABEL_DEFAULT));
        configurePicker(picker, config);
        return picker;
    }

    private void configurePicker(DateTimePicker picker, DateTimePickerConfig config) {
        picker.setDatePlaceholder(config.datePlaceholder);
        picker.setTimePlaceholder(config.timePlaceholder);
        picker.setRequiredIndicatorVisible(config.required);
        picker.getElement().getChild(1).getStyle().setPaddingRight("0.5em");

        // Add validation listeners
        picker.addValueChangeListener(
                event -> {
                    updateValue();
                });
        picker.addValidationStatusChangeListener(
                event -> {
                    validateRange();
                    validateDateTimeConstraints();
                });
    }

    private FlexLayout createFlexLayout() {
        FlexLayout layout = new FlexLayout();
        layout.addClassName(CSS_CLASS_NAME + "-container");
        layout.setFlexWrap(FlexLayout.FlexWrap.WRAP);
        layout.addClassName(LumoUtility.Gap.MEDIUM);
        return layout;
    }

    private void setupLayout(FlexLayout layout) {
        layout.add(startPicker, endPicker);
        getContent().addClassName(CSS_CLASS_NAME);
        getContent().add(layout, validationDisplay);
    }

    private void updateValue() {
        var startValue = startPicker.getValue();
        var endValue = endPicker.getValue();
        DateTimeRange newValue = null;
        if (startValue != null || endValue != null) {
            newValue = new DateTimeRange(startPicker.getValue(), endPicker.getValue());
        }
        setModelValue(newValue, true);
        validateRange();
    }

    private void validateRange() {
        if (shouldSkipRangeValidation()) {
            return;
        }
        boolean invalid = isInvalidRange();
        setInvalid(invalid);
        setErrorMessage(invalid ? RANGE_ERROR_MESSAGE : null);
    }

    private boolean shouldSkipRangeValidation() {
        return (startPicker.isInvalid() || endPicker.isInvalid()) && !isInvalidRange();
    }

    private boolean isInvalidRange() {
        DateTimeRange value = getValue();
        if (value == null) return false;
        LocalDateTime start = value.getStart();
        LocalDateTime end = value.getEnd();
        return end != null && start != null && end.isBefore(start);
    }

    private void validateDateTimeConstraints() {
        boolean isInvalid = false;
        String errorMessage = null;

        // Validate minimum constraints
        if (min != null) {
            if (startPicker.getValue() != null && startPicker.getValue().isBefore(min)) {
                isInvalid = true;
                errorMessage = String.format(MIN_DATE_ERROR, DATE_TIME_FORMATTER.format(min));
            }
            if (endPicker.getValue() != null && endPicker.getValue().isBefore(min)) {
                isInvalid = true;
                errorMessage = String.format(MIN_DATE_ERROR, DATE_TIME_FORMATTER.format(min));
            }
        }

        // Validate maximum constraints
        if (max != null && !isInvalid) {
            // Only check max if min validation passed
            if (startPicker.getValue() != null && startPicker.getValue().isAfter(max)) {
                isInvalid = true;
                errorMessage = String.format(MAX_DATE_ERROR, DATE_TIME_FORMATTER.format(max));
            }
            if (endPicker.getValue() != null && endPicker.getValue().isAfter(max)) {
                isInvalid = true;
                errorMessage = String.format(MAX_DATE_ERROR, DATE_TIME_FORMATTER.format(max));
            }
        }

        // Update component state
        if (isInvalid) {
            setInvalid(true);
            setErrorMessage(errorMessage);
        } else {
            // Only clear if there are no range validation errors
            if (!isInvalidRange()) {
                setInvalid(false);
                setErrorMessage(null);
            }
        }
    }

    private boolean isOutsideDateConstraints() {
        if (min != null) {
            if ((startPicker.getValue() != null && startPicker.getValue().isBefore(min))
                    || (endPicker.getValue() != null && endPicker.getValue().isBefore(min))) {
                return true;
            }
        }
        if (max != null) {
            if ((startPicker.getValue() != null && startPicker.getValue().isAfter(max))
                    || (endPicker.getValue() != null && endPicker.getValue().isAfter(max))) {
                return true;
            }
        }
        return false;
    }

    @Builder
    public static class DateTimePickerConfig {
        private String label;
        private String datePlaceholder;
        private String timePlaceholder;
        private boolean required;
    }

    private static class ValidationDisplay extends Span {
        ValidationDisplay() {
            getStyle()
                    .setColor("var(--lumo-error-text-color)")
                    .setFontSize("var(--lumo-font-size-xs)")
                    .setFontWeight("var(--vaadin-input-field-error-font-weight, 400)");
            setVisible(false);
        }

        String getMessage() {
            return getText();
        }

        void setMessage(String message) {
            setText(message);
            setVisible(StringUtils.isNotBlank(message));
        }
    }
}