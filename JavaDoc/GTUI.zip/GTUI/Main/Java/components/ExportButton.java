package com.ebtedge.fns.gateway.components;

import com.ebtedge.fns.gateway.security.CurrentUserAccess;
import com.ebtedge.fns.gateway.security.UserPermission;
import com.vaadin.flow.component.button.Button;
import com.vaadin.hilla.ApplicationContextProvider;
import java.util.List;

/**
 * The ExportButton class extends the Button class and represents a button component used for data
 * export functionality within a user interface. It enforces user permissions to determine whether
 * the button should be enabled or kept disabled.
 */
public class ExportButton extends Button {
    private final List<UserPermission> permissions;

    public ExportButton(List<UserPermission> permissions) {
        super("Export");
        this.permissions = permissions;
        reset();
    }

    public void enable() {
        if (hasRequiredPermissions()) {
            removeThemeName("disabled-button");
            addThemeName("search-button");
            setEnabled(true);
        }
    }

    private boolean hasRequiredPermissions() {
        if (permissions == null || permissions.isEmpty()) {
            return true;
        }

        CurrentUserAccess currentUserAccess =
                ApplicationContextProvider.getApplicationContext().getBean(CurrentUserAccess.class);

        return currentUserAccess != null
                && permissions.stream().allMatch(currentUserAccess::hasPermission);
    }

    public void reset() {
        addClassName("export-button");
        addThemeName("disabled-button"); // Add a disabled theme initially
        setEnabled(false);
    }
}
