package com.ebtedge.fns.gateway.components;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.H4;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.splitlayout.SplitLayout;
import com.vaadin.flow.shared.Registration;
import com.vaadin.flow.theme.lumo.LumoUtility;

/**
 * A responsive drawer component with a details panel
 *
 * @param <T> Type of data to be displayed in a details panel
 */
@CssImport("themes/fns-gateway/components/details-drawer.css")
public class DetailsDrawer<T> extends Div {
    private static final String CSS_CLASS_NAME = "details-drawer";
    private static final String DETAILS_CLASS_NAME = "drawer-details";
    private static final String OPEN_CLASS_NAME = "open";
    private static final String CLOSED_CLASS_NAME = "closed";
    private static final String DEFAULT_DETAILS_TITLE = "Details";

    private static final int SPLIT_FULL = 100;
    private static final int SPLIT_HALF = 50;

    private final SplitLayout splitLayout;
    private final Div detailsPanel;
    private final Div detailsWrapper;
    private final Component details;
    private final H4 detailsTitle;

    /**
     * Creates a new Drawer with the main panel and details
     *
     * @param mainPanel Main content panel
     * @param details Details panel implementation
     */
    public DetailsDrawer(Component mainPanel, Component details) {
        this.details = details;
        this.detailsWrapper = new Div();

        setupMainLayout();
        this.splitLayout = createSplitLayout(mainPanel);
        this.detailsPanel = createDetailsPanel();
        this.detailsTitle = createDetailsTitle();

        assemblePanels();
    }

    private void setupMainLayout() {
        addClassName(CSS_CLASS_NAME);
        setSizeFull();
    }

    private SplitLayout createSplitLayout(Component mainPanel) {
        SplitLayout layout = new SplitLayout();
        layout.setSizeFull();
        layout.addToPrimary(mainPanel);
        layout.setSplitterPosition(SPLIT_FULL);
        return layout;
    }

    private Div createDetailsPanel() {
        Div panel = new Div();
        panel.addClassName(DETAILS_CLASS_NAME);
        panel.setWidthFull();
        panel.setWidth("auto");
        return panel;
    }

    private H4 createDetailsTitle() {
        H4 title = new H4(DEFAULT_DETAILS_TITLE);
        title.addClassName("drawer-details-title");
        return title;
    }

    private void assemblePanels() {
        HorizontalLayout topActions = createTopActions();
        detailsPanel.add(topActions, detailsWrapper);

        Div secondaryWrapper = new Div(detailsPanel);
        splitLayout.addToSecondary(secondaryWrapper);

        add(splitLayout);
    }

    private HorizontalLayout createTopActions() {
        HorizontalLayout actions = new HorizontalLayout();
        configureTopActions(actions);

        Button closeButton = createCloseButton();
        actions.add(closeButton, detailsTitle);

        return actions;
    }

    private void configureTopActions(HorizontalLayout actions) {
        actions.setSpacing(false);
        actions.setPadding(false);
        actions.addClassNames(LumoUtility.Padding.SMALL);
        actions.setAlignItems(FlexComponent.Alignment.BASELINE);
    }

    private Button createCloseButton() {
        Button closeButton = new Button(VaadinIcon.CLOSE.create());
        closeButton
                .getStyle()
                .setBackground("transparent")
                .setColor("inherit")
                .set("padding", "0px");
        closeButton.addClickListener(e -> hideDetails());
        return closeButton;
    }

    /**
     * Sets the details panel title
     *
     * @param title New title text
     */
    public void setDetailsTitle(String title) {
        detailsTitle.setText(title);
    }

    /**
     * Shows details for the given data
     *
     * @param data Data to display in the details panel
     */
    public void showDetails(T data) {
        detailsWrapper.removeAll();
        updateDetailsVisibility(true, data);
        detailsWrapper.add(details);
        splitLayout.setSplitterPosition(SPLIT_HALF);
    }

    /** Hides the details panel */
    public void hideDetails() {
        updateDetailsVisibility(false, null);
        detailsWrapper.removeAll();
        splitLayout.setSplitterPosition(SPLIT_FULL);
        fireEvent(new DetailsCloseEvent(this, true));
    }

    /**
     * Adds a listener that will be invoked when the details panel is closed.
     *
     * @param listener the listener to be notified of {@link DetailsCloseEvent}.
     * @return the registration object for removing the listener.
     */
    public Registration addDetailsCloseListener(
            ComponentEventListener<DetailsCloseEvent> listener) {
        return addListener(DetailsCloseEvent.class, listener);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private void updateDetailsVisibility(boolean visible, T data) {
        detailsPanel.removeClassName(visible ? CLOSED_CLASS_NAME : OPEN_CLASS_NAME);
        detailsPanel.addClassName(visible ? OPEN_CLASS_NAME : CLOSED_CLASS_NAME);
        if (details instanceof DetailsDrawer.DrawableDetails drawableDetails) {
            if (visible) {
                drawableDetails.showDetails(data);
            } else {
                drawableDetails.hideDetails();
            }
        }
    }

    /** Interface for implementing closable details panels */
    public interface DrawableDetails<T> {
        /**
         * Called when details should be shown
         *
         * @param data Data to display
         */
        void showDetails(T data);

        /** Called when details are being hidden */
        default void hideDetails() {}
    }

    /**
     * Represents an event fired when the details panel of a {@link DetailsDrawer} is closed. This
     * class extends {@link ComponentEvent} and provides contextual information about the component
     * source and the origin of the event.
     *
     * <p>This event can be triggered programmatically or as a result of user interaction with the
     * details panel.
     *
     * <p>Use this event in conjunction with the {@link DetailsDrawer#addDetailsCloseListener}
     * method to listen for and handle close events of the details panel.
     *
     * @param <T> the type of the component that is the source of the event
     */
    public static class DetailsCloseEvent extends ComponentEvent<DetailsDrawer<?>> {
        /**
         * Creates a new event using the given source and indicator whether the event originated
         * from the client side or the server side.
         *
         * @param source the source component
         * @param fromClient <code>true</code> if the event originated from the client side, <code>
         *     false</code> otherwise
         */
        public DetailsCloseEvent(DetailsDrawer source, boolean fromClient) {
            super(source, fromClient);
        }
    }
}
