package com.ebtedge.fns.gateway.components;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.component.tabs.Tabs;
import com.vaadin.flow.shared.Registration;

import lombok.Getter;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;

/** A tab sheet component that lazily loads tab content */
public class LazyTabSheet extends VerticalLayout {
    private static final String CSS_CLASS_NAME = "lazy-tab-sheet";

    private final Map<Tab, Component> contentCache;
    private final Set<ComponentEventListener<TabChangeEvent>> changeListeners;
    private final Function<Tab, Component> contentSupplier;
    private final Div contentContainer;
    private final Tabs tabs;

    /**
     * Creates a new LazyTabSheet
     *
     * @param tabs Tabs component
     * @param contentSupplier Function to create content for each tab
     */
    public LazyTabSheet(Tabs tabs, Function<Tab, Component> contentSupplier) {
        this.tabs = tabs;
        this.contentSupplier = contentSupplier;
        this.contentCache = new HashMap<>();
        this.changeListeners = new HashSet<>();
        this.contentContainer = new Div();

        setupComponent();
        setupTabChangeListener();
        initializeContent();
    }

    private void setupComponent() {
        addClassName(CSS_CLASS_NAME);
        contentContainer.setSizeFull();
        add(tabs, contentContainer);
    }

    private void setupTabChangeListener() {
        tabs.addSelectedChangeListener(
                event -> {
                    updateTabContent();
                    fireTabChangeEvent(event);
                });
    }

    private void initializeContent() {
        updateTabContent();
    }

    /**
     * Adds a listener for tab change events
     *
     * @param listener Listener to add
     * @return Registration for removing the listener
     */
    public Registration addSelectedChangeListener(ComponentEventListener<TabChangeEvent> listener) {
        changeListeners.add(listener);
        return () -> changeListeners.remove(listener);
    }

    /**
     * Gets the currently selected tab
     *
     * @return Currently selected tab
     */
    public Tab getSelectedTab() {
        return tabs.getSelectedTab();
    }

    /**
     * Gets the content component for a specific tab
     *
     * @param tab Tab to get content for
     * @return Content component or null if not cached
     */
    public Component getTabContent(Tab tab) {
        return contentCache.get(tab);
    }

    private void updateTabContent() {
        Tab selectedTab = getSelectedTab();
        if (selectedTab != null) {
            Component content = getOrCreateContent(selectedTab);
            showContent(content);
        }
    }

    private Component getOrCreateContent(Tab tab) {
        return contentCache.computeIfAbsent(tab, this::createContent);
    }

    private Component createContent(Tab tab) {
        try {
            return contentSupplier.apply(tab);
        } catch (Exception e) {
            return createErrorContent(e);
        }
    }

    private Component createErrorContent(Exception e) {
        Div errorDiv = new Div();
        errorDiv.setText("Error loading tab content: " + e.getMessage());
        errorDiv.getStyle().set("color", "red");
        return errorDiv;
    }

    private void showContent(Component content) {
        contentContainer.removeAll();
        contentContainer.add(content);
    }

    private void fireTabChangeEvent(Tabs.SelectedChangeEvent selectedChangeEvent) {
        TabChangeEvent event =
                new TabChangeEvent(
                        this,
                        selectedChangeEvent.getSelectedTab(),
                        selectedChangeEvent.getPreviousTab());
        changeListeners.forEach(listener -> listener.onComponentEvent(event));
    }

    /** Event fired when selected tab changes */
    public static class TabChangeEvent extends ComponentEvent<LazyTabSheet> {
        @Getter private final Tab selectedTab;
        @Getter private final Tab previousTab;

        public TabChangeEvent(LazyTabSheet source, Tab selectedTab, Tab previousTab) {
            super(source, false);
            this.selectedTab = selectedTab;
            this.previousTab = previousTab;
        }
    }
}
