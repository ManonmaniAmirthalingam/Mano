package com.ebtedge.fns.gateway.components;

import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.Div;

/**
 * A custom dialog component with a spinner element. This dialog is intended to be used as a loading
 * indicator, showing a spinner animation while some background operation is being performed.
 *
 * <p>The dialog is designed to: - Prevent closing using Escape key. - Prevent closing by clicking
 * areas outside the dialog. - Remove size constraints by unsetting the minimum width.
 *
 * <p>The visual appearance is styled using an external CSS file specified by the annotation
 * {@code @CssImport("themes/fns-gateway/components/spinner-dialog.css")}.
 */
@CssImport("themes/fns-gateway/components/spinner-dialog.css")
public class SpinnerDialog extends Dialog {

    public SpinnerDialog() {
        addClassName("spinner-dialog");
        setCloseOnEsc(false);
        setCloseOnOutsideClick(false);
        setMinWidth("unset");
        Div spinner = new Div();
        spinner.addClassName("spinner");
        add(spinner);
    }

    public void close() {
        getElement().executeJs("setTimeout(() => this.opened = false, 500)");
    }
}
