package com.ebtedge.fns.gateway.rule;

import lombok.RequiredArgsConstructor;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Represents a context for managing attributes during rule evaluation. Provides methods to retrieve
 * and manipulate attributes while adhering to immutability rules and allows the creation of custom
 * contexts through a builder interface.
 */
public interface RuleContext {

    /**
     * Gets a typed attribute from the context
     *
     * @param name the attribute name
     * @param type the class of expected type
     * @param <T> the expected type of the attribute
     * @return optional containing the attribute value if present
     * @throws ClassCastException if the attribute exists but cannot be cast to the requested type
     */
    default <T> Optional<T> getAttribute(String name, Class<T> type) {
        return Optional.empty();
    }

    /**
     * Sets a named attribute in the context with validation
     *
     * @param name the attribute name
     * @param value the attribute value
     * @param <T> the type of the attribute
     * @throws IllegalArgumentException if name is null or empty
     * @throws UnsupportedOperationException if context is immutable
     */
    default <T> void setAttribute(String name, T value) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Attribute name cannot be null or empty");
        }
        throw new UnsupportedOperationException("This context does not support mutable attributes");
    }

    /**
     * Gets all attributes in this context
     *
     * @return unmodifiable map of attribute names to values
     */
    default Map<String, Object> getAttributes() {
        return Map.of();
    }

    /**
     * Creates a new context builder for implementing classes
     *
     * @return a new context builder
     */
    static ContextBuilder builder() {
        return new DefaultRuleContext.DefaultContextBuilder();
    }

    interface ContextBuilder {
        /**
         * Adds an attribute to the context being built
         *
         * @param name attribute name
         * @param value attribute value
         * @return this builder
         */
        ContextBuilder withAttribute(String name, Object value);

        /**
         * Builds the context
         *
         * @return new RuleContext instance
         */
        RuleContext build();
    }

    @RequiredArgsConstructor
    class DefaultRuleContext implements RuleContext {
        private final Map<String, Object> attributes;

        @Override
        public <T> Optional<T> getAttribute(String name, Class<T> type) {
            Object value = attributes.get(name);
            if (type.isInstance(value)) {
                return Optional.of(type.cast(value));
            }
            return Optional.empty();
        }

        @Override
        public Map<String, Object> getAttributes() {
            return attributes;
        }

        /** Default implementation of ContextBuilder */
        public static class DefaultContextBuilder implements ContextBuilder {
            private final Map<String, Object> attributes = new ConcurrentHashMap<>();

            @Override
            public ContextBuilder withAttribute(String name, Object value) {
                if (name != null) {
                    attributes.put(name, value);
                }
                return this;
            }

            @Override
            public RuleContext build() {
                return new DefaultRuleContext(attributes);
            }
        }
    }
}
