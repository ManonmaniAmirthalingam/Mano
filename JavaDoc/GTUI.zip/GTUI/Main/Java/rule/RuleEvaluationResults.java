package com.ebtedge.fns.gateway.rule;

import lombok.Getter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Represents the overall results of evaluating a set of rules. This class maintains a collection of
 * individual rule evaluation results, while providing methods to analyze and summarize the
 * outcomes.
 *
 * @param <T> The type of the violations reported by rules
 */
@Getter
@ToString
public class RuleEvaluationResults<T> {

    /** Flag indicating if any rules were violated */
    private boolean violated;

    /** List of individual rule evaluation results */
    private final List<RuleEvaluationResult<T>> evaluationResults;

    /** Creates a new RuleEvaluationResults instance */
    public RuleEvaluationResults() {
        this.evaluationResults = new ArrayList<>();
    }

    /**
     * Adds a single evaluation result and updates the violation status
     *
     * @param result The evaluation result to add
     */
    public void addResult(RuleEvaluationResult<T> result) {
        if (result != null) {
            evaluationResults.add(result);
            updateViolationStatus();
        }
    }

    /**
     * Adds multiple evaluation results and updates the violation status
     *
     * @param results Collection of results to add
     */
    public void addResults(List<RuleEvaluationResult<T>> results) {
        if (results != null) {
            evaluationResults.addAll(results);
            updateViolationStatus();
        }
    }

    /** Updates the overall violation status based on individual results */
    private void updateViolationStatus() {
        this.violated = evaluationResults.stream().anyMatch(RuleEvaluationResult::isViolated);
    }

    /**
     * Gets all violations from all results
     *
     * @return Set of unique rule violations
     */
    public Set<T> getAllViolations() {
        return evaluationResults.parallelStream()
                .filter(RuleEvaluationResult::isViolated)
                .flatMap(result -> result.getViolations().stream())
                .collect(Collectors.toUnmodifiableSet());
    }

    /**
     * Gets all failed evaluations (with errors)
     *
     * @return List of evaluation results that encountered errors
     */
    public List<RuleEvaluationResult<T>> getFailedEvaluations() {
        return evaluationResults.stream().filter(RuleEvaluationResult::isError).toList();
    }

    /**
     * Checks if any evaluations failed with errors
     *
     * @return true if any evaluations had errors
     */
    public boolean hasErrors() {
        return evaluationResults.stream().anyMatch(RuleEvaluationResult::isError);
    }

    /**
     * Gets the count of violated rules
     *
     * @return Number of violated rules
     */
    public int getViolationCount() {
        return (int) evaluationResults.stream().filter(RuleEvaluationResult::isViolated).count();
    }

    /**
     * Creates a summary of the evaluation results
     *
     * @return String containing evaluation summary
     */
    public String getSummary() {
        return String.format(
                """
                Rule Evaluation Summary:
                - Total rules: %d
                - Violated rules: %d
                - Failed evaluations: %d
                - Total violations: %d
                """,
                evaluationResults.size(),
                getViolationCount(),
                getFailedEvaluations().size(),
                getAllViolations().size());
    }
}
