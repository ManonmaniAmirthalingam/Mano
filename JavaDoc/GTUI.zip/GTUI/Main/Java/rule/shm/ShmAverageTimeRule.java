package com.ebtedge.fns.gateway.rule.shm;

import com.ebtedge.fns.gateway.rule.RuleType;
import org.springframework.stereotype.Component;

/**
 * Represents a specific implementation of an abstract rule for calculating average system health
 * monitoring time. This rule evaluates data based on the "Average Count" (AT) type defined in the
 * {@link ShmRuleType} enumeration. It is designed to calculate and monitor average metrics over a
 * given time period.
 *
 * <p>This class extends {@link AbstractShmRule} and provides a concrete type and priority for the
 * rule. It is used in rule evaluation systems to identify and validate average-based violations in
 * monitored entities.
 *
 * <p>Key functionalities include: - Assigning the rule type as "AT" (Average Count). - Specifying
 * the rule's priority as zero, implying its execution preference in comparison to other rules.
 */
@Component
public class ShmAverageTimeRule extends AbstractShmRule {

    @Override
    public RuleType getType() {
        return ShmRuleType.AT;
    }

    @Override
    public int getPriority() {
        return 0;
    }
}
