package com.ebtedge.fns.gateway.rule.shm;

import com.ebtedge.fns.gateway.rule.RuleType;
import org.springframework.stereotype.Component;

/**
 * A rule implementation used for evaluating percentage-based system health monitoring conditions.
 * This class extends the behavior of {@code AbstractShmRule}, providing functionality for applying
 * rules related to percentage counts and their associated violations.
 *
 * <p>This implementation uses {@code ShmRuleType.PC} as its rule type, representing "Percentage
 * Count".
 *
 * <p>Key features include: - Defining the specific rule type as percentage-based monitoring. -
 * Setting the priority for rule evaluation to zero, allowing it to be processed accordingly in the
 * sequence of rule evaluations.
 *
 * <p>This class is a component managed by the Spring framework.
 */
@Component
public class ShmPercentageCountRule extends AbstractShmRule {

    @Override
    public RuleType getType() {
        return ShmRuleType.PC;
    }

    @Override
    public int getPriority() {
        return 0;
    }
}
