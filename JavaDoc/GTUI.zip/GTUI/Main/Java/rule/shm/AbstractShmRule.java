package com.ebtedge.fns.gateway.rule.shm;

import com.ebtedge.fns.gateway.model.ShmAlert;
import com.ebtedge.fns.gateway.rule.Rule;
import com.ebtedge.fns.gateway.rule.RuleContext;
import com.ebtedge.fns.gateway.rule.RuleEvaluationResult;
import com.ebtedge.fns.gateway.stats.MonitorStatistics;
import com.ebtedge.fns.gateway.util.BinUtil;
import com.ebtedge.yb.entity.ShmEntityAssociation;
import com.ebtedge.yb.entity.ShmRuleMeta;
import lombok.extern.slf4j.Slf4j;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Abstract base class for system health monitoring (SHM) rules, providing common functionality for
 * evaluating rule violations based on input, context, and associated metadata.
 *
 * <p>This class implements the {@link Rule} interface and introduces methods that determine whether
 * a given entity violates defined SHM rules by leveraging statistical data, entity associations,
 * and rule metadata.
 *
 * <p>Subclasses of this abstract class should define specific rule types and evaluation logic by
 * overriding the {@code getType()} and {@code getPriority()} methods.
 */
@Slf4j
public abstract class AbstractShmRule implements Rule<ShmRuleInput, RuleContext, ShmRuleViolation> {

    public static String STATISTIC_KEY = "statistic";
    public static String ENTITY_ASSOCIATIONS_KEY = "entityAssociations";
    public static String RULE_META_KEY = "ruleMeta";

    @Override
    public RuleEvaluationResult<ShmRuleViolation> evaluate(ShmRuleInput input, RuleContext ctx) {
        List<ShmRuleViolation> violations = findViolations(input, ctx);

        return RuleEvaluationResult.<ShmRuleViolation>builder()
                .ruleType(getType())
                .violated(!violations.isEmpty())
                .violations(violations)
                .build();
    }

    /** Finds violations based on statistics and metadata */
    private List<ShmRuleViolation> findViolations(ShmRuleInput input, RuleContext ctx) {
        MonitorStatistics statistics =
                ctx.getAttribute(STATISTIC_KEY, MonitorStatistics.class)
                        .orElse(new MonitorStatistics(Map.of()));
        List<String> entities;
        if (BinUtil.isBinNumber(input.getEntity())) {
            entities = List.of(input.getEntity());
        } else {
            entities = findAssociatedEntities(input.getEntity(), ctx);
        }
        List<ShmRuleMeta> ruleMeta = getRuleMeta(ctx);

        Map<ShmAlert, Integer> alertAccumulation =
                statistics.getAlertAccumulations().entrySet().parallelStream()
                        .filter(entry -> isApplicable(entry, ruleMeta))
                        .filter(entry -> hasViolation(entry, entities))
                        .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
        if (alertAccumulation.isEmpty()) {
            return Collections.emptyList();
        }
        if (log.isDebugEnabled()) {
            log.debug(
                    """
                Entity {} has violated rule {}.
                Rule input: {},
                """,
                    input.getEntity(),
                    getType().getName(),
                    input);
        }
        return List.of(
                ShmRuleViolation.builder()
                        .entity(input.getEntity())
                        .ruleType(getType())
                        .alertAccumulation(alertAccumulation)
                        .build());
    }

    @SuppressWarnings("unchecked")
    private List<String> findAssociatedEntities(String entity, RuleContext ctx) {
        List<ShmEntityAssociation> entityAssociations =
                ctx.getAttribute(ENTITY_ASSOCIATIONS_KEY, List.class)
                        .orElse(Collections.emptyList());
        return entityAssociations.stream()
                .filter(assoc -> assoc.getEntityName().equals(entity))
                .map(ShmEntityAssociation::getAlertEntity)
                .toList();
    }

    private boolean hasViolation(
            Map.Entry<ShmAlert, Integer> entry, List<String> associatedEntities) {
        return associatedEntities.stream()
                .anyMatch(entity -> entity.equals(entry.getKey().getAlertEntity()));
    }

    private boolean isApplicable(
            Map.Entry<ShmAlert, Integer> entry, List<ShmRuleMeta> ruleMeta) {
        return ruleMeta.stream()
                .anyMatch(
                        metadata ->
                                metadata.getTriggerId().equals(entry.getKey().getAlertTriggerId()));
    }

    @SuppressWarnings("unchecked")
    private List<ShmRuleMeta> getRuleMeta(RuleContext ctx) {
        List<ShmRuleMeta> ruleMeta =
                ctx.getAttribute(RULE_META_KEY, List.class).orElse(Collections.emptyList());
        return ruleMeta.stream()
                .filter(ShmRuleMeta::getEnabled)
                .filter(
                        metadata ->
                                getType().equals(ShmRuleType.fromName(metadata.getTriggerType())))
                .toList();
    }
}
