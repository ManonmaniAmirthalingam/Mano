package com.ebtedge.fns.gateway.rule.shm;

import com.ebtedge.fns.gateway.rule.RuleType;
import org.springframework.stereotype.Component;

/**
 * Represents a rule for accumulating count evaluation in the system health monitoring framework.
 * Extends {@code AbstractShmRule} to provide specific implementation details for handling
 * accumulated count monitoring scenarios.
 *
 * <p>This rule evaluates entities based on their accumulated counts within the system monitoring
 * context, leveraging statistical data and metadata provided during rule evaluation.
 *
 * <p>Overrides methods to specify its rule type and evaluation priority: - {@code getType()}
 * returns the rule as {@code ShmRuleType.AC}. - {@code getPriority()} defines the priority level of
 * the rule as 0.
 *
 * <p>Intended to be used in scenarios where counting accumulated data is critical for system health
 * decision-making, and to enforce compliance or alert managers based on accumulated data
 * thresholds.
 */
@Component
public class ShmAccumulatingCountRule extends AbstractShmRule {

    @Override
    public RuleType getType() {
        return ShmRuleType.AC;
    }

    @Override
    public int getPriority() {
        return 0;
    }
}
