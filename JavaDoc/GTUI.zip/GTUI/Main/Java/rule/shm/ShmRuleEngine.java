package com.ebtedge.fns.gateway.rule.shm;

import com.ebtedge.fns.gateway.rule.*;
import com.ebtedge.fns.gateway.service.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * ShmRuleEngine is a rule engine implementation for system health monitoring (SHM) rules. It
 * evaluates a set of rules against the provided input and returns the results of the rule
 * evaluations. The engine supports evaluating all rules or a specific subset of rules based on the
 * rule types provided.
 *
 * <p>This class is designed to handle both synchronous rule evaluation operations and error
 * management during the execution of individual rules. It also facilitates the creation of context
 * necessary for rule evaluation based on statistical and metadata services.
 *
 * <p>The engine ensures input validation, contextual information injection, and handles exceptions
 * gracefully to return meaningful error details in case of failure.
 *
 * @see RuleEngine
 * @see Rule
 * @see RuleEvaluationResults
 * @see ShmRuleInput
 * @see ShmRuleViolation
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ShmRuleEngine
        implements RuleEngine<RuleEvaluationResults<ShmRuleViolation>, ShmRuleInput> {

    private final List<Rule<ShmRuleInput, RuleContext, ShmRuleViolation>> rules;
    private final ShmStatisticsService statisticsService;
    private final ShmEntityAssociationService entityAssociationService;
    private final ShmRuleMetaService ruleMetaService;

    /**
     * Evaluates all applicable rules for the given input.
     *
     * @param input The input to evaluate against the rules
     * @return Results of all rule evaluations
     * @throws IllegalArgumentException if input is invalid
     */
    @Override
    public RuleEvaluationResults<ShmRuleViolation> evaluateAll(ShmRuleInput input) {
        RuleEvaluationResults<ShmRuleViolation> results;
        try {
            log.debug("Starting rule evaluation for input: {}", input);
            validateInput(input);
            results = evaluate(input, getSupportedRuleTypes());
        } catch (Exception e) {
            log.error("Fatal error during rule evaluation. {}", e.getMessage(), e);
            results = createErrorResults(e);
        }
        log.debug("Completed rules evaluation.\n {}", results.getSummary());
        return results;
    }

    /**
     * Evaluates specific rule types for the given input.
     *
     * @param input The input to evaluate
     * @param ruleTypes List of rule types to evaluate
     * @return Results of rule evaluations
     */
    @Override
    public RuleEvaluationResults<ShmRuleViolation> evaluate(
            ShmRuleInput input, List<RuleType> ruleTypes) {
        var filteredRules = filterRulesByType(ruleTypes);
        return processRules(input, filteredRules);
    }

    private List<Rule<ShmRuleInput, RuleContext, ShmRuleViolation>> filterRulesByType(
            List<RuleType> ruleTypes) {
        return rules.stream()
                .filter(rule -> ruleTypes.contains(rule.getType()))
                .collect(Collectors.toList());
    }

    private RuleEvaluationResults<ShmRuleViolation> processRules(
            ShmRuleInput input,
            List<Rule<ShmRuleInput, RuleContext, ShmRuleViolation>> rulesToProcess) {
        RuleEvaluationResults<ShmRuleViolation> results = new RuleEvaluationResults<>();
        RuleContext context = createContext(input);

        results.addResults(
                rulesToProcess.stream()
                        .sorted()
                        .map(rule -> evaluateRuleWithContext(rule, input, context))
                        .toList());
        return results;
    }

    private RuleEvaluationResult<ShmRuleViolation> evaluateRuleWithContext(
            Rule<ShmRuleInput, RuleContext, ShmRuleViolation> rule,
            ShmRuleInput input,
            RuleContext context) {
        RuleEvaluationResult<ShmRuleViolation> result;
        try {
            log.debug("Evaluating rule: {}", rule.getType());
            result = rule.evaluate(input, context);
        } catch (Exception e) {
            log.error("Error evaluating rule {}: {}", rule.getType(), e.getMessage(), e);
            result = createErrorResult(rule, e);
        }
        log.debug("Rule evaluation complete.\n {}", result.getSummary());
        return result;
    }

    private void validateInput(ShmRuleInput input) {
        if (input == null) {
            throw new IllegalArgumentException("Rule evaluation input cannot be null");
        }
        if (input.getFrom() == null || input.getTo() == null) {
            throw new IllegalArgumentException("Time range cannot be null");
        }
        if (input.getFrom().isAfter(input.getTo())) {
            throw new IllegalArgumentException("Invalid time range: 'from' is after 'to'");
        }
    }

    private RuleContext createContext(ShmRuleInput input) {
        try {
            var statistics = statisticsService.getMonitorStats(input.getFrom(), input.getTo());
            return RuleContext.builder()
                    .withAttribute(AbstractShmRule.STATISTIC_KEY, statistics)
                    .withAttribute(
                            AbstractShmRule.ENTITY_ASSOCIATIONS_KEY,
                            entityAssociationService.getAll())
                    .withAttribute(AbstractShmRule.RULE_META_KEY, ruleMetaService.getAll())
                    .build();
        } catch (Exception e) {
            log.error("Error creating rule context: {}", e.getMessage(), e);
            throw new RuleEvaluationException("Failed to create rule context", e);
        }
    }

    private RuleEvaluationResult<ShmRuleViolation> createErrorResult(
            Rule<ShmRuleInput, RuleContext, ShmRuleViolation> rule, Exception e) {
        return RuleEvaluationResult.<ShmRuleViolation>builder()
                .ruleType(rule.getType())
                .error(true)
                .errorMessage("Rule evaluation failed: " + e.getMessage())
                .build();
    }

    private RuleEvaluationResults<ShmRuleViolation> createErrorResults(Exception e) {
        RuleEvaluationResults<ShmRuleViolation> results = new RuleEvaluationResults<>();
        results.addResult(
                RuleEvaluationResult.<ShmRuleViolation>builder()
                        .error(true)
                        .errorMessage("Fatal error during rule evaluation: " + e.getMessage())
                        .build());
        return results;
    }

    @Override
    public List<RuleType> getSupportedRuleTypes() {
        return Arrays.asList(ShmRuleType.values());
    }
}
