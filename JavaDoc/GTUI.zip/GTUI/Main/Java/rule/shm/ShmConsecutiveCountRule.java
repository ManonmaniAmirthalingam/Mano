package com.ebtedge.fns.gateway.rule.shm;

import com.ebtedge.fns.gateway.rule.RuleType;
import org.springframework.stereotype.Component;

/**
 * A specific implementation of the {@link AbstractShmRule} that defines a rule for checking
 * consecutive occurrences of system health violations. This rule determines whether entities have
 * consecutively triggered specific system health alerts as defined by the rule type.
 *
 * <p>This implementation sets the rule type to consecutive count and assigns it a default priority
 * used in evaluating and managing rule execution order.
 *
 * <p>Components: - Defines the rule type as {@link ShmRuleType#CC}, representing the "Consecutive
 * Count" rule. - Implements the priority level with a default value of zero.
 *
 * <p>Responsibilities: - Provide metadata about the rule type to the evaluation framework. -
 * Support ordering and prioritization of the rule within the broader rule evaluation lifecycle.
 */
@Component
public class ShmConsecutiveCountRule extends AbstractShmRule {

    @Override
    public RuleType getType() {
        return ShmRuleType.CC;
    }

    @Override
    public int getPriority() {
        return 0;
    }
}
