package com.ebtedge.fns.gateway.rule.shm;

import java.time.LocalDateTime;

import lombok.Builder;
import lombok.Value;

/**
 * Represents input parameters for the evaluation of system health monitoring rules. Provides
 * information about the time range and the specific entity for which rules should be assessed.
 *
 * <p>Instances of this class are immutable and need to be constructed using the builder pattern
 * provided by Lombok annotations.
 *
 * <p>This class is utilized within the system health monitoring process to supply necessary context
 * for assessing the defined rules, ensuring accurate and targeted evaluations.
 */
@Value
@Builder(toBuilder = true)
public class ShmRuleInput {
    LocalDateTime from;
    LocalDateTime to;
    String entity;
}
