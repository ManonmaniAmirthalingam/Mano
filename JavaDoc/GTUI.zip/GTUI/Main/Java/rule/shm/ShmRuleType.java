package com.ebtedge.fns.gateway.rule.shm;

import com.ebtedge.fns.gateway.rule.RuleType;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.Arrays;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Enumeration of system health check rule types. Defines different types of rules used for
 * monitoring system health.
 */
@Getter
@RequiredArgsConstructor
public enum ShmRuleType implements RuleType {
    /** Rule type for tracking accumulated count over time */
    AC("Accumulating Count"),

    /** Rule type for monitoring average counts */
    AT("Average Count"),

    /** Rule type for checking consecutive occurrences */
    CC("Consecutive Count"),

    /** Rule type for percentage-based monitoring */
    PC("Percentage Count"),

    /** Rule type for minimum transaction threshold */
    MT("Minimum Transaction");

    private static final Map<String, ShmRuleType> NAME_MAP =
            Arrays.stream(values())
                    .collect(Collectors.toUnmodifiableMap(ShmRuleType::getName, type -> type));

    private final String description;

    /**
     * Returns the name of the rule type.
     *
     * @return The enumeration name as the rule type identifier
     */
    @Override
    public String getName() {
        return name();
    }

    /**
     * Finds a rule type by its name.
     *
     * @param name The name of the rule type to find
     * @return The matching rule type
     * @throws IllegalArgumentException if no matching rule type is found
     */
    public static ShmRuleType fromName(String name) {
        return Optional.ofNullable(NAME_MAP.get(name))
                .orElseThrow(
                        () ->
                                new IllegalArgumentException(
                                        String.format(
                                                "Unknown rule type: %s. Available types: %s",
                                                name, Arrays.toString(values()))));
    }

    /**
     * Provides a string representation of the rule type.
     *
     * @return A string containing the name and description of the rule type
     */
    @Override
    public String toString() {
        return String.format("%s (%s)", name(), description);
    }
}
