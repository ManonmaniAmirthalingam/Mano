package com.ebtedge.fns.gateway.rule.shm;

import com.ebtedge.fns.gateway.rule.RuleType;
import org.springframework.stereotype.Component;

/**
 * Represents a system health monitoring rule that enforces a minimum transaction threshold. This
 * concrete implementation of the {@link AbstractShmRule} specifically evaluates whether the given
 * input violates the minimum transaction rule type.
 *
 * <p>The rule is identified as {@link ShmRuleType#MT}, which stands for "Minimum Transaction". It
 * has the lowest priority within the rule evaluation system by returning a priority value of 0.
 */
@Component
public class ShmMinimumTransactionRule extends AbstractShmRule {

    @Override
    public RuleType getType() {
        return ShmRuleType.MT;
    }

    @Override
    public int getPriority() {
        return 0;
    }
}
