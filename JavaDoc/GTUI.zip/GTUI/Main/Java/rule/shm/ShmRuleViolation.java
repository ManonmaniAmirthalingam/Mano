package com.ebtedge.fns.gateway.rule.shm;

import com.ebtedge.fns.gateway.model.ShmAlert;
import com.ebtedge.fns.gateway.rule.RuleType;
import lombok.Builder;
import lombok.Value;

import java.util.Map;

/**
 * Represents a violation of a system health monitoring rule. Encapsulates details about the entity
 * involved, the rule type that was violated, and accumulations of related alerts.
 *
 * <p>This class provides an immutable model for conveying rule violation data and is typically
 * utilized in rule evaluation systems to highlight breaches.
 */
@Value
@Builder
public class ShmRuleViolation {
    String entity;
    RuleType ruleType;
    @Builder.Default Map<ShmAlert, Integer> alertAccumulation = Map.of();
}
