package com.ebtedge.fns.gateway.rule;

/**
 * Represents a rule that can evaluate specific input in a given context. Rules are prioritized and
 * can be compared for sorting based on their priority. Additional methods provide evaluation
 * details, rule applicability, and type information.
 *
 * @param <T> The type of input the rule evaluates
 * @param <C> The type of context in which the rule evaluates, must extend RuleContext
 * @param <V> The type of violations or results produced during evaluation
 */
public interface Rule<T, C extends RuleContext, V> extends Comparable<Rule<T, C, V>> {

    /**
     * Evaluates the input against the rule using the provided context
     *
     * @param input the input to evaluate
     * @param ctx the context for evaluation
     * @return the result of the rule evaluation
     * @throws IllegalArgumentException if input or context is invalid
     */
    RuleEvaluationResult<V> evaluate(T input, C ctx);

    /**
     * Gets the type of this rule
     *
     * @return the rule type
     */
    RuleType getType();

    /**
     * Gets the priority of this rule. Higher priority rules should be evaluated before lower
     * priority ones.
     *
     * @return the rule priority
     */
    int getPriority();

    /**
     * Compares rules based on priority for sorting
     *
     * @param other the rule to compare with
     * @return comparison result based on priority
     */
    @Override
    default int compareTo(Rule<T, C, V> other) {
        return Integer.compare(other.getPriority(), this.getPriority());
    }

    /**
     * Checks if this rule is applicable for the given input and context
     *
     * @param input the input to check
     * @param ctx the context to check
     * @return true if the rule is applicable
     */
    default boolean isApplicable(T input, C ctx) {
        return true;
    }
}
