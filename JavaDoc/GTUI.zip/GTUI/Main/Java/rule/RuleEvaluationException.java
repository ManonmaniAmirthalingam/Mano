package com.ebtedge.fns.gateway.rule;

/**
 * Represents an exception that occurs during the evaluation of rules in a rule engine. This
 * exception is typically thrown when a rule cannot be evaluated successfully due to an internal
 * error, invalid input, or unforeseen issues in the evaluation process.
 *
 * <p>This class extends {@code RuntimeException}, allowing it to be used in scenarios where
 * exceptions are intended to signify critical runtime failures during rule evaluation.
 *
 * <p>Instances of this exception include a message describing the error and an optional cause to
 * provide further context about the failure.
 */
public class RuleEvaluationException extends RuntimeException {
    public RuleEvaluationException(String message, Throwable cause) {
        super(message, cause);
    }
}
