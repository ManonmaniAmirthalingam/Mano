package com.ebtedge.fns.gateway.rule;

import lombok.Builder;
import lombok.Value;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * Represents the result of evaluating a rule in a rule-based system. This class provides
 * information such as whether the rule was violated, the type of the rule evaluated, any violations
 * encountered, and details about potential errors during the evaluation process.
 *
 * @param <T> the type of violations or results produced during evaluation
 */
@Value
@Builder(toBuilder = true)
public class RuleEvaluationResult<T> {

    /** Indicates if the rule was violated */
    boolean violated;

    /** The type of rule that was evaluated */
    RuleType ruleType;

    /** List of specific violations found during evaluation -- GETTER -- Gets the violation list */
    @Builder.Default List<T> violations = Collections.emptyList();

    /** Indicates if an error occurred during evaluation */
    @Builder.Default boolean error = false;

    /** Description of any error that occurred */
    String errorMessage;

    /**
     * Gets the error message if present
     *
     * @return Optional containing the error message
     */
    public Optional<String> getErrorMessage() {
        return Optional.ofNullable(errorMessage);
    }

    /**
     * Gets the number of violations
     *
     * @return Count of violations
     */
    public int getViolationCount() {
        return violations.size();
    }

    /**
     * Checks if there are any violations
     *
     * @return true if there are violations
     */
    public boolean hasViolations() {
        return !violations.isEmpty();
    }

    /**
     * Creates a human-readable summary of the evaluation result
     *
     * @return Formatted summary string
     */
    public String getSummary() {
        if (error) {
            return String.format(
                    "Rule evaluation failed for %s: %s",
                    ruleType.getName(), errorMessage != null ? errorMessage : "Unknown error");
        }

        return String.format(
                """
                Rule evaluation for %s:
                - Violated: %s
                - Violations: %d
                """,
                ruleType.getDescription(), violated, getViolationCount());
    }

    /**
     * Creates a successful result
     *
     * @param ruleType The type of rule evaluated
     * @return New RuleEvaluationResult instance
     */
    public static RuleEvaluationResult success(RuleType ruleType) {
        return builder().ruleType(ruleType).violated(false).build();
    }

    /**
     * Creates an error result
     *
     * @param ruleType The type of rule evaluated
     * @param errorMessage Description of the error
     * @return New RuleEvaluationResult instance
     */
    public static RuleEvaluationResult error(RuleType ruleType, String errorMessage) {
        return builder().ruleType(ruleType).error(true).errorMessage(errorMessage).build();
    }
}
