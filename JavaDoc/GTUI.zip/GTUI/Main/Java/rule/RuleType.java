package com.ebtedge.fns.gateway.rule;

/**
 * Represents a type of rule used in rule evaluation systems. Provides metadata about the rule type
 * including a unique name and a human-readable description. Implementations of this interface can
 * define logic for categorizing and managing different rule types.
 */
public interface RuleType {

    /**
     * Gets the unique name identifier of the rule type
     *
     * @return the rule type name
     */
    String getName();

    /**
     * Gets the human-readable description of the rule type
     *
     * @return the rule type description
     */
    String getDescription();
}
