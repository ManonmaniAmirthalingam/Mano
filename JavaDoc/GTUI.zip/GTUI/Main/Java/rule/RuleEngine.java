package com.ebtedge.fns.gateway.rule;

import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * Represents a generic rule engine that evaluates rules on specified inputs to yield results. The
 * RuleEngine interface facilitates rule-based evaluations, supports both synchronous and
 * asynchronous operations, and enables the querying of supported rule types.
 *
 * @param <R> The type of result produced after evaluating the rules
 * @param <T> The type of input the rules are evaluated against
 */
public interface RuleEngine<R, T> {

    /**
     * Evaluates all applicable rules against the given input
     *
     * @param input the input to evaluate
     * @return the aggregated result of all rule evaluations
     * @throws RuleEvaluationException if evaluation fails
     */
    R evaluateAll(T input);

    /**
     * Asynchronously evaluates all applicable rules
     *
     * @param input the input to evaluate
     * @return future containing the aggregated result
     */
    default CompletableFuture<R> evaluateAllAsync(T input) {
        return CompletableFuture.supplyAsync(() -> evaluateAll(input));
    }

    /**
     * Evaluates a specific subset of rules
     *
     * @param input the input to evaluate
     * @param ruleTypes the types of rules to evaluate
     * @return the aggregated result of specified rule evaluations
     */
    default R evaluate(T input, List<RuleType> ruleTypes) {
        throw new UnsupportedOperationException("Selective rule evaluation not implemented");
    }

    /**
     * Gets all rule types supported by this engine
     *
     * @return list of supported rule types
     */
    default List<RuleType> getSupportedRuleTypes() {
        return List.of();
    }
}
