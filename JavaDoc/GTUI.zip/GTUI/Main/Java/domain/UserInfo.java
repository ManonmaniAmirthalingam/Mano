package com.ebtedge.fns.gateway.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserInfo {

    private String userId;

    private String firstName;

    private String lastName;

    private String middleName;

    private String email;

    private Set<String> roles;

    private boolean isAdminUser;
	
	private String phoneNumber;

    public boolean hasRole(String role) {
        return roles.contains(role);
    }
}
