package com.ebtedge.ivr.service;

import java.util.List;

import com.ebtedge.ivr.bean.IvrAniBlockSearchCriteria;
import com.ebtedge.ivr.bean.IvrAniBlockSearchResultBean;

public interface IvrAniBlockInfoStoredProc {

	/*
	 * @param IvrAniBlockSearchCriteria
	 * @return List of IvrAniBlockSearchResultBean
	 */
	
	List<IvrAniBlockSearchResultBean> findIvrAniBlock (IvrAniBlockSearchCriteria criteria ) throws Exception;
} 
