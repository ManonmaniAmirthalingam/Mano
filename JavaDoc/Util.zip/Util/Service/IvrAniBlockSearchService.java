package com.ebtedge.ivr.service;

import java.sql.Array;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Struct;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.ebtedge.ivr.bean.IvrAniBlockSearchCriteria;
import com.ebtedge.ivr.bean.IvrAniBlockSearchResultBean;
import com.google.common.base.Supplier;

import oracle.jdbc.OracleTypes;

public class IvrAniBlockSearchService extends StoredProcExecutorService {

	private static final Logger log = LogManager.getLogger(IvrAniBlockSearchService.class);

	public IvrAniBlockSearchService(JdbcTemplate jdbcTemplate, String storedProcName) {
		super(jdbcTemplate, storedProcName);
	}

	@Override
	protected List doExecute(Supplier<?> searchCriteria) {
		try {
			return executeService(searchCriteria);

		} catch (Exception ex) {
			log.error("error in doExecute:{}", ex);
		}
		return null;
	}

	@Override
	protected void setInputParams(Supplier<?> searchCriteria, Connection connection,
			CallableStatement callablestatement) throws Exception {
		log.info("Setting input params to DW DB starts");

		try {
			IvrAniBlockSearchCriteria criteria = (IvrAniBlockSearchCriteria) searchCriteria.get();

			String stateCode = criteria.getStateCode().toUpperCase();

			// Table name setted to dummy for now for getting output from DB
			String resTypeObjName = "IVR_ANI_NONSTOP_RSP_TBL";

			SimpleDateFormat formatter = new SimpleDateFormat("dd-MMMM-yyyy");

			java.util.Date extractDate = null;

			
			 try 
			 { 
				 extractDate = formatter.parse(criteria.getExtractDate());
			  
			  
			  } catch (Exception ex) { System.out.
			  println("Please check the dates provided. They must be in the format must be mm/dd/yyyy"
			  ); }
			 

			callablestatement.setString(1, stateCode);
			callablestatement.setString(2, criteria.getExtractDate());
			callablestatement.setString(3, criteria.getBlockType());
			callablestatement.setString(4, criteria.getBlockReason());

			// out parameter to retrieve the output from the SP
			callablestatement.registerOutParameter(5, OracleTypes.ARRAY, resTypeObjName.toUpperCase());

			log.info("Setting input parameter completed for Ivr Ani Block Search");

		} catch (SQLException ex) {
			log.error("SQL exception while setting parameters into callable statement: {}" + ex);
		} catch (Exception ex) {
			log.error("Expection while setting parameters into callable statement: {}" + ex);
		}

	}

	@Override
	protected List getOutputParams(CallableStatement callablestatement, Supplier<?> searchCriteria) {

		log.info("Getting output params to MMS DB starts");
		try {
			List<IvrAniBlockSearchResultBean> list = parseOutData(callablestatement, searchCriteria);
			return list;
		} catch (Exception ex) {
			log.error("SQL exception while parsing result for Ivr Ani Block search : {}" + ex);
			return null;
		}

	}

	// The below code map the SP out with Tandem Bean list
	private List<IvrAniBlockSearchResultBean> parseOutData(CallableStatement callablestatement,
			Supplier<?> searchCriteria) throws Exception {

		log.debug("Enter");
		try {
			Array ivrAniBlockRawData = (Array) callablestatement.getArray(5);
			int ctr = 0;
			if (ivrAniBlockRawData == null)
				return Collections.emptyList();
			Object ivrAniBlockList[] = (Object[]) ivrAniBlockRawData.getArray();

			List<IvrAniBlockSearchResultBean> ivrAniSearchResultBeanList = Stream.of(ivrAniBlockList).map(ivrInfo -> {
				Struct structIvrInfo = (Struct) ivrInfo;
				IvrAniBlockSearchResultBean ivrSearchResultBean = null;
				try {
					Object[] attributes = structIvrInfo.getAttributes();
					ivrSearchResultBean = mapIvrSearchResultInfo(attributes);
				} catch (Exception ex) {
					log.error("Unable to get Ivr Ani Block search result from Oracle STRUCT {}", ex);
				}
				return ivrSearchResultBean;
			}).collect(Collectors.toList());
			log.info("Ivr Bean result formed from MMS DB results is {}", ivrAniSearchResultBeanList.toString());
			return ivrAniSearchResultBeanList;
		} catch (Exception ex) {
			log.error("Error fetching Ivr Search result from stored proc output: {}", ex);
			throw new Exception("No details found");
		}

	}

	private IvrAniBlockSearchResultBean mapIvrSearchResultInfo(Object[] attributes) {
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMMM-yyyy");
		IvrAniBlockSearchResultBean ivrAniBlockSearchResultBean = new IvrAniBlockSearchResultBean();

		// adding dummy attributes array for now need to check with dw data once SP is
		// ready
		// case number is neglected since shiny said she will take care at tandem end
		String aniNum = (String) Optional.ofNullable(attributes[2]).orElseGet(this::getDefaultVal).toString();
		String panNum = (String) Optional.ofNullable(attributes[10]).orElseGet(this::getDefaultVal).toString();
		String blockType = (String) Optional.ofNullable(attributes[4]).orElseGet(this::getDefaultVal);
		String blockReason = (String) Optional.ofNullable(attributes[9]).orElseGet(this::getDefaultVal);
		// need to fetch either from CM or from BlockReason field
		String procCode = (String) Optional.ofNullable(attributes[9]).orElseGet(this::getDefaultVal);
		// need to work on CST conversion
		String blockStartTime = (String) Optional.ofNullable(attributes[6]).orElseGet(this::getDefaultVal).toString();
		String blockEndTime = (String) Optional.ofNullable(attributes[7]).orElseGet(this::getDefaultVal).toString();
		String noOfCalls = (String) Optional.ofNullable(attributes[8]).orElseGet(this::getDefaultVal).toString();

		ivrAniBlockSearchResultBean.setAniNum(aniNum).setPanNum(panNum).setBlockType(blockType)
				.setBlockReason(blockReason)
				// need to update proc code
				.setProcCode(procCode).setBlockStartTime(blockStartTime).setBlockEndTime(blockEndTime)
				.setNoOfCalls(noOfCalls);

		return ivrAniBlockSearchResultBean;
	}

	private String getDefaultVal() {
		return "";
	}

}
