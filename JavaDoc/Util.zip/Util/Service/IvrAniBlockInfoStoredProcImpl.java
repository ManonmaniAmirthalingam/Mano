package com.ebtedge.ivr.service;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.ebtedge.ivr.bean.IvrAniBlockSearchCriteria;
import com.ebtedge.ivr.bean.IvrAniBlockSearchResultBean;



@Component
public class IvrAniBlockInfoStoredProcImpl implements IvrAniBlockInfoStoredProc
{

	private static final Logger Log = LogManager.getLogger(IvrAniBlockInfoStoredProcImpl.class);
	
	private JdbcTemplate jdbcTemplate;
	
	
	public IvrAniBlockInfoStoredProcImpl(JdbcTemplate jdbcTemplate)
	{
		super();
		this.jdbcTemplate=jdbcTemplate;
	}
	
	
	@Override
	public List<IvrAniBlockSearchResultBean> findIvrAniBlock(IvrAniBlockSearchCriteria criteria) throws Exception {
		
		Log.debug("Start");
		try {
			
			//dummy need to give SP name
			//String storedProcName ="{CALL PKG_IVR_ANI_EXTRACT.IvrAniExtractNonStopUtilityMgr(?,?,?,?)}";
			String storedProcName ="{CALL PKG_IVR_ANI_EXTRACT.IvrAniExtractNonStopUtilityMgr(IVR_ANI_NONSTOP_RQST(?,?,?,?),?)}";
			
			StoredProcExecutorService ivrAniBlockSearch = new IvrAniBlockSearchService(jdbcTemplate, storedProcName);
			List<IvrAniBlockSearchResultBean> list =(List<IvrAniBlockSearchResultBean>) ivrAniBlockSearch.doExecute(()->criteria);
			Log.debug("exit");
			return list;
			}
		catch (Exception ex) {
			ex.printStackTrace();
			Log.error(ex.getMessage());
			throw ex;
			}
			
			}
		
	}


