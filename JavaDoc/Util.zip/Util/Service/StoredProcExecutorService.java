package com.ebtedge.ivr.service;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.google.common.base.Supplier;

abstract class StoredProcExecutorService {

	private static Logger log= LogManager.getLogger(StoredProcExecutorService.class);
	protected JdbcTemplate jdbcTemplate;
	protected String storedProcName;
	
	public StoredProcExecutorService(JdbcTemplate jdbcTemplate,String storedProcName)
	{
		this.jdbcTemplate=jdbcTemplate;
		this.storedProcName=storedProcName;
	}
	
	protected List executeService(Supplier<?> searchCriteria) throws Exception
	{
		log.info("Stored Proc execution starts");
		Connection connection=null;
		CallableStatement callableStatement =null;
		try
		{
			connection =jdbcTemplate.getDataSource().getConnection();
			callableStatement=connection.prepareCall(storedProcName);
			setInputParams(searchCriteria,connection,callableStatement);
			boolean result =callableStatement.execute();
			return getOutputParams(callableStatement, searchCriteria);
		
		}
		
		catch(Exception ex)
		{
			log.error((new StringBuilder(String.valueOf(storedProcName))).append("Execution failed:").toString());
			throw new Exception((new StringBuilder(String.valueOf(storedProcName))).append("Execution failed").append(ex.getMessage()).toString());
		}
		finally {
			
			if(connection!=null)
			{
				try {
					connection.close();
					}
				catch(SQLException ex)
				{
					log.error("error while closing connection object: {}", ex);
				}
			}
			
			if(callableStatement!=null)
			{
				try {
					callableStatement.close();	
				}
				catch (Exception ex) {
					log.error("error while closing callableStatement {}", ex);
				}
			}
		}
	}

		
		protected abstract List doExecute(Supplier<?> searchCriteria);
		
		protected abstract void setInputParams(Supplier<?> searchCriteria, Connection connection,
				CallableStatement callablestatement) throws Exception;
		
		protected abstract List getOutputParams(CallableStatement callablestatement,Supplier<?> searchCriteria);
		
	}
	

