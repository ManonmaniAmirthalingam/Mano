package com.ebtedge.ivr.bean;

public class IvrAniBlockSearchCriteria {

	private String stateCode;
	private String extractDate;
	private String blockType;
	private String blockReason;
	private String agency;
		
	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	public String getExtractDate() {
		return extractDate;
	}

	public void setExtractDate(String extractDate) {
		this.extractDate = extractDate;
	}

	public String getBlockType() {
		return blockType;
	}

	public void setBlockType(String blockType) {
		this.blockType = blockType;
	}

	public String getBlockReason() {
		return blockReason;
	}

	public void setBlockReason(String blockReason) {
		this.blockReason = blockReason;
	}

	
	public String getAgency() {
		return agency;
	}

	public void setAgency(String agency) {
		this.agency = agency;
	}

	@Override
	public String toString() {
		return "IvrAniBlockSearchCriteria [stateCode=" + stateCode + ", extractDate=" + extractDate + ", blockType="
				+ blockType + ", blockReason=" + blockReason + ", agency=" + agency + "]";
	}
	

	//default constructors
	public IvrAniBlockSearchCriteria()
	{
		super();
	}
	
	
	//parameterized Constructors
	public IvrAniBlockSearchCriteria(String stateCode, String extractDate, String blockType, String blockReason) {
		super();
		this.stateCode = stateCode;
		this.extractDate = extractDate;
		this.blockType = blockType;
		this.blockReason = blockReason;
	}
	
	
}
