package com.ebtedge.ivr.bean;

public class IvrAniBlockSearchResultBean {

	private String aniNum;
	private String panNum;
	private String blockType;
	private String blockReason;
	private String procCode;
	private String blockStartTime;	
	private String blockEndTime;
	private String noOfCalls;
	
	public String getAniNum() {
		return aniNum;
	}
	public IvrAniBlockSearchResultBean setAniNum(String aniNum) {
		this.aniNum = aniNum;
		return this;
	}
	public String getPanNum() {
		return panNum;
	}
	public IvrAniBlockSearchResultBean setPanNum(String panNum) {
		this.panNum = panNum;
		return this;
	}
	public String getBlockType() {
		return blockType;
	}
	public IvrAniBlockSearchResultBean setBlockType(String blockType) {
		this.blockType = blockType;
		return this;
	}
	public String getBlockReason() {
		return blockReason;
	}
	public IvrAniBlockSearchResultBean setBlockReason(String blockReason) {
		this.blockReason = blockReason;
		return this;
	}
	public String getProcCode() {
		return procCode;
	}
	public IvrAniBlockSearchResultBean setProcCode(String procCode) {
		this.procCode = procCode;
		return this;
	}
	public String getBlockStartTime() {
		return blockStartTime;
	}
	public IvrAniBlockSearchResultBean setBlockStartTime(String blockStartTime) {
		this.blockStartTime = blockStartTime;
		return this;	
	}
	public String getBlockEndTime() {
		return blockEndTime;
	}
	public IvrAniBlockSearchResultBean setBlockEndTime(String blockEndTime) {
		this.blockEndTime = blockEndTime;
		return this;
	}
	public String getNoOfCalls() {
		return noOfCalls;
	}
	public IvrAniBlockSearchResultBean setNoOfCalls(String noOfCalls) {
		this.noOfCalls = noOfCalls;
		return this;
	}
	
	@Override
	public String toString() {
		return "IvrAniBlockSearchResultBean [aniNum=" + aniNum + ", panNum=" + panNum + ", blockType=" + blockType
				+ ", blockReason=" + blockReason + ", procCode=" + procCode + ", blockStartTime=" + blockStartTime
				+ ", blockEndTime=" + blockEndTime + ", noOfCalls=" + noOfCalls + "]";
	}
	
	
	
}
