package com.ebtedge.ivr.worker;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class IvrMailer {
	
	private static final Logger log = LogManager.getLogger(IvrMailer.class);
	private SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
	private String strSendMailNotification = null;
	private String strSendTo = null;
	private String strMailServer = null;
	private String[] strArray = new String[20];
	private String startTime = null; 
	private String fromAddress = null;
	private String hostName = "";
	private String smtpPort= "";
	
	
	public IvrMailer(SimpleDateFormat formatter, String strSendMailNotification, String strSendTo, String strMailServer,
			String[] strArray, String startTime, String fromAddress, String hostName, String smtpPort) {
		super();
		this.formatter = formatter;
		this.strSendMailNotification = strSendMailNotification;
		this.strSendTo = strSendTo;
		this.strMailServer = strMailServer;
		this.strArray = strArray;
		this.startTime = startTime;
		this.fromAddress = fromAddress;
		this.hostName = hostName;
		
	}
	
	/*Mail properties from property file*/
	public IvrMailer(Properties properties)
	{
		strMailServer =(String)properties.getProperty("mailServer");
		fromAddress = (String)properties.get("fromAddress");
		String sendTo = (String)properties.get("sendTo");
		strArray =	sendTo.split(",");
		smtpPort = (String) properties.get("mailPort");
	}

	

	public String getStrSendMailNotification() {
		return strSendMailNotification;
	}

	public void setStrSendMailNotification(String strSendMailNotification) {
		this.strSendMailNotification = strSendMailNotification;
	}

	public String getStrSendTo() {
		return strSendTo;
	}

	public void setStrSendTo(String strSendTo) {
		this.strSendTo = strSendTo;
	}

	public String getStrMailServer() {
		return strMailServer;
	}

	public void setStrMailServer(String strMailServer) {
		this.strMailServer = strMailServer;
	}

	public String[] getStrArray() {
		return strArray;
	}

	public void setStrArray(String[] strArray) {
		this.strArray = strArray;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getFromAddress() {
		return fromAddress;
	}

	public void setFromAddress(String fromAddress) {
		this.fromAddress = fromAddress;
	}

	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public void sendStartNotification(String states,String subject) {
		InetAddress inetAddress = null;
		try {
			inetAddress = InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			log.error("Unable to fetch Local Host Address {}", e.toString());
		}
		String hostName = null!=inetAddress?inetAddress.getHostName():"";
		startTime = new Timestamp(System.currentTimeMillis()).toString().substring(0, 19);
		StringBuffer msgBuffer = new StringBuffer("Hello,\n\n"); 
	
		msgBuffer.append("This is the Startup notification of Gov DW IVR ANI Block Update Utility \n\n") 
				 .append("\nStart Time : ")
				 .append(startTime)
				 .append("\nExecuted from server : ")
				 .append(hostName)
				 .append("\nStates :")
				 .append(states)
				 .append("\n\nPlease do not reply to this email notification");
		try {

			postMail(strArray, subject, msgBuffer.toString(), fromAddress);
			log.info("Start up email sent successfully ");

		} catch (MessagingException me) {
			log.error("Unable to send Start up email {}", me.toString());

		} catch (Exception e) {
			log.error("Unable to send Start up email {}", e.toString());
		}

	}
	
	public void sendEndNotification(String strSummary, String subject, String states, Map<String, List<String>> successMaplist) {
		StringBuffer msgBuffer = new StringBuffer();
		InetAddress inetAddress = null;
		try {
			inetAddress = InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			log.error("Unable to fetch Local Host Address {}", e.toString());
		}
		String hostName = null!=inetAddress?inetAddress.getHostName():"";
		msgBuffer = new StringBuffer();
		msgBuffer.append("Hello,\n\n")
				 .append("This is the Completion notification of Gov DW IVR ANI Block Update.\n\n")
				 .append("\nStart Time : ")
				 .append(startTime)
				 .append("\nEnd Time   : ")
				 .append((new Timestamp(System.currentTimeMillis())).toString().substring(0, 19))
				 .append("\nExecuted from server : ")
				 .append(hostName)
				 .append("\nStates :")
				 .append(states)
				 .append("\nSuccesFully Update Merchants :")
				 .append(getSuccessListFormatted(successMaplist))
				 .append("\n").append(strSummary)
				 .append("\nPlease do not reply to this email notification");
		try {
			postMail(strArray, subject, msgBuffer.toString(), fromAddress);
			log.info("End Notification email sent successfully ");
		} catch (Exception me) {
			log.error("Unable to send End Notification email- exception- {}", me.toString());
		}
	}
		
	public void postMail( String recipients[ ], String subject, String message , String from) throws MessagingException{
		boolean debug = false;

		 //Set the host smtp address
		 Properties props = new Properties();
		 props.put("mail.smtp.host", strMailServer);
		 props.put("mail.smtp.port", smtpPort);

		// create some properties and get the default Session
		Session session = Session.getDefaultInstance(props);
		session.setDebug(debug);

		// create a message
		Message msg = new MimeMessage(session);

		// set the from and to address
		InternetAddress addressFrom = new InternetAddress(from);
		msg.setFrom(addressFrom);

		//InternetAddress[] addressTo = new InternetAddress[recipients.length]; 
		Address[] addresses = new Address[recipients.length];
		msg.addRecipient(Message.RecipientType.TO, new InternetAddress(recipients[0]));
		for (int i = 0; i < recipients.length; i++)
		{
			addresses[i] = new InternetAddress(recipients[i]);
		}
		msg.setRecipients(Message.RecipientType.TO, addresses);
		//msg.addRecipient(Message.RecipientType.TO, new InternetAddress("statesupport@fisdev.local"));
   
		// Setting the Subject and Content Type
		msg.setSubject(subject);
		msg.setContent(message, "text/plain");
		Transport.send(msg);
	}

	public void sendFailureNotification(String strSummary, String subject, String state) {
		StringBuffer msgBuffer = new StringBuffer();
		msgBuffer.append("Hello,\n\n")
				 .append("The following ANI Numbers failed to get updated to Tandem with the following reasons from DW IVR.\n\n")
				 .append("\nState : ")
				 .append(state)
				 .append("\n").append(strSummary)
				 .append("\n").append("\nPlease check the logs for more details")
				 .append("\n\n").append("\nActionItems: The above failed retailer ids have to be updated manually ")
				 .append("\n\nPlease do not reply to this email notification");
		try {
			postMail(strArray, subject, msgBuffer.toString(), fromAddress);
			log.info("Failed IVR Ani Notification email sent successfully for state - {}", state);
		} catch (Exception me) {
			log.error("Unable to send failed Merchants Notification email- exception- {}", me.toString());
		}
	}
	
	
	
	public void sendDataBaseFailureNotification(String strSummary, String subject, String state) {
		StringBuffer msgBuffer = new StringBuffer();
		msgBuffer.append("Hello,\n\n")
				 .append("The Gov DW IVR Ani Update Utility run failed with issue connecting to DW DataBase.\n\n")
				 .append("\nState : ")
				 .append(state)
				 .append("\nException Detail : ")
				 .append(strSummary)
				 .append("\nPlease do not reply to this email notification");
		try {
			postMail(strArray, subject, msgBuffer.toString(), fromAddress);
			log.info("DataBase connectivity error Notification email sent successfully for state - {}", state);
		} catch (Exception me) {
			log.error("Unable to send DataBase connectivity error Notification email- exception- {}", me.toString());
		}
	}

	private String getSuccessListFormatted(Map<String, List<String>> successMaplist) {
		StringBuffer msgBuffer = new StringBuffer();
		for (String key : successMaplist.keySet()) {
			msgBuffer.append("\n"+ key + " = " + successMaplist.get(key).toString());
		}
		return msgBuffer.toString();
		
	}
	
	
	
}
