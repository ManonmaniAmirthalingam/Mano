package com.ebtedge.ivr.worker;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.ebtedge.ivr.bean.IvrAniBlockSearchCriteria;
import com.ebtedge.ivr.bean.IvrAniBlockSearchResultBean;
import com.ebtedge.ivr.config.DwDbConfig;
import com.ebtedge.ivr.service.IvrAniBlockInfoStoredProcImpl;
import com.efunds.gov.admin.domain.Dict;
import com.efunds.gov.common.Context;
import com.efunds.gov.common.Registry;
import com.efunds.gov.common.RegistryLocal;
import com.efunds.gov.server.tandem.HostException;
import com.efunds.gov.server.tandem.ServerInterface;
import com.efunds.gov.server.tandem.ServerInterfaceException;
import com.efunds.gov.server.tandem.ServerTags;
import com.zaxxer.hikari.HikariDataSource;

public class IvrAniBlock {
	private static final Logger Log = LogManager.getLogger(IvrAniBlock.class);
	private IvrAniBlockSearchCriteria criteria;
	private String statistics ="";
	ServerInterface server = new ServerInterface();
	
	public IvrAniBlock (IvrAniBlockSearchCriteria criteria, String statistics)
	{
		this.criteria=criteria;
		this.statistics= statistics;
	}

	public IvrAniBlock()
	{
		super();
	}
	
	public List<String> processForCriteria(IvrAniBlockSearchCriteria criteria,Properties properties)
		{
		this.criteria= criteria;
		List<String> successUpdate = new ArrayList<String>();
		Map<String,String> failureDetails = new HashedMap<String,String>();
		
		//Results
		List<IvrAniBlockSearchResultBean> list =getDwIvrAniBlocks(properties);
		List<String> aniBlocksFromDB = new ArrayList<String>();
		
		for(IvrAniBlockSearchResultBean ivrsearch : list)
		{
			aniBlocksFromDB.add(ivrsearch.getAniNum());
		}
		
		Log.info("Number of Ani Block records returned from DW for {} is {}",
				criteria.getStateCode(),list.size());
		
		if(null==list||list.size()==0) 
		{
			Log.info("No Ani block records returned from DW for {}",
					criteria.getStateCode());		
		return successUpdate;
		}
		
		//To lead gov properites used inside govCommanJar
		setupTandemServerConnection();
		
		int szList = list.size();
		for(int i=0;i<szList; i++)
		{
			try {
				updateIvrAniBlock(list.get(i),criteria);
				successUpdate.add(list.get(i).getAniNum());
				}
			catch (Exception ex) {
				String failureReason = "";
				if(ex instanceof HostException)
				{
					HostException he = (HostException)ex;
					if(he.getMessage().contains("ATX051"))
					{
						Log.error("Card not found for the Ani number - {}",
								list.get(i).getAniNum());
						failureReason="Card not found";
					}
					//}else if(he.getMessage().contains("0"))
					//{
						//need to handle this else part after confirmation
					//}
					else {
						Log.error("Exception while updating the server{} ", he.toString());
						failureReason = he.getMessage();
					}
					}
				
				else if (ex instanceof ServerInterfaceException)
				{
					ServerInterfaceException se =(ServerInterfaceException)ex;
					Log.error("Server Interface Exception for the Ani number -{}",list.get(i).getAniNum());
					failureReason=se.getMessage();
				} else {
				
					Log.error("Exception while updating the server {}", ex.toString());
					failureReason = "Error while updating to the Server. Check logs for more details.";
				}
				failureDetails.put(list.get(i).getAniNum(), failureReason);
			}

		}
		
		if(!failureDetails.isEmpty()) {
			sendFailedIvrAniBlockDetails( properties,  failureDetails, criteria.getStateCode());
		}
		 return successUpdate;
		}
						
		
	private List<IvrAniBlockSearchResultBean> getDwIvrAniBlocks(Properties properties) {
		Log.info("Invoking DW DB to fetch Ivr Ani Block details");
		
		//invoke the stored Procedure
		DwDbConfig dwConfig = new DwDbConfig();
		try {
			HikariDataSource ds = dwConfig.getHikariDataSource();
			JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
			IvrAniBlockInfoStoredProcImpl sp = new IvrAniBlockInfoStoredProcImpl(jdbcTemplate);
			return sp.findIvrAniBlock(criteria);
			}
		catch (IOException e) {
			Log.error("Exception while establishing Ivr Ani Block Extract table connection to DW DB {}", e.toString());
			sendDataBaseFailure(properties, e.getMessage(),criteria.getStateCode());
			System.exit(0);
		} catch (Exception e) {
			Log.error("Exception while establishing Ivr Ani Block Extract table connection to DW DB {}", e.toString());
			sendDataBaseFailure(properties, e.getMessage(),criteria.getStateCode());
			System.exit(0);
		}
			
		return null;
	}
	
	private boolean setupTandemServerConnection()
	{
		Registry registry = new Registry();
		registry.registerComponent(ServerInterface.DEFAULT_KEY, server);
		RegistryLocal.setRegistry(registry);
        try {
            java.io.InputStream stream = Thread.currentThread()
					.getContextClassLoader().getResourceAsStream("GovProperties.properties");
            Properties properties = new Properties();
            properties.load(stream);
            registry.registerComponent("GovProperties", properties);
        } catch (Exception ex) {
        	Log.error("Exception while loading Gov Properties {}", ex.toString());
        }
		
		return true;
	}
	
	private void updateIvrAniBlock(IvrAniBlockSearchResultBean ivrAniResultBean,
			IvrAniBlockSearchCriteria criteria) {
		
		Log.info("Input format for server call starts");
		Context context = new Context();
		context.put(Dict.STATE, criteria.getStateCode());
		context.put(Dict.AGENCY, criteria.getAgency());
		context.put(Dict.DISTRICT_CODE, "");
		context.put(Dict.USER_ID, "");
		
		context.put(Dict.ANI, ivrAniResultBean.getAniNum());
		context.put(Dict.PAN, ivrAniResultBean.getPanNum());
		context.put(Dict.Block_type, ivrAniResultBean.getBlockType());
		context.put(Dict.Block_reason, ivrAniResultBean.getBlockReason());
		context.put(Dict.Proc_code, ivrAniResultBean.getBlockReason());
		context.put(Dict.Block_start_ts, ivrAniResultBean.getBlockStartTime());
		context.put(Dict.Block_end_ts, ivrAniResultBean.getBlockEndTime());
		context.put(Dict.No_of_calls, ivrAniResultBean.getNoOfCalls());
		
		Log.info("About to Invoke Server for IVR ANI Block update for PAN - {}", ivrAniResultBean.getPanNum());
		server.send(ServerTags.IVR_PH_NO_BLOCKING_REQUEST, context);
		String responseCode= (String) context.get("responseCode");
	    Log.info("Update Successful for IVR ANI record with PAN - {} with responseCode {}" , ivrAniResultBean.getPanNum(),responseCode);

	}
	
	

	private void sendFailedIvrAniBlockDetails(Properties properties, Map<String, String> failedDetails, String state) {
		try {
			IvrMailer mailer  = new IvrMailer(properties);
			 String subject = "Failed to update IVR ANI details Notification from Gov DW IVR Ani Update Utility";
			 StringBuilder sb = new StringBuilder();
		        Iterator<Entry<String, String>> iter = failedDetails.entrySet().iterator();
		        while (iter.hasNext()) {
		            Entry<String, String> entry = iter.next();
		            sb.append(entry.getKey());
		            sb.append('=').append('"');
		            sb.append(entry.getValue().trim());
		            sb.append('"');
		            sb.append("\n");
		        }
			 mailer.sendFailureNotification(sb.toString(),subject, state);
			 Log.info("Successfully sent out failed to update IVR Ani details for state {}", state);
		} catch (Exception e) {
			Log.error("Error sending out failed to update merchant details for state {} with exception {}", state, e.toString());
		}
		 
	}
	
	
	private void sendDataBaseFailure(Properties properties, String failureDetail, String state) {
		try {
			IvrMailer mailer  = new IvrMailer(properties);
			 String subject = "Gov DW IVR Ani Update Utility run failed due to error connecting to DW DataBase";
			 mailer.sendDataBaseFailureNotification(failureDetail,subject, state);
			 Log.info("Successfully sent out DataBase connectivity error Notification for state {}", state);
		} catch (Exception e) {
			Log.error("Error sending out DataBase connectivity error Notification for state {} with exception {}", state, e.toString());
		}
		 
	}
	

	
	
	
}
