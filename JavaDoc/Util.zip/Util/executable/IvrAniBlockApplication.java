package com.ebtedge.ivr.executable;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ebtedge.ivr.bean.IvrAniBlockSearchCriteria;
import com.ebtedge.ivr.worker.IvrAniBlock;
import com.ebtedge.ivr.worker.IvrMailer;

public class IvrAniBlockApplication {

	private static final Logger Log = LogManager.getLogger(IvrAniBlockApplication.class); 
	public static void main(String[] args) {
		
		/*check given input is valid*/
		Log.info("Gov IVR ANI Block update utility process starting ");
		loadSystemPropertiesFile();
		
		IvrAniBlockSearchCriteria criteria = validateInput(args);
		if(null==criteria)
		{
			Log.error("Please check the input arguments provided and try again. The utility expects the state code");
			System.exit(0);
		}
		
		Log.info("Input Validation successful");
		
		/*Form the criteria object*/ 
		//check about block type,reason,date fields to take care
		String statesToRun ="";
		InputStream stream = null;
		IvrMailer mailer = null;
		String subject = "";
		Properties properties = new Properties();
		try {
			stream= Thread.currentThread()
					.getContextClassLoader().getResourceAsStream("gov.ivr.aniblock.properties");
			
			properties.load(stream);
			mailer = new IvrMailer(properties);
		}
		catch (Exception e) {
			 e.printStackTrace();
		        System.exit(0);
		}
	        statesToRun=properties.getProperty("states.to.extract");
	        Log.info("States to Run from properties - {}",statesToRun);
	        if(statesToRun.isEmpty())
	        {
	        	Log.error("Exiting as States to empty from property file");
	        	System.exit(0);
	        }
	        
	        //Mail Notification trigger
	        String sendMail = properties.getProperty("sendMailNotification");
	        if(sendMail.equalsIgnoreCase("yes")) {
	        	subject = "Startup Notification of Gov DW IVR Ani Update Utility";
				mailer.sendStartNotification(statesToRun, subject);
			}
	        
	        StringTokenizer st= new StringTokenizer(statesToRun,",");      
	        Log.info("Utility to extract information for states {}",statesToRun);
	        Map<String, List<String>> successMaplist = new HashMap<>();
	        IvrAniBlock ivrAniBlock = new IvrAniBlock();
	        while(st.hasMoreTokens())
	        {
	        	List<String> successUpdate = new ArrayList<String>(); 
	        	String stateCode =st.nextToken();
	        	criteria.setStateCode(stateCode);
	        	criteria.setAgency(properties.getProperty("agency."+stateCode));
	        	criteria.setExtractDate(properties.getProperty("date.to.extract"));
	        	criteria.setBlockType(properties.getProperty("blockType.to.extract"));
	        	criteria.setBlockReason(properties.getProperty("blockReason.to.extract"));
	        	Log.info("Processing criteria - {} for State {}" , criteria.toString());
				successUpdate = ivrAniBlock.processForCriteria(criteria, properties);
				successMaplist.put(statesToRun, successUpdate);
				Log.info("Successfully update IVR Ani Block for State {} are {}",statesToRun,successUpdate);
				}
	        
								
	if(sendMail.equalsIgnoreCase("yes")) {
    	subject = "Ending Notification of Gov DW IVR Ani Block Update Utility";
		mailer.sendEndNotification("",subject, statesToRun,successMaplist);
	}
	
	Log.info("GovDW Ivr Ani Block Update Utility Processing is Completed");

	}		
	
	//StateCode args is mandatory,other params are optional
	private static IvrAniBlockSearchCriteria validateInput(String[] args) {
		
		String stateCode="";
		String extractDate="";
		
		IvrAniBlockSearchCriteria criteria =null;
		
		if(args.length>0 && args.length>=1) {
			stateCode=args[0];
			extractDate= args[1];
			
		}
		else {
			Log.error("Exitng as Input Arguments are not provided");
			System.exit(0);
		}
		
		//check format of the date, the format should be "30-MAY-2023"
		SimpleDateFormat formatter =new SimpleDateFormat("dd-MMMM-yyyy");
		try {
			formatter.parse(extractDate);
			criteria = new IvrAniBlockSearchCriteria(stateCode, extractDate, "", "");
		}
		catch (Exception e) {
			Log.error("Please check the date provided. The Extract date should be in the format dd-MMMM-yyyy");
		}
		return criteria;
	}
	private static void loadSystemPropertiesFile() {
		Properties properties =new Properties();
		
		try {
			InputStream inputStream = Thread
					.currentThread()
					.getContextClassLoader()
					.getResourceAsStream("System.properties");
			properties.load(inputStream);
			Enumeration names = properties.propertyNames();
			while(names.hasMoreElements())
			{
				String key=((String) names.nextElement()).trim();
				String value=properties.getProperty(key).trim();
				System.setProperty(key, value);
			}
			Log.info("Successfully loaded System Properties");
		}
		catch (Exception e) {
			Log.warn("Unable to load System.properties with exception {}", e.toString());
		}
		
		
	}

}
