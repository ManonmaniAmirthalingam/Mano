package com.ebtedge.ivr.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import com.efunds.gov.security.DecryptPasswordTripleDES;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

 
@Configuration
@ComponentScan(basePackages = "com.efunds.gsdw")
public class DwDbConfig {

	 private static final Logger log = LogManager.getLogger(DwDbConfig.class);

	    private static final String DW_CP_CONFIG_FILE = "jdbc.dw.properties";

	    @Bean
	    public HikariDataSource getHikariDataSource() throws IOException, Exception {
	        log.info("hikari datasource creation...");
	        try {
	            InputStream ins = Thread.currentThread().getContextClassLoader().getResourceAsStream(DW_CP_CONFIG_FILE);
	            Properties properties = new Properties();
	            properties.load(ins);
	            String masterKey = "0123456789ABCEDF123456780123456789ABCEDF12345678";
	            String url = properties.getProperty("dw.jdbc.url");
	            String userName = properties.getProperty("dw.jdbc.username");
	            String password = properties.getProperty("dw.jdbc.password");
	            String encryptKey = properties.getProperty("dw.jdbc.encryptKey");
	            
	            String driverClassName = properties.getProperty("dw.jdbc.driverClassName", "oracle.jdbc.OracleDriver");
	            String maxPoolSize = properties.getProperty("dw.jdbc.maximumPoolSize", "5");
	            String minIdle = properties.getProperty("dw.jdbc.minimum-idle", "5");
	            String conTimeout = properties.getProperty("dw.jdbc.connection-timeout", "30000");
	            String idleTimeout = properties.getProperty("dw.jdbc.idle-timeout", "120000");
	            String maxLifeTime = properties.getProperty("dw.jdbc.max-lifetime", "1000");
	            String autoCommit = properties.getProperty("dw.jdbc.auto-commit", "true");
	            String leaakDectionThreshold = properties.getProperty("dw.jdbc.leak-detection-threshold", "12000");
	            
	            
	           url = getEncryptedValue(masterKey, encryptKey, url);
	           password = getEncryptedValue(masterKey, encryptKey, password);
	            log.info("Hikari DW config info from " + DW_CP_CONFIG_FILE + ": {} {} {} {} {} {} {} {} {} {} ", url, userName, driverClassName, maxPoolSize, minIdle, conTimeout, idleTimeout,
	                    maxLifeTime, autoCommit, leaakDectionThreshold);

	            HikariConfig config = new HikariConfig();
	            config.setJdbcUrl(url);
	            config.setUsername(userName);
	            config.setPassword(password);
	            config.setDriverClassName(driverClassName);
	            config.setMaximumPoolSize(Integer.parseInt(maxPoolSize));
	            config.setMinimumIdle(Integer.parseInt(minIdle));
	            config.setConnectionTimeout(Long.parseLong(conTimeout));
	            config.setIdleTimeout(Long.parseLong(idleTimeout));
	            config.setMaxLifetime(Long.parseLong(maxLifeTime));
	            config.setAutoCommit(Boolean.valueOf(autoCommit));
	            config.setLeakDetectionThreshold(Long.valueOf(leaakDectionThreshold));
	            HikariDataSource dataSource = new HikariDataSource(config);
	            log.info("DW datasource created... {}", dataSource.toString());
	            return dataSource;
	        } catch (Exception e) {
	            log.error("Hikari data source creation failed: {}", e);
	            throw new Exception("Datasource creation failed: ");
	        }
	    }
	  

	    @Bean
	    public JdbcTemplate jdbcTemplate(DataSource dataSource) throws IOException {
	        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
	        jdbcTemplate.setResultsMapCaseInsensitive(true);
	        log.info("jdbcTemplate has been created");
	        return jdbcTemplate;
	    }


	    /**
	     * @param masterKey
	     * @param encryptKey
	     * @param encryptString
	     * @return
	     * @throws Exception
	     */
	    private static String getEncryptedValue(
	            String masterKey,
	            String encryptKey,
	            String encryptString)
	            throws Exception { 
				String clearKey = DecryptPasswordTripleDES.decrypt(masterKey, encryptKey);
				return DecryptPasswordTripleDES.decrypt(clearKey, encryptString);
	    }

}
